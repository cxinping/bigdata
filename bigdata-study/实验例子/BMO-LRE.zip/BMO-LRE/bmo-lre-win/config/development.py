# -*- coding: utf-8 -*-
"""
Created on 2021-04-06

@author: WangShuo
"""

DEBUG = True

SFTP_REPORT_HOST = '10.119.61.119'
SFTP_REPORT_PORT = 22
SFTP_REPORT_USER = 'bmo-lre'
SFTP_REPORT_PRIVATE_KEY_PATH = '/opt/bmo-lre/config/id_rsa_bmo-lre'
SFTP_REPORT_PUT_DIRS = ['/opt/bmo-lre/report']
SFTP_REPORT_GET_DIR = '/opt/bmo-lre/report'