# -*- coding: utf-8 -*-
'''
Created on 2021-04-06

@author: WangShuo
'''

from bmolre import init_app

app = init_app(config_object='config.development')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
