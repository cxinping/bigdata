# -*- coding: utf-8 -*-
"""
Created on 2021-04-06

@author: Wang Shuo
"""

from ..commons.logging import get_logger, log_entry_exit
import paramiko
import os

log = get_logger(__name__)


@log_entry_exit
def sftp_connect(host, port, username, private_key_path):
    """
    :param host:              SFTP的服务器IP
    :param port:　            SFTP 服务器的端口,默认端口 22
    :param username:　        SFTP的服务器账号
    :param private_key_path:　SFTP使用的私钥
    """
    transport = paramiko.Transport((host, port))
    pk = paramiko.RSAKey.from_private_key(open(private_key_path))
    transport.connect(username=username, pkey=pk)
    sftp = paramiko.SFTPClient.from_transport(transport)
    return transport, sftp


def sftp_listdir(host, port, username, private_key_path, path):
    transport = None
    sftp = None
    try:
        transport, sftp = sftp_connect(host, port, username, private_key_path)
        dirs = sftp.listdir(path)
        return dirs
    except Exception as err:
        raise RuntimeError(err)
    finally:
        if sftp:
            sftp.close()
        if transport:
            transport.close()


def sftp_put_file(host, port, username, private_key_path, local_file, remote_dirs):
    """
    上传本地文件到SFTP服务器
    :param host:              SFTP的服务器IP
    :param port:　            SFTP 服务器的端口,默认端口 22
    :param username:　        SFTP的服务器账号
    :param private_key_path:　SFTP使用的私钥
    :param local_file:　      要上传的本地文件
    :param remote_dirs:　     上传到SFTP的目录
    :return:
    """
    transport = None
    sftp = None
    try:
        transport, sftp = sftp_connect(host, port, username, private_key_path)

        for remote_dir in remote_dirs:
            file_name = os.path.basename(local_file)
            remote_file = remote_dir + '/' + file_name
            log.debug("* SFTP put localfile=" + local_file + ' to SFTP remote_file=' + remote_file)
            sftp.put(local_file, remote_file)
    except Exception as err:
        raise RuntimeError(err)
    finally:
        if sftp:
            sftp.close()
        if transport:
            transport.close()


def sftp_get_file(host, port, username, private_key_path, remote_file, local_file):
    """
    下载SFTP服务器上的文件到本地
    :param host:              SFTP的服务器IP
    :param port:　            SFTP 服务器的端口,默认端口 22
    :param username:　        SFTP的服务器账号
    :param private_key_path:　SFTP使用的私钥
    :param remote_file:　     SFTP上的文件
    :param local_file:　      下载到本地的文件
    :return:
    """
    try:
        transport, sftp = sftp_connect(host, port, username, private_key_path)

        sftp.get(remote_file, local_file)

        if sftp:
            sftp.close()
        if transport:
            transport.close()
    except Exception as err:
        print(err)
        raise RuntimeError(str(err))


def sftp_remove_file(host, port, username, private_key_path, remote_file):
    """
    删除SFTP服务器上的文件
    :param host:              SFTP的服务器IP
    :param port:　            SFTP 服务器的端口,默认端口 22
    :param username:　        SFTP的服务器账号
    :param private_key_path:　SFTP使用的私钥
    :param remote_file:　     SFTP上的文件
    :param local_file:　      下载到本地的文件
    :return:
    """
    try:
        transport, sftp = sftp_connect(host, port, username, private_key_path)

        sftp.remove(remote_file)

        if sftp:
            sftp.close()
        if transport:
            transport.close()
    except Exception as err:
        print(err)
        raise RuntimeError(str(err))
