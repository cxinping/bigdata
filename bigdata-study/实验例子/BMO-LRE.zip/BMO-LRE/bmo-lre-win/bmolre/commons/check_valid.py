# -*- coding: utf-8 -*-

"""
Created on 2021-04-06

@author: Wang Shuo
"""


import os.path

from .logging import get_logger

log = get_logger(__name__)


def is_valid_excel(file_name):
    """ 判断是否是一个有效的excel文件 """

    try:
        suffix_ls = ['xlsx', 'xls']
        file_suffix = os.path.splitext(file_name)[1][1:]
        if file_suffix in suffix_ls:
            return True
        return False
    except Exception as err:
        log.warning(err, exc_info=True)
        return False
