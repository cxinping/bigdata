# -*- coding: utf-8 -*-

"""
Created on 2021-04-06

@author: Wang Shuo
"""

from bmolre.commons.logging import get_logger
from bmolre.exceptions import ReportException
from win32com.client import Dispatch
import pythoncom

log = get_logger(__name__)


def open_save_excel(file_name):
    try:
        log.debug("**********************")
        log.debug("*** begin open_save_excel()  ***")
        pythoncom.CoInitialize()
        xlApp = Dispatch("Excel.Application")
        xlApp.Visible = False
        xlBook = xlApp.Workbooks.Open(file_name)
        xlBook.Save()
        xlBook.Close()
        xlBook = None
        xlApp = None
        log.debug("*** end open_save_excel()  ***")
    except Exception as err:
        log.error(err)
        raise ReportException(str(err))




