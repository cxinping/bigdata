# -*- coding: utf-8 -*-

"""
Created on 2021-04-06

@author: Wang Shuo
"""

from flask import Blueprint, jsonify
from http import HTTPStatus
from flask import current_app as app
import time, os
from ..commons.logging import get_logger
from ..services.report_services import open_save_excel
from ..commons.check_valid import is_valid_excel
from ..commons.report_utils import sftp_put_file, sftp_get_file, sftp_remove_file
from ..commons.constant import CFG_SFTP_REPORT_HOST, CFG_SFTP_REPORT_PORT, CFG_SFTP_REPORT_USER, \
    CFG_SFTP_REPORT_PRIVATE_KEY_PATH, \
    CFG_SFTP_REPORT_PUT_DIRS, CFG_SFTP_REPORT_GET_DIR

report_bp = Blueprint('report', __name__)
log = get_logger(__name__)


@report_bp.route('/daily/open/save/<file_name>', methods=['GET'])
def open_save_report(file_name):
    """
    打开和保存一个excel文件

    """

    log.debug("*******************************")
    log.debug("open and save daily report service")
    http_status = HTTPStatus.OK
    result = {'report_type': 'daily'}

    try:
        log.debug('* file_name=%s', file_name)
        report_get_dir = None
        if CFG_SFTP_REPORT_GET_DIR in app.config:
            report_get_dir = app.config[CFG_SFTP_REPORT_GET_DIR]

        local_file = report_get_dir + '/' + file_name
        log.debug('* local_file=%s', local_file)

        if is_valid_excel(local_file):
            start_time = time.time()
            # 1, down load excel from SFTP Server
            sftp_get_report_file(local_file)
            # 2, open and save excel
            open_save_excel(local_file)
            # 3, put excel to SFTP Server
            sftp_put_daily_report(local_file)

            end_time = time.time()
            result['execution_time'] = round(end_time - start_time)
            result['message'] = 'get, save, put excel successful.'
        else:
            http_status = HTTPStatus.BAD_REQUEST
            result['message'] = 'input excel file is invalid.'

    except Exception as err:
        log.error(err, exc_info=True)
        http_status = HTTPStatus.INTERNAL_SERVER_ERROR
        result['message'] = str(err)

    result['status'] = http_status
    response = jsonify(result)
    log.info('response=%s', response)
    log.info('http_status=%s', http_status)
    return response, http_status


def sftp_get_report_file(local_file):
    host = None
    port = None
    username = None
    private_key_path = None
    report_get_dir = None

    if CFG_SFTP_REPORT_HOST in app.config:
        host = app.config[CFG_SFTP_REPORT_HOST]
    if CFG_SFTP_REPORT_PORT in app.config:
        port = app.config[CFG_SFTP_REPORT_PORT]
    if CFG_SFTP_REPORT_USER in app.config:
        username = app.config[CFG_SFTP_REPORT_USER]
    if CFG_SFTP_REPORT_PRIVATE_KEY_PATH in app.config:
        private_key_path = app.config[CFG_SFTP_REPORT_PRIVATE_KEY_PATH]
    if CFG_SFTP_REPORT_GET_DIR in app.config:
        report_get_dir = app.config[CFG_SFTP_REPORT_GET_DIR]

    log.debug("**********************")
    log.debug("*** step, sftp get report file from SFTP server")

    try:
        file_name = os.path.basename(local_file)
        remote_file = report_get_dir + '/' + file_name
        log.debug('* sftp_get_report_file() local_file={}'.format(local_file))
        log.debug('* sftp_get_report_file() remote_file={}'.format(remote_file))

        sftp_get_file(host=host, port=port, username=username,
                      private_key_path=private_key_path,
                      local_file=local_file, remote_file=remote_file)
    except Exception as err:
        log.error(err, exc_info=True)
        raise RuntimeError(str(err))


def sftp_put_daily_report(local_file):
    host = None
    port = None
    username = None
    private_key_path = None
    remote_dirs = None

    try:
        if CFG_SFTP_REPORT_HOST in app.config:
            host = app.config[CFG_SFTP_REPORT_HOST]
        if CFG_SFTP_REPORT_PORT in app.config:
            port = app.config[CFG_SFTP_REPORT_PORT]
        if CFG_SFTP_REPORT_USER in app.config:
            username = app.config[CFG_SFTP_REPORT_USER]
        if CFG_SFTP_REPORT_PRIVATE_KEY_PATH in app.config:
            private_key_path = app.config[CFG_SFTP_REPORT_PRIVATE_KEY_PATH]
        if CFG_SFTP_REPORT_PUT_DIRS in app.config:
            remote_dirs = app.config[CFG_SFTP_REPORT_PUT_DIRS]

        log.debug("**********************")
        log.debug("*** step3, sftp put report file to SFTP dirs")
        log.debug('local_file=')
        log.debug(local_file)
        log.debug(type(local_file))
        log.debug('remote_dirs=')
        log.debug(remote_dirs)
        log.debug(type(remote_dirs))

        sftp_put_file(host=host, port=port, username=username,
                      private_key_path=private_key_path,
                      local_file=local_file, remote_dirs=remote_dirs)
    except Exception as err:
        log.error(err, exc_info=True)
        raise RuntimeError(str(err))


def sftp_remove_daily_report(file_name):
    host = None
    port = None
    username = None
    private_key_path = None
    remote_dirs = None

    try:
        if CFG_SFTP_REPORT_HOST in app.config:
            host = app.config[CFG_SFTP_REPORT_HOST]
        if CFG_SFTP_REPORT_PORT in app.config:
            port = app.config[CFG_SFTP_REPORT_PORT]
        if CFG_SFTP_REPORT_USER in app.config:
            username = app.config[CFG_SFTP_REPORT_USER]
        if CFG_SFTP_REPORT_PRIVATE_KEY_PATH in app.config:
            private_key_path = app.config[CFG_SFTP_REPORT_PRIVATE_KEY_PATH]
        if CFG_SFTP_REPORT_PUT_DIRS in app.config:
            remote_dirs = app.config[CFG_SFTP_REPORT_PUT_DIRS]

        remote_file = remote_dirs[0] + '/' + file_name
        log.debug("**********************")
        log.debug("*** step3, remove file from SFTP Server")

        sftp_remove_file(host=host, port=port, username=username,
                         private_key_path=private_key_path,
                         remote_file=remote_file)
    except Exception as err:
        log.error(err, exc_info=True)
        raise RuntimeError(str(err))
