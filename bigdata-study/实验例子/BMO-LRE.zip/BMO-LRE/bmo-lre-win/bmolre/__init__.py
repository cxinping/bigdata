# -*- coding: utf-8 -*-

'''
Created on 2021-04-06

@author: WangShuo
'''

import os
import logging as python_logging
from flask import Flask, jsonify
from http import HTTPStatus
from .views.report import report_bp
from bmolre.commons.constant import CFG_DEBUG
from ._version import __version__

WARN_MSG_MISSING_CONFIG = 'Config %s cannot be found.'


def create_app(config_object='config.default', config_map=None):
    # Create and configure the app
    app = Flask(__name__, instance_relative_config=True, instance_path='/opt/bmo-lre/config')

    # configure blue print
    app.register_blueprint(report_bp, url_prefix='/report')

    # Overwrite default config by input parameter
    app.config.from_object(config_object)

    if config_map is not None:
        # load the test config if passed in
        app.config.from_mapping(config_map)

    # Load the configuration from the instance folder which won't be committed to version control
    app.config.from_pyfile('config.py', silent=True)

    app.logger.debug('app.config=%s', app.config)
    
    # Put configurations into os environment
    if CFG_DEBUG in app.config:
        os.environ[CFG_DEBUG] = str(app.config[CFG_DEBUG])
    else:
        app.logger.warning(WARN_MSG_MISSING_CONFIG, CFG_DEBUG)

    # Create logger after app initiated to avoid recursive dependency
    app.logger.debug('os.environ=%s', os.environ)

    # a simple page that says hello
    @app.route('/hello')
    def hello():
        result = {'lre_service_status':'ok'}
        result['version'] = __version__

        #TODO: test email server connection
        
        return jsonify(result), HTTPStatus.OK

    return app

def init_app(config_object='config.default'):
    app = create_app(config_object)

    return app
