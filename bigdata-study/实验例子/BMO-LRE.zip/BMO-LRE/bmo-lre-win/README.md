## Prerequisites
* Python 3.6.8 which is officially provided by Redhat
* Flask 1.1.2
* pywin32
* paramiko 2.7.2

## Usage
### Open and save daily report
```
https://{server:port}//report/daily/open/save/{file_name}
```


## Repository
```
http://10.119.61.92:7990/projects/LRE/repos/bmo-lre-win/browse
```