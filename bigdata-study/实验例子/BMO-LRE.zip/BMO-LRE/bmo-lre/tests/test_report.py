# -*- coding: utf-8 -*-

"""
Created on 2021-01-11

@author: Wang Shuo
"""

import unittest
from bmolre import create_app
from bmolre.commons.report_enums import ReportType
from bmolre.commons.constant import CFG_MAIL_RECIPIENTS
from bmolre.services.report_services import BaseReport
from bmolre.exts import db
from unittest.mock import patch

from bmolre.services.report_services import LreDailyReportBuilder, LreDailyReport, G14ReportBuilder, G14Report
from bmolre.services.report_task_services import TaskExecutor
from bmolre.exceptions import ReportException, EmailException


class TestReport(unittest.TestCase):

    def setUp(self):
        app = create_app(config_object='config.default', config_map={'TESTING': True})
        db.init_app(app)
        self.client = app.test_client()
        self.app = app
        self.data_date = '20200331'
        self.report_type = ReportType.DAILY_REPORT

    def tearDown(self):
        pass

    def test_init_base_report(self):
        print('* run test_init_base_report()')

        with self.app.app_context():
            report = BaseReport(report_type=self.report_type, data_date=self.data_date)
            self.assertIsNotNone(report)

            report_type = report.get_report_type()
            self.assertIsNotNone(report_type)

            data_date = report.get_data_date()
            self.assertIsNotNone(data_date)

            report_service = report.get_report_service()
            self.assertIsNotNone(report_service)

            target_report = report.get_target_report()
            self.assertIsNotNone(target_report)

    def test_create_daily_report(self):
        with patch.object(TaskExecutor, 'send_email', return_value=None):
            rv = self.client.get('/report/daily/123?email=True')
            self.assertIn(b'Data date is invalid.', rv.data)
            self.assertIn(b'"status":400', rv.data)
            self.assertIn(b'Alert email is sent.', rv.data)

        rv = self.client.get('/report/daily/20210101')
        self.assertIn(b'The input date is a holiday. No daily report is generated.', rv.data)
        self.assertIn(b'"status":200', rv.data)
        self.assertNotIn(b'Alert email is sent.', rv.data)

        with patch.object(LreDailyReportBuilder, 'create_report',
                          side_effect=ReportException('dummy report exception')), patch.object(TaskExecutor,
                                                                                               'send_email',
                                                                                               return_value=None), self.assertLogs(
                'bmolre', level='ERROR') as cm:
            rv = self.client.get('/report/daily/20200630?email=True')
            self.assertIn(b'dummy report exception', rv.data)
            self.assertIn(b'"status":500', rv.data)
            self.assertIn('ERROR:bmolre.views.report:dummy report exception', str(cm.output))
            self.assertIn('ReportException', str(cm.output))
            self.assertIn('Traceback', str(cm.output))
            self.assertIn(b'Alert email is sent.', rv.data)

        # with patch.object(LreDailyReportBuilder, 'create_report',
        #                   return_value=LreDailyReport('20200630')), patch.object(TaskExecutor, 'send_email',
        #                                                                          side_effect=EmailException(
        #                                                                                  'dummy email exception')), self.assertLogs(
        #         'bmolre', level='ERROR') as cm:
        #     rv = self.client.get('/report/daily/20200630?email=True')
        #     self.assertIn(b'dummy email exception', rv.data)
        #     self.assertIn(b'"status":500', rv.data)
        #     self.assertIn('ERROR:bmolre.views.report:dummy email exception', str(cm.output))
        #     self.assertIn('EmailException', str(cm.output))
        #     self.assertIn('Traceback', str(cm.output))

        with patch.object(LreDailyReportBuilder, 'create_report',
                          return_value=LreDailyReport('20200630')), patch.object(TaskExecutor, 'send_email',
                                                                                 return_value=None):
            rv = self.client.get('/report/daily/20200630')
            self.assertIn(b'LRE daily report is created successfully.', rv.data)
            self.assertNotIn(b'Email is sent.', rv.data)
            self.assertIn(b'"status":200', rv.data)
            self.assertNotIn(b'Alert email is sent.', rv.data)

        with patch.object(LreDailyReportBuilder, 'create_report',
                          return_value=LreDailyReport('20200630')), patch.object(TaskExecutor, 'send_email',
                                                                                 return_value=None), patch.dict(
                self.app.config):
            del self.app.config[CFG_MAIL_RECIPIENTS]
            rv = self.client.get('/report/daily/20200630')
            self.assertIn(b'LRE daily report is created successfully.', rv.data)
            self.assertNotIn(b'Email is sent.', rv.data)
            self.assertIn(b'"status":200', rv.data)
            self.assertNotIn(b'Alert email is sent.', rv.data)

        with patch.object(LreDailyReportBuilder, 'create_report',
                          return_value=LreDailyReport('20200630')), patch.object(TaskExecutor, 'send_email',
                                                                                 return_value=None):
            rv = self.client.get('/report/daily/20200630?email=False')
            self.assertIn(b'LRE daily report is created successfully.', rv.data)
            self.assertNotIn(b'Email is sent.', rv.data)
            self.assertIn(b'"status":200', rv.data)
            self.assertNotIn(b'Alert email is sent.', rv.data)

        # with patch.object(LreDailyReportBuilder, 'create_report',
        #                   return_value=LreDailyReport('20200630')), patch.object(TaskExecutor, 'send_email',
        #                                                                          return_value=None):
        #     rv = self.client.get('/report/daily/20200630?email=True')
        #     self.assertIn(b'LRE daily report is created successfully.', rv.data)
        #     self.assertIn(b'Email is sent.', rv.data)
        #     self.assertIn(b'"status":200', rv.data)
        #     self.assertNotIn(b'Alert email is sent.', rv.data)

    def test_create_g14_report(self):
        with patch.object(TaskExecutor, 'send_email', return_value=None):
            rv = self.client.get('/report/g14/123?email=True')
            self.assertIn(b'Data date is invalid.', rv.data)
            self.assertIn(b'"status":400', rv.data)
            self.assertIn(b'Alert email is sent.', rv.data)

        # rv = self.client.get('/report/g14/20210101')
        # self.assertIn(b'The input date is a holiday. No G14 report is generated.', rv.data)
        # self.assertIn(b'"status":200', rv.data)
        # self.assertNotIn(b'Alert email is sent.', rv.data)
        #
        # with patch.object(G14ReportBuilder, 'create_report',
        #                   side_effect=ReportException('dummy report exception')), patch.object(TaskExecutor,
        #                                                                                        'send_email',
        #                                                                                        return_value=None), self.assertLogs(
        #         'bmolre', level='ERROR') as cm:
        #     rv = self.client.get('/report/g14/20210112?email=True')
        #     self.assertIn(b'dummy report exception Alert email is sent', rv.data)
        #     self.assertIn(b'"status":500', rv.data)
        #     self.assertIn('ERROR:bmolre.views.report:dummy report exception', str(cm.output))
        #     self.assertIn('ReportException', str(cm.output))
        #     self.assertIn('Traceback', str(cm.output))
        #     self.assertIn(b'Alert email is sent.', rv.data)
        #
        # with patch.object(G14ReportBuilder, 'create_report', return_value=G14Report('20200630')):
        #     rv = self.client.get('/report/g14/20210112')
        #     self.assertIn(b'"status":500', rv.data)
        #     self.assertNotIn('No such file or directory', str(cm.output))


if __name__ == "__main__":
    unittest.main(verbosity=2)
