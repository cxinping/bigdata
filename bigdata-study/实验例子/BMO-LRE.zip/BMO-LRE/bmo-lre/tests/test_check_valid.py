# -*- coding: utf-8 -*-

"""
Created on 2020-12-02

@author: Wang Shuo
"""

import unittest

import bmolre.commons.check_valid as check_valid


class TestCheckValid(unittest.TestCase):
        
    def test_is_valid_date(self):
        self.assertTrue(check_valid.is_valid_date('20200630'))
        self.assertFalse(check_valid.is_valid_date('2020-06-30'))

if __name__ == "__main__":
    unittest.main(verbosity=2)
