# -*- coding: utf-8 -*-

"""
Created on 2020-12-28

@author: Wang Shuo
"""

import unittest
from bmolre import create_app
from bmolre.models.data_models import (
    query_safe_mid_rate_data, change_foreign_currency_to_cny, query_rate_currency, query_loan_data,
    query_daily_auto_fin_data, query_g14_auto_fin_data, query_customer_list_report,
    query_indirect_customer_from_trade_finance_transaction, query_fefc_data,
    query_daily_ead_report_data, query_g14_ead_report_data, query_g14_capital_data, query_daily_capital_data,
    query_g14_llp_data, query_daily_llp_data, query_g14_bond_ncd_data, query_daily_bond_ncd_data,
    query_daily_ead_report_data2, query_g14_ead_report_data2, query_holidays,
    query_credit_exposure_data, query_daily_money_market_data,query_interbank_financing_business_data, query_interbank_lending_data
)
from bmolre.exts import db


class TestDataModel(unittest.TestCase):

    def setUp(self):
        app = create_app(config_object='config.default', config_map={'TESTING': True})
        db.init_app(app)
        self.app = app
        self.data_date = '20201231'

    def tearDown(self):
        pass

    def test_query_safe_mid_rate_data(self):
        print('* run test_query_safe_mid_rate_data()')
        with self.app.app_context():
            safe_mid_rate_data = query_safe_mid_rate_data(data_date=self.data_date, basic_ccy='USD', forward_ccy='CNY')
            if safe_mid_rate_data:
                self.assertIsNotNone(safe_mid_rate_data)

    def test_change_foreign_currency_to_cny(self):
        print('* run test_change_foreign_currency_to_cny()')
        with self.app.app_context():
            currency_to_cny_data = change_foreign_currency_to_cny(date_date=self.data_date, foreign_ccy='USD', amount=1)
            if currency_to_cny_data:
                self.assertIsNotNone(currency_to_cny_data)

    def test_query_rate_currency(self):
        print('* run test_query_rate_currency()')
        with self.app.app_context():
            rate_currency_data = query_rate_currency(self.data_date)
            if rate_currency_data:
                self.assertIsNotNone(rate_currency_data)

    def test_query_loan_data(self):
        print('* run test_query_loan_data()')
        with self.app.app_context():
            loan_data = query_loan_data(self.data_date)
            if loan_data:
                self.assertIsNotNone(loan_data)

    def test_query_daily_auto_fin_data(self):
        print('* run test_query_auto_fin_data()')
        with self.app.app_context():
            auto_fin_data = query_daily_auto_fin_data(self.data_date)
            if auto_fin_data:
                self.assertIsNotNone(auto_fin_data)

    def test_query_g14_auto_fin_data(self):
        print('* run test_query_g14_auto_fin_data()')
        with self.app.app_context():
            auto_fin_data = query_g14_auto_fin_data(self.data_date)
            if auto_fin_data:
                self.assertIsNotNone(auto_fin_data)

    def test_query_customer_list_report(self):
        print('* run test_query_customer_list_report()')
        with self.app.app_context():
            customer_list_data = query_customer_list_report(self.data_date)
            self.assertIsNotNone(customer_list_data)

    def test_query_indirect_customer_from_trade_finance_transaction(self):
        print('* run test_query_indirect_customer_from_trade_finance_transaction()')
        with self.app.app_context():
            customer_list_data = query_indirect_customer_from_trade_finance_transaction(self.data_date)
            self.assertIsNotNone(customer_list_data)

    def test_query_fefc_data(self):
        print('* run test_query_fefc_data()')
        with self.app.app_context():
            fefc_list_data = query_fefc_data(self.data_date)
            self.assertIsNotNone(fefc_list_data)

    def test_query_daily_capital_data(self):
        print('* run test_query_daily_capital_data()')
        with self.app.app_context():
            daily_capital_data = query_daily_capital_data(self.data_date)
            self.assertIsNotNone(daily_capital_data)

    def test_query_daily_ead_report_data(self):
        print('* run test_query_daily_ead_report_data()')
        with self.app.app_context():
            daily_ead_report_data = query_daily_ead_report_data(self.data_date)
            self.assertIsNotNone(daily_ead_report_data)

    def test_query_daily_ead_report_data2(self):
        print('* run test_query_daily_ead_report_data2()')
        with self.app.app_context():
            daily_ead_report_data2 = query_daily_ead_report_data2(self.data_date)
            self.assertIsNotNone(daily_ead_report_data2)

    def test_query_g14_ead_report_data(self):
        print('* run test_query_g14_ead_report_data()')
        with self.app.app_context():
            g14_ead_report_data = query_g14_ead_report_data(self.data_date)
            self.assertIsNotNone(g14_ead_report_data)

    def test_query_g14_ead_report_data2(self):
        print('* run test_query_g14_ead_report_data2()')
        with self.app.app_context():
            g14_ead_report_data2 = query_g14_ead_report_data2(self.data_date)
            self.assertIsNotNone(g14_ead_report_data2)

    def test_query_capital_data(self):
        print('* run test_query_capital_data()')
        with self.app.app_context():
            g14_capital_data = query_g14_capital_data(self.data_date)
            self.assertIsNotNone(g14_capital_data)

            daily_capital_data = query_daily_capital_data(self.data_date)
            self.assertIsNotNone(daily_capital_data)

    def test_query_interbank_financing_business_data(self):
        print('* run test_query_interbank_financing_business_data()')
        with self.app.app_context():
            g14_capital_data = query_interbank_financing_business_data(self.data_date)
            self.assertIsNotNone(g14_capital_data)

    def test_query_interbank_lending_data(self):
        print('* run test_query_interbank_lending_data()')
        with self.app.app_context():
            g14_capital_data = query_interbank_lending_data(self.data_date)
            self.assertIsNotNone(g14_capital_data)

    def test_query_llp_data(self):
        print('* run test_query_llp_data()')
        with self.app.app_context():
            daily_llp_data = query_daily_llp_data(self.data_date)
            self.assertIsNotNone(daily_llp_data)

            g14_capital_data = query_g14_llp_data(self.data_date)
            self.assertIsNotNone(g14_capital_data)

    def test_query_bond_ncd_data(self):
        print('* run test_query_bond_ncd_data()')
        with self.app.app_context():
            g14_bond_ncd_data = query_g14_bond_ncd_data(self.data_date)
            self.assertIsNotNone(g14_bond_ncd_data)

            daily_bond_ncd_data = query_daily_bond_ncd_data(self.data_date)
            self.assertIsNotNone(daily_bond_ncd_data)

    def test_query_holidays(self):
        print('* run test_query_holidays()')
        with self.app.app_context():
            count_num = query_holidays('20201001')['count_num']
            self.assertEqual(count_num, 1)

    def test_query_credit_exposure_data(self):
        print('* run test_query_credit_exposure_data()')
        with self.app.app_context():
            credit_exposure = query_credit_exposure_data(self.data_date)
            self.assertIsNotNone(credit_exposure)

    def test_query_daily_money_market_data(self):
        print('* run test_query_daily_money_market_data()')
        with self.app.app_context():
            money_market_data = query_daily_money_market_data(self.data_date)
            self.assertIsNotNone(money_market_data)

if __name__ == "__main__":
    unittest.main(verbosity=2)
