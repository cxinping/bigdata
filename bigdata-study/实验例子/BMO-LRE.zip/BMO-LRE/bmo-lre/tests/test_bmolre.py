# -*- coding: utf-8 -*-

"""
Created on 2020-11-27

@author: Wang Shuo
"""

import unittest
from bmolre import create_app
from bmolre.commons.constant import CFG_REPORT_DB_URL, CFG_SQLALCHEMY_BINDS
from bmolre.services.report_task_services import TaskExecutor
import os
from bmolre.exts import db
from unittest.mock import patch

class TestBmoLre(unittest.TestCase):
    def setUp(self):
        app = create_app(config_object='config.default', config_map={'TESTING': True})
        db.init_app(app)
        self.client = app.test_client()
        self.app = app

    def tearDown(self):
        pass

    def test_hello(self):
        with patch.object(TaskExecutor, 'sftp_listdir', return_value=[]):
            rv = self.client.get('/hello')
            self.assertIn(b'"lre_service_status":200', rv.data)

    def test_encryption(self):
        rv = self.client.get('/encryption/BMOpass')
        assert b'JYz0KAA7KZC2SMlK+Hccsg==' in rv.data

    def test_app_is_Production(self):
        self.assertTrue(self.app.config['DEBUG'] is False)

    def test_db(self):
        print('* run test_db()')

        with self.app.app_context():
            report_db_url = os.environ[CFG_REPORT_DB_URL]
            self.assertIsNotNone(report_db_url)

            rra_db_url = self.app.config[CFG_SQLALCHEMY_BINDS]['rra']
            self.assertIsNotNone(rra_db_url)


if __name__ == "__main__":
    unittest.main(verbosity=2)
