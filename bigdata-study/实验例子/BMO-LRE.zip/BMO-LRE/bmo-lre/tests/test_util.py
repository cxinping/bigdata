# -*- coding: utf-8 -*-

"""
Created on 2020-12-02

@author: Wang Shuo
"""

from decimal import Decimal
import os
import unittest
from unittest.mock import patch

from bmolre import create_app
import bmolre.commons.constant as constant
import bmolre.commons.util as util
from bmolre.exts import db


class TestUtil(unittest.TestCase):

    def setUp(self):
        app = create_app(config_object='config.default', config_map={'TESTING': True})
        db.init_app(app)
        self.app = app

    def tearDown(self):
        pass

    def test_get_current_time(self):
        curr_time = util.get_current_time()
        self.assertIsNotNone(curr_time)

    def test_convert_digital_precision(self):
        self.assertEqual(util.convert_digital_precision('1.115'), Decimal('1.12'))
        self.assertEqual(util.convert_digital_precision('1.114'), Decimal('1.11'))
        self.assertEqual(util.convert_digital_precision('1.125'), Decimal('1.13'))
        self.assertEqual(util.convert_digital_precision('1.545'), Decimal('1.55'))
        self.assertEqual(util.convert_digital_precision('1.555'), Decimal('1.56'))
        self.assertEqual(util.convert_digital_precision('1.1'), Decimal('1.10'))
        self.assertEqual(util.convert_digital_precision(None), Decimal('0.00'))

    def test_is_blank(self):
        self.assertTrue(util.is_blank(None))
        self.assertTrue(util.is_blank(''))
        self.assertTrue(util.is_blank(' '))
        self.assertFalse(util.is_blank('I am not blank'))

    def test_encrypt(self):
        with patch.dict(os.environ, {}, clear=True):
            ciphertext = util.encrypt('BMOpass')
            self.assertEqual(ciphertext, 'Qk1PcGFzcw==')

        with patch.dict(os.environ, {constant.CFG_AES_KEY: "BMO's golden key"}, clear=True):
            ciphertext = util.encrypt('BMOpass')
            self.assertEqual(ciphertext, 'JYz0KAA7KZC2SMlK+Hccsg==')

    def test_decrypt(self):
        with patch.dict(os.environ, {}, clear=True):
            ciphertext = util.decrypt('Qk1PcGFzcw==')
            self.assertEqual(ciphertext, 'BMOpass')

        with patch.dict(os.environ, {constant.CFG_AES_KEY: "BMO's golden key"}, clear=True):
            ciphertext = util.decrypt('JYz0KAA7KZC2SMlK+Hccsg==')
            self.assertEqual(ciphertext, 'BMOpass')

    def test_decrypt_db_uri(self):
        with patch.dict(os.environ, {constant.CFG_AES_KEY: "BMO's golden key"}, clear=True):
            encrypted_uri = 'postgresql://bmo_lre:Q8YdiHZzkToHrqADcZgoYg==@10.119.61.146:5432/bmo_lre'
            decrypted_uri = util.decrypt_db_uri(encrypted_uri)
            self.assertEqual(decrypted_uri, 'postgresql://bmo_lre:Dev_2020@10.119.61.146:5432/bmo_lre')

            encrypted_uri = 'oracle://LREQUERY:6ET+0yoaJIt9bJor05AlPw==@10.119.61.174:1521/RRAD1'
            decrypted_uri = util.decrypt_db_uri(encrypted_uri)
            self.assertEqual(decrypted_uri, 'oracle://LREQUERY:Dti_202011@10.119.61.174:1521/RRAD1')

            encrypted_uri = 'oracle://LREQUERY:6ET+0yoaJIt9bJor05AlPw==@10.119.61.15:1521/RRAU1'
            decrypted_uri = util.decrypt_db_uri(encrypted_uri)
            print(decrypted_uri)
            self.assertEqual(decrypted_uri, 'oracle://LREQUERY:Dti_202011@10.119.61.15:1521/RRAU1')

    def test_db_fetch_to_dict(self):
        print('* run test_db_fetch_to_dict()')
        with self.app.app_context():
            query_sql = 'select * from v$version'
            query_result = util.db_fetch_to_dict(query_sql, params=None, fecth='all', bind='rra')
            self.assertIsNotNone(query_result)


if __name__ == "__main__":
    unittest.main(verbosity=2)


