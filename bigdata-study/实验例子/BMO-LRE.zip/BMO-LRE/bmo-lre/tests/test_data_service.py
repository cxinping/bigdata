# -*- coding: utf-8 -*-

"""
Created on 2020-12-01

@author: Wang Shuo
"""

import unittest
from unittest.mock import patch
from bmolre import create_app
from bmolre.services.data_services import DataService
from bmolre.commons.report_enums import RateSheetEnum, ReportType
from bmolre.exts import db
from decimal import Decimal
from bmolre.exceptions import DataException


class TestDataService(unittest.TestCase):
    def setUp(self):
        app = create_app(config_object='config.default', config_map={'TESTING': True})
        db.init_app(app)
        self.app = app
        self.data_service = DataService()
        self.data_date = '20200331'

    def tearDown(self):
        pass

    def test_query_rate_data(self):
        print('* run test_query_rate_data()')

        with self.app.app_context():
            ccy_rate_list = self.data_service.query_rate_data(self.data_date)

            for ccy_rate_item in ccy_rate_list:
                basic_ccy = ccy_rate_item[RateSheetEnum.BASIC_CCY.value]
                forward_ccy = ccy_rate_item[RateSheetEnum.FORWARD_CCY.value]
                ccy_rate = ccy_rate_item[RateSheetEnum.CCY_RATE.value]
                if basic_ccy == 'USD' and forward_ccy == 'CNY':
                    ccy_rate = Decimal(ccy_rate).quantize(Decimal('0.0000'))
                    target_ccy_rate = Decimal(7.0851).quantize(Decimal('0.0000'))
                    self.assertEqual(ccy_rate, target_ccy_rate)

            # Test the case when foreign_cny_ccy_rate is None
            with patch('bmolre.models.data_models.change_foreign_currency_to_cny',
                       return_value=None), self.assertRaises(DataException):
                self.data_service.query_rate_data(self.data_date)

            # Test the case when foreign_cny_ccy_rate raised an Exception
            with patch('bmolre.models.data_models.change_foreign_currency_to_cny',
                       side_effect=KeyError), self.assertRaises(DataException):
                self.data_service.query_rate_data(self.data_date)

    def test_query_usd_to_cny_rate(self):
        print('* run test_query_usd_to_cny_rate()')

        with self.app.app_context():
            usd_to_cny_rate = self.data_service.query_usd_to_cny_rate(self.data_date)
            self.assertIsNotNone(usd_to_cny_rate)

            # Test the case when usd_cny_rate_obj is None
            with patch('bmolre.models.data_models.query_safe_mid_rate_data', return_value=None), self.assertRaises(
                    DataException):
                self.data_service.query_usd_to_cny_rate(self.data_date)

    def test_query_loan_data(self):
        print('* run test_query_loan_data()')

        with self.app.app_context():
            loan_data = self.data_service.query_loan_data(self.data_date)
            self.assertIsNotNone(loan_data)

            # Test the case when loans is None
            with patch('bmolre.models.data_models.query_loan_data', return_value=None), self.assertRaises(
                    DataException):
                self.data_service.query_loan_data(self.data_date)

    def test_query_customer_list_report(self):
        print('* run test_query_customer_list_report()')

        with self.app.app_context():
            customer_data = self.data_service.query_customer_list_report(self.data_date)
            self.assertTrue(len(customer_data) >= 0)

            # Test the case when customer_data_list is None
            with patch('bmolre.models.data_models.query_customer_list_report', return_value=None), self.assertRaises(
                    DataException):
                self.data_service.query_customer_list_report(self.data_date)

    def test_query_indirect_customer_from_trade_finance_transaction(self):
        print('* run test_query_indirect_customer_from_trade_finance_transaction()')

        with self.app.app_context():
            customer_data = self.data_service.query_indirect_customer_from_trade_finance_transaction(self.data_date)
            self.assertTrue(len(customer_data) >= 0)

            # Test the case when customer_data_list is None
            with patch('bmolre.models.data_models.query_indirect_customer_from_trade_finance_transaction',
                       return_value=None), self.assertRaises(DataException):
                self.data_service.query_indirect_customer_from_trade_finance_transaction(self.data_date)

    def test_query_capital_data(self):
        print('* run test_query_capital_data()')

        with self.app.app_context():
            #self.data_date = '20201031'
            self.data_date = '2021231'
            capital_data = self.data_service.query_capital_data(self.data_date, ReportType.DAILY_REPORT)
            self.assertTrue(len(capital_data) >= 0)

            # Test the case when capital_data is None
            with patch('bmolre.models.data_models.query_daily_capital_data', return_value=None), self.assertRaises(
                    DataException):
                self.data_service.query_capital_data(self.data_date, ReportType.DAILY_REPORT)

    def test_query_ead_report_data(self):
        print('* run test_query_ead_report_data()')

        with self.app.app_context():
            ead_data = self.data_service.query_ead_report_data(self.data_date, ReportType.DAILY_REPORT)
            self.assertTrue(len(ead_data) >= 0)

    def test_query_ead_report_data2(self):
        print('* run test_query_ead_report_data2()')

        with self.app.app_context():
            ead_data = self.data_service.query_ead_report_data2(self.data_date, ReportType.DAILY_REPORT)
            self.assertTrue(len(ead_data) >= 0)

    def test_query_daily_money_market_data(self):
        print('* run test_query_daily_money_market_data()')

        with self.app.app_context():
            mm505_data = self.data_service.query_daily_money_market_data(self.data_date)
            self.assertTrue(len(mm505_data) >= 0)

            # Test the case when mm505_data_list is None
            with patch('bmolre.models.data_models.query_daily_money_market_data', return_value=None), self.assertRaises(
                    DataException):
                self.data_service.query_daily_money_market_data(self.data_date)

    def test_query_g14_money_market_data(self):
        print('* run test_query_g14_money_market_data()')

        with self.app.app_context():
            mm505_data = self.data_service.query_g14_money_market_data(self.data_date)
            self.assertTrue(len(mm505_data) >= 0)

            # Test the case when mm505_data_list is None
            with patch('bmolre.models.data_models.query_g14_money_market_data', return_value=None), self.assertRaises(
                    DataException):
                self.data_service.query_g14_money_market_data(self.data_date)

    def test_query_dsc_data(self):
        print('* run test_query_dsc_data()')

        with self.app.app_context():
            desc_data = self.data_service.query_dsc_data(self.data_date)
            self.assertTrue(len(desc_data) >= 0)

            # Test the case when dsc_data_list is None
            with patch('bmolre.models.data_models.query_dsc_data', return_value=None), self.assertRaises(DataException):
                self.data_service.query_dsc_data(self.data_date)

    def test_query_llp_data(self):
        print('* run test_query_llp_data()')

        with self.app.app_context():
            daily_llp_data = self.data_service.query_llp_data(self.data_date, ReportType.DAILY_REPORT)
            self.assertTrue(len(daily_llp_data) >= 0)

            g14_llp_data = self.data_service.query_llp_data(self.data_date, ReportType.G14_REPORT)
            self.assertTrue(len(g14_llp_data) >= 0)

            # Test the case when llp_data_list is None
            with patch('bmolre.models.data_models.query_daily_llp_data', return_value=None), self.assertRaises(
                    DataException):
                self.data_service.query_llp_data(self.data_date, ReportType.DAILY_REPORT)

    def test_query_nostro_data(self):
        print('* run test_query_nostro_data()')

        with self.app.app_context():
            nostro_data = self.data_service.query_nostro_data(self.data_date)
            self.assertTrue(len(nostro_data) >= 0)

            # Test the case when nostro_data_list is None
            with patch('bmolre.models.data_models.query_nostro_data', return_value=None), self.assertRaises(
                    DataException):
                self.data_service.query_nostro_data(self.data_date)

    def test_query_limit_data(self):
        print('* run test_query_limit_data()')

        with self.app.app_context():
            limit_data = self.data_service.query_limit_data(self.data_date)
            self.assertTrue(len(limit_data) >= 0)

            # Test the case when limit_data_list is None
            with patch('bmolre.models.data_models.query_limit_data', return_value=None), self.assertRaises(
                    DataException):
                self.data_service.query_limit_data(self.data_date)

    def test_query_auto_fin_data(self):
        print('* run test_query_auto_fin_data()')

        with self.app.app_context():
            with self.assertRaises(DataException):
                self.data_date = '20200101'
                auto_fin_data = self.data_service.query_auto_fin_data(self.data_date, ReportType.DAILY_REPORT)
                self.assertIsNotNone(auto_fin_data)

    def test_query_offbs_tf_data(self):
        print('* run test_query_offbs_tf_data()')

        with self.app.app_context():
            offbs_tf_data = self.data_service.query_offbs_tf_data(self.data_date)
            self.assertTrue(len(offbs_tf_data) >= 0)

            # Test the case when offbs_data_list is None
            with patch('bmolre.models.data_models.query_offbs_tf_data', return_value=None), self.assertRaises(
                    DataException):
                self.data_service.query_offbs_tf_data(self.data_date)

    def test_query_bond_ncd_data(self):
        print('* run test_query_bond_ncd_data()')

        with self.app.app_context():
            bond_ncd_data = self.data_service.query_bond_ncd_data(self.data_date, ReportType.DAILY_REPORT)
            self.assertTrue(len(bond_ncd_data) >= 0)

    def test_query_pboc_data(self):
        print('* run test_query_pboc_data()')

        with self.app.app_context():
            pboc_data = self.data_service.query_pboc_data(self.data_date)
            self.assertTrue(len(pboc_data) >= 0)

    def test_query_credit_exposure_data(self):
        print('* run test_query_credit_exposure_data()')

        with self.app.app_context():
            with self.assertRaises(DataException):
                credit_exposure_data = self.data_service.query_credit_exposure_data(self.data_date)
                self.assertIsNotNone(credit_exposure_data)

    def test_query_holidays(self):
        print('* run test_query_holidays()')

        with self.app.app_context():
            holidays_data = self.data_service.query_holidays(self.data_date)
            self.assertIsNotNone(holidays_data)

    def test_query_fefc_data(self):
        print('* run test_query_fefc_data()')

        with self.app.app_context():
            fefc_data = self.data_service.query_fefc_data(self.data_date)
            self.assertIsNotNone(fefc_data)


if __name__ == "__main__":
    unittest.main(verbosity=2)
