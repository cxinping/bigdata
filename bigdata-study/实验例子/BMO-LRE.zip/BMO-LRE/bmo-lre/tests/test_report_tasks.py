# -*- coding: utf-8 -*-

import unittest
from bmolre import create_app
from bmolre.commons.logging import get_logger
from bmolre.services.report_task_services import send_email
from flask import render_template
from bmolre.commons.constant import (CFG_MAIL_RECIPIENTS, CFG_MAIL_SENDER, CFG_SUPPORT_MAIL_RECIPIENTS,
    CFG_SUPPORT_MAIL_SENDER )

log = get_logger(__name__)


class TestReportTask(unittest.TestCase):
    def setUp(self):
        app = create_app(config_object='config.development', config_map={'DEBUG': True})
        self.app = app
        self.data_date = '20201010'

    def tearDown(self):
        pass

    def test_send_email(self):
        sender = None
        recipients = None
        if CFG_SUPPORT_MAIL_SENDER in self.app.config:
            sender = self.app.config[CFG_SUPPORT_MAIL_SENDER]
        if CFG_SUPPORT_MAIL_RECIPIENTS in self.app.config:
            recipients = self.app.config[CFG_SUPPORT_MAIL_RECIPIENTS]

        subject = '[test email] LRE EOC Failed {data_date}'.format(data_date=self.data_date)

        print(sender)
        print(recipients , type(recipients) )
        print(self.app)

        with self.app.app_context(), self.app.test_request_context():
            send_email(subject=subject, sender=sender,
                       recipients=recipients,
                       html_body=render_template('daily_report_email.html'),
                       app=self.app,
                       attachment_path=None)


if __name__ == "__main__":
    unittest.main(verbosity=2)
