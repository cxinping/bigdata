# -*- coding: utf-8 -*-

"""
Created on 2020-12-02

@author: Wang Shuo
"""

import unittest
import bmolre.commons.report_utils as report_utils

class TestReportUtil(unittest.TestCase):
    def setUp(self):
        self.data_date = '20201202'

    def tearDown(self):
        pass

    def test_create_random_number(self):
        uuid = report_utils.create_random_number(length=10)
        self.assertIsNotNone(uuid)

    def test_get_daily_report_date(self):
        str_date = '20200630'
        report_date = report_utils.get_daily_report_date(str_date)
        self.assertEqual(report_date, '2020/06/30')
    
    def test_gen_subject_title(self):
        str_date = '20200630'
        subject_title = report_utils.gen_subject_title(str_date)
        self.assertEqual(subject_title, 'LRE daily monitoring sheet as of Jun 30,2020 (Confidential and Internal use)')
        
    def test_filter_data_daily_single_cust(self):
        df = report_utils.filter_data_daily_single_cust('tests/test_report_utils.xlsx')
        cbs_id_list = df['CBS_ID'].tolist()
        self.assertIn('000813', cbs_id_list)
        self.assertIn('009000', cbs_id_list)
        self.assertIn('300728', cbs_id_list)
        self.assertIn('600131', cbs_id_list)
        
    def test_filter_data_g14_single_cust(self):
        df = report_utils.filter_data_g14_single_cust('tests/test_report_utils.xlsx')
        uen_list = df['UEN'].tolist()
        self.assertIn('239169', uen_list)
        self.assertIn('35104954', uen_list)
        self.assertIn('36157454', uen_list)
        self.assertIn('37012243', uen_list)
        
    def test_filter_data_group_corp(self):
        df = report_utils.filter_data_group_corp('tests/test_report_utils.xlsx')
        group_code_list = df['GROUP_CODE'].tolist()
        self.assertIn('900006', group_code_list)
        self.assertIn('900009', group_code_list)
        self.assertIn('900014D', group_code_list)
        self.assertNotIn('900013D', group_code_list)
       
    def test_filter_data_group_bank(self):
        df = report_utils.filter_data_group_bank('tests/test_report_utils.xlsx')
        uen_list = df['UEN'].tolist()
        self.assertIn('10000452D', uen_list)
        self.assertIn('10000453D', uen_list)
        self.assertIn('10000454D', uen_list)
        self.assertNotIn('10000451D', uen_list)
    
    def test_filter_data_g14_group_cust(self):
        df = report_utils.filter_data_g14_group_cust('tests/test_report_utils.xlsx')
        uen_list = df['GROUP_CODE'].tolist()
        self.assertIn('900006', uen_list)
        self.assertIn('900009', uen_list)
        self.assertIn('900014D', uen_list)
        self.assertNotIn('900008', uen_list)
    
    def test_filter_data_g14_single_interbank(self):
        df = report_utils.filter_data_g14_single_interbank('tests/test_report_utils.xlsx')
        uen_list = df['UEN'].tolist()
        self.assertIn('23008278', uen_list)
        self.assertIn('239169', uen_list)
        self.assertIn('258597', uen_list)
        self.assertIn('55239', uen_list)
        self.assertNotIn('36157454', uen_list)
        
    def test_filter_data_g14_group_interbank(self):
        df = report_utils.filter_data_g14_group_interbank('tests/test_report_utils.xlsx')
        uen_list = df['Connection UEN'].tolist()
        self.assertIn('10000452D', uen_list)
        self.assertIn('10000453D', uen_list)
        self.assertIn('10000454D', uen_list)
        self.assertNotIn('10000451D', uen_list)

    def test_get_last_business_day_season(self):
        self.assertEqual(report_utils.get_last_business_day_season('20210204'), '20201231')
        self.assertEqual(report_utils.get_last_business_day_season('20200405'), '20200331')
        self.assertEqual(report_utils.get_last_business_day_season('20200331'), '20191231')
        self.assertEqual(report_utils.get_last_business_day_season('20200929'), '20200630')
        self.assertEqual(report_utils.get_last_business_day_season('20201001'), '20200930')
        self.assertEqual(report_utils.get_last_business_day_season('20230103'), '20221230')
        self.assertEqual(report_utils.get_last_business_day_season('20240103'), '20231229')
    
    def test_is_runnable_date(self):
        self.assertTrue(report_utils.is_runnable_date('20210111'))
        self.assertTrue(report_utils.is_runnable_date('20210413'))
        self.assertTrue(report_utils.is_runnable_date('20210715'))
        self.assertTrue(report_utils.is_runnable_date('20211018'))
        self.assertFalse(report_utils.is_runnable_date('20210110'))
        self.assertFalse(report_utils.is_runnable_date('20210409'))
        self.assertFalse(report_utils.is_runnable_date('20210719'))
        self.assertFalse(report_utils.is_runnable_date('20211020'))
        self.assertFalse(report_utils.is_runnable_date('20210213'))
        self.assertFalse(report_utils.is_runnable_date('20210313'))
        self.assertFalse(report_utils.is_runnable_date('20210513'))
        self.assertFalse(report_utils.is_runnable_date('20210613'))
        self.assertFalse(report_utils.is_runnable_date('20210813'))
        self.assertFalse(report_utils.is_runnable_date('20210913'))
        self.assertFalse(report_utils.is_runnable_date('20211113'))
        self.assertFalse(report_utils.is_runnable_date('20211213'))

if __name__ == "__main__":
    unittest.main(verbosity=2)
