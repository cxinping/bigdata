# -*- coding: utf-8 -*-

"""
Created on 2020-11-27

@author: Wang Shuo
"""


from decimal import Decimal
import time
import glob
import os
import shutil
import unittest
from unittest.mock import patch

from openpyxl import load_workbook

from bmolre import create_app
from bmolre.commons.logging import get_logger
import bmolre.commons.constant as constant
from bmolre.commons.report_enums import ReportType, LreDailyReportSpreadSheets, G14ReportSpreadSheets
from bmolre.exceptions import ReportInvalidDataDateException, ReportException, \
    DataException
from bmolre.exts import db
from bmolre.services.report_cal_services import ReportService
from bmolre.services.report_services import BaseReport, LreDailyReport, G14Report

log = get_logger(__name__)

class TestReportService(unittest.TestCase):
    
    def cleanup(self):
        if os.path.exists(constant.CREATED_REPORT_PATH):
            
            for file_name in os.listdir(constant.CREATED_REPORT_PATH):
                file_path = os.path.join(constant.CREATED_REPORT_PATH, file_name)
                log.debug('Deleting "%s" ...', file_path)
                os.unlink(file_path)
                while os.path.exists(file_path):
                    # sometime the deletion is slow, we have to wait a while
                    time.sleep(1)
                log.debug('%s:exists=%s', file_path, os.path.exists(file_path))

            log.debug('Deleting "%s" ...', constant.CREATED_REPORT_PATH)
            shutil.rmtree(constant.CREATED_REPORT_PATH)
            log.debug('%s:exists=%s', constant.CREATED_REPORT_PATH, os.path.exists(constant.CREATED_REPORT_PATH))
    
    def setUp(self):
        app = create_app(config_object='config.default', config_map={'DEBUG': True})
        db.init_app(app)
        self.app = app
        self.report_service = ReportService()
        self.data_date = '20200331'
        
        self.cleanup()
    
    def tearDown(self):
        self.cleanup()

    def test_BaseReport_constructor(self):
        with self.assertRaises(ReportInvalidDataDateException):
            BaseReport(ReportType.DAILY_REPORT, 'abc123')

    def test_load_target_report(self):
        # case of no report path
        LreDailyReport('20200331').load_target_report()
        self.assertTrue(
            os.path.exists(constant.CREATED_REPORT_PATH + '/Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
   
        # case of renaming report if exists
        LreDailyReport('20200331').load_target_report()
        self.assertEqual(
            len(glob.glob1(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331*.xlsx')), 2)
   
        # case of G14 report
        G14Report('20200331').load_target_report()
        self.assertTrue(os.path.exists(constant.CREATED_REPORT_PATH + '/G14_Report-20200331.xlsx'))
    
        # Exception
        with patch('openpyxl.load_workbook', side_effect=Exception('dummy exception')), self.assertRaises(
                ReportException):
            G14Report('20200331').load_target_report()
        
    
    def test_init_rate_sheet(self):

        rate_data_list = [{'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'EUR', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('7.7908043004')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'NZD', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('4.2455619624')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'SEK', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('0.7023247077')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'GBP', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('8.7273199035')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'CNY', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('0.998786547')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'JPY', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('0.0653317071')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'SGD', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('4.9758444747')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'CHF', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('7.354900608')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'DKK', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('1.0432030389')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'HKD', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('0.9138857937')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'THB', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('0.2161734861')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'USD', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('7.0851')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'AUD', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('4.3679854053')}, {'s_date': '20200331', 'e_date': '20200331', 'basic_ccy': 'CAD', 'forward_ccy': 'CNY', 'ccy_rate': Decimal('4.9946625003')}]
        
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()
        
        with patch.object(ReportService, 'init_rate_data', return_value=rate_data_list):
            daily_report.init_rate_sheet()
            wb = load_workbook(constant.CREATED_REPORT_PATH + '/Large_Risk_Exposure_Daily_Report-20200331.xlsx')
            sheet_ranges = wb[LreDailyReportSpreadSheets.RATE.value]
            self.assertEqual(sheet_ranges['A2'].value, '20200331')
            self.assertEqual(sheet_ranges['B2'].value, '20200331')
            self.assertEqual(sheet_ranges['C2'].value, 'EUR')
            self.assertEqual(sheet_ranges['D2'].value, 'CNY')
            self.assertEqual(sheet_ranges['E2'].value, 7.7908043004)
             
        with patch.object(ReportService, 'init_rate_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_rate_sheet()
            

    def test_init_loan_sheet(self):

        loan_cn_data_list = [{'data_date': '20200331', 'cbs_cust_id': '600688', 'currency': 'CNY', 'amount': Decimal('50000000'), 'interest_received_to_gl': Decimal('76527.78'), 'status': 'New', 'our_ref': '300WC01200730002'}, {'data_date': '20200331', 'cbs_cust_id': '600661', 'currency': 'USD', 'amount': Decimal('948106.8'), 'interest_received_to_gl': Decimal('7687.25'), 'status': 'New', 'our_ref': '300FA01200210001'}]
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()
        
        with patch.object(ReportService, 'query_loan_data', return_value=loan_cn_data_list), patch.object(ReportService, 'query_cny_rate_from_cache', return_value=7.0851):
            daily_report.init_loan_sheet()
            wb = load_workbook(constant.CREATED_REPORT_PATH + '/Large_Risk_Exposure_Daily_Report-20200331.xlsx')
            sheet_ranges = wb[LreDailyReportSpreadSheets.LOAN.value]
   
            self.assertEqual(sheet_ranges['A2'].value, '=K2')
            self.assertEqual(sheet_ranges['K2'].value, '600688')
            self.assertEqual(sheet_ranges['L2'].value, 'CNY')
            self.assertEqual(sheet_ranges['M2'].value, 50000000)
            self.assertEqual(sheet_ranges['AU2'].value, 76527.78)
            self.assertEqual(sheet_ranges['BO2'].value, '=IFERROR(IF(L2="CNY",M2+AU2, 1*(M2+AU2)),0)')
            self.assertEqual(sheet_ranges['BP2'].value, '=IFERROR(IF(L2="CNY",M2, 1*(M2)),0)')
   
            self.assertEqual(sheet_ranges['A3'].value, '=K3')
            self.assertEqual(sheet_ranges['K3'].value, '600661')
            self.assertEqual(sheet_ranges['L3'].value, 'USD')
            self.assertEqual(sheet_ranges['M3'].value, 948106.8)
            self.assertEqual(sheet_ranges['AU3'].value, 7687.25)
            self.assertEqual(sheet_ranges['BO3'].value, '=IFERROR(IF(L3="CNY",M3+AU3, 7.0851*(M3+AU3)),0)')
            self.assertEqual(sheet_ranges['BP3'].value, '=IFERROR(IF(L3="CNY",M3, 7.0851*(M3)),0)')
             
        with patch.object(ReportService, 'query_loan_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_loan_sheet()
   
        with patch.object(ReportService, 'query_loan_data', side_effect=DataException('dummy data exception')), self.assertLogs('bmolre.services.report_services.LreDailyReport', level='WARN') as cm:
            daily_report.init_loan_sheet()
            self.assertIn('WARNING:bmolre.services.report_services.LreDailyReport:dummy data exception', str(cm.output))
            self.assertIn('Traceback', str(cm.output))

    def test_init_other_inputs_sheet(self):
        # generate daily report
        other_input_data = {'tier1_capital_amt': Decimal('244108.46'), 'total_capital_amt': Decimal('245518.6')}
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()
        
        with patch.object(ReportService, 'query_capital_data', return_value=other_input_data):
            daily_report.init_other_inputs_sheet()
            wb = load_workbook(constant.CREATED_REPORT_PATH + '/Large_Risk_Exposure_Daily_Report-20200331.xlsx')
            sheet_ranges = wb[LreDailyReportSpreadSheets.OTHER_INPUTS.value]
            self.assertEqual(sheet_ranges['B2'].value, 245518.6)
            self.assertEqual(sheet_ranges['B3'].value, 244108.46)

        with patch.object(ReportService, 'query_capital_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_other_inputs_sheet()

        # generate G14 report
        g14_report = G14Report('20200331')
        g14_report.load_target_report()
        ifb_data = {'rank_cd': '1', 'fin_institution_name_cd': 'FN_INSTITUTION_NAME_CD_B0107H211000001', 'fin_institution_code_cd': 'B0107H211000001',
                    'ib_drawdown_amt': Decimal('87197.8'), 'ib_lending_amt': Decimal('0'), 'ib_borrow_amt': Decimal('0'), 'payment_amt': Decimal('87197.8'),
                    'nostro_amt': Decimal('0'), 'buy_back_sale_amt': Decimal('0'),
                    'oth_ib_financing_amt': Decimal('0'), 'total_ib_financing_amt': Decimal('87197.8'),
                    'reduce_ib_financing_amt': Decimal('87197.8'), 'proportion_capital': None,
                    'settle_ib_deposit': Decimal('0'), 'zero_rw_asset': Decimal('0')}
        domestic_summary_data1 = [{'item_name': 'Ⅰ. 资产', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '     1. 现金', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '     2. 贵金属', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '     3. 存放中央银行款项', 'foreign_in_cny_amount': Decimal('16900.56'), 'cny_amount': Decimal('7223.42'), 'total_in_cny_amount': Decimal('24123.98')}, {'item_name': '     4. 存放同业款项', 'foreign_in_cny_amount': Decimal('-1246.11'), 'cny_amount': Decimal('38782.62'), 'total_in_cny_amount': Decimal('37536.51')}, {'item_name': '              4.1 境内商业银行', 'foreign_in_cny_amount': Decimal('0.34'), 'cny_amount': Decimal('31930.43'), 'total_in_cny_amount': Decimal('31930.77')}, {'item_name': '              4.2 境内其他银行业金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '              4.3 境内证券业金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '              4.4 境内保险业金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '              4.5 境内其他金融机构', 'foreign_in_cny_amount': Decimal('4096.14'), 'cny_amount': Decimal('6852.19'), 'total_in_cny_amount': Decimal('10948.33')}, {'item_name': '              4.6境外金融机构', 'foreign_in_cny_amount': Decimal('-5342.59'), 'cny_amount': 0, 'total_in_cny_amount': Decimal('-5342.59')}, {'item_name': '     5. 应收利息', 'foreign_in_cny_amount': Decimal('538.02'), 'cny_amount': Decimal('5762.71'), 'total_in_cny_amount': Decimal('6300.73')}, {'item_name': '     6. 贷款', 'foreign_in_cny_amount': Decimal('10824.06'), 'cny_amount': Decimal('58076.87'), 'total_in_cny_amount': Decimal('68900.93')}, {'item_name': '     7. 贸易融资', 'foreign_in_cny_amount': Decimal('23713.06'), 'cny_amount': Decimal('1395.38'), 'total_in_cny_amount': Decimal('25108.44')}, {'item_name': '     8. 贴现及买断式转贴现', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '     9. 其他贷款', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '     10. 拆放同业', 'foreign_in_cny_amount': Decimal('129675.98'), 'cny_amount': Decimal('29981.44'), 'total_in_cny_amount': Decimal('159657.42')}, {'item_name': '               10.1 境内商业银行', 'foreign_in_cny_amount': Decimal('121173.86'), 'cny_amount': Decimal('29981.44'), 'total_in_cny_amount': Decimal('151155.3')}, {'item_name': '               10.2 境内其他银行业金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               10.3 境内证券业金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               10.4 境内保险业金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               10.5 境内其他金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               10.6境外金融机构', 'foreign_in_cny_amount': Decimal('8502.12'), 'cny_amount': 0, 'total_in_cny_amount': Decimal('8502.12')}, {'item_name': '     11. 其他应收款', 'foreign_in_cny_amount': Decimal('6228.37'), 'cny_amount': Decimal('3149.77'), 'total_in_cny_amount': Decimal('9378.14')}, {'item_name': '     12. 投资', 'foreign_in_cny_amount': 0, 'cny_amount': Decimal('189944.95'), 'total_in_cny_amount': Decimal('189944.95')}, {'item_name': '               12.1 债券', 'foreign_in_cny_amount': 0, 'cny_amount': Decimal('189944.95'), 'total_in_cny_amount': Decimal('189944.95')}, {'item_name': '               12.2 股票', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               12.3 其他', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '                    12.3.1 其中：长期股权投资', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '     13.买入返售资产', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               13.1 境内商业银行', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               13.2 境内其他银行业金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               13.3境内证券业金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               13.4 境内保险业金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               13.5 境内其他金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               13.6 境外金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               13.7 境内外非金融机构', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               13.8中央银行', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '               按品种分类：13.9.1债券', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '                          13.9.2 票据 ', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '                          13.9.3 贷款', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '                          13.9.4 其他', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '     14. 长期待摊费用', 'foreign_in_cny_amount': 0, 'cny_amount': Decimal('215.03'), 'total_in_cny_amount': Decimal('215.03')}, {'item_name': '     15. 固定资产原价', 'foreign_in_cny_amount': Decimal('1471.93'), 'cny_amount': Decimal('7262.17'), 'total_in_cny_amount': Decimal('8734.1')}, {'item_name': '     16. 减：累计折旧', 'foreign_in_cny_amount': Decimal('1324.89'), 'cny_amount': Decimal('4808.07'), 'total_in_cny_amount': Decimal('6132.96')}, {'item_name': '     17. 固定资产净值', 'foreign_in_cny_amount': Decimal('147.04'), 'cny_amount': Decimal('2454.1'), 'total_in_cny_amount': Decimal('2601.14')}, {'item_name': '     18. 固定资产清理', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '     19. 在建工程', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '     20. 无形资产', 'foreign_in_cny_amount': 0, 'cny_amount': Decimal('2333.63'), 'total_in_cny_amount': Decimal('2333.63')}, {'item_name': '     21. 抵债资产', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '     22. 递延所得税资产', 'foreign_in_cny_amount': Decimal('3.58'), 'cny_amount': 0, 'total_in_cny_amount': Decimal('3.58')}, {'item_name': '     23. 其他资产', 'foreign_in_cny_amount': Decimal('120348.57'), 'cny_amount': Decimal('746.06'), 'total_in_cny_amount': Decimal('121094.63')}, {'item_name': '                       23.1投资性房地产', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '                       23.2衍生金融资产', 'foreign_in_cny_amount': Decimal('119809.79'), 'cny_amount': Decimal('365.53'), 'total_in_cny_amount': Decimal('120175.32')}, {'item_name': '                       23.3商誉', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '                       23.4投资同业存单', 'foreign_in_cny_amount': 0, 'cny_amount': 0, 'total_in_cny_amount': 0}, {'item_name': '      24. 减：各项资产减值损失准备', 'foreign_in_cny_amount': Decimal('742.28'), 'cny_amount': Decimal('909.58'), 'total_in_cny_amount': Decimal('1651.86')}, {'item_name': '      25. 资产总计', 'foreign_in_cny_amount': Decimal('306390.85'), 'cny_amount': Decimal('339156.4'), 'total_in_cny_amount': Decimal('645547.25')}]
        domestic_summary_data2 = {'interbank_lending_amount': Decimal('53340.4'), 'entrusted_party_pays_amount': Decimal('97814.89')}

        with patch.object(ReportService, 'query_capital_data', return_value=other_input_data), patch.object(ReportService, 'query_interbank_financing_business_data', return_value=ifb_data), patch.object(ReportService, 'query_domestic_summary_data1', return_value=domestic_summary_data1), patch.object(ReportService, 'query_domestic_summary_data2', return_value=domestic_summary_data2):
           g14_report.init_other_inputs_sheet()
           wb = load_workbook(constant.CREATED_REPORT_PATH + '/G14_Report-20200331.xlsx')
           sheet_ranges = wb[LreDailyReportSpreadSheets.OTHER_INPUTS.value]
           self.assertEqual(sheet_ranges['B2'].value, 245518.6)
           self.assertEqual(sheet_ranges['B3'].value, 244108.46)
           self.assertEqual(sheet_ranges['B10'].value, '1')
           self.assertEqual(sheet_ranges['C10'].value, 'FN_INSTITUTION_NAME_CD_B0107H211000001')
           self.assertEqual(sheet_ranges['D10'].value, 'B0107H211000001')
           self.assertEqual(sheet_ranges['E10'].value, 87197.8)
           self.assertEqual(sheet_ranges['F10'].value, 0)
           self.assertEqual(sheet_ranges['G10'].value, 0)
           self.assertEqual(sheet_ranges['H10'].value, 87197.8)
           self.assertEqual(sheet_ranges['I10'].value, 0)
           self.assertEqual(sheet_ranges['J10'].value, 0)
           self.assertEqual(sheet_ranges['K10'].value, 0)
           self.assertEqual(sheet_ranges['L10'].value, 87197.8)
           self.assertEqual(sheet_ranges['M10'].value, 87197.8)
           self.assertEqual(sheet_ranges['N10'].value, None)
           self.assertEqual(sheet_ranges['O10'].value, 0)
           self.assertEqual(sheet_ranges['P10'].value, 0)

           self.assertEqual(sheet_ranges['C18'].value, 16900.56)
           self.assertEqual(sheet_ranges['D18'].value, 7223.42)
           self.assertEqual(sheet_ranges['E18'].value, 24123.98)
           self.assertEqual(sheet_ranges['E73'].value, 53340.4)
           self.assertEqual(sheet_ranges['E75'].value, 97814.89)


    def test_init_bond_ncd_sheet(self):
        
        bond_ncd_data_list = [{'cbs_id': '300106', 'accounting_code': 'POL', 'issuser_uen': '35013861', 'ccy': 'CNY', 'balance': 50480000, 'interest_receivable': Decimal('163565.5'), 'profit_center': 'T3773'}]
        
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()
        
        with patch.object(ReportService, 'query_bond_ncd_data', return_value=bond_ncd_data_list):
            daily_report.init_bond_ncd_sheet()
            wb = load_workbook(constant.CREATED_REPORT_PATH + '/Large_Risk_Exposure_Daily_Report-20200331.xlsx')
            sheet_ranges = wb[LreDailyReportSpreadSheets.BOND_NCD.value]
            self.assertEqual(sheet_ranges['A2'].value, '=H2')
            self.assertEqual(sheet_ranges['B2'].value, 'POL')
            self.assertEqual(sheet_ranges['C2'].value, '35013861')
            self.assertEqual(sheet_ranges['D2'].value, 'CNY')
            self.assertEqual(sheet_ranges['E2'].value, 50480000)
            self.assertEqual(sheet_ranges['F2'].value, 163565.5)
            self.assertEqual(sheet_ranges['G2'].value, '=IFERROR(IF(D2="CNY",E2+F2, 1 * (E2+F2) ),0)')
            self.assertEqual(sheet_ranges['H2'].value, '300106')
            self.assertEqual(sheet_ranges['I2'].value, 'T3773')

        with patch.object(ReportService, 'query_bond_ncd_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_bond_ncd_sheet()

    def test_init_single_cust_sheet(self):
        with self.app.app_context():
            daily_report = LreDailyReport('20200331')
            daily_report.load_target_report()
            daily_report.init_customer_sheet()
            daily_report.init_single_cust_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.SINGLE_CUST.value]
            self.assertEqual(sheet_ranges['A3'].value, '000007')
            self.assertEqual(sheet_ranges['C3'].value, '=VLOOKUP(A3,Customer!$B:$E,4,FALSE)')
            self.assertEqual(sheet_ranges['D3'].value, '=IF(COUNTIF($C:$C,C3)=1,"N",IF(C3=0,"N","Y"))')
            self.assertEqual(sheet_ranges['E3'].value, '=IF(F3<>0,RANK(F3,F:F)+COUNTIF($F$3:$F3,F3)-1,0)')

    def test_init_group_corp_sheet(self):
        print('run test_init_group_corp_sheet()')

        with self.app.app_context():
            daily_report = LreDailyReport('20200331')
            daily_report.load_target_report()
            daily_report.init_customer_sheet()
            daily_report.init_group_corp_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.GROUP_CORP.value]

            self.assertEqual(str(sheet_ranges['A3'].value), '900002')
            self.assertEqual(sheet_ranges['B3'].value, '=IFERROR(VLOOKUP($A3,Customer!$T:$V,3,FALSE), "")')
            self.assertEqual(sheet_ranges['C3'].value, '=A3')
            self.assertEqual(sheet_ranges['D3'].value, '=IF(E3<>0,RANK(E3,E:E)+COUNTIF($E$3:$E3,E3)-1,0)')

    def test_init_group_bank_sheet(self):
        print('run test_init_group_bank_sheet()')

        with self.app.app_context():
            daily_report = LreDailyReport('20200331')
            daily_report.load_target_report()
            daily_report.init_customer_sheet()
            daily_report.init_group_bank_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.GROUP_BANK.value]

            self.assertEqual(str(sheet_ranges['D3'].value), '=IF($C3="Y",$A3,IFERROR(VLOOKUP($A3,Customer!$E:$Z,22),""))')
            self.assertEqual(str(sheet_ranges['E3'].value), '=IF(F3<>0,RANK(F3,F:F)+COUNTIF($F$3:$F3,F3)-1,0)')
            self.assertEqual(str(sheet_ranges['F3'].value), '=J3+L3')
            self.assertEqual(str(sheet_ranges['G3'].value), "=F3/'Other inputs'!$B$3")
            self.assertEqual(str(sheet_ranges['H3'].value), "='Other inputs'!$B$3 * 'Summary Control'!$F$4-F3")



    def test_init_summary_control_sheet(self):
        print('run init_summary_control_sheet()')

        with self.app.app_context():
            daily_report = LreDailyReport('20200331')
            daily_report.load_target_report()
            daily_report.init_summary_control_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.SUMMARY_CONTROL.value]

            self.assertEqual(str(sheet_ranges['C1'].value), '2020/03/31')
            self.assertEqual(str(sheet_ranges['C2'].value), "='Other inputs'!$B$2")
            self.assertEqual(str(sheet_ranges['C3'].value), "='Other inputs'!$B$3")

    def test_init_single_interbank_sheet(self):
        print('run test_init_single_interbank_sheet()')

        with self.app.app_context():
            g14_report = G14Report('20200331')
            g14_report.load_target_report()
            g14_report.init_customer_sheet()
            g14_report.init_single_interbank_sheet()
            wb = load_workbook(
                os.path.join(constant.CREATED_REPORT_PATH, 'G14_Report-20200331.xlsx'))
            sheet_ranges = wb[G14ReportSpreadSheets.SINGLE_INTERBANK.value]

            self.assertEqual(str(sheet_ranges['F3'].value), "=E3/'Other inputs'!$B$3")
            self.assertEqual(str(sheet_ranges['G3'].value), '=IF(F3>=2.5%,"Y","N")')

    def test_init_g1401_sheet(self):
        print('run test_init_g1401_sheet()')

        with self.app.app_context():
            g14_report = G14Report('20201231')
            g14_report.load_target_report()
            g14_report.init_g1401_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'G14_Report-20201231.xlsx'))
            sheet_ranges = wb[G14ReportSpreadSheets.G1401.value]

            self.assertEqual(str(sheet_ranges['D2'].value), '报表日期：2020年12月')
            self.assertEqual(str(sheet_ranges['C8'].value), '=SUM(E8:J8)')
            self.assertEqual(str(sheet_ranges['C9'].value), '=SUM(E9:J9)')
            self.assertEqual(str(sheet_ranges['C10'].value), '=E10')
            self.assertEqual(str(sheet_ranges['C11'].value), '=SUM(E11:J11)')

    def test_init_g1402_sheet(self):
        print('run test_init_g1402_sheet()')

        with self.app.app_context():
            g14_report = G14Report('20201231')
            g14_report.load_target_report()
            g14_report.init_g1402_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'G14_Report-20201231.xlsx'))
            sheet_ranges = wb[G14ReportSpreadSheets.G1402.value]

            self.assertEqual(str(sheet_ranges['B9'].value), '1')



    def test_init_g1403_sheet(self):
        print('run test_init_g1403_sheet()')

        with self.app.app_context():
            g14_report = G14Report('20201231')
            g14_report.load_target_report()
            g14_report.init_g1403_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'G14_Report-20201231.xlsx'))
            sheet_ranges = wb[G14ReportSpreadSheets.G1403.value]

            self.assertEqual(str(sheet_ranges['D10'].value), '=IFERROR( VLOOKUP(B10,\'Single Cust\'!$A:$M,3,0), "" )')
            self.assertEqual(str(sheet_ranges['E10'].value), '=IFERROR(VLOOKUP(B10,\'Single Cust\'!$A:$M,4,0),"" )')

    def test_init_g1404_sheet(self):
        print('run test_init_g1404_sheet()')

        with self.app.app_context():
            g14_report = G14Report('20201231')
            g14_report.load_target_report()
            g14_report.init_g1404_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'G14_Report-20201231.xlsx'))
            sheet_ranges = wb[G14ReportSpreadSheets.G1404.value]

            self.assertEqual(str(sheet_ranges['D10'].value), '=IFERROR(IF(LEN(VLOOKUP(B10,\'Group Cust\'!$A:$C,3,0))=0, "", VLOOKUP(B10,\'Group Cust\'!$A:$C,3,0) ), "" )')
            self.assertEqual(str(sheet_ranges['E10'].value), "=IFERROR(IF(LEN(VLOOKUP(B10,'Group Cust'!$A:$L,4,0))=0, \"\",VLOOKUP(A10,'Group Cust'!$A:$L,4,0)), \"\" )")

    def test_init_g1405_sheet(self):
        print('run test_init_g1405_sheet()')

        with self.app.app_context():
            g14_report = G14Report('20201231')
            g14_report.load_target_report()
            g14_report.init_g1405_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'G14_Report-20201231.xlsx'))
            sheet_ranges = wb[G14ReportSpreadSheets.G1405.value]

            self.assertEqual(str(sheet_ranges['D10'].value), '= IF(VLOOKUP(A10,\'Single Interbank\'!$A:$E,5,0)>0,VLOOKUP(A10,\'Single Interbank\'!$A:$K,3,0),"#N/A")')
            self.assertEqual(str(sheet_ranges['E10'].value), '= IF( VLOOKUP(A10,\'Single Interbank\'!$A:$E,5,0)>0, VLOOKUP(A10,\'Single Interbank\'!$A:$K,4,0),"#N/A")')

    def test_init_g1406_sheet(self):
        print('run test_init_g1406_sheet()')

        with self.app.app_context():
            g14_report = G14Report('20201231')
            g14_report.load_target_report()
            g14_report.init_g1406_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'G14_Report-20201231.xlsx'))
            sheet_ranges = wb[G14ReportSpreadSheets.G1406.value]

            self.assertEqual(str(sheet_ranges['D10'].value), '=VLOOKUP($B10,IF({1,0},\'Group Interbank\'!$Y:$Y, \'Group Interbank\'!C:C),2,FALSE)')
            self.assertEqual(str(sheet_ranges['E10'].value), '=VLOOKUP($B10,IF({1,0},\'Group Interbank\'!$Y:$Y, \'Group Interbank\'!D:D),2,FALSE)')


    def test_init_fefc_sheet(self):
        print('run test_init_fefc_sheet()')
        fefc_data_list = [{'uen': 55239, 'product_exposure': 22543730, 'product_exposure_cny': Decimal('159724581.423')}, {'uen': 199662, 'product_exposure': 787533, 'product_exposure_cny': Decimal('5579750.0583')}]

        with patch.object(ReportService, 'query_fefc_data', return_value=fefc_data_list):
            daily_report = LreDailyReport('20200331')
            daily_report.load_target_report()
            daily_report.init_fefc_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.FEFC.value]

            self.assertEqual(str(sheet_ranges['A2'].value), '55239')
            self.assertEqual(str(sheet_ranges['B2'].value), '22543730')
            self.assertEqual(str(sheet_ranges['C2'].value), '159724581.423')
            self.assertEqual(str(sheet_ranges['A3'].value), '199662')
            self.assertEqual(str(sheet_ranges['B3'].value), '787533')
            self.assertEqual(str(sheet_ranges['C3'].value), '5579750.0583')

        with patch.object(ReportService, 'query_fefc_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_fefc_sheet()

    def test_init_daily_mm505_sheet(self):
        mm505_data_list = [{'cbs_id': '300352', 'report_date': '20200325', 'value_date': '20200325', 'mat_date': '20200401', 'deal_type': 'XL', 'deal_type_rra': 'XL', 'ccy': 'USD', 'amount': Decimal('40000000'), 'interest_rec_pay': Decimal('15166.6666666666666666666666666666666667'), 'name_short': 'BNS SHA', 'customer_type': 'BANK', 'wss_customer_number': '560067', 'inventory': 'Y', 'customer_short_name': '560067', 'cny_eqv': Decimal('283511457.35'), 'interest_amt': Decimal('107457.35')}, {'cbs_id': '300523', 'report_date': '20200331', 'value_date': '20200331', 'mat_date': '20200401', 'deal_type': 'XL', 'deal_type_rra': 'XL', 'ccy': 'CNY', 'amount': Decimal('250000000'), 'interest_rec_pay': Decimal('11208.3333333333333333333333333333333333'), 'name_short': 'CMB SHE', 'customer_type': 'BANK', 'wss_customer_number': '546236', 'inventory': 'Y', 'customer_short_name': '546236', 'cny_eqv': Decimal('250011208.333333333333333333333333333333'), 'interest_amt': Decimal('11208.3333333333333333333333333333333333')}]
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()
        
        with patch.object(ReportService, 'query_daily_money_market_data', return_value=mm505_data_list):
            daily_report.init_daily_mm505_sheet()
            wb = load_workbook(constant.CREATED_REPORT_PATH + '/Large_Risk_Exposure_Daily_Report-20200331.xlsx')
            sheet_ranges = wb[LreDailyReportSpreadSheets.MM_505.value]
            self.assertEqual(sheet_ranges['A2'].value, '=AC2')
            self.assertEqual(sheet_ranges['B2'].value, '20200331')
            self.assertEqual(sheet_ranges['H2'].value, '20200325')
            self.assertEqual(sheet_ranges['I2'].value, '20200401')
            self.assertEqual(sheet_ranges['J2'].value, 'XL')
            self.assertEqual(sheet_ranges['K2'].value, 'XL')
            self.assertEqual(sheet_ranges['M2'].value, 'USD')
            self.assertEqual(sheet_ranges['N2'].value, 40000000)
            self.assertEqual(sheet_ranges['O2'].value, 15166.66666666667)
            self.assertEqual(sheet_ranges['S2'].value, 'BNS SHA')
            self.assertEqual(sheet_ranges['U2'].value, 'BANK')
            self.assertEqual(sheet_ranges['V2'].value, '560067')
            self.assertEqual(sheet_ranges['AA2'].value, 'Y')
            self.assertEqual(sheet_ranges['AB2'].value, '560067')
            self.assertEqual(sheet_ranges['AC2'].value, '300352')
            self.assertEqual(sheet_ranges['AD2'].value, 283511457.35)

        with patch.object(ReportService, 'query_daily_money_market_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_daily_mm505_sheet()
        
    def test_init_g14_mm505_sheet(self):
        mm505_data_list = [{'cbs_id': '300352', 'report_date': '20200325', 'value_date': '20200325', 'mat_date': '20200401', 'deal_type': 'XL', 'deal_type_rra': 'XL', 'ccy': 'USD', 'amount': Decimal('40000000'), 'interest_rec_pay': Decimal('15166.6666666666666666666666666666666667'), 'name_short': 'BNS SHA', 'customer_type': 'BANK', 'wss_customer_number': '560067', 'inventory': 'Y', 'customer_short_name': '560067', 'cny_eqv': Decimal('283511457.35'), 'interest_amt': Decimal('107457.35')}, {'cbs_id': '300523', 'report_date': '20200331', 'value_date': '20200331', 'mat_date': '20200401', 'deal_type': 'XL', 'deal_type_rra': 'XL', 'ccy': 'CNY', 'amount': Decimal('250000000'), 'interest_rec_pay': Decimal('11208.3333333333333333333333333333333333'), 'name_short': 'CMB SHE', 'customer_type': 'BANK', 'wss_customer_number': '546236', 'inventory': 'Y', 'customer_short_name': '546236', 'cny_eqv': Decimal('250011208.333333333333333333333333333333'), 'interest_amt': Decimal('11208.3333333333333333333333333333333333')}]
        g14_report = G14Report('20200331')
        g14_report.load_target_report()
        
        with patch.object(ReportService, 'query_g14_money_market_data', return_value=mm505_data_list):
            g14_report.init_g14_mm505_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH,'G14_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.MM_505.value]
            self.assertEqual(sheet_ranges['A2'].value, '=AC2')
            self.assertEqual(sheet_ranges['B2'].value, '20200331')
            self.assertEqual(sheet_ranges['H2'].value, '20200325')
            self.assertEqual(sheet_ranges['I2'].value, '20200401')
            self.assertEqual(sheet_ranges['J2'].value, 'XL')
            self.assertEqual(sheet_ranges['K2'].value, 'XL')
            self.assertEqual(sheet_ranges['M2'].value, 'USD')
            self.assertEqual(sheet_ranges['N2'].value, 40000000)
            self.assertEqual(sheet_ranges['O2'].value, 15166.66666666667)
            self.assertEqual(sheet_ranges['S2'].value, 'BNS SHA')
            self.assertEqual(sheet_ranges['U2'].value, 'BANK')
            self.assertEqual(sheet_ranges['V2'].value, '560067')
            self.assertEqual(sheet_ranges['AA2'].value, 'Y')
            self.assertEqual(sheet_ranges['AB2'].value, '560067')
            self.assertEqual(sheet_ranges['AC2'].value, '300352')
            self.assertEqual(sheet_ranges['AD2'].value, 283511457.35)

        with patch.object(ReportService, 'query_g14_money_market_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            g14_report.init_g14_mm505_sheet()
    
    def test_init_daily_master_list_sheet(self):
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()

        data_ls = [{'local_branch': None, 'cbs_id': 'CORPORATE_B056', 'wss_id': None, 'pix_id': None, 'uen': 'B056',
                    'otl_id': None, 'uniform_social_credit_code': 'B056', 'customer_name_cn': 'CHINAL*************',
                    'customer_name_en': 'CHINAL*************', 'customer_category': 'CORPORATE', 'nationality': '',
                    'country': '', 'exposure_country': None, 'area': None, 'corp_type': None, 'corp_size': None,
                    'industry_code': None, 'holding_type': None, 'unique_id_value': '', 'group_code': '',
                    'group_name': '', 'group_chinese_name': None, 'status': None, 'data_date': '20201231',
                    'connection_uen': None, 'connection_name': None, 'g14_group_ind': 'N'}]

        daily_report.init_daily_master_list_sheet(data_ls)
        wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
        sheet_ranges = wb[LreDailyReportSpreadSheets.DAILY_MASTER_LIST.value]
        self.assertEqual(sheet_ranges['A3'].value, '=IF(ISBLANK(VLOOKUP(B3,Customer!$B:$E,4,0)),"",VLOOKUP(B3,Customer!$B:$E,4,0))')
        self.assertEqual(sheet_ranges['B3'].value, '=Customer!B2')
        self.assertEqual(sheet_ranges['N3'].value, '=SUM(BD3)')
        self.assertEqual(sheet_ranges['S3'].value, '=SUMIFS(Loan!BP:BP,Loan!$A:$A,\'Daily Master List\'!B3)/10000+Z3')
        self.assertEqual(sheet_ranges['AA3'].value, '=SUMIFS(PBOC!$F:$F,PBOC!A:A,\'Daily Master List\'!B3)/10000')
        self.assertEqual(sheet_ranges['AB3'].value, '=SUMIFS(\'Auto Fin\'!F:F,\'Auto Fin\'!A:A,\'Daily Master List\'!B3)/10000')
        self.assertEqual(sheet_ranges['AH3'].value, '=SUMIFS(\'MM 505\'!$AD:$AD,\'MM 505\'!$AA:$AA,"Y",\'MM 505\'!$J:$J,"XL",\'MM 505\'!$A:$A,\'Daily Master List\'!B3)/10000')
        self.assertEqual(sheet_ranges['AM3'].value, '=SUMIFS(EAD!$I:$I,EAD!A:A,\'Daily Master List\'!B3)/10000')
        self.assertEqual(sheet_ranges['AN3'].value, '=SUMIFS(Nostro!F:F,Nostro!A:A,\'Daily Master List\'!B3)/10000')
        self.assertEqual(sheet_ranges['AQ3'].value, '=SUMIFS(\'Bond & NCD\'!G:G,\'Bond & NCD\'!A:A,B3,\'Bond & NCD\'!B:B,"POL")/10000+SUMIFS(\'Bond & NCD\'!G:G,\'Bond & NCD\'!A:A,B3,\'Bond & NCD\'!B:B,"GVT")/10000')
        self.assertEqual(sheet_ranges['BD3'].value, '=IF(COUNTIF($A$3:A3,A3)=1,$BD$2*SUMIFS(FEFC!$C:$C,FEFC!$A:$A,A3)/10000,0)')

    def test_init_g14_master_list_sheet(self):
        g14_report = G14Report('20200331')
        g14_report.load_target_report()

        data_ls = [{'local_branch': None, 'cbs_id': 'CORPORATE_B056', 'wss_id': None, 'pix_id': None, 'uen': 'B056', 'otl_id': None, 'uniform_social_credit_code': 'B056', 'customer_name_cn': 'CHINAL*************', 'customer_name_en': 'CHINAL*************', 'customer_category': 'CORPORATE', 'nationality': '', 'country': '', 'exposure_country': None, 'area': None, 'corp_type': None, 'corp_size': None, 'industry_code': None, 'holding_type': None, 'unique_id_value': '', 'group_code': '', 'group_name': '', 'group_chinese_name': None, 'status': None, 'data_date': '20201231', 'connection_uen': None, 'connection_name': None, 'g14_group_ind': 'N'}]
        g14_report.init_g14_master_list_sheet(data_ls)
        wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'G14_Report-20200331.xlsx'))
        sheet_ranges = wb[G14ReportSpreadSheets.G14_MASTER_LIST.value]
        self.assertEqual(sheet_ranges['A3'].value, '=IF(ISBLANK(VLOOKUP(B3,Customer!$B:$E,4,0)),"",VLOOKUP(B3,Customer!$B:$E,4,0))')
        self.assertEqual(sheet_ranges['B3'].value, '=Customer!B2')
        self.assertEqual(sheet_ranges['N3'].value, '=SUM(AM3)')
        self.assertEqual(sheet_ranges['S3'].value, '=SUMIFS(Loan!BP:BP,Loan!$A:$A,\'G14 Master List\'!B3)/10000+Z3')
        self.assertEqual(sheet_ranges['AA3'].value, '=SUMIFS(PBOC!$F:$F,PBOC!A:A,\'G14 Master List\'!B3)/10000')
        self.assertEqual(sheet_ranges['AB3'].value, '=SUMIFS(\'Auto Fin\'!F:F,\'Auto Fin\'!A:A,\'G14 Master List\'!B3)/10000')
        self.assertEqual(sheet_ranges['AH3'].value, '=SUMIFS(\'MM 505\'!$AD:$AD,\'MM 505\'!$AA:$AA,\"Y\",\'MM 505\'!$J:$J,\"XL\",\'MM 505\'!$A:$A,\'G14 Master List\'!B3)/10000')
        self.assertEqual(sheet_ranges['AM3'].value, '=SUMIFS(EAD!$I:$I,EAD!A:A,\'G14 Master List\'!B3)/10000')
        self.assertEqual(sheet_ranges['AN3'].value, '=SUMIFS(Nostro!F:F,Nostro!A:A,\'G14 Master List\'!B3)/10000')
        self.assertEqual(sheet_ranges['AQ3'].value, '=SUMIFS(\'Bond & NCD\'!G:G,\'Bond & NCD\'!A:A,B3,\'Bond & NCD\'!B:B,"POL",\'Bond & NCD\'!I:I,"T3773")/10000')

    def test_init_ead_sheet(self):
        ead_data_list = [{'cbs_cif_id': '300761', 'counterparity_long_name': None, 'counterpary_type': None, 'ibuk_customer_number': '560022', 'ead_usd': None, 'ead_cny_eqv': Decimal('3348452253.1')}, {'cbs_cif_id': '300055', 'counterparity_long_name': 'CUSTOMER_NAME1_897', 'counterpary_type': 'CORPORATE', 'ibuk_customer_number': '560299', 'ead_usd': Decimal('107062.11'), 'ead_cny_eqv': Decimal('758545.75')}]
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()

        with patch.object(ReportService, 'cal_ead_report_data', return_value=ead_data_list):
            daily_report.init_ead_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.EAD.value]

            self.assertEqual(sheet_ranges['A2'].value, '=J2')
            self.assertEqual(sheet_ranges['E2'].value, '560022')
            self.assertEqual(sheet_ranges['F2'].value, None)
            self.assertEqual(sheet_ranges['I2'].value, 3348452253.1)
            self.assertEqual(sheet_ranges['J2'].value, '300761')

            self.assertEqual(sheet_ranges['A3'].value, '=J3')
            self.assertEqual(sheet_ranges['E3'].value, '560299')
            self.assertEqual(sheet_ranges['F3'].value, 107062.11)
            self.assertEqual(sheet_ranges['I3'].value, 758545.75)
            self.assertEqual(sheet_ranges['J3'].value, '300055')

        with patch.object(ReportService, 'cal_ead_report_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_ead_sheet()

        with patch.object(ReportService, 'cal_ead_report_data', side_effect=DataException('dummy data exception')), self.assertRaises(ReportException):
            daily_report.init_ead_sheet()


    def test_init_llp_sheet(self):
        llp_data_list = [{'transaction_ref': 'BMBJ619174EX', 'branch': 'HO', 'bs_offbs': 'BS', 'deal_type': 'LC discounting', 'uen': '55140', 'ccy_cny_usd': 'USD', 'prov_amt': Decimal('7265.7459')}, {'transaction_ref': 'BMBJ223966AV', 'branch': 'HO', 'bs_offbs': 'BS', 'deal_type': 'Refinancing', 'uen': '266677', 'ccy_cny_usd': 'CNY', 'prov_amt': Decimal('8219.372738')}]
        
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()

        with patch.object(ReportService, 'query_llp_data', return_value=llp_data_list), patch.object(ReportService, 'query_cny_rate_from_cache', return_value=7.0851):
            daily_report.init_llp_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.LLP.value]

            self.assertEqual(sheet_ranges['B3'].value, 'BS')
            self.assertEqual(sheet_ranges['C3'].value, 'LC discounting')
            self.assertEqual(sheet_ranges['F3'].value, '55140')
            self.assertEqual(sheet_ranges['T3'].value, 'USD')
            self.assertEqual(sheet_ranges['V3'].value, 7265.7459)
            self.assertEqual(sheet_ranges['AD3'].value, '=IFERROR(IF(T3="CNY",V3, 7.0851 * V3 ),0)')

            self.assertEqual(sheet_ranges['B4'].value, 'BS')
            self.assertEqual(sheet_ranges['C4'].value, 'Refinancing')
            self.assertEqual(sheet_ranges['F4'].value, '266677')
            self.assertEqual(sheet_ranges['T4'].value, 'CNY')
            self.assertEqual(sheet_ranges['V4'].value, 8219.372738)
            self.assertEqual(sheet_ranges['AD4'].value, '=IFERROR(IF(T4="CNY",V4, 1 * V4 ),0)')

        with patch.object(ReportService, 'query_llp_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_llp_sheet()

    def test_init_nostro_sheet(self):
        nostro_data_list = [{'cbs_customer_id': '009015', 'ccy': 'CNY', 'amount': Decimal('300973228.77'), 'fcy_amount': Decimal('68257.07')}]
        
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()

        with patch.object(ReportService, 'query_nostro_data', return_value=nostro_data_list):
            daily_report.init_nostro_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.NOSTRO.value]

            self.assertEqual(sheet_ranges['A2'].value, '=B2')
            self.assertEqual(sheet_ranges['B2'].value, '009015')
            self.assertEqual(sheet_ranges['C2'].value, 'CNY')
            self.assertEqual(sheet_ranges['D2'].value, 300973228.77)
            self.assertEqual(sheet_ranges['E2'].value, 68257.07)
            self.assertEqual(sheet_ranges['F2'].value, '=(D2+E2)')

        with patch.object(ReportService, 'query_nostro_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_nostro_sheet()

    def test_init_offbs_tf_sheet(self):
        offbs_tf_data_list = [{'cbs_id': '600551', 'uen_no': '36415432', 'offbs_factor': Decimal('0.5'), 'deal_type': 'Guarantee', 'currency': 'CNY', 'amount': 426000}]
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()

        with patch.object(ReportService, 'query_offbs_tf_data', return_value=offbs_tf_data_list):
            daily_report.init_offbs_tf_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.OFFBS_TF.value]

            self.assertEqual(sheet_ranges['A2'].value, '=C2')
            self.assertEqual(sheet_ranges['B2'].value, '36415432')
            self.assertEqual(sheet_ranges['C2'].value, '600551')
            self.assertEqual(sheet_ranges['D2'].value, 0.5)
            self.assertEqual(sheet_ranges['G2'].value, 'Guarantee')
            self.assertEqual(sheet_ranges['J2'].value, '36415432')
            self.assertEqual(sheet_ranges['K2'].value, 'CNY')
            self.assertEqual(sheet_ranges['L2'].value, 426000)
            self.assertEqual(sheet_ranges['X2'].value, '=IFERROR(IF(\'offbs TF\'!K2="CNY",\'offbs TF\'!L2, 1 * L2),0)')

        with patch.object(ReportService, 'query_offbs_tf_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_offbs_tf_sheet()
            
    def test_init_limit_sheet(self):
        limit_data_list = [{'cbs_id': '000346', 'customer_id': '000346', 'currency': 'USD', 'available_credit_limit': Decimal('7417.39708'), 'revocable': 'Revocable', 'org_period_in_one_year': 'Y'}, {'cbs_id': '600471', 'customer_id': '600471', 'currency': 'USD', 'available_credit_limit': Decimal('0.00000'), 'revocable': 'Irrevocable', 'org_period_in_one_year': 'N'}] 
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()

        with patch.object(ReportService, 'cal_limit_data', return_value=limit_data_list), patch.object(ReportService, 'query_cny_rate_from_cache', return_value=7.0851):
            daily_report.init_limit_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.LIMIT.value]

            self.assertEqual(sheet_ranges['A3'].value, '=D3')
            self.assertEqual(sheet_ranges['D3'].value, '000346')
            self.assertEqual(sheet_ranges['G3'].value, 'USD')
            self.assertEqual(sheet_ranges['O3'].value, 7417.39708)
            self.assertEqual(sheet_ranges['R3'].value, 'Revocable')
            self.assertEqual(sheet_ranges['U3'].value, 'Y')
            self.assertEqual(sheet_ranges['AJ3'].value, '=IFERROR(IF(G3="CNY",O3*1000, 7.0851 * O3 * 1000),0)')

            self.assertEqual(sheet_ranges['A4'].value, '=D4')
            self.assertEqual(sheet_ranges['D4'].value, '600471')
            self.assertEqual(sheet_ranges['G4'].value, 'USD')
            self.assertEqual(sheet_ranges['O4'].value, 0)
            self.assertEqual(sheet_ranges['R4'].value, 'Irrevocable')
            self.assertEqual(sheet_ranges['U4'].value, 'N')
            self.assertEqual(sheet_ranges['AJ4'].value, '=IFERROR(IF(G4="CNY",O4*1000, 7.0851 * O4 * 1000),0)')

        with patch.object(ReportService, 'cal_limit_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_limit_sheet()

    def test_init_pboc_sheet(self):
        pboc_data_list = [{'cbs_id': '009000', 'currency': 'CNY', 'amount': Decimal('241239878.75')}]
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()

        with patch.object(ReportService, 'query_pboc_data', return_value=pboc_data_list):
            daily_report.init_pboc_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.PBOC.value]

            self.assertEqual(sheet_ranges['A2'].value, '=B2')
            self.assertEqual(sheet_ranges['B2'].value, '009000')
            self.assertEqual(sheet_ranges['C2'].value, 'CNY')
            self.assertEqual(sheet_ranges['D2'].value, 241239878.75)
            self.assertEqual(sheet_ranges['E2'].value, None)
            self.assertEqual(sheet_ranges['F2'].value, '=IFERROR(IF(C2="CNY",D2+E2, 1 * (D2+E2) ),0)')

        with patch.object(ReportService, 'query_pboc_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_pboc_sheet()

    def test_init_customer_sheet(self):
        customer_data_list=[{'local_branch': '200', 'cbs_id': '300728', 'wss_id': '560155', 'pix_id': None, 'uen': '36157454', 'otl_id': None, 'uniform_social_credit_code': None, 'customer_name_cn': '风华矿业投***********', 'customer_name_en': '风华矿业>投***********', 'customer_category': 'CORPORATE', 'nationality': 'HK', 'country': 'CN', 'exposure_country': 'HK', 'area': '2 异地', 'corp_type': '2 外资机构', 'corp_size': '5.>不适用', 'industry_code': 'F51 批发业', 'holding_type': None, 'unique_id_value': '636***801', 'group_code': None, 'group_name': None, 'group_chinese_name': None, 'status': 'O', 'data_date': '20200331', 'connection_uen': None, 'connection_name': None}]
        customer_g14_group_ind_ls = None
        daily_report = LreDailyReport('20200331')
        daily_report.load_target_report()

        with patch.object(ReportService, 'cal_customer_data', return_value=(customer_data_list, customer_g14_group_ind_ls)):
            daily_report.init_customer_sheet()
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.CUSTOMER.value]

            self.assertEqual(sheet_ranges['A2'].value, '200')
            self.assertEqual(sheet_ranges['B2'].value, '300728')
            self.assertEqual(sheet_ranges['H2'].value, '风华矿业投***********')

        with patch.object(ReportService, 'cal_customer_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_customer_sheet()
        
    def test_init_dsc_sheet(self):
        dsc_data_list=[{'cbs_id': '300302', 'beneficiary_cbs_id': None, 'riskparty_uen': '10000584', 'riskparty_cbsid': '300302', 'product': 'Advance', 'with_bank_customer': 'IFI', 'riskparty_cbsid_2': '300302', 'riskpary_uen_2': '10000584', 'currency': 'USD', 'amount': Decimal('2903201.23'), 'interest_in_advance': 'N', 'income_accrual_amount': Decimal('24356.6967'), 'our_ref': 'BMBJ222495AV'}]
        
        daily_report=LreDailyReport('20200331')
        daily_report.load_target_report()
        
        with patch.object(ReportService,'query_dsc_data',return_value=dsc_data_list), patch.object(ReportService, 'query_cny_rate_from_cache', return_value=7.0851):
            daily_report.init_dsc_sheet()
       
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.DSC.value]
            

            self.assertEqual(sheet_ranges['A2'].value, '300302')
            self.assertEqual(sheet_ranges['H2'].value, 'Advance')
            self.assertEqual(sheet_ranges['V2'].value, 'USD')
            self.assertEqual(sheet_ranges['W2'].value, 2903201.23)
            self.assertEqual(sheet_ranges['CO2'].value, '=IF(AK2="Y",IFERROR(IF(V2="CNY",W2, W2 * 7.0851 ) ,0),IFERROR(IF(V2="CNY",W2+AR2, (W2+AR2)* 7.0851 ),0))')

              
        with patch.object(ReportService, 'query_dsc_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_dsc_sheet()
            
    def test_init_auto_fin_sheet(self):
        fin_data_list=[{'cbs_id': None, 'currency': 'CNY', 'amount': Decimal('200000000'), 'interest_received_to_gl': None}]
        daily_report=LreDailyReport('20200331')
        daily_report.load_target_report()
        
        with patch.object(ReportService,'query_auto_fin_data',return_value=fin_data_list), patch.object(ReportService, 'query_cny_rate_from_cache', return_value=7.0851):
            daily_report.init_auto_fin_sheet()
       
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.AUTO_FIN.value]
            
            self.assertEqual(sheet_ranges['C2'].value, 'CNY')
            self.assertEqual(sheet_ranges['D2'].value, 200000000)
            self.assertEqual(sheet_ranges['F2'].value, '=IFERROR(IF(C2="CNY",D2+E2, 1 * (D2+E2) ),0)')
            
        with patch.object(ReportService, 'query_auto_fin_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_auto_fin_sheet()            
            
    def test_init_credit_exposure_sheet(self):
        credit_exposure_data_list=[{'customer_id': '301015', 'borrower': 'GRAYHILL ELECTR********************************', 'revocable': 'Revocable', 'available_credit_limit': Decimal('97.98908'), 'guarantor_type_1': 'Commercial Bank', 'name_guarantor_1': 'BMO Ha**************', 'org_period_in_one_year': 'Y', 'uen_guarantor_1': '11001382'}]
        daily_report=LreDailyReport('20200331')
        daily_report.load_target_report()
        
        with patch.object(ReportService,'query_credit_exposure_data',return_value=credit_exposure_data_list):
            daily_report.init_credit_exposure_sheet()
       
            wb = load_workbook(os.path.join(constant.CREATED_REPORT_PATH, 'Large_Risk_Exposure_Daily_Report-20200331.xlsx'))
            sheet_ranges = wb[LreDailyReportSpreadSheets.CREDIT_EXPOSURE.value]
            
            self.assertEqual(sheet_ranges['A2'].value, '301015')
            self.assertEqual(sheet_ranges['C2'].value, 'Revocable')
            self.assertEqual(sheet_ranges['D2'].value, 97.98908)
            
        with patch.object(ReportService, 'query_credit_exposure_data', side_effect=Exception('dummy exception')), self.assertRaises(ReportException):
            daily_report.init_credit_exposure_sheet() 


if __name__ == "__main__":
    unittest.main(verbosity=2)
