# -*- coding: utf-8 -*-

"""
Created on 2020-12-02

@author: Wang Shuo
"""

import logging
import os
import unittest
from unittest.mock import patch

from bmolre.commons.constant import CFG_DEBUG
from bmolre.commons.logging import get_logger


class TestLogger(unittest.TestCase):
        
    def test_get_logger(self):
        
        with patch.dict(os.environ, {CFG_DEBUG: 'False'}):
            logger = get_logger()
            self.assertEqual(logger.name, 'root')
            self.assertEqual(logger.level, logging.INFO)
        
        with patch.dict(os.environ, {CFG_DEBUG: 'True'}):
            logger = get_logger()
            self.assertEqual(logger.name, 'root')
            self.assertEqual(logger.level, logging.DEBUG)

        with patch.dict(os.environ):
            if CFG_DEBUG in os.environ:
                del os.environ[CFG_DEBUG]
            logger = get_logger()
            self.assertEqual(logger.name, 'root')
            self.assertEqual(logger.level, logging.DEBUG)

        with patch.dict(os.environ, {CFG_DEBUG: 'True'}):
            logger_name = 'bmolre.services.report_services.LreDailyReport'
            logger = get_logger(logger_name)
            self.assertEqual(logger.name, logger_name)
            self.assertEqual(logger.getEffectiveLevel(), logging.DEBUG)
            with self.assertLogs(logger_name, 'INFO') as cm:
                logger.info('dummy logs')
                self.assertEqual(cm.output, ['INFO:bmolre.services.report_services.LreDailyReport:dummy logs'])

if __name__ == "__main__":
    unittest.main(verbosity=2)
