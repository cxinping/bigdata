# -*- coding: utf-8 -*-

import unittest
from bmolre import create_app
from bmolre.commons.logging import get_logger
from bmolre.commons.report_enums import ReportType
from bmolre.exts import db
from bmolre.services.report_cal_services import ReportService


log = get_logger(__name__)


class TestReportService(unittest.TestCase):

    def setUp(self):
        app = create_app(config_object='config.default', config_map={'DEBUG': True})
        db.init_app(app)
        self.app = app
        self.report_service = ReportService()
        self.data_date = '20200331'

    def tearDown(self):
        pass

    def test_cal_ead_report_data(self):
        print('* run test_cal_ead_report_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                ead_data = self.report_service.cal_ead_report_data(data_date=self.data_date,
                                                                   report_type=ReportType.DAILY_REPORT)
                self.assertIsNotNone(ead_data)
            except Exception as err:
                print(str(err))

    def test_query_fefc_data(self):
        print('* run test_query_fefc_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                fefc_data = self.report_service.query_fefc_data(data_date=self.data_date)
                self.assertIsNotNone(fefc_data)
            except Exception as err:
                print(str(err))

    def test_init_rate_data(self):
        print('* run test_init_rate_data()')

        with self.app.app_context():
            rate_data = self.report_service.init_rate_data(self.data_date)
            self.assertIsNotNone(rate_data)

    def test_query_cny_rate_from_cache(self):
        print('* run test_query_cny_rate_from_cache() begin')

        with self.app.app_context():
            ccy_rate = self.report_service.query_cny_rate_from_cache(self.data_date, 'USD')
            self.assertIsNotNone(ccy_rate)
            print('*** ccy_rate=', ccy_rate)

    def test_cal_loan_data(self):
        print('* run test_cal_loan_data()')

        with self.app.app_context():
            loan_cn_data = self.report_service.query_loan_data(data_date=self.data_date)
            self.assertIsNotNone(loan_cn_data)

    def test_query_indirect_customer_from_trade_finance_transaction(self):
        print('* run test_query_indirect_customer_from_trade_finance_transaction()')

        with self.app.app_context():
            indirect_customer_from_trade_finance_transaction_data = self.report_service.query_indirect_customer_from_trade_finance_transaction(
                data_date=self.data_date)
            self.assertIsNotNone(indirect_customer_from_trade_finance_transaction_data)

    def test_query_capital_data(self):
        print('* run test_query_capital_data()')
        self.data_date = '20200331'

        with self.app.app_context():
            try:
                capital_data = self.report_service.query_capital_data(data_date=self.data_date,
                                                                      report_type=ReportType.DAILY_REPORT)
                self.assertIsNotNone(capital_data)
            except Exception as err:
                print(str(err))

    def test_query_money_market_data(self):
        print('* run test_query_money_market_data()')
        self.data_date = '20200331'

        with self.app.app_context():
            try:
                daily_mm505_data = self.report_service.query_daily_money_market_data(data_date=self.data_date)
                self.assertIsNotNone(daily_mm505_data)

                g14_mm505_data = self.report_service.query_g14_money_market_data(data_date=self.data_date)
                self.assertIsNotNone(g14_mm505_data)
            except Exception as err:
                print(str(err))

    def test_query_dsc_data(self):
        print('* run test_query_dsc_data()')
        self.data_date = '20200331'

        with self.app.app_context():
            try:
                dsc_data = self.report_service.query_dsc_data(data_date=self.data_date)
                self.assertIsNotNone(dsc_data)
            except Exception as err:
                print(str(err))

    def test_query_llp_data(self):
        print('* run test_query_llp_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                llp_data = self.report_service.query_llp_data(data_date=self.data_date,
                                                              report_type=ReportType.DAILY_REPORT)
                self.assertIsNotNone(llp_data)
            except Exception as err:
                print(str(err))

    def test_cal_limit_data(self):
        print('* run test_cal_limit_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                limit_data = self.report_service.cal_limit_data(data_date=self.data_date)
                self.assertIsNotNone(limit_data)
            except Exception as err:
                print(str(err))

    def test_query_auto_fin_data(self):
        print('* run test_query_auto_fin_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                auto_fin_data = self.report_service.query_auto_fin_data(report_type=ReportType.DAILY_REPORT,data_date=self.data_date)
                self.assertIsNotNone(auto_fin_data)
            except Exception as err:
                print(str(err))

    def test_query_offbs_tf_data(self):
        print('* run test_query_offbs_tf_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                offbs_tf_data = self.report_service.query_offbs_tf_data(data_date=self.data_date)
                self.assertIsNotNone(offbs_tf_data)
            except Exception as err:
                print(str(err))

    def test_query_bond_ncd_data(self):
        print('* run test_query_bond_ncd_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                offbs_tf_data = self.report_service.query_bond_ncd_data(data_date=self.data_date,
                                                                        report_type=ReportType.DAILY_REPORT)
                self.assertIsNotNone(offbs_tf_data)
            except Exception as err:
                print(str(err))

    def test_query_pboc_data(self):
        print('* run test_query_pboc_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                pboc_data = self.report_service.query_pboc_data(data_date=self.data_date)
                self.assertIsNotNone(pboc_data)
            except Exception as err:
                print(str(err))

    def test_query_credit_exposure_data(self):
        print('* run test_query_credit_exposure_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                credit_exposure_data = self.report_service.query_credit_exposure_data(data_date=self.data_date)
                self.assertIsNotNone(credit_exposure_data)
            except Exception as err:
                print(str(err))

    def test_is_holidays(self):
        print('* run test_is_holidays()')
        self.data_date = '20201001'
        with self.app.app_context():
            try:
                is_holidays = self.report_service.is_holidays(data_date=self.data_date)
                self.assertIsNotNone(is_holidays)
            except Exception as err:
                print(str(err))

if __name__ == "__main__":
    unittest.main(verbosity=2)
