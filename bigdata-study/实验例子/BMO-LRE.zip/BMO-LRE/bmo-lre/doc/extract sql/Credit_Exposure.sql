--CREDIT_EXPOSURE
select CUSTOMER_ID,
       BORROWER,
       Revocable,
       available_credit_limit,
       GUARANTOR_TYPE_1,
       NAME_GUARANTOR_1,
       org_period_in_one_year
  from rra_sids.S_FLC_CREDIT_EXPOSURE
 where data_date = '20200630'
