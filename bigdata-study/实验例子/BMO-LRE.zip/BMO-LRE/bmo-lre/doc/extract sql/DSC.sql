 select RISKPARTY_CBSID CBS_ID,
               BENEFICIARY_CBS_ID,  
               RISKPARTY_UEN,
               RISKPARTY_CBSID,
               PRODUCT,
               WITH_BANK_CUSTOMER,
               RISKPARTY_CBSID RISKPARTY_CBSID2,
               RISKPARTY_UEN RISKPARTY_UEN2,
               CURRENCY,
               AMOUNT,
               INTEREST_IN_ADVANCE,
               INCOME_ACCRUAL_AMOUNT,
               OUR_REF
          from rra_inx.REP_ME_DISCOUNT_DB T
         where report_date = :data_date 
           and TO_CHAR(PRINCIPAL_MATURITY_DATE, 'YYYYMMDD') > :data_date
