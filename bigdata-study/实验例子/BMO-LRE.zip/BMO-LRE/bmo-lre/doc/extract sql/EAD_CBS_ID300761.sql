/*select '300761' CBS_ID,
       '560022' IBUK_Customer,
       null EAD_Total,
       round(RISK_EXPOSURE / 10000, 2) * 10000 EAD_CNY_EQV,
       '300761' CBS_ID
  from RRA_INX.RRF_ME_CP_CREDIT_RISK_FACT
 where di_item_cd = 'IT_G4B_3_05'
   and data_date = substr('20200630', 0, 6)*/

--update daily sql

   
   
   WITH TMP_A AS
 (SELECT /*+materialize*/
   NVL(SUM(T.BALANCE), 0) BALANCE
    FROM RRA_GBDS.GBDS_GL T
   WHERE T.ACT_ITEM_CODE = '102051000'
     AND T.BRANCH_CODE = '000'
     AND T.CURRENCY = '946'
     AND T.DATA_DATE = :data_date ),
TMP_B AS
 (SELECT /*+materialize*/
   NVL(SUM(RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date ,
                                                'USD',
                                                'CNY',
                                                RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date ,
                                                                                     'CAD',
                                                                                     'USD',
                                                                                     T.EAD,
                                                                                     'STAND'),
                                                'SAFE_MID')),
       0) BALANCE
    FROM RRA_SIDS.S_MAN_SACCR T
   WHERE T.DATA_DATE = (select MAX(DATA_DATE)
                          from RRA_SIDS.S_MAN_SACCR
                         where data_date <= :data_date )
     AND T.UEN = '35049115'
     AND ((T.SRC_SYS_CD = 'CURRPLUS' AND T.INSTM_TYPE <> 'WRTOPT') OR
         T.SRC_SYS_CD <> 'CURRPLUS'))
SELECT '300761' CBS_ID,
       '560022' IBUK_Customer,
       null EAD_Total,
       ROUND((A.BALANCE + B.BALANCE), 2) EAD_CNY_EQV,
       '300761' CBS_ID
  FROM TMP_A A
  JOIN TMP_B B
    ON 1 = 1