--4.1.2.3.3
select DATA_DATE, UEN, CONNECTION_UEN, CONNECTION_NAME, null Status
  from rra_sids.s_Man_Connection_Info
 where data_date = '20200331'
