  SELECT cbs_cust_id , currency,amount, interest_received_to_gl
    FROM RRA_SIDS.S_MAN_LOAN_DETAILS
   WHERE lower(status) != 'ex'
     AND lower(status) != 'expired'
     AND finished is null
     AND data_date = :data_date
