 --other inputs part4
   --���У�ͬҵ���
   
 
 SELECT 20201231 data_date,
        '���У�ͬҵ���' ITEM_NAME,
        ROUND(SUM(BALANCE) / 10000, 2) TOTAL_IN_CNY_AMOUNT
   FROM RRA_GBDS.GBDS_GL
  WHERE DATA_DATE = 20201231
    AND ACT_ITEM_CODE IN (104110111,
                          104110112,
                          104110120,
                          104110201,
                          104110202,
                          104110300,
                          104110400,
                          104110500,
                          104110600,
                          104210110,
                          104210120,
                          104210210,
                          104210220,
                          104210300,
                          104210400,
                          104210500,
                          104210600)
    AND CURRENCY = '946'
    AND BRANCH_CODE = '000' 
