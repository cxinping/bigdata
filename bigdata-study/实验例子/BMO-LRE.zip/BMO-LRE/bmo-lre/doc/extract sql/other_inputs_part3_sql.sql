  --other inputs part3 ITEM 1-58
   select 20201231 data_date,
          ITEM_SEQUENCE,
          ITEM_NAME,
          FOREIGN_IN_CNY_AMOUNT,
          CNY_AMOUNT,
          TOTAL_IN_CNY_AMOUNT
     from RRA_INX.REP_CBRC_GL_VIEW
    where  data_date = substr('20201231',0,6)
      and REPORT_ID = 'CBRC1001'
      and ORG_CD = '000'
      and ITEM_SEQUENCE <59
    order by ITEM_SEQUENCE
