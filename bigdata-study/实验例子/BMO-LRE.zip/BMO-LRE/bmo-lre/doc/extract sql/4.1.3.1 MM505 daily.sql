----4.1.3.1 MM505 daily

select T2.CBS_ID,
       T1.Report_Date,
       T1.START_DATE Value_Date,
       Mat_Date,
       Deal_Type,
       Deal_Type Deal_Type_RRA,
       Ccy,
       PRINCIPAL_AMT Amount,
       TOTAL_INTEREST,
       Name_Short,
       TYPE,
       MM_CUST_NUM,
       'Y' Inventory,
       MM_CUST_NUM Customer_Short_Name,
       T2.CBS_ID,
       CASE
         WHEN t1.ccy = 'CNY' THEN
          T1.PRINCIPAL_AMT
         ELSE
          PACK_UTIL.FUN_GET_CURR_CONV(20200630,
                                      'USD',
                                      'CNY',
                                      PACK_UTIL.FUN_GET_CURR_CONV(20200630,
                                                                  T1.CCY,
                                                                  'USD',
                                                                  T1.PRINCIPAL_AMT,
                                                                  'STAND'),
                                      'SAFE_MID')
       END CNY_EQV,
       case
         when to_date('20200630', 'YYYYMMDD') -
              to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
          0
         else
          decode(substr(BASIS_CODE, -3),
                 0,
                 0,
                 ((CASE
                   WHEN t1.ccy = 'CNY' THEN
                    T1.PRINCIPAL_AMT
                 
                   ELSE
                    PACK_UTIL.FUN_GET_CURR_CONV(20200630,
                                                'USD',
                                                'CNY',
                                                PACK_UTIL.FUN_GET_CURR_CONV(20200630,
                                                                            T1.CCY,
                                                                            'USD',
                                                                            T1.PRINCIPAL_AMT,
                                                                            'STAND'),
                                                'SAFE_MID')
                 END) * Rate * (to_date('20200630', 'YYYYMMDD') -
                 to_date(Start_date, 'YYYYMMDD') + 1)) /
                 substr(BASIS_CODE, -3) / 100)
       END interest_AMT --MM 505Lending/placing

  from rra_sids.S_WSS_MM T1
  left join rra_sids.s_cbi_t_cmn_cust_inf T2
    on T1.Mm_Cust_Num = T2.Ibuk_Id
   and T2.Data_Date = '20200630'
 where T1.data_date = '20200630'
   and (T1.TYPE NOT in ('INTR', 'CORP') and
       T1.Name_Short NOT IN ('BMCNBJBEJ',
                              'BMCNSHSHA',
                              'BMOT3773',
                              'BMCNHOBEJ',
                              'BMCNGZGNZ',
                              'EQUITY',
                              'PBCS BEJ'))
   and T1.MAT_DATE > T1.data_date
   and T1.Deal_type = 'XL'
