with S_WSS_MM_TMP as
 (select *
    from (select T.Deal_Number,
                 T.START_DATE,
                 T.Ccy,
                 T.Mat_Date,
                 T.PRINCIPAL_AMT,
                 T.Rate,
                 T.BASIS_CODE,
                 T.Mm_Cust_Num,
                 T.TYPE,
                 T.Name_Short,
                 T.Deal_Type,
                 T.Report_Date,
                 row_number() over(partition by deal_number order by data_date desc) RN
            from rra_sids.S_WSS_MM T
           where (T.TYPE NOT in ('INTR', 'CORP') and
                 T.Name_Short NOT IN ('BMCNBJBEJ',
                                       'BMCNSHSHA',
                                       'BMOT3773',
                                       'BMCNHOBEJ',
                                       'BMCNGZGNZ',
                                       'EQUITY',
                                       'PBCS BEJ'))
             and T.Deal_type = 'XL'
             AND T.Start_Date <= :data_date
             and T.Mat_Date > :data_date)
   where RN = 1)

select T1.Deal_Number,
       T2.CBS_ID,
       T1.Report_Date,
       T1.START_DATE Value_Date,
       Mat_Date,
       Deal_Type,
       Deal_Type Deal_Type_RRA,
       Ccy,
       PRINCIPAL_AMT Amount,
       case
         when to_date(:data_date, 'YYYYMMDD') -
              to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
          0
         else
          decode(substr(BASIS_CODE, -3),
                 0,
                 0,
                 (T1.PRINCIPAL_AMT * Rate *
                 (to_date(:data_date, 'YYYYMMDD') -
                 to_date(Start_date, 'YYYYMMDD') + 1)) /
                 substr(BASIS_CODE, -3) / 100)
       END TOTAL_INTEREST,
       Name_Short,
       TYPE,
       MM_CUST_NUM,
       'Y' Inventory,
       MM_CUST_NUM Customer_Short_Name,
       T2.CBS_ID,
       CASE
         WHEN t1.ccy = 'CNY' THEN
          T1.PRINCIPAL_AMT
         ELSE
          RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                               'USD',
                                               'CNY',
                                               RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                                    T1.CCY,
                                                                                    'USD',
                                                                                    T1.PRINCIPAL_AMT,
                                                                                    'STAND'),
                                               'SAFE_MID')
       END + case
         when to_date(:data_date, 'YYYYMMDD') -
              to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
          0
         else
          decode(substr(BASIS_CODE, -3),
                 0,
                 0,
                 ((CASE
                   WHEN t1.ccy = 'CNY' THEN
                    T1.PRINCIPAL_AMT
                 
                   ELSE
                    RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                         'USD',
                                                         'CNY',
                                                         RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                                              T1.CCY,
                                                                                              'USD',
                                                                                              T1.PRINCIPAL_AMT,
                                                                                              'STAND'),
                                                         'SAFE_MID')
                 END) * Rate * (to_date(:data_date, 'YYYYMMDD') -
                 to_date(Start_date, 'YYYYMMDD') + 1)) /
                 substr(BASIS_CODE, -3) / 100)
       END CNY_EQV,
       case
         when to_date(:data_date, 'YYYYMMDD') -
              to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
          0
         else
          decode(substr(BASIS_CODE, -3),
                 0,
                 0,
                 ((CASE
                   WHEN t1.ccy = 'CNY' THEN
                    T1.PRINCIPAL_AMT
                 
                   ELSE
                    RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                         'USD',
                                                         'CNY',
                                                         RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                                              T1.CCY,
                                                                                              'USD',
                                                                                              T1.PRINCIPAL_AMT,
                                                                                              'STAND'),
                                                         'SAFE_MID')
                 END) * Rate * (to_date(:data_date, 'YYYYMMDD') -
                 to_date(Start_date, 'YYYYMMDD') + 1)) /
                 substr(BASIS_CODE, -3) / 100)
       END interest_AMT
  from S_WSS_MM_TMP T1
  left join rra_sids.s_cbi_t_cmn_cust_inf T2
    on T1.Mm_Cust_Num = T2.Ibuk_Id
   and T2.Data_Date = :data_date
   
   
   
   
   
