select distinct ccy
  from (select BASIC_CCY CCY
          from RRA_GBDS.GBDS_EX_RATE
         where 20200701 between s_date and e_date
           and RATE_TYPE = 'STAND'
        union all
        select FORWARD_CCY CCY
          from RRA_GBDS.GBDS_EX_RATE
         where 20200701 between s_date and e_date
           and RATE_TYPE = 'STAND')