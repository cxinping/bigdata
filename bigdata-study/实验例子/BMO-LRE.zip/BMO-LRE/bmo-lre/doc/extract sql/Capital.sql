--capital   
SELECT CET1_CAPITAL_AMT,
       TIER1_CAPITAL_AMT,
       TOTAL_CAPITAL_AMT,
       RATE,
       DATA_DATE
  FROM RRA_SIDS.S_MAN_FIN_CAPITAL T
 WHERE DATA_DATE = (SELECT MAX(DATA_DATE)
                      FROM RRA_SIDS.S_MAN_FIN_CAPITAL
                     WHERE DATA_DATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE('20200331',
                                                                            'YYYYMMDD'),
                                                                    -1)),
                                                'YYYYMMDD'))
