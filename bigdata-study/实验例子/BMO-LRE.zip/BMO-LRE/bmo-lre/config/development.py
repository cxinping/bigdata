# -*- coding: utf-8 -*-
"""
Created on 2020-10-28

@author: WangShuo
"""

DEBUG = True

# configure database information
SQLALCHEMY_TRACK_MODIFICATIONS = False
SQLALCHEMY_ECHO = True

# Email
MAIL_SERVER = 'QAAPPMAIL.BMOGC.NET'
MAIL_PORT = 25

MAIL_SENDER = 'bmo-lre@no-reply.com'
MAIL_RECIPIENTS = ['cbs.china@nesbittburns.com']
SUPPORT_MAIL_SENDER = 'bmo-lre@no-reply.com'
SUPPORT_MAIL_RECIPIENTS = ['cbs.china@nesbittburns.com']
MONITOR_MAIL_RECIPIENTS = ['cbs.china@nesbittburns.com']

# SFTP
SFTP_HOST = '10.119.61.195'
SFTP_PORT = 22
SFTP_USER = 'bmo-lre'
SFTP_PRIVATE_KEY_PATH = '/opt/bmo-lre/config/id_rsa_bmo-lre'
SFTP_PUT_DIRS = ['/RRA/HQ/COP', '/RRA/HQ/TFO', '/RRA/HQ/TPS', '/RRA/HQ/FIN']

# Monitor
OPEN_EXCEL_URL = 'http://10.119.51.99:5001/report/daily/open/save/'

SFTP_REPORT_HOST = '10.119.61.119'
SFTP_REPORT_PORT = 22
SFTP_REPORT_USER = 'bmo-lre'
SFTP_REPORT_PRIVATE_KEY_PATH = '/opt/bmo-lre/config/id_rsa_bmo-lre'
SFTP_REPORT_PUT_DIRS = ['/home/bmo-lre/report/']