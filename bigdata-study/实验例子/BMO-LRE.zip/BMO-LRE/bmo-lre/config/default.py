# -*- coding: utf-8 -*-
"""
Created on 2020-10-28

@author: WangShuo
"""

DEBUG = False

# Configure database information
SQLALCHEMY_TRACK_MODIFICATIONS = False
SQLALCHEMY_ECHO = False

# Email
MAIL_SERVER = 'smtp.bmogc.net'
MAIL_PORT = 25

MAIL_SENDER = 'no-reply@bmo.com'
MAIL_RECIPIENTS = ['ChinaLREDailyReport@bmo.com']
SUPPORT_MAIL_SENDER = 'TIChinaAlert@bmo.com'
SUPPORT_MAIL_RECIPIENTS = ['ChinaAST-NTP@bmo.com']
MONITOR_MAIL_RECIPIENTS = ['ChinaAST-NTP@bmo.com']

# SFTP
SFTP_HOST = '10.119.35.58'
SFTP_PORT = 22
SFTP_USER = 'sa_ti_lre'
SFTP_PRIVATE_KEY_PATH = '/opt/bmo-lre/config/id_rsa_bmo-lre'
SFTP_PUT_DIRS = ['/COP', '/TFO', '/TPS', '/FIN']

# Monitor
OPEN_EXCEL_URL = 'http://10.119.51.99:5001/report/daily/open/save/'

SFTP_REPORT_HOST = '10.119.61.119'
SFTP_REPORT_PORT = 22
SFTP_REPORT_USER = 'bmo-lre'
SFTP_REPORT_PRIVATE_KEY_PATH = '/opt/bmo-lre/config/id_rsa_bmo-lre'
SFTP_REPORT_PUT_DIRS = ['/home/bmo-lre/report/']



