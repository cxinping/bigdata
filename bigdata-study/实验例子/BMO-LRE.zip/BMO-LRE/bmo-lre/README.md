## Prerequisites
* Python 3.6.8 which is officially provided by Redhat
* Flask 1.1.2
* Flask-SQLAlchemy 2.4.4
* Flask-Mail 0.9.1
* Flask-Security 3.0.0
* Flask-JWT-Extended 3.25.0
* psycopg2  2.8.6
* openpyxl 3.0.5
* pandas 1.1.4
* cachelib 0.1.1
* cx_Oracle 8.0.1
* Oracle Instant Client 19.9
* pycryptodome
* paramiko 2.7.2
* requests 2.7.0

## Installation
[LRE Implementation Guide](https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:9443/display/KB/LRE+Implementation+Guide)

## Usage
### Generate daily report
```
https://{server:port}//report/daily/{data_date}
```

### Generate G14 reports
```
https://{server:port}//report/g14/{data_date}
```

## Repository
```
http://10.119.61.92:7990/projects/LRE/repos/bmo-lre/browse
```
