# -*- coding: utf-8 -*-
'''
Created on 2020-10-28

@author: WangShuo
'''
import os
from setuptools import find_packages, setup

pkg_vars  = {}
with open("bmolre/_version.py") as fp:
    exec(fp.read(), pkg_vars)

version = pkg_vars['__version__']

if 'BAMBOO_BUILDNUMBER' in os.environ:
    version += '.' + os.environ['BAMBOO_BUILDNUMBER']
elif 'bamboo_buildNumber' in os.environ:
    version += '.' + os.environ['bamboo_buildNumber']

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name='bmo-lre',
    version=version,
    packages=find_packages(),
    description='BMO LRE Service',
    long_description=long_description,
    long_description_content_type="text/markdown",
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    include_package_data=True,
    zip_safe=False,
    python_requires='>=3.6',
    url='http://10.119.61.92:7990/projects/LRE/repos/bmo-lre/browse',
    author='Wang, Shuo',
    author_email='Shuo.Wang@bmo.com',
    license='©2021 BMO Financial Group. All copyrights reserved.'
)