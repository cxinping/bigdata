# -*- coding: utf-8 -*-

"""
Created on 2020-11-13

@author: Wang Shuo
"""

from bmolre.commons.logging import get_logger
from bmolre.commons.report_enums import (
    RateSheetEnum, LoanSheetEnum, OtherInputsSheetEnum, CustomerSheetEnum,
    EadSheetEnum, MM505SheetEnum, DscSheetEnum, LlpSheetEnum, NostroSheetEnum,
    LimitSheetEnum, AutoFinSheetEnum, OffbsTfSheetEnum, BondNcdSheetEnum,
    PbocSheetEnum, CreditExposureSheetNum, ReportType, FefcSheetNum
)
import bmolre.models.data_models as rra_db
from bmolre.exceptions import DataException

log = get_logger(__name__)


class DataService(object):

    def __init__(self):
        pass

    def query_rate_data(self, data_date):
        """
        查询外币到人民币的汇率
        :param data_date: 取数日期
        """

        rate_ccy_list = rra_db.query_rate_currency(data_date)
        ls = []

        try:
            forward_ccy = 'CNY'
            for rate_ccy_item in rate_ccy_list:
                basic_ccy = rate_ccy_item['ccy']
                s_date = data_date
                e_date = data_date

                foreign_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(date_date=data_date,
                                                                             foreign_ccy=basic_ccy, amount=1)['end']
                if foreign_cny_ccy_rate is None:
                    raise DataException('The rates value searched by data_date is empty, check rates.')

                foreign_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=basic_ccy,
                                                                    forward_ccy=forward_ccy,
                                                                    ccy_rate=foreign_cny_ccy_rate)
                ls.append(foreign_cny_ccy_obj)
        except DataException as err:
            raise err
        except Exception as err:
            raise DataException(str(err))
        
        return ls

    def query_usd_to_cny_rate(self, data_date):
        """
        查询美元到人民币的汇率
        :param data_date: 取数日期
        """
        usd_cny_rate_obj = rra_db.query_safe_mid_rate_data(data_date, 'USD', 'CNY')

        if usd_cny_rate_obj:
            return usd_cny_rate_obj['ccy_rate']
        else:
            raise DataException('Exchange rate from USD to RMB is empty in {}, please check it.'.format(data_date))

    def __create_rate_table_item(self, s_date, e_date, basic_ccy, forward_ccy, ccy_rate):
        return {
            RateSheetEnum.S_DATE.value: s_date,
            RateSheetEnum.E_DATE.value: e_date,
            RateSheetEnum.BASIC_CCY.value: basic_ccy,
            RateSheetEnum.FORWARD_CCY.value: forward_ccy,
            RateSheetEnum.CCY_RATE.value: ccy_rate
        }

    def query_loan_data(self, data_date):
        loans = rra_db.query_loan_data(data_date)
        if loans is None:
            raise DataException('The loan data was searched by {} is empty, please check it'.format(data_date))

        results = []

        for loan_item in loans:
            loan_obj = self.__create_loan_table_item(data_date=data_date, cbs_cust_id=loan_item['cbs_cust_id'],
                                                     amount=loan_item['amount'],
                                                     currency=loan_item['currency'],
                                                     interest_received_to_gl=loan_item['interest_received_to_gl'],
                                                     status=loan_item['status'],
                                                     our_ref=loan_item['our_ref']
                                                     )
            results.append(loan_obj)

        return results

    def __create_loan_table_item(self, data_date, cbs_cust_id, currency, amount, interest_received_to_gl, status,
                                 our_ref):
        return {
            LoanSheetEnum.DATA_DATE.value: data_date,
            LoanSheetEnum.CBS_CUST_ID.value: cbs_cust_id,
            LoanSheetEnum.CURRENCY.value: currency,
            LoanSheetEnum.AMOUNT.value: amount,
            LoanSheetEnum.INTEREST_RECEIVED_TO_GL.value: interest_received_to_gl,
            LoanSheetEnum.STATUS.value: status,
            LoanSheetEnum.OUR_REF.value: our_ref
        }

    def query_customer_list_report(self, data_date):
        """
        At BMOS008_sql.sql
        4.1.2.3.1 Extract BMO Customer to LRE Calculation
        In the working file, BMO Customer data use RRA BMOS0008 customer list report as data source.
        Select customer with Status = O in RRAS0008.
        :param data_date: 取数日期
        """

        customer_data_list = rra_db.query_customer_list_report(data_date=data_date)
        customer_ls = []
        if customer_data_list is None:
            raise DataException(
                '4.1.2.3.1 customer_data_list is empty, whether there is RRAS0008 data on {}'.format(data_date))

        for customer_data in customer_data_list:
            customer_obj = self.__create_customer_item(local_branch=customer_data['local_branch'],
                                                       cbs_id=customer_data['cbs_id'], wss_id=customer_data['wss_id'],
                                                       pix_id=customer_data['pix_id'], uen=customer_data['uen'],
                                                       otl_id=customer_data['otl_id'],
                                                       uniform_social_credit_code=customer_data[
                                                           'uniform_social_credit_code'],
                                                       customer_name_cn=customer_data['customer_name_cn'],
                                                       customer_name_en=customer_data['customer_name_en'],
                                                       customer_category=customer_data['customer_category'],
                                                       nationality=customer_data['nationality'],
                                                       country=customer_data['country'],
                                                       exposure_country=customer_data['exposure_country'],
                                                       area=customer_data['area'], corp_type=customer_data['corp_type'],
                                                       corp_size=customer_data['corp_size'],
                                                       industry_code=customer_data['industry_code'],
                                                       holding_type=customer_data['holding_type'],
                                                       unique_id_value=customer_data['unique_id_value'],
                                                       group_code=customer_data['group_code'],
                                                       group_name=customer_data['group_name'],
                                                       group_chinese_name=customer_data['group_chinese_name'],
                                                       status=customer_data['status'],
                                                       data_date=customer_data['data_date'],
                                                       connection_uen=customer_data['connection_uen'],
                                                       connection_name=customer_data['connection_name'])
            customer_ls.append(customer_obj)
        return customer_ls

    def query_indirect_customer_from_trade_finance_transaction(self, data_date):
        """
        4.1.2.3.2.1 Extract Indirect Customer Data to LRE Calculation - Limit Customer from Trade Finance Transaction and Issuer from Bond/NCD
        Limit Customer from Trade Finance Transaction
        Source: Limit customer of trade finance deal transaction.
        Reference : RRA report BMOS0018
        :param data_date: 取数日期
        """

        customer_data_list = rra_db.query_indirect_customer_from_trade_finance_transaction(data_date=data_date)
        customer_ls = []
        if customer_data_list is None:
            raise DataException(
                '4.1.2.3.2.1 customer_data_list is empty, whether there is BMOS0018 data on {}'.format(data_date))

        for customer_item in customer_data_list:
            customer_obj = self.__create_customer_item(local_branch=None,
                                                       cbs_id=customer_item['cbs_id'], wss_id=None,
                                                       pix_id=None, uen=customer_item['uen'],
                                                       otl_id=customer_item['otl_id'],
                                                       uniform_social_credit_code=customer_item[
                                                           'uniform_social_credit_code'],
                                                       customer_name_cn=customer_item['customer_name_cn'],
                                                       customer_name_en=customer_item['customer_name_en'],
                                                       customer_category=customer_item['customer_category'],
                                                       nationality=customer_item['nationality'],
                                                       country=customer_item['country'],
                                                       exposure_country=customer_item['exposure_country'],
                                                       area=None, corp_type=None,
                                                       corp_size=None,
                                                       industry_code=None,
                                                       holding_type=None,
                                                       unique_id_value=customer_item['unique_id_value'],
                                                       group_code=customer_item['group_code'],
                                                       group_name=customer_item['group_name'],
                                                       group_chinese_name=None,
                                                       status=None,
                                                       data_date=customer_item['data_date'],
                                                       connection_uen=customer_item['connection_uen'],
                                                       connection_name=customer_item['connection_name'])
            customer_ls.append(customer_obj)
        return customer_ls

    def __create_customer_item(self, local_branch, cbs_id, wss_id, pix_id, uen,
                               otl_id, uniform_social_credit_code, customer_name_cn,
                               customer_name_en, customer_category, nationality,
                               country, exposure_country, area, corp_type,
                               corp_size, industry_code, holding_type, unique_id_value,
                               group_code, group_name, group_chinese_name, status, data_date, connection_uen,
                               connection_name):
        return {
            CustomerSheetEnum.LOCAL_BRANCH.value: local_branch,
            CustomerSheetEnum.CBS_ID.value: cbs_id,
            CustomerSheetEnum.WSS_ID.value: wss_id,
            CustomerSheetEnum.PIX_ID.value: pix_id,
            CustomerSheetEnum.UEN.value: uen,
            CustomerSheetEnum.OTL_ID.value: otl_id,
            CustomerSheetEnum.UNIFORM_SOCIAL_CREDIT_CODE.value: uniform_social_credit_code,
            CustomerSheetEnum.CUSTOMER_NAME_CN.value: customer_name_cn,
            CustomerSheetEnum.CUSTOMER_NAME_EN.value: customer_name_en,
            CustomerSheetEnum.CUSTOMER_CATEGORY.value: customer_category,
            CustomerSheetEnum.NATIONALITY.value: nationality,
            CustomerSheetEnum.COUNTRY.value: country,
            CustomerSheetEnum.EXPOSURE_COUNTRY.value: exposure_country,
            CustomerSheetEnum.AREA.value: area,
            CustomerSheetEnum.CORP_TYPE.value: corp_type,
            CustomerSheetEnum.CORP_SIZE.value: corp_size,
            CustomerSheetEnum.INDUSTRY_CODE.value: industry_code,
            CustomerSheetEnum.HOLDING_TYPE.value: holding_type,
            CustomerSheetEnum.UNIQUE_ID_VALUE.value: unique_id_value,
            CustomerSheetEnum.GROUP_CODE.value: group_code,
            CustomerSheetEnum.GROUP_NAME.value: group_name,
            CustomerSheetEnum.GROUP_CHINESE_NAME.value: group_chinese_name,
            CustomerSheetEnum.STATUS.value: status,
            CustomerSheetEnum.DATA_DATE.value: data_date,
            CustomerSheetEnum.CONNECTION_UEN.value: connection_uen,
            CustomerSheetEnum.CONNECTION_NAME.value: connection_name
        }

    def query_capital_data(self, data_date, report_type):
        """
        查询资本净额和一级资本净额       
        :param data_date: 取数日期
        :param report_type: 报表类型
        """
        capital_data = None

        if report_type == ReportType.G14_REPORT:
            capital_data = rra_db.query_g14_capital_data(data_date=data_date)
        elif report_type == ReportType.DAILY_REPORT:
            capital_data = rra_db.query_daily_capital_data(data_date=data_date)

        if capital_data is None:
            raise DataException('capital_data is empty, whether there is capital data on {}'.format(data_date))

        if report_type == ReportType.G14_REPORT:
            query_data_date = capital_data['data_date']
            if query_data_date != data_date:
                raise DataException('query_data_date did not equals data_date , capital_data is empty, whether there is capital data on {}'.format(data_date))

        return self.__create_capital_item(tier1_capital_amt=capital_data['tier1_capital_amt'],
                                          total_capital_amt=capital_data['total_capital_amt'])

    def __create_capital_item(self, tier1_capital_amt, total_capital_amt):
        return {
            OtherInputsSheetEnum.TIER1_CAPITAL_AMT.value: tier1_capital_amt,
            OtherInputsSheetEnum.TOTAL_CAPITAL_AMT.value: total_capital_amt
        }

    def query_interbank_financing_business_data(self, data_date):
        """
        查询同业融资业务
        :param data_date: 取数日期
        """
        ifb_data = rra_db.query_interbank_financing_business_data(data_date)

        if ifb_data is None:
            raise DataException('interbank_financing_business_data is empty, whether there is capital data on {}'.format(data_date))

        return self.__create_interbank_financing_business_item(rank_cd=ifb_data['rank_cd'], fin_institution_name_cd=ifb_data['fn_institution_name_cd'], fin_institution_code_cd=ifb_data['fn_institution_code_cd'], ib_drawdown_amt=ifb_data['ib_drawdown_amt'],
                        ib_lending_amt=ifb_data['ib_lending_amt'], ib_borrow_amt=ifb_data['ib_borrow_amt'], payment_amt=ifb_data['payment_amt'], nostro_amt=ifb_data['nostro_amt'], buy_back_sale_amt=ifb_data['buy_back_sale_amt'], oth_ib_financing_amt=ifb_data['oth_ib_financing_amt'],
                        total_ib_financing_amt=ifb_data['total_ib_financing_amt'],reduce_ib_financing_amt=ifb_data['reduce_ib_financing_amt'], proportion_capital=ifb_data['proportion_capital'] , settle_ib_deposit=ifb_data['settle_ib_deposit'], zero_rw_asset=ifb_data['zero_rw_asset'])

    def __create_interbank_financing_business_item(self, rank_cd, fin_institution_name_cd, fin_institution_code_cd, ib_drawdown_amt,
                        ib_lending_amt, ib_borrow_amt, payment_amt, nostro_amt, buy_back_sale_amt, oth_ib_financing_amt,
                        total_ib_financing_amt,reduce_ib_financing_amt, proportion_capital , settle_ib_deposit, zero_rw_asset ):
        return {
            OtherInputsSheetEnum.RANK_CD.value : rank_cd,
            OtherInputsSheetEnum.FN_INSTITUTION_NAME_CD.value: fin_institution_name_cd,
            OtherInputsSheetEnum.FN_INSTITUTION_CODE_CD.value: fin_institution_code_cd,
            OtherInputsSheetEnum.IB_DRAWDOWN_AMT.value: ib_drawdown_amt,
            OtherInputsSheetEnum.IB_LENDING_AMT.value: ib_lending_amt,
            OtherInputsSheetEnum.IB_BORROW_AMT.value: ib_borrow_amt,
            OtherInputsSheetEnum.PAYMENT_AMT.value: payment_amt,
            OtherInputsSheetEnum.NOSTRO_AMT.value: nostro_amt,
            OtherInputsSheetEnum.BUY_BACK_SALE_AMT.value: buy_back_sale_amt,
            OtherInputsSheetEnum.OTH_IB_FINANCING_AMT.value : oth_ib_financing_amt,
            OtherInputsSheetEnum.TOTAL_IB_FINANCING_AMT.value : total_ib_financing_amt,
            OtherInputsSheetEnum.REDUCE_IB_FINANCING_AMT.value: reduce_ib_financing_amt,
            OtherInputsSheetEnum.PROPORTION_CAPITAL.value: proportion_capital,
            OtherInputsSheetEnum.SETTLE_IB_DEPOSIT.value : settle_ib_deposit,
            OtherInputsSheetEnum.ZERO_RW_ASSET.value : zero_rw_asset
        }

    def query_domestic_summary_data1(self, data_date):
        """
         查询 境内汇总数据
         :param data_date: 取数日期

        """

        dsd_data_list = rra_db.query_domestic_summary_data(data_date)

        if dsd_data_list is None:
            raise DataException('domestic_summary_data(境内汇总数据) is empty, whether there is data on {}'.format(data_date))

        dsd_ls = []

        for dsd_item in dsd_data_list:
            dsd_obj = self.__create_domestic_summary_item1(item_name=dsd_item['item_name'], foreign_in_cny_amount=dsd_item['foreign_in_cny_amount'], cny_amount=dsd_item['cny_amount'], total_in_cny_amount=dsd_item['total_in_cny_amount'])
            dsd_ls.append(dsd_obj)

        return dsd_ls

    def __create_domestic_summary_item1(self, item_name, foreign_in_cny_amount, cny_amount, total_in_cny_amount):
        return {
            OtherInputsSheetEnum.ITEM_NAME.value: item_name,
            OtherInputsSheetEnum.FOREIGN_IN_CNY_AMOUNT.value : foreign_in_cny_amount,
            OtherInputsSheetEnum.CNY_AMOUNT.value : cny_amount,
            OtherInputsSheetEnum.TOTAL_IN_CNY_AMOUNT.value: total_in_cny_amount
        }


    def query_domestic_summary_data2(self , data_date):
        """
         查询 其中：同业拆借, 其中：受托方同业代付
         :param data_date: 取数日期

        """
        ild = rra_db.query_interbank_lending_data(data_date)
        if ild is None:
            raise DataException('interbank_lending_data(同业拆借数据) is empty, whether there is data on {}'.format(data_date))

        eppd = rra_db.query_entrusted_party_pays_data(data_date)
        if eppd is None:
            raise DataException('entrusted_party_pays_data(受托方同业代付数据) is empty, whether there is data on {}'.format(data_date))

        return self.__create_domestic_summary_item2(interbank_lending_amount=ild['total_in_cny_amount'], entrusted_party_pays_amount=eppd['total_in_cny_amount'])

    def __create_domestic_summary_item2(self, interbank_lending_amount, entrusted_party_pays_amount):
        return {
            OtherInputsSheetEnum.INTERBANK_LENDING_AMOUNT.value : interbank_lending_amount,
            OtherInputsSheetEnum.ENTRUSTED_PARTY_PAYS_AMOUNT.value : entrusted_party_pays_amount
        }

    def query_ead_report_data(self, data_date, report_type):
        """
        查询 EAD report数据
        :param data_date: 取数日期
        :param report_type: 报表类型
        """

        ead_data_list = None
        if report_type == ReportType.G14_REPORT:
            ead_data_list = rra_db.query_g14_ead_report_data(data_date=data_date)
        elif report_type == ReportType.DAILY_REPORT:
            ead_data_list = rra_db.query_daily_ead_report_data(data_date=data_date)

        ead_ls = []
        if ead_data_list:
            for ead_item in ead_data_list:
                ead_obj = self.__create_ead_report_item(cbs_id=ead_item['cbs_cif_id'],
                                                        counterparty_longname=ead_item['counterparty_long_name'],
                                                        counterparty_type=ead_item['counterparty_type'],
                                                        ibuk_customer_number=ead_item['ibuk_customer_number'],
                                                        ead_usd=ead_item['ead_usd'], ead_cny_eqv=None)
                ead_ls.append(ead_obj)

        return ead_ls

    def query_ead_report_data2(self, data_date, report_type):
        """
        查询 EAD report数据
        :param data_date: 取数日期
        :param report_type: 报表类型
        """

        ead_data_list = None
        if report_type == ReportType.G14_REPORT:
            ead_data_list = rra_db.query_g14_ead_report_data2(data_date=data_date)
        elif report_type == ReportType.DAILY_REPORT:
            ead_data_list = rra_db.query_daily_ead_report_data2(data_date=data_date)

        ead_ls = []

        for ead_item in ead_data_list:
            ead_obj = self.__create_ead_report_item(cbs_id=ead_item['cbs_id'],
                                                    counterparty_longname=None,
                                                    counterparty_type=None,
                                                    ibuk_customer_number=ead_item['ibuk_customer'],
                                                    ead_usd=ead_item['ead_total'], ead_cny_eqv=ead_item['ead_cny_eqv'])
            ead_ls.append(ead_obj)
        return ead_ls

    def __create_ead_report_item(self, cbs_id, counterparty_longname, counterparty_type,
                                 ibuk_customer_number, ead_usd, ead_cny_eqv):
        return {
            EadSheetEnum.CBS_ID.value: cbs_id,
            EadSheetEnum.COUNTERPARTY_LONG_NAME.value: counterparty_longname,
            EadSheetEnum.COUNTERPARTY_TYPE.value: counterparty_type,
            EadSheetEnum.IBUK_CUSTOMER_NUMBER.value: ibuk_customer_number,
            EadSheetEnum.EAD_USD.value: ead_usd,
            EadSheetEnum.EAD_CNY_EQV.value: ead_cny_eqv
        }

    def query_daily_money_market_data(self, data_date):
        mm505_data_list = rra_db.query_daily_money_market_data(data_date)
        mm505_ls = []

        if mm505_data_list is None:
            raise DataException('daily mm505_data_list is empty, whether there is daily MM505 data on {}'.format(data_date))

        for mm505_item in mm505_data_list:
            mm505_obj = self.__create_mm505_item(cbs_id=mm505_item['cbs_id'], report_date=mm505_item['report_date'],
                                                 value_date=mm505_item['value_date'], mat_date=mm505_item['mat_date'],
                                                 deal_type=mm505_item['deal_type'],
                                                 deal_type_rra=mm505_item['deal_type_rra'], ccy=mm505_item['ccy'],
                                                 amount=mm505_item['amount'],
                                                 interest_rec_pay=mm505_item['total_interest'],
                                                 name_short=mm505_item['name_short'], customer_type=mm505_item['type'],
                                                 wss_customer_number=mm505_item['mm_cust_num'],
                                                 inventory=mm505_item['inventory'],
                                                 customer_short_name=mm505_item['customer_short_name'],
                                                 cny_eqv=mm505_item['cny_eqv'], interest_amt=mm505_item['interest_amt'])

            mm505_ls.append(mm505_obj)
        return mm505_ls

    def query_g14_money_market_data(self, data_date):
        """
        查询 g14的money market 数据
        :param data_date: 取数日期
        """
        mm505_data_list = rra_db.query_g14_money_market_data(data_date)
        mm505_ls = []

        if mm505_data_list is None:
            raise DataException('g14 mm505_data_list is empty, whether there is g14 MM505 data on {}'.format(data_date))

        for mm505_item in mm505_data_list:
            mm505_obj = self.__create_mm505_item(cbs_id=mm505_item['cbs_id'], report_date=mm505_item['report_date'],
                                                 value_date=mm505_item['value_date'], mat_date=mm505_item['mat_date'],
                                                 deal_type=mm505_item['deal_type'],
                                                 deal_type_rra=mm505_item['deal_type_rra'], ccy=mm505_item['ccy'],
                                                 amount=mm505_item['amount'],
                                                 interest_rec_pay=mm505_item['total_interest'],
                                                 name_short=mm505_item['name_short'], customer_type=mm505_item['type'],
                                                 wss_customer_number=mm505_item['mm_cust_num'],
                                                 inventory=mm505_item['inventory'],
                                                 customer_short_name=mm505_item['customer_short_name'],
                                                 cny_eqv=mm505_item['cny_eqv'], interest_amt=mm505_item['interest_amt'])

            mm505_ls.append(mm505_obj)
        return mm505_ls

    def __create_mm505_item(self, cbs_id, report_date, value_date, mat_date, deal_type, deal_type_rra, ccy,
                            amount, interest_rec_pay, name_short, customer_type, wss_customer_number, inventory,
                            customer_short_name, cny_eqv, interest_amt):
        return {
            MM505SheetEnum.CBS_ID.value: cbs_id,
            MM505SheetEnum.REPORT_DATE.value: report_date,
            MM505SheetEnum.VALUE_DATE.value: value_date,
            MM505SheetEnum.MAT_DATE.value: mat_date,
            MM505SheetEnum.DEAL_TYPE.value: deal_type,
            MM505SheetEnum.DEAL_TYPE_RRA.value: deal_type_rra,
            MM505SheetEnum.CCY.value: ccy,
            MM505SheetEnum.AMOUNT.value: amount,
            MM505SheetEnum.TOTAL_INTEREST.value: interest_rec_pay,
            MM505SheetEnum.NAME_SHORT.value: name_short,
            MM505SheetEnum.TYPE.value: customer_type,
            MM505SheetEnum.MM_CUST_NUM.value: wss_customer_number,
            MM505SheetEnum.INVENTORY.value: inventory,
            MM505SheetEnum.CUSTOMER_SHORT_NAME.value: customer_short_name,
            MM505SheetEnum.CNY_EQV.value: cny_eqv,
            MM505SheetEnum.INTEREST_AMT.value: interest_amt,
        }

    def query_dsc_data(self, data_date):
        """
        查询 DSC 数据
        :param data_date: 取数日期
        """
        dsc_data_list = rra_db.query_dsc_data(data_date)
        dsc_ls = []

        if dsc_data_list is None:
            raise DataException('dsc_data_list is empty, whether there is DSC data on {}'.format(data_date))

        for dsc_item in dsc_data_list:
            dsc_obj = self.__create_dsc_item(cbs_id=dsc_item['cbs_id'],
                                             beneficiary_cbs_id=dsc_item['beneficiary_cbs_id'],
                                             riskparty_uen=dsc_item['riskparty_uen'],
                                             riskparty_cbsid=dsc_item['riskparty_cbsid'], product=dsc_item['product'],
                                             with_bank_customer=dsc_item['with_bank_customer'],
                                             riskparty_cbsid_2=dsc_item['riskparty_cbsid2'],
                                             riskpary_uen_2=dsc_item['riskparty_uen2'], currency=dsc_item['currency'],
                                             amount=dsc_item['amount'],
                                             interest_in_advance=dsc_item['interest_in_advance'],
                                             income_accrual_amount=dsc_item['income_accrual_amount'],
                                             our_ref=dsc_item['our_ref'])

            dsc_ls.append(dsc_obj)
        return dsc_ls

    def __create_dsc_item(self, cbs_id, beneficiary_cbs_id, riskparty_uen, riskparty_cbsid, product, with_bank_customer,
                          riskparty_cbsid_2,
                          riskpary_uen_2, currency, amount, interest_in_advance, income_accrual_amount,
                          our_ref):
        return {
            DscSheetEnum.CBS_ID.value: cbs_id,
            DscSheetEnum.BENEFICARY_CBS_ID.value: beneficiary_cbs_id,
            DscSheetEnum.RISKPARTY_UEN.value: riskparty_uen,
            DscSheetEnum.RISKPARTY_CBSID.value: riskparty_cbsid,
            DscSheetEnum.PRODUCT.value: product,
            DscSheetEnum.WITH_BANK_CUSTOMER.value: with_bank_customer,
            DscSheetEnum.RISKPARTY_CBSID_2.value: riskparty_cbsid_2,
            DscSheetEnum.RISKPARTY_UEN_2.value: riskpary_uen_2,
            DscSheetEnum.CURRENCY.value: currency,
            DscSheetEnum.AMOUNT.value: amount,
            DscSheetEnum.INTEREST_IN_ADVANCE.value: interest_in_advance,
            DscSheetEnum.INCOME_ACCRUAL_AMOUNT.value: income_accrual_amount,
            DscSheetEnum.OUR_REF.value: our_ref
        }

    def query_llp_data(self, data_date, report_type):
        """
        查询 LLP 数据
        :param data_date: 取数日期
        """

        llp_data_list = None
        if report_type == ReportType.G14_REPORT:
            llp_data_list = rra_db.query_g14_llp_data(data_date=data_date)
        elif report_type == ReportType.DAILY_REPORT:
            llp_data_list = rra_db.query_daily_llp_data(data_date=data_date)

        llp_ls = []

        if llp_data_list is None:
            raise DataException('llp_data_list is empty, whether there is LLP data on {}'.format(data_date))

        for llp_item in llp_data_list:
            llp_obj = self.__create_llp_item(transaction_ref=llp_item['transaction_ref'],
                                             branch=llp_item['branch'], bs_offbs=llp_item['bsoffbs'],
                                             deal_type=llp_item['deal_type'],
                                             uen=llp_item['uen'], ccy_cny_usd=llp_item['ccy_cny_usd'],
                                             prov_amt=llp_item['prov_amt'])
            llp_ls.append(llp_obj)

        return llp_ls

    def __create_llp_item(self, transaction_ref, branch, bs_offbs, deal_type, uen, ccy_cny_usd, prov_amt):
        return {
            LlpSheetEnum.TRANSACTION_REF.value: transaction_ref,
            LlpSheetEnum.BRANCH.value: branch,
            LlpSheetEnum.BS_OFFBS.value: bs_offbs,
            LlpSheetEnum.DEAL_TYPE.value: deal_type,
            LlpSheetEnum.UEN.value: uen,
            LlpSheetEnum.CCY_CNY_USD.value: ccy_cny_usd,
            LlpSheetEnum.PROV_AMT.value: prov_amt
        }

    def query_nostro_data(self, data_date):
        """
        查询 nostro 数据
        :param data_date: 取数日期
        """
        nostro_data_list = rra_db.query_nostro_data(data_date)
        nostro_ls = []

        if nostro_data_list is None:
            raise DataException('nostro_data_list is empty, whether there is Nostro data on {}'.format(data_date))

        for nostro_item in nostro_data_list:
            nostro_obj = self.__create_nostro_item(cbs_customer_id=nostro_item['cust_no'], ccy=nostro_item['ccy'],
                                                   amount=nostro_item['amount'],
                                                   fcy_amount=nostro_item['fcy_amount'])
            nostro_ls.append(nostro_obj)
        return nostro_ls

    def __create_nostro_item(self, cbs_customer_id, ccy, amount, fcy_amount):
        return {
            NostroSheetEnum.CUST_NO.value: cbs_customer_id,
            NostroSheetEnum.CCY.value: ccy,
            NostroSheetEnum.AMOUNT.value: amount,
            NostroSheetEnum.FCY_AMOUNT.value: fcy_amount
        }

    def query_limit_data(self, data_date):
        """
        查询 limit 数据
        :param data_date: 取数日期
        """
        limit_data_list = rra_db.query_limit_data(data_date)
        limit_ls = []

        if limit_data_list is None:
            raise DataException('limit_data_list is empty, whether there is Limit data on {}'.format(data_date))

        for limit_item in limit_data_list:
            limit_obj = self.__create_limit_item(cbs_id=limit_item['cbs_id'], customer_id=limit_item['customer_id'],
                                                 currency=limit_item['currency'],
                                                 available_credit_limit=limit_item['available_credit_limit'],
                                                 revocable=limit_item['revocable'],
                                                 org_period_in_one_year=limit_item['org_period_in_one_year'])
            limit_ls.append(limit_obj)
        return limit_ls

    def __create_limit_item(self, cbs_id, customer_id, currency, available_credit_limit, revocable,
                            org_period_in_one_year):
        return {
            LimitSheetEnum.CBS_ID.value: cbs_id,
            LimitSheetEnum.CUSTOMER_ID.value: customer_id,
            LimitSheetEnum.CURRENCY.value: currency,
            LimitSheetEnum.AVAILABLE_CREDIT_LIMIT.value: available_credit_limit,
            LimitSheetEnum.REVOCABLE.value: revocable,
            LimitSheetEnum.ORG_PERIOD_IN_ONE_YEAR.value: org_period_in_one_year
        }

    def query_auto_fin_data(self, data_date, report_type):
        """
        查询 auto fin 数据
        :param data_date: 取数日期
        :param report_type: 报表类型
        """
        auto_fin_data_list = None

        if report_type == ReportType.DAILY_REPORT:
            auto_fin_data_list = rra_db.query_daily_auto_fin_data(data_date)
        elif report_type == ReportType.G14_REPORT:
            auto_fin_data_list = rra_db.query_g14_auto_fin_data(data_date)

        if auto_fin_data_list is None:
            raise DataException('auto_fin_data_list is empty, whether there is auto_fin data on {}'.format(data_date))

        auto_fin_list = []
        for auto_fin_item in auto_fin_data_list:
            auto_fin_obj = self.__create_autfo_fin_item(cbs_id=auto_fin_item['cbs_cust_id'],
                                                        currency=auto_fin_item['currency'],
                                                        amount=auto_fin_item['amount'],
                                                        interest_received_to_gl=auto_fin_item[
                                                            'interest_received_to_gl'])
            auto_fin_list.append(auto_fin_obj)
        return auto_fin_list

    def __create_autfo_fin_item(self, cbs_id, currency, amount, interest_received_to_gl):
        return {
            AutoFinSheetEnum.CBS_ID.value: cbs_id,
            AutoFinSheetEnum.CURRENCY.value: currency,
            AutoFinSheetEnum.AMOUNT.value: amount,
            AutoFinSheetEnum.INTEREST_RECEIVED_TO_SQL.value: interest_received_to_gl
        }

    def query_offbs_tf_data(self, data_date):
        """
        查询 offbs 数据
        :param data_date: 取数日期
        """
        offbs_data_list = rra_db.query_offbs_tf_data(data_date)

        if offbs_data_list is None:
            raise DataException('offbs_data_list is empty, whether there is offbs data on {}'.format(data_date))

        offbs_tf_obj_list = []

        for offbs_tf_item in offbs_data_list:
            offbs_tf_obj = self.__create_offbs_tf_item(cbs_id=offbs_tf_item['cbs_id'], uen_no=offbs_tf_item['uen_no'],
                                                       offbs_factor=offbs_tf_item['offbs_factor'],
                                                       deal_type=offbs_tf_item['deal_type'],
                                                       currency=offbs_tf_item['currency'],
                                                       amount=offbs_tf_item['amount'])
            offbs_tf_obj_list.append(offbs_tf_obj)
        return offbs_tf_obj_list

    def __create_offbs_tf_item(self, cbs_id, uen_no, offbs_factor, deal_type, currency, amount):
        return {
            OffbsTfSheetEnum.CBS_ID.value: cbs_id,
            OffbsTfSheetEnum.UEN_NO.value: uen_no,
            OffbsTfSheetEnum.OFFBS_FACTOR.value: offbs_factor,
            OffbsTfSheetEnum.DEAL_TYPE.value: deal_type,
            OffbsTfSheetEnum.CURRENCY.value: currency,
            OffbsTfSheetEnum.AMOUNT.value: amount
        }

    def query_bond_ncd_data(self, data_date, report_type):
        """
        查询 bond&ncd 数据
        :param data_date: 取数日期
        :param report_type: 报表类型
        """
        bond_ncd_data_list = None

        if report_type == ReportType.DAILY_REPORT:
            bond_ncd_data_list = rra_db.query_daily_bond_ncd_data(data_date)
        elif report_type == ReportType.G14_REPORT:
            bond_ncd_data_list = rra_db.query_g14_bond_ncd_data(data_date)

        bond_ncd_obj_list = []

        for bond_ncd_item in bond_ncd_data_list:
            bond_ncd_obj = self.__create_bond_ncd_item(cbs_id=bond_ncd_item['cbs_id'],
                                                       accounting_code=bond_ncd_item['accounting_code'],
                                                       issuser_uen=bond_ncd_item['issuer_uen'],
                                                       ccy=bond_ncd_item['ccy'],
                                                       balance=bond_ncd_item['balance'],
                                                       interest_receivable=bond_ncd_item['interest_receivable'],
                                                       profit_center=bond_ncd_item['profit_centre'])
            bond_ncd_obj_list.append(bond_ncd_obj)

        return bond_ncd_obj_list

    def __create_bond_ncd_item(self, cbs_id, accounting_code, issuser_uen, ccy, balance, interest_receivable,
                               profit_center):
        return {
            BondNcdSheetEnum.CBS_ID.value: cbs_id,
            BondNcdSheetEnum.ACCOUNTING_CODE.value: accounting_code,
            BondNcdSheetEnum.ISSUER_UEN.value: issuser_uen,
            BondNcdSheetEnum.CCY.value: ccy,
            BondNcdSheetEnum.BALANCE.value: balance,
            BondNcdSheetEnum.INTEREST_RECEIVABLE.value: interest_receivable,
            BondNcdSheetEnum.PROFIT_CENTER.value: profit_center
        }

    def query_pboc_data(self, data_date):
        """
        查询 pboc 数据
        :param data_date: 取数日期
        """
        pboc_data_list = rra_db.query_pboc_data(data_date)
        pboc_obj_list = []

        for pboc_item in pboc_data_list:
            pboc_obj = self.__create_pboc_item(cbs_id=pboc_item[PbocSheetEnum.CBS_ID.value],
                                               currency=pboc_item[PbocSheetEnum.CURRENCY.value],
                                               amount=pboc_item[PbocSheetEnum.AMOUNT.value])
            pboc_obj_list.append(pboc_obj)
        return pboc_obj_list

    def __create_pboc_item(self, cbs_id, currency, amount):
        return {
            PbocSheetEnum.CBS_ID.value: cbs_id,
            PbocSheetEnum.CURRENCY.value: currency,
            PbocSheetEnum.AMOUNT.value: amount
        }

    def query_credit_exposure_data(self, data_date):
        """
        查询 credit exposure 数据
        :param data_date: 取数日期
        """
        credit_exposure_list = rra_db.query_credit_exposure_data(data_date)
        credit_exposure_obj_list = []

        if credit_exposure_list is None:
            raise DataException('credit_exposure is empty, whether there is credit_exposure data on {}'.format(data_date))

        for credit_exposure_item in credit_exposure_list:
            credit_exposure_obj = self.__create_credit_exposure_item(customer_id=credit_exposure_item['customer_id'],
                                                                     borrower=credit_exposure_item['borrower'],
                                                                     revocable=credit_exposure_item['revocable'],
                                                                     available_credit_limit=credit_exposure_item[
                                                                         'available_credit_limit'],
                                                                     guarantor_type_1=credit_exposure_item[
                                                                         'guarantor_type_1'],
                                                                     name_guarantor_1=credit_exposure_item[
                                                                         'name_guarantor_1'],
                                                                     org_period_in_one_year=credit_exposure_item[
                                                                         'org_period_in_one_year'],
                                                                     uen_guarantor_1=credit_exposure_item[
                                                                         'uen_guarantor_1'])
            credit_exposure_obj_list.append(credit_exposure_obj)
        return credit_exposure_obj_list

    def __create_credit_exposure_item(self, customer_id, borrower, revocable, available_credit_limit, guarantor_type_1,
                                      name_guarantor_1, org_period_in_one_year, uen_guarantor_1):
        return {
            CreditExposureSheetNum.CUSTOMER_ID.value: customer_id,
            CreditExposureSheetNum.BORROWER.value: borrower,
            CreditExposureSheetNum.REVOCABLE.value: revocable,
            CreditExposureSheetNum.AVAILABLE_CREDIT_LIMIT.value: available_credit_limit,
            CreditExposureSheetNum.GUARANTOR_TYPE_1.value: guarantor_type_1,
            CreditExposureSheetNum.NAME_GUARANTOR_1.value: name_guarantor_1,
            CreditExposureSheetNum.ORG_PERIOD_IN_ONE_YEAR.value: org_period_in_one_year,
            CreditExposureSheetNum.UEN_GUARANTOR_1.value: uen_guarantor_1
        }

    def query_holidays(self, data_date):
        data = rra_db.query_holidays(data_date)
        return data['count_num']

    def query_fefc_data(self, data_date):
        fefc_list = rra_db.query_fefc_data(data_date)
        fefc_obj_list = []

        if fefc_list is None:
            raise DataException(
                'fefc is empty, whether there is fefc data on {}'.format(data_date))

        for fefc_item in fefc_list:
            fefc_obj = self.__create_fefc_item(uen=fefc_item['uen'], product_exposure=fefc_item['product_exposure'], product_exposure_cny=fefc_item['product_exposure_cny'])
            fefc_obj_list.append(fefc_obj)

        return fefc_obj_list

    def __create_fefc_item(self, uen, product_exposure, product_exposure_cny):
        return {
            FefcSheetNum.UEN.value: uen,
            FefcSheetNum.PRODUCT_EXPOSURE.value: product_exposure,
            FefcSheetNum.PRODUCT_EXPOSURE_CNY.value: product_exposure_cny,
        }