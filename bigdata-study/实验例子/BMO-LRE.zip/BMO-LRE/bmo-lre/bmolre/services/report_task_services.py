# -*- coding: utf-8 -*-

"""
Created on 2020-12-31

@author: Wang Shuo
"""

from ..commons.logging import get_logger, log_entry_exit
from ..exts import mail
from ..exceptions import EmailException
from flask_mail import Message
import os
import paramiko

log = get_logger(__name__)


class TaskExecutor(object):

    def __init__(self):
        pass

    def send_email(self, subject, sender, recipients, html_body, app, attachment_path=None):
        send_email(subject, sender, recipients, html_body, app, attachment_path)

    def sftp_put_file(self, host, port, username, private_key_path, local_file, remote_dirs):
        sftp_put_file(host, port, username, private_key_path, local_file, remote_dirs)

    def sftp_listdir(self, host, port, username, private_key_path, path='.'):
        return sftp_listdir(host, port, username, private_key_path, path)

    def sftp_get_file(self, host, port, username, private_key_path, remote_file, local_file):
        sftp_get_file(host, port, username, private_key_path, remote_file, local_file)


def send_email(subject, sender, recipients, html_body, app, attachment_path):
    """
    发送邮件
    :param subject: 标题
    :param sender: 发送方
    :param recipients:收件人列表
    :param html_body: HTML
    :param app: Flask应用
    :param attachment_path: 附件
    :return:
    """

    log.debug('subject=%s, sender=%, recipients=%s', subject, sender, recipients)

    try:
        msg = Message(subject, sender=sender, recipients=recipients)
        msg.html = html_body

        if app and attachment_path:
            with app.open_resource(attachment_path) as fp:
                attchment_name = os.path.basename(attachment_path)
                msg.attach(attchment_name, "text/csv", fp.read())
        mail.send(msg)
    except Exception as err:
        raise EmailException(err)


@log_entry_exit
def sftp_connect(host, port, username, private_key_path):
    '''
    :param host:              SFTP的服务器IP
    :param port:　            SFTP 服务器的端口,默认端口 22
    :param username:　        SFTP的服务器账号
    :param private_key_path:　SFTP使用的私钥
    '''
    transport = paramiko.Transport((host, port))
    pk = paramiko.RSAKey.from_private_key(open(private_key_path))
    transport.connect(username=username, pkey=pk)
    sftp = paramiko.SFTPClient.from_transport(transport)
    return transport, sftp


def sftp_listdir(host, port, username, private_key_path, path):
    transport = None
    sftp = None
    try:
        transport, sftp = sftp_connect(host, port, username, private_key_path)
        dirs = sftp.listdir(path)
        return dirs
    except Exception as err:
        raise RuntimeError(err)
    finally:
        if sftp:
            sftp.close()
        if transport:
            transport.close()


def sftp_put_file(host, port, username, private_key_path, local_file, remote_dirs):
    """
    上传本地文件到SFTP服务器
    :param host:              SFTP的服务器IP
    :param port:　            SFTP 服务器的端口,默认端口 22
    :param username:　        SFTP的服务器账号
    :param private_key_path:　SFTP使用的私钥
    :param local_file:　      要上传的本地文件
    :param remote_dirs:　     上传到SFTP的目录
    :return:
    """
    transport = None
    sftp = None
    try:
        transport, sftp = sftp_connect(host, port, username, private_key_path)

        for remote_dir in remote_dirs:
            file_name = os.path.basename(local_file)
            sftp.put(local_file, remote_dir + '/' + file_name)
    except Exception as err:
        raise RuntimeError(err)
    finally:
        if sftp:
            sftp.close()
        if transport:
            transport.close()


def sftp_get_file(host, port, username, private_key_path, remote_file, local_file):
    """
    下载SFTP服务器上的文件到本地
    :param host:              SFTP的服务器IP
    :param port:　            SFTP 服务器的端口,默认端口 22
    :param username:　        SFTP的服务器账号
    :param private_key_path:　SFTP使用的私钥
    :param remote_file:　     SFTP上的文件
    :param local_file:　      下载到本地的文件
    :return:
    """
    try:
        transport, sftp = sftp_connect(host, port, username, private_key_path)

        sftp.get(remote_file, local_file)

        if sftp:
            sftp.close()
        if transport:
            transport.close()
    except Exception as err:
        print(err)
        raise RuntimeError(str(err))


class RatioMonitorData(object):

    @property
    def is_over_d6(self):
        """
        是否超过非同业单一客户贷款余额的 Threshold
        :return:
        """
        return self._is_over_d6

    @is_over_d6.setter
    def is_over_d6(self, value):
        self._is_over_d6 = value

    @property
    def is_over_e6(self):
        """
        是否超过非同业单一客户贷款余额的 Alert
        :return:
        """
        return self.is_over_e6

    @is_over_e6.setter
    def is_over_e6(self, value):
        self.is_over_e6 = value

    @property
    def d6(self):
        return self._d6

    @d6.setter
    def d6(self, value):
        self._d6 = value

    @property
    def e6(self):
        return self._e6

    @e6.setter
    def e6(self, value):
        self._e6 = value

    @property
    def g6(self):
        return self._g6

    @g6.setter
    def g6(self, value):
        self._g6 = value

    @property
    def h6(self):
        return self._h6

    @h6.setter
    def h6(self, value):
        self._h6 = value

    @property
    def g7(self):
        return self._g7

    @g7.setter
    def g7(self, value):
        self._g7 = value

    @property
    def h7(self):
        return self._h7

    @h7.setter
    def h7(self, value):
        self._h7 = value

    #######################################

    @property
    def is_over_d8(self):
        """
        是否超过非同业单一客户风险暴露余额的Threshold
        :return:
        """
        return self._is_over_d8

    @is_over_d8.setter
    def is_over_d8(self, value):
        self._is_over_d8 = value

    @property
    def is_over_e8(self):
        """
        是否超过非同业单一客户风险暴露余额的 Alert
        :return:
        """
        return self._is_over_e8

    @is_over_e8.setter
    def is_over_e8(self, value):
        self._is_over_e8 = value

    @property
    def d8(self):
        return self._d8

    @d8.setter
    def d8(self, value):
        self._d8 = value

    @property
    def e8(self):
        return self._e8

    @e8.setter
    def e8(self, value):
        self._e8 = value

    @property
    def i8(self):
        return self._i8

    @i8.setter
    def i8(self, value):
        self._i8 = value

    @property
    def j8(self):
        return self._j8

    @j8.setter
    def j8(self, value):
        self._j8 = value

    @property
    def i9(self):
        return self._i9

    @i9.setter
    def i9(self, value):
        self._i9 = value

    @property
    def j9(self):
        return self._j9

    @j9.setter
    def j9(self, value):
        self._j9 = value

   ##################################################

    @property
    def is_over_d10(self):
        """
        是否超过一组非同业关联客户风险暴露余额的Threshold
        :return:
        """
        return self._is_over_d10

    @is_over_d10.setter
    def is_over_d10(self, value):
        self._is_over_d10 = value

    @property
    def is_over_e10(self):
        """
        是否超过一组非同业关联客户风险暴露余额的 Alert
        :return:
        """
        return self._is_over_e10

    @is_over_e10.setter
    def is_over_e10(self, value):
        self._is_over_e10 = value

    @property
    def d10(self):
        return self._d10

    @d10.setter
    def d10(self, value):
        self._d10 = value

    @property
    def e10(self):
        return self._e10

    @e10.setter
    def e10(self, value):
        self._e10 = value

    @property
    def i10(self):
        return self._i10

    @i10.setter
    def i10(self, value):
        self._i10 = value

    @property
    def j10(self):
        return self._j10

    @j10.setter
    def j10(self, value):
        self._j10 = value

    @property
    def i11(self):
        return self._i11

    @i11.setter
    def i11(self, value):
        self._i11 = value

    @property
    def j11(self):
        return self._j11

    @j11.setter
    def j11(self, value):
        self._j11 = value

    ############################################

    @property
    def is_over_d12(self):
        """
        是否超过同业单一客户或集团客户风险暴露的Threshold
        :return:
        """
        return self._is_over_d12

    @is_over_d12.setter
    def is_over_d12(self, value):
        self._is_over_d12 = value

    @property
    def is_over_e12(self):
        """
        是否超过同业单一客户或集团客户风险暴露的 Alert
        :return:
        """
        return self._is_e12

    @is_over_e12.setter
    def is_over_e12(self, value):
        self._is_e12 = value

    @property
    def d12(self):
        return self._d12

    @d12.setter
    def d12(self, value):
        self._d12 = value

    @property
    def e12(self):
        return self._e12

    @e12.setter
    def e12(self, value):
        self._e12 = value

    @property
    def i12(self):
        return self._i12

    @i12.setter
    def i12(self, value):
        self._i12 = value

    @property
    def j12(self):
        return self._j12

    @j12.setter
    def j12(self, value):
        self._j12 = value

    @property
    def i13(self):
        return self._i13

    @i13.setter
    def i13(self, value):
        self._i13 = value

    @property
    def j13(self):
        return self._j13

    @j13.setter
    def j13(self, value):
        self._j13 = value



