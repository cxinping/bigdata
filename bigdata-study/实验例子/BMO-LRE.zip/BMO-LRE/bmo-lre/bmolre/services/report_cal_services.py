# -*- coding: utf-8 -*-

"""
Created on 2020-11-27

@author: Wang Shuo
"""

from ..commons.logging import get_logger, log_entry_exit
from ..exceptions import ReportException
from ..services.data_services import DataService
from ..commons.report_enums import (RateSheetEnum, CustomerSheetEnum, EadSheetEnum, LimitSheetEnum, ReportType)
from ..commons.report_utils import create_random_number
from ..commons.util import is_blank, convert_digital_precision
from cachelib import SimpleCache

log = get_logger(__name__)

cache = SimpleCache()


class ReportService(object):

    def __init__(self):
        self.data_service = DataService()
        self.rates = {}

    def query_cny_rate_from_cache(self, data_date, basic_ccy):
        key = 'rate:cny:' + str(data_date)
        rates = cache.get(key)
        ccy_rate = None

        if rates is None:
            try:
                rate_data_list = self.data_service.query_rate_data(data_date)
                for rate_item in rate_data_list:
                    if basic_ccy == rate_item[RateSheetEnum.BASIC_CCY.value]:
                        ccy_rate = rate_item[RateSheetEnum.CCY_RATE.value]
                        cache.set(key, rate_data_list, timeout=60 * 60)
                        break
            except Exception as err:
                log.error(err)
                raise ReportException(str(err))

        else:
            for rate_item in rates:
                if basic_ccy == rate_item[RateSheetEnum.BASIC_CCY.value]:
                    ccy_rate = rate_item[RateSheetEnum.CCY_RATE.value]
                    break
        return ccy_rate

    @log_entry_exit
    def init_rate_data(self, data_date):
        """
        查询Rate取数据
        :param data_date: 查询报表时间
        :return:
        """
        try:
            return self.data_service.query_rate_data(data_date)
        except Exception as err:
            raise ReportException(str(err))

    def query_loan_data(self, data_date):
        return self.data_service.query_loan_data(data_date)

    def query_capital_data(self, data_date, report_type):
        """
         查询资本净额和一级资本净额
         :param data_date: 取数日期
         :param report_type: 报表类型
         """
        return self.data_service.query_capital_data(data_date=data_date, report_type=report_type)

    def query_interbank_financing_business_data(self, data_date):
        """
         查询同业融资业务
         :param data_date: 取数日期

         """
        return self.data_service.query_interbank_financing_business_data(data_date)

    def query_domestic_summary_data1(self, data_date):
        """
         查询 境内汇总数据
         :param data_date: 取数日期

        """
        return self.data_service.query_domestic_summary_data1(data_date)

    def query_domestic_summary_data2(self, data_date):
        """
         查询 其中：同业拆借, 其中：受托方同业代付
         :param data_date: 取数日期

         """
        return self.data_service.query_domestic_summary_data2(data_date)

    def query_customer_list_report(self, data_date):
        """
        Extract BMO Customer to LRE Calculation
        In the working file, BMO Customer data use RRA BMOS0008 customer list report as data source.
        Select customer with Status = O in RRAS0008.
        :param data_date: 取数日期
        """
        return self.data_service.query_customer_list_report(data_date)

    def query_indirect_customer_from_trade_finance_transaction(self, data_date):
        customer_data_list = self.data_service.query_indirect_customer_from_trade_finance_transaction(data_date)
        for custoemr_item in customer_data_list:
            # customer_category = custoemr_item[CustomerSheetEnum.CUSTOMER_CATEGORY.value]
            # if is_blank(customer_category):
            #     customer_category = 'NONE'
            # 与CBS_ID区别开，满足唯一性，不要６位数字
            #dummy_cbs_id = customer_category + '_' + create_random_number(len=10)
            #custoemr_item[CustomerSheetEnum.CBS_ID.value] = dummy_cbs_id
            #custoemr_item[CustomerSheetEnum.CUSTOMER_NAME_CN.value] = ''
            custoemr_item[CustomerSheetEnum.NATIONALITY.value] = ''
            custoemr_item[CustomerSheetEnum.COUNTRY.value] = ''
            custoemr_item[CustomerSheetEnum.GROUP_CODE.value] = ''
            custoemr_item[CustomerSheetEnum.GROUP_NAME.value] = ''
            custoemr_item[CustomerSheetEnum.UNIQUE_ID_VALUE.value] = ''

        return customer_data_list

    def cal_customer_data(self, data_date, report_type):
        customer_ls = []
        customer_list_report_data_list = self.query_customer_list_report(data_date)
        indirect_customers1 = self.query_indirect_customer_from_trade_finance_transaction(data_date)

        customer_ls.extend(customer_list_report_data_list)
        customer_ls.extend(indirect_customers1)

        customer_g14_group_ind_ls = None
        if ReportType.G14_REPORT == report_type:
            customer_g14_group_ind_ls = self.__cal__g14_group_ind(customer_ls)
        return customer_ls, customer_g14_group_ind_ls

    def __cal__g14_group_ind(self, customer_ls):
        customer_g14_group_ind_ls = []
        for customer_item in customer_ls:
            connection_uen = customer_item[CustomerSheetEnum.CONNECTION_UEN.value]
            group_code = customer_item[CustomerSheetEnum.GROUP_CODE.value]
            g14_group_ind = None

            if is_blank(connection_uen) and ( is_blank(group_code) or group_code == 0 ):
                g14_group_ind = 'N'
                customer_item[CustomerSheetEnum.G14_GROUP_IND.value] = g14_group_ind
                customer_g14_group_ind_ls.append(customer_item)
            else:
                g14_group_ind = 'Y'
                customer_item[CustomerSheetEnum.G14_GROUP_IND.value] = g14_group_ind

        return customer_g14_group_ind_ls

    def cal_ead_report_data(self, data_date, report_type):
        ead_data_list = []
        ead_data_list1 = self.data_service.query_ead_report_data2(data_date, report_type)
        ead_data_list2 = self.data_service.query_ead_report_data(data_date, report_type)
        ead_data_list.extend(ead_data_list1)
        ead_data_list.extend(ead_data_list2)

        usd_cny_rate = self.data_service.query_usd_to_cny_rate(data_date)

        for ead_item in ead_data_list:
            if ead_item[EadSheetEnum.EAD_USD.value]:
                ead_usd_cn = ead_item[EadSheetEnum.EAD_USD.value] * usd_cny_rate
                ead_item[EadSheetEnum.EAD_CNY_EQV.value] = convert_digital_precision(ead_usd_cn, 2)
                ead_item[EadSheetEnum.EAD_USD.value] = convert_digital_precision(ead_item[EadSheetEnum.EAD_USD.value], 2)

        return ead_data_list

    def query_daily_money_market_data(self, data_date):
        return self.data_service.query_daily_money_market_data(data_date)

    def query_g14_money_market_data(self, data_date):
        return self.data_service.query_g14_money_market_data(data_date)

    def query_dsc_data(self, data_date):
        return self.data_service.query_dsc_data(data_date)

    def query_llp_data(self, data_date, report_type):
        return self.data_service.query_llp_data(data_date, report_type)

    def query_nostro_data(self, data_date):
        return self.data_service.query_nostro_data(data_date)

    def cal_limit_data(self, data_date):
        limit_data_list = self.data_service.query_limit_data(data_date)

        for limit_item in limit_data_list:
            limit_item[LimitSheetEnum.AVAILABLE_CREDIT_LIMIT.value] = convert_digital_precision(val=limit_item[LimitSheetEnum.AVAILABLE_CREDIT_LIMIT.value], precision=5)

        return limit_data_list

    def query_auto_fin_data(self, data_date, report_type):
        return self.data_service.query_auto_fin_data(data_date, report_type)

    def query_offbs_tf_data(self, data_date):
        return self.data_service.query_offbs_tf_data(data_date)

    def query_bond_ncd_data(self, data_date, report_type):
        return self.data_service.query_bond_ncd_data(data_date, report_type)

    def query_pboc_data(self, data_date):
        return self.data_service.query_pboc_data(data_date)

    def query_credit_exposure_data(self, data_date):
        return self.data_service.query_credit_exposure_data(data_date)

    def is_holidays(self, data_date):
        holiday_count = self.data_service.query_holidays(data_date)

        flag = False
        if holiday_count > 0:
            flag = True
        return flag

    def query_fefc_data(self, data_date):
        return self.data_service.query_fefc_data(data_date)


