# -*- coding: utf-8 -*-

"""
Created on 2020-11-10

@author: Wang Shuo
"""

from abc import ABCMeta, abstractmethod
from datetime import datetime
import os
import shutil
from bmolre.commons.logging import get_logger
import bmolre.commons.constant as constant
from bmolre.exceptions import ReportException, ReportInvalidDataDateException, DataException
from bmolre.commons.report_enums import (
    ReportType, G14ReportSpreadSheets, LreDailyReportSpreadSheets, RateSheetEnum, LoanSheetEnum,
    OtherInputsSheetEnum, CustomerSheetEnum, EadSheetEnum, CommonParamEnum, MM505SheetEnum, DscSheetEnum,
    LlpSheetEnum, NostroSheetEnum, LimitSheetEnum, AutoFinSheetEnum, OffbsTfSheetEnum, BondNcdSheetEnum,
    PbocSheetEnum, CreditExposureSheetNum, FefcSheetNum
)
from bmolre.services.report_cal_services import ReportService
from bmolre.commons.check_valid import is_valid_date
from bmolre.commons.report_utils import (filter_data_daily_single_cust, filter_data_group_corp, filter_data_group_bank,
                                         get_daily_report_date, rename_report, filter_data_g14_single_cust,
                                         filter_data_g14_group_cust, filter_data_g14_single_interbank,
                                         filter_data_g14_group_interbank, CalG14CustomerData)
from bmolre.commons.util import convert_digital_precision
from bmolre.services.report_task_services import RatioMonitorData
import openpyxl
from openpyxl.utils import column_index_from_string

LOG_INIT_SHEET = 'Initializing sheet "%s" ...'


class BaseReport(metaclass=ABCMeta):
    __wb = None

    def __init__(self, report_type, data_date):

        self._log = get_logger(__name__ + '.' + self.__class__.__name__)

        """
        :param report_type: 报表类型
        :param data_date : 查询报表时间
        """
        self.__report_type = report_type

        if not is_valid_date(data_date):
            raise ReportInvalidDataDateException(
                'The input data_date({}) is invalid, The correct data_date format is 20201119'.format(data_date))

        self.__data_date = data_date
        self.__report_service = ReportService()

    def get_log(self):
        return self._log

    def get_report_type(self):
        return self.__report_type

    def get_data_date(self):
        return self.__data_date

    def get_report_service(self):
        return self.__report_service

    def create_target_report(self):
        """
        根据报表模板复制一份报表的模板
        :return: 返回复制的报表模板，包括：报表模板的地址和名称
        """
        report_template = self.__get_report_template()
        target_report = self.get_target_report()

        if not os.path.exists(constant.CREATED_REPORT_PATH):
            os.mkdir(constant.CREATED_REPORT_PATH)

        if os.path.isfile(target_report):
            rename_report(target_report)

        shutil.copy(report_template, target_report)
        # 更改文件的权限
        os.chmod(target_report, 0o644)

    def remove_target_report(self):
        """
        删除目标报表
        """
        target_report = self.get_target_report()
        if os.path.isfile(target_report):
            os.remove(target_report)


    def get_target_report(self):
        """
        :return:返回生成的目标报表，包括：目标报表的地址和名称
        """
        report_day = str(self.get_data_date())
        lre_daily_report_name = 'Large_Risk_Exposure_Daily_Report-{}.xlsx'.format(report_day)
        g14_report_name = 'G14_Report-{}.xlsx'.format(report_day)
        target_report = None

        if self.get_report_type() == ReportType.DAILY_REPORT:
            target_report = os.path.join(constant.CREATED_REPORT_PATH, lre_daily_report_name)
        elif self.get_report_type() == ReportType.G14_REPORT:
            target_report = os.path.join(constant.CREATED_REPORT_PATH, g14_report_name)

        return target_report

    def __get_report_template(self):
        report_template = None
        if self.get_report_type() == ReportType.DAILY_REPORT:
            report_template = os.path.join(constant.REPORT_TEMPLATE_PATH, constant.LRE_DAILY_REPORT_TEMPLATE)
        elif self.get_report_type() == ReportType.G14_REPORT:
            report_template = os.path.join(constant.REPORT_TEMPLATE_PATH, constant.G14_QUARTERLY_REPORT_TEMPLATE)
        return report_template

    def load_target_report(self):
        try:
            self._log.info('Loading %s report => %s ...', self.get_report_type().value, self.get_target_report())
            self.create_target_report()
            self.__wb = openpyxl.load_workbook(self.get_target_report())
        except Exception as err:
            raise ReportException(err)

    def load_target_report_with_dataonly(self):
        try:
            self._log.info('Loading %s report => %s ...', self.get_report_type().value, self.get_target_report())
            self.__wb = openpyxl.load_workbook(self.get_target_report(), data_only=True )
        except Exception as err:
            raise ReportException(err)

    def get_workbook(self):
        return self.__wb

    def save_report(self):
        self._log.info("Saving %s report ...", self.get_report_type().value)
        self.__wb.save(self.get_target_report())

    def init_rate_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.RATE.value)
        rate_worksheet = self.__wb[LreDailyReportSpreadSheets.RATE.value]

        try:
            rate_data_list = self.get_report_service().init_rate_data(self.get_data_date())

            self._log.debug('rate_data_list=%s', rate_data_list)

            row_num = len(rate_data_list)
            column_num = 5
            for row in range(0, row_num):
                rate_obj = rate_data_list[row]

                for column in range(0, column_num):
                    cell = rate_worksheet.cell(row=row + 2, column=column + 1)
                    if column == 0:
                        cell.value = rate_obj[RateSheetEnum.S_DATE.value]
                    elif column == 1:
                        cell.value = rate_obj[RateSheetEnum.E_DATE.value]
                    elif column == 2:
                        cell.value = rate_obj[RateSheetEnum.BASIC_CCY.value]
                    elif column == 3:
                        cell.value = rate_obj[RateSheetEnum.FORWARD_CCY.value]
                    elif column == 4:
                        cell.value = rate_obj[RateSheetEnum.CCY_RATE.value]
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_loan_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.LOAN.value)
        loan_worksheet = self.__wb[LreDailyReportSpreadSheets.LOAN.value]

        try:
            loan_cn_data_list = self.get_report_service().query_loan_data(data_date=self.get_data_date())

            self._log.debug('loan_cn_data_list=%s', loan_cn_data_list)

            row_num = len(loan_cn_data_list)

            column_num = column_index_from_string('BQ')
            for row in range(0, row_num):
                loan_cn_obj = loan_cn_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):

                    if column == column_index_from_string('A'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cbs_id_formula = '=K' + str(row_idx_1)
                        cell.value = cbs_id_formula
                        # add LRE-108 B
                    elif column == column_index_from_string('B'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = loan_cn_obj[LoanSheetEnum.STATUS.value]
                    elif column == column_index_from_string('K'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = loan_cn_obj[LoanSheetEnum.CBS_CUST_ID.value]
                    elif column == column_index_from_string('L'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = loan_cn_obj[LoanSheetEnum.CURRENCY.value]
                    elif column == column_index_from_string('M'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = loan_cn_obj[LoanSheetEnum.AMOUNT.value]
                        # add LRE-108 R
                    elif column == column_index_from_string('R'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = loan_cn_obj[LoanSheetEnum.OUR_REF.value]
                    elif column == column_index_from_string('AU'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = loan_cn_obj[LoanSheetEnum.INTEREST_RECEIVED_TO_GL.value]
                    elif column == column_index_from_string('BO'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = loan_cn_obj[LoanSheetEnum.CURRENCY.value]

                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IFERROR(IF(L{row_idx_1}="CNY",M{row_idx_1}+AU{row_idx_1}, {cny_rate}*(M{row_idx_1}+AU{row_idx_1})),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula
                    elif column == column_index_from_string('BP'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = loan_cn_obj[LoanSheetEnum.CURRENCY.value]

                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IFERROR(IF(L{row_idx_1}="CNY",M{row_idx_1}, {cny_rate}*(M{row_idx_1})),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

        except DataException as err:
            self._log.warning(err, exc_info=True)
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_other_inputs_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.OTHER_INPUTS.value)

        try:
            other_inputs_worksheet = self.__wb[LreDailyReportSpreadSheets.OTHER_INPUTS.value]
            other_input_data = self.get_report_service().query_capital_data(self.get_data_date(),
                                                                            self.get_report_type())

            self._log.debug('other_input_data=%s', other_input_data)

            other_inputs_worksheet['B2'].value = other_input_data[OtherInputsSheetEnum.TOTAL_CAPITAL_AMT.value]
            other_inputs_worksheet['B3'].value = other_input_data[OtherInputsSheetEnum.TIER1_CAPITAL_AMT.value]

            if self.get_report_type() == ReportType.G14_REPORT:
                # 同业融资业务
                ifb_data = self.get_report_service().query_interbank_financing_business_data(self.get_data_date())
                other_inputs_worksheet['B10'].value = ifb_data[OtherInputsSheetEnum.RANK_CD.value]
                other_inputs_worksheet['C10'].value = ifb_data[OtherInputsSheetEnum.FN_INSTITUTION_NAME_CD.value]
                other_inputs_worksheet['D10'].value = ifb_data[OtherInputsSheetEnum.FN_INSTITUTION_CODE_CD.value]
                other_inputs_worksheet['E10'].value = ifb_data[OtherInputsSheetEnum.IB_DRAWDOWN_AMT.value]
                other_inputs_worksheet['F10'].value = ifb_data[OtherInputsSheetEnum.IB_LENDING_AMT.value]
                other_inputs_worksheet['G10'].value = ifb_data[OtherInputsSheetEnum.IB_BORROW_AMT.value]
                other_inputs_worksheet['H10'].value = ifb_data[OtherInputsSheetEnum.PAYMENT_AMT.value]
                other_inputs_worksheet['I10'].value = ifb_data[OtherInputsSheetEnum.NOSTRO_AMT.value]
                other_inputs_worksheet['J10'].value = ifb_data[OtherInputsSheetEnum.BUY_BACK_SALE_AMT.value]
                other_inputs_worksheet['K10'].value = ifb_data[OtherInputsSheetEnum.OTH_IB_FINANCING_AMT.value]
                other_inputs_worksheet['L10'].value = ifb_data[OtherInputsSheetEnum.TOTAL_IB_FINANCING_AMT.value]
                other_inputs_worksheet['M10'].value = ifb_data[OtherInputsSheetEnum.REDUCE_IB_FINANCING_AMT.value]
                other_inputs_worksheet['N10'].value = ifb_data[OtherInputsSheetEnum.PROPORTION_CAPITAL.value]
                other_inputs_worksheet['O10'].value = ifb_data[OtherInputsSheetEnum.SETTLE_IB_DEPOSIT.value]
                other_inputs_worksheet['P10'].value = ifb_data[OtherInputsSheetEnum.ZERO_RW_ASSET.value]

                # 境内汇总数据
                domestic_summary_data1 = self.get_report_service().query_domestic_summary_data1(self.get_data_date())
                row_num = 58 - 1
                column_num = column_index_from_string('F')

                for row in range(1, row_num):
                    ds_obj = domestic_summary_data1[row]
                    row_idx_1 = row + 15

                    for column in range(0, column_num):
                        if column == column_index_from_string('C'):
                            cell = other_inputs_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = ds_obj[OtherInputsSheetEnum.FOREIGN_IN_CNY_AMOUNT.value]
                            cell.number_format = '0.00'
                        elif column == column_index_from_string('D'):
                            cell = other_inputs_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = ds_obj[OtherInputsSheetEnum.CNY_AMOUNT.value]
                            cell.number_format = '0.00'
                        elif column == column_index_from_string('E'):
                            cell = other_inputs_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = ds_obj[OtherInputsSheetEnum.TOTAL_IN_CNY_AMOUNT.value]
                            cell.number_format = '0.00'

                # 其中：同业拆借, 其中：受托方同业代付
                domestic_summary_data2 = self.get_report_service().query_domestic_summary_data2(self.get_data_date())
                other_inputs_worksheet['E73'].value = domestic_summary_data2[OtherInputsSheetEnum.INTERBANK_LENDING_AMOUNT.value]
                other_inputs_worksheet['E73'].number_format = '#,##0_ '
                other_inputs_worksheet['E75'].value = domestic_summary_data2[OtherInputsSheetEnum.ENTRUSTED_PARTY_PAYS_AMOUNT.value]
                other_inputs_worksheet['E75'].number_format = '#,##0_ '

        except DataException as err:
            #self._log.warning(err, exc_info=True)
            raise ReportException(err)
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_bond_ncd_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.BOND_NCD.value)

        wb = self.get_workbook()
        bond_ncd_worksheet = wb[LreDailyReportSpreadSheets.BOND_NCD.value]

        try:
            bond_ncd_data_list = self.get_report_service().query_bond_ncd_data(self.get_data_date(), self.get_report_type())

            self._log.debug('bond_ncd_data_list=%s', bond_ncd_data_list)

            row_num = len(bond_ncd_data_list)
            column_num = column_index_from_string('J')

            for row in range(0, row_num):
                bond_ncd_obj = bond_ncd_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=H{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.ACCOUNTING_CODE.value]
                    elif column == column_index_from_string('C'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.ISSUER_UEN.value]
                    elif column == column_index_from_string('D'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.CCY.value]
                    elif column == column_index_from_string('E'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.BALANCE.value]
                    elif column == column_index_from_string('F'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.INTEREST_RECEIVABLE.value]
                    elif column == column_index_from_string('G'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = bond_ncd_obj[BondNcdSheetEnum.CCY.value]
                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IFERROR(IF(D{row_idx_1}="CNY",E{row_idx_1}+F{row_idx_1}, {cny_rate} * (E{row_idx_1}+F{row_idx_1}) ),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula
                    elif column == column_index_from_string('H'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('I'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.PROFIT_CENTER.value]

            self._log.debug('*** Bond & NCD data nums={}'.format(len(bond_ncd_data_list)))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_ead_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.EAD.value)
        wb = self.get_workbook()
        ead_worksheet = wb[LreDailyReportSpreadSheets.EAD.value]

        try:
            ead_data_list = self.get_report_service().cal_ead_report_data(self.get_data_date(), self.get_report_type())

            self._log.debug('ead_data_list=%s', ead_data_list)

            # 没有数据也是正常现象, 2020-12-06
            if len(ead_data_list) == 0:
                self._log.warning("EAD data is empty, please verify." , exc_info=True)
            else:
                row_num = len(ead_data_list)
                column_num = column_index_from_string('K')

                for row in range(0, row_num):
                    ead_obj = ead_data_list[row]
                    row_idx_1 = row + 2

                    for column in range(0, column_num):
                        if column == column_index_from_string('A'):
                            cell = ead_worksheet.cell(row=row_idx_1, column=column)
                            cell_formula = '=J{idx}'.format(idx=row_idx_1)
                            cell.value = cell_formula
                        elif column == column_index_from_string('C'):
                            cell = ead_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = ead_obj[EadSheetEnum.COUNTERPARTY_LONG_NAME.value]
                        elif column == column_index_from_string('D'):
                            cell = ead_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = ead_obj[EadSheetEnum.COUNTERPARTY_TYPE.value]
                        elif column == column_index_from_string('E'):
                            cell = ead_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = ead_obj[EadSheetEnum.IBUK_CUSTOMER_NUMBER.value]
                        elif column == column_index_from_string('F'):
                            cell = ead_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = ead_obj[EadSheetEnum.EAD_USD.value]
                        elif column == column_index_from_string('I'):
                            cell = ead_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = ead_obj[EadSheetEnum.EAD_CNY_EQV.value]
                        elif column == column_index_from_string('J'):
                            cell = ead_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = ead_obj[EadSheetEnum.CBS_ID.value]
        except DataException as err:
            raise ReportException(err)
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_llp_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.LLP.value)
        wb = self.get_workbook()
        llp_worksheet = wb[LreDailyReportSpreadSheets.LLP.value]

        try:
            llp_data_list = self.get_report_service().query_llp_data(self.get_data_date(), self.get_report_type())

            self._log.debug('llp_data_list=%s', llp_data_list)

            row_num = len(llp_data_list)
            column_num = column_index_from_string('AF')

            for row in range(0, row_num):
                llp_obj = llp_data_list[row]
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.BRANCH.value]
                    elif column == column_index_from_string('B'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.BS_OFFBS.value]
                    elif column == column_index_from_string('C'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.DEAL_TYPE.value]
                    elif column == column_index_from_string('D'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.TRANSACTION_REF.value]
                    elif column == column_index_from_string('F'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.UEN.value]
                    elif column == column_index_from_string('T'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.CCY_CNY_USD.value]
                    elif column == column_index_from_string('V'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.PROV_AMT.value]
                    elif column == column_index_from_string('AD'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = llp_obj[LlpSheetEnum.CCY_CNY_USD.value]

                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IFERROR(IF(T{row_idx_1}="CNY",V{row_idx_1}, {cny_rate} * V{row_idx_1} ),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AE') and self.get_report_type() == ReportType.G14_REPORT:
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(C{idx}=\"Interbank Lending\",VLOOKUP(F{idx},'MM 505'!AE:AF,2,0),\"\")".format(idx=row_idx_1)
                        cell.value = cell_formula

            self._log.debug('LLP nums={}'.format(len(llp_data_list)))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_nostro_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.NOSTRO.value)
        wb = self.get_workbook()
        nostro_worksheet = wb[LreDailyReportSpreadSheets.NOSTRO.value]

        try:
            nostro_data_list = self.get_report_service().query_nostro_data(self.get_data_date())

            self._log.debug('nostro_data_list=%s', nostro_data_list)

            row_num = len(nostro_data_list)
            column_num = column_index_from_string('G')

            for row in range(0, row_num):
                nostro_obj = nostro_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=B{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = nostro_obj[NostroSheetEnum.CUST_NO.value]
                    elif column == column_index_from_string('C'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = nostro_obj[NostroSheetEnum.CCY.value]
                    elif column == column_index_from_string('D'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = nostro_obj[NostroSheetEnum.AMOUNT.value]
                    elif column == column_index_from_string('E'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = nostro_obj[NostroSheetEnum.FCY_AMOUNT.value]
                    elif column == column_index_from_string('F'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=(D{row_idx_1}+E{row_idx_1})'.format(row_idx_1=row_idx_1)
                        cell.value = cell_formula
            self._log.debug('Nostro nums={}'.format(len(nostro_data_list)))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_offbs_tf_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.OFFBS_TF.value)
        wb = self.get_workbook()
        offbs_tf_worksheet = wb[LreDailyReportSpreadSheets.OFFBS_TF.value]

        try:
            offbs_tf_data_list = self.get_report_service().query_offbs_tf_data(self.get_data_date())

            self._log.debug('offbs_tf_data_list=%s', offbs_tf_data_list)

            row_num = len(offbs_tf_data_list)
            column_num = column_index_from_string('Y')

            for row in range(0, row_num):
                offbs_tf_obj = offbs_tf_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=C{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.UEN_NO.value]
                    elif column == column_index_from_string('C'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('D'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.OFFBS_FACTOR.value]
                    elif column == column_index_from_string('G'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.DEAL_TYPE.value]
                    elif column == column_index_from_string('J'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.UEN_NO.value]
                    elif column == column_index_from_string('K'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.CURRENCY.value]
                    elif column == column_index_from_string('L'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.AMOUNT.value]
                    elif column == column_index_from_string('X'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = offbs_tf_obj[OffbsTfSheetEnum.CURRENCY.value]
                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = "=IFERROR(IF('offbs TF'!K{row_idx_1}=\"CNY\",'offbs TF'!L{row_idx_1}, {cny_rate} * L{row_idx_1}),0)".format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

            self._log.debug('*** offbs TF data nums={}'.format(len(offbs_tf_data_list)))
        except DataException as err:
            self._log.warning(err, exc_info=True)
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_limit_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.LIMIT.value)
        wb = self.get_workbook()
        limit_worksheet = wb[LreDailyReportSpreadSheets.LIMIT.value]

        try:
            limit_data_list = self.get_report_service().cal_limit_data(self.get_data_date())

            self._log.debug('limit_data_list=%s', limit_data_list)

            row_num = len(limit_data_list)
            column_num = column_index_from_string('AK')

            for row in range(0, row_num):
                limit_obj = limit_data_list[row]
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=D{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('D'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = limit_obj[LimitSheetEnum.CUSTOMER_ID.value]
                    elif column == column_index_from_string('G'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = limit_obj[LimitSheetEnum.CURRENCY.value]
                    elif column == column_index_from_string('O'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = limit_obj[LimitSheetEnum.AVAILABLE_CREDIT_LIMIT.value]
                    elif column == column_index_from_string('R'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = limit_obj[LimitSheetEnum.REVOCABLE.value]
                    elif column == column_index_from_string('U'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = limit_obj[LimitSheetEnum.ORG_PERIOD_IN_ONE_YEAR.value]
                    elif column == column_index_from_string('AJ'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = limit_obj[LimitSheetEnum.CURRENCY.value]
                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)

                        cell_formula = '=IFERROR(IF(G{row_idx_1}="CNY",O{row_idx_1}*1000, {cny_rate} * O{row_idx_1} * 1000),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

            self._log.debug('*** Limit data nums={}'.format(len(limit_data_list)))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_auto_fin_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.AUTO_FIN.value)
        wb = self.get_workbook()
        auto_fin_worksheet = wb[LreDailyReportSpreadSheets.AUTO_FIN.value]

        try:
            auto_fin_data_list = self.get_report_service().query_auto_fin_data(self.get_data_date(), self.get_report_type())

            self._log.debug('auto_fin_data_list=%s', auto_fin_data_list)

            row_num = len(auto_fin_data_list)
            column_num = column_index_from_string('G')

            for row in range(0, row_num):
                auto_fin_obj = auto_fin_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=B{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = auto_fin_obj[AutoFinSheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('C'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = auto_fin_obj[AutoFinSheetEnum.CURRENCY.value]
                    elif column == column_index_from_string('D'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = auto_fin_obj[AutoFinSheetEnum.AMOUNT.value]
                    elif column == column_index_from_string('E'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = auto_fin_obj[AutoFinSheetEnum.INTEREST_RECEIVED_TO_SQL.value]
                    elif column == column_index_from_string('F'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = auto_fin_obj[AutoFinSheetEnum.CURRENCY.value]
                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IFERROR(IF(C{row_idx_1}="CNY",D{row_idx_1}+E{row_idx_1}, {cny_rate} * (D{row_idx_1}+E{row_idx_1}) ),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

            self._log.debug('*** Auto_Fin data nums={}'.format(len(auto_fin_data_list)))
        except DataException as err:
            # 没有数据也是正常现象, 2020-12-06
            self._log.warning(err, exc_info=True)
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_pboc_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.PBOC.value)
        wb = self.get_workbook()
        pboc_worksheet = wb[LreDailyReportSpreadSheets.PBOC.value]

        try:
            pboc_data_list = self.get_report_service().query_pboc_data(self.get_data_date())

            self._log.debug('pboc_data_list=%s', pboc_data_list)

            # 没有PBOC数据是正常现象
            if len(pboc_data_list) == 0:
                self._log.warning("PBOC data is empty, please verify." , exc_info=True)
            else:

                row_num = len(pboc_data_list)
                column_num = column_index_from_string('G')

                for row in range(0, row_num):
                    pboc_obj = pboc_data_list[row]
                    row_idx_1 = row + 2

                    for column in range(0, column_num):
                        if column == column_index_from_string('A'):
                            cell = pboc_worksheet.cell(row=row_idx_1, column=column)
                            cell_formula = '=B{idx}'.format(idx=row_idx_1)
                            cell.value = cell_formula
                        elif column == column_index_from_string('B'):
                            cell = pboc_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = pboc_obj[PbocSheetEnum.CBS_ID.value]
                        elif column == column_index_from_string('C'):
                            cell = pboc_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = pboc_obj[PbocSheetEnum.CURRENCY.value]
                        elif column == column_index_from_string('D'):
                            cell = pboc_worksheet.cell(row=row_idx_1, column=column)
                            cell.value = pboc_obj[PbocSheetEnum.AMOUNT.value]
                        elif column == column_index_from_string('F'):
                            cell = pboc_worksheet.cell(row=row_idx_1, column=column)
                            cny_rate = 0
                            currency = pboc_obj[PbocSheetEnum.CURRENCY.value]
                            if currency == CommonParamEnum.CNY.value:
                                cny_rate = 1
                            else:
                                cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                    data_date=self.get_data_date(), basic_ccy=currency)
                            cell_formula = '=IFERROR(IF(C{idx}="CNY",D{idx}+E{idx}, {cny_rate} * (D{idx}+E{idx}) ),0)'.format(
                                idx=row_idx_1, cny_rate=cny_rate)
                            cell.value = cell_formula
                self._log.debug('*** PBOC data nums={}'.format(len(pboc_data_list)))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_customer_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.CUSTOMER.value)
        wb = self.get_workbook()
        customer_worksheet = wb[LreDailyReportSpreadSheets.CUSTOMER.value]

        try:
            customer_data_list, customer_g14_group_ind_ls = self.get_report_service().cal_customer_data(
                self.get_data_date(), self.get_report_type())

            self._log.debug('customer_data_list=%s', customer_data_list)
            self._log.debug('customer_g14_group_ind_ls=%s', customer_g14_group_ind_ls)

            row_num = len(customer_data_list)
            column_num = column_index_from_string('AD')

            for row in range(0, row_num):
                customer_obj = customer_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.LOCAL_BRANCH.value]
                    elif column == column_index_from_string('B'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('C'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ''  ###可能需要写入公式，暂时写入空
                    elif column == column_index_from_string('D'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.PIX_ID.value]
                    elif column == column_index_from_string('E'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.UEN.value]
                    elif column == column_index_from_string('F'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.OTL_ID.value]
                    elif column == column_index_from_string('G'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.UNIFORM_SOCIAL_CREDIT_CODE.value]
                    elif column == column_index_from_string('H'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CUSTOMER_NAME_CN.value]
                    elif column == column_index_from_string('I'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CUSTOMER_NAME_EN.value]
                    elif column == column_index_from_string('J'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CUSTOMER_CATEGORY.value]
                    elif column == column_index_from_string('K'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.NATIONALITY.value]
                    elif column == column_index_from_string('L'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.COUNTRY.value]
                    elif column == column_index_from_string('M'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.EXPOSURE_COUNTRY.value]
                    elif column == column_index_from_string('N'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.AREA.value]
                    elif column == column_index_from_string('O'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CORP_TYPE.value]
                    elif column == column_index_from_string('P'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CORP_SIZE.value]
                    elif column == column_index_from_string('Q'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.INDUSTRY_CODE.value]
                    elif column == column_index_from_string('R'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.HOLDING_TYPE.value]
                    elif column == column_index_from_string('S'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.UNIQUE_ID_VALUE.value]
                    elif column == column_index_from_string('T'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.GROUP_CODE.value]
                    elif column == column_index_from_string('U'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.GROUP_NAME.value]
                    elif column == column_index_from_string('V'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.GROUP_CHINESE_NAME.value]
                    elif column == column_index_from_string('W'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.STATUS.value]
                    elif column == column_index_from_string('Y'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.DATA_DATE.value]
                    elif column == column_index_from_string('Z'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CONNECTION_UEN.value]
                    elif column == column_index_from_string('AA'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CONNECTION_NAME.value]
                    elif column == column_index_from_string('AB'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=B' + str(row_idx_1)
                        cell.value = cell_formula
                    elif self.get_report_type() == ReportType.G14_REPORT and column == column_index_from_string('AC'):
                        ## ColumnAC is G14 group ind
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.G14_GROUP_IND.value]

            self._log.debug('* customer row_num={}'.format(row_num))
            return customer_data_list, customer_g14_group_ind_ls
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_credit_exposure_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.CREDIT_EXPOSURE.value)
        wb = self.get_workbook()
        credit_exposure_worksheet = wb[LreDailyReportSpreadSheets.CREDIT_EXPOSURE.value]

        try:
            credit_exposure_data_list = self.get_report_service().query_credit_exposure_data(self.get_data_date())

            self._log.debug('credit_exposure_data_list=%s', credit_exposure_data_list)

            row_num = len(credit_exposure_data_list)
            column_num = column_index_from_string('J')

            for row in range(0, row_num):
                credit_exposure_obj = credit_exposure_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = credit_exposure_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = credit_exposure_obj[CreditExposureSheetNum.CUSTOMER_ID.value]
                    elif column == column_index_from_string('B'):
                        cell = credit_exposure_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = credit_exposure_obj[CreditExposureSheetNum.BORROWER.value]
                    elif column == column_index_from_string('C'):
                        cell = credit_exposure_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = credit_exposure_obj[CreditExposureSheetNum.REVOCABLE.value]
                    elif column == column_index_from_string('D'):
                        cell = credit_exposure_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = credit_exposure_obj[CreditExposureSheetNum.AVAILABLE_CREDIT_LIMIT.value]
                    elif column == column_index_from_string('E'):
                        # ColumnE is UEN_GUARANTOR_1
                        cell = credit_exposure_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = credit_exposure_obj[CreditExposureSheetNum.UEN_GUARANTOR_1.value]
                    elif column == column_index_from_string('F'):
                        cell = credit_exposure_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = credit_exposure_obj[CreditExposureSheetNum.GUARANTOR_TYPE_1.value]
                    elif column == column_index_from_string('G'):
                        cell = credit_exposure_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = credit_exposure_obj[CreditExposureSheetNum.NAME_GUARANTOR_1.value]
                    elif column == column_index_from_string('H'):
                        cell = credit_exposure_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = credit_exposure_obj[CreditExposureSheetNum.ORG_PERIOD_IN_ONE_YEAR.value]

            self._log.debug('*** CREDIT EXPOSURE data nums={}'.format(len(credit_exposure_data_list)))
        except DataException as err:
            # 没有数据可能是正常现象
            self._log.warning(err, exc_info=True)
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_dsc_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.DSC.value)
        wb = self.get_workbook()
        dsc_worksheet = wb[LreDailyReportSpreadSheets.DSC.value]

        try:
            dsc_data_list = self.get_report_service().query_dsc_data(self.get_data_date())
            self._log.debug('dsc_data_list=%s', dsc_data_list)
            row_num = len(dsc_data_list)
            column_num = column_index_from_string('CQ')

            for row in range(0, row_num):
                dsc_obj = dsc_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('B'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.BENEFICARY_CBS_ID.value]
                    elif column == column_index_from_string('C'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.RISKPARTY_UEN.value]
                    elif column == column_index_from_string('D'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.RISKPARTY_CBSID.value]
                    elif column == column_index_from_string('H'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.PRODUCT.value]
                    elif column == column_index_from_string('K'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.WITH_BANK_CUSTOMER.value]
                    elif column == column_index_from_string('L'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.RISKPARTY_CBSID_2.value]
                    elif column == column_index_from_string('U'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.RISKPARTY_UEN_2.value]
                    elif column == column_index_from_string('V'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.CURRENCY.value]
                    elif column == column_index_from_string('W'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.AMOUNT.value]
                    elif column == column_index_from_string('AA'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.OUR_REF.value]
                    elif column == column_index_from_string('AK'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.INTEREST_IN_ADVANCE.value]
                    elif column == column_index_from_string('AR'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.INCOME_ACCRUAL_AMOUNT.value]
                    elif column == column_index_from_string('CO'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = dsc_obj[DscSheetEnum.CURRENCY.value]

                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IF(AK{row_idx_1}="Y",IFERROR(IF(V{row_idx_1}="CNY",W{row_idx_1}, W{row_idx_1} * {cny_rate} ) ,0),IFERROR(IF(V{row_idx_1}="CNY",W{row_idx_1}+AR{row_idx_1}, (W{row_idx_1}+AR{row_idx_1})* {cny_rate} ),0))'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula
                    elif column == column_index_from_string('CP'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = dsc_obj[DscSheetEnum.CURRENCY.value]

                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IF(AK{row_idx_1}="Y",IFERROR(IF(V{row_idx_1}="CNY",W{row_idx_1}, W{row_idx_1} * {cny_rate} ),0),IFERROR(IF(V{row_idx_1}="CNY",W{row_idx_1}, (W{row_idx_1}) * {cny_rate} ),0))'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

            self._log.debug('DSC nums={}'.format(len(dsc_data_list)))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_mm505_sheet(self, mm505_worksheet, mm505_data_list):

        self._log.debug('mm505_data_list=%s', mm505_data_list)

        row_num = len(mm505_data_list)
        column_num = column_index_from_string('AG')

        for row in range(0, row_num):
            mm505_obj = mm505_data_list[row]
            row_idx_1 = row + 2

            for column in range(0, column_num):
                if column == column_index_from_string('A'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell_formula = '=AC{idx}'.format(idx=row_idx_1)
                    cell.value = cell_formula
                elif column == column_index_from_string('B'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = self.get_data_date()
                elif column == column_index_from_string('H'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.VALUE_DATE.value]
                elif column == column_index_from_string('I'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.MAT_DATE.value]
                elif column == column_index_from_string('J'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.DEAL_TYPE.value]
                elif column == column_index_from_string('K'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.DEAL_TYPE_RRA.value]
                elif column == column_index_from_string('M'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.CCY.value]
                elif column == column_index_from_string('N'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.AMOUNT.value]
                elif column == column_index_from_string('O'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.TOTAL_INTEREST.value]
                elif column == column_index_from_string('S'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.NAME_SHORT.value]
                elif column == column_index_from_string('U'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.TYPE.value]
                elif column == column_index_from_string('V'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.MM_CUST_NUM.value]
                elif column == column_index_from_string('AA'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.INVENTORY.value]
                elif column == column_index_from_string('AB'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.CUSTOMER_SHORT_NAME.value]
                elif column == column_index_from_string('AC'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.CBS_ID.value]
                elif column == column_index_from_string('AD'):
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell.value = mm505_obj[MM505SheetEnum.CNY_EQV.value]
                elif column == column_index_from_string('AE') and self.get_report_type() == ReportType.G14_REPORT:
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell_formula = '=VLOOKUP(AC{idx},Customer!B:E,4,0)'.format(idx=row_idx_1)
                    cell.value = cell_formula
                elif column == column_index_from_string('AF') and self.get_report_type() == ReportType.G14_REPORT:
                    cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                    cell_formula = '=A{idx}'.format(idx=row_idx_1)
                    cell.value = cell_formula

            self._log.debug('MM505 nums={}'.format(len(mm505_data_list)))

    def init_master_list(self, master_list_worksheet, row_index, column_index):

        if column_index == column_index_from_string('A'):
            # ColumnA is UEN
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(ISBLANK(VLOOKUP(B{idx},Customer!$B:$E,4,0)),"",VLOOKUP(B{idx},Customer!$B:$E,4,0))'.format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('B'):
            # ColumnB is CBS_ID
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=Customer!B{idx}'.format(idx=(row_index - 1))
            cell.value = cell_formula
        elif column_index == column_index_from_string('C'):
            # ColumnC is CUSTOMER_NAME_EN
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=VLOOKUP(B{idx},Customer!$B:$I,8,0)'.format(idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('D'):
            # ColumnD is CUSTOMER_CATEGORY
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=VLOOKUP(B{idx},Customer!$B:$J,9,0)'.format(idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('E'):
            # ColumnE is CBS Group
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(IF(D{idx}="CORPORATE",VLOOKUP(B{idx},Customer!$B:$AA,19,0),"")=0,"",IF(D{idx}="CORPORATE",VLOOKUP(B{idx},Customer!$B:$AA,19,0),""))'.format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('F'):
            # ColumnF is Connection UEN
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(ISBLANK(VLOOKUP(B{idx},Customer!B:Z,25,0)),"",VLOOKUP(B{idx},Customer!B:Z,25,0))'.format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('G'):
            # ColumnG is G14 group ind
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(AND(E{idx}="",OR(F{idx}="",F{idx}=0)),"N","Y")'.format(idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('H'):
            # ColumnH is H14 cust type\nG14 客户类型
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(G{idx}="Y",IF(OR(D{idx}="CORPORATE",D{idx}="GOV"),"非同业集团客户","同业集团客户"),IF(OR(D{idx}="CORPORATE",D{idx}="GOV"),"非同业单一客户","同业单一客户"))'.format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('I'):
            # ColumnI is Is UEN Duplicate?
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(COUNTIF($A:$A,A{idx})=1,"N",IF(A{idx}=0,"N","Y"))'.format(idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('J'):
            # ColumnJ is Total Risk Exposure\n风险暴露总和
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=SUM(M{idx}:R{idx},V{idx})'.format(idx=row_index)
            cell.value = cell_formula
        elif column_index == column_index_from_string('K'):
            # ColumnK is %
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=J{idx}/'Other inputs'!$B$3".format(idx=row_index)
            cell.number_format = '0.00%'
            cell.value = cell_formula
        elif column_index == column_index_from_string('L'):
            # ColumnL is LRE IND
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(K{idx}>=2.5%,"Y","N")'.format(idx=row_index)
            cell.value = cell_formula
        elif column_index == column_index_from_string('M'):
            # ColumnM is General Risk Exposure\n一般风险暴露
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=SUM(W{idx}:Y{idx}, AH{idx}:AJ{idx},AA{idx}:AB{idx},AN{idx})-SUM(AR{idx}:AV{idx})'.format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('N'):
            # ColumnN is Counterparty Credit Risk Exposure\n交易对手信用风险暴露
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=SUM(BD{idx})'.format(idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('O'):
            # ColumnO is Potential Risk Exposure\n潜在风险暴露
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=SUM($AC{idx}:$AG{idx}) - SUM(AW{idx}:AY{idx})'.format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('P'):
            # ColumnP is Trading Book Risk Exposure\n交易账簿风险暴露
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=AK{idx}+AL{idx}'.format(idx=row_index)
            cell.value = cell_formula
        elif column_index == column_index_from_string('Q'):
            # ColumnQ is Specified Risk Exposure 特定风险暴露
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell.value = 0
        elif column_index == column_index_from_string('R'):
            # ColumnR is Other Risk Exposure 其他风险暴露
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell.value = 0
        elif column_index == column_index_from_string('S'):
            # ColumnS is Loan balance\n贷款余额
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS(Loan!BP:BP,Loan!$A:$A,'Daily Master List'!B{idx})/10000+Z{idx}".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('T'):
            # ColumnT is Exception
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(OR(B{idx}="009000",B{idx}="301148",B{idx}="300621",B{idx}="300622",B{idx}="300761"),J{idx},AQ{idx})'.format(
                idx=row_index)
            cell.value = cell_formula
        elif column_index == column_index_from_string('U'):
            # ColumnU is Risk transfer ind\n风险缓释
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(COUNTIF($A$3:A{idx},A{idx})=1, IF(AZ{idx}="Y", "Y", IF(BA{idx}="Y", "Y", "")), "" )'.format(
                idx=row_index)
            cell.value = cell_formula
        elif column_index == column_index_from_string('V'):
            # ColumnV is Risk mitigation & transfer
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(COUNTIF($A$3:A{idx},A{idx})=1,IF($AZ{idx}="Y", -($W{idx}+SUM($AC{idx}:$AE{idx})-SUM($AR{idx},$AW{idx})), IF($BA{idx}="Y", -SUMIF($BB:$BB,$A{idx},$V:$V), 0)),0)'.format(
                idx=row_index)
            cell.value = cell_formula
        elif column_index == column_index_from_string('W'):
            # ColumnW is Corporate Lending
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS(Loan!$BO:$BO,Loan!$A:$A,$B{idx})/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('X'):
            # ColumnX is FIG Loans (IFI)
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS(DSC!$CO:$CO,DSC!$D:$D,$B{idx},DSC!$K:$K,\"IFI\")/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('Y'):
            # ColumnY is TF finance (DSC)
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS(DSC!$CO:$CO,DSC!$D:$D,$B{idx},DSC!$K:$K,\"DSC\")/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('Z'):
            # ColumnZ is TF finance (DSC)\n贷款余额
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS(DSC!$CP:$CP,DSC!$B:$B,$B{idx},DSC!$K:$K,\"DSC\")/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AA'):
            # ColumnAA is Others
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=SUMIFS(PBOC!$F:$F,PBOC!A:A,\'Daily Master List\'!B{idx})/10000'.format(
                idx=row_index)
            cell.value = cell_formula
        elif column_index == column_index_from_string('AB'):
            # ColumnAB is Auto Fin
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS('Auto Fin'!F:F,'Auto Fin'!A:A,'Daily Master List'!B{idx})/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AC'):
            # ColumnAC is Irrevocable Loan Commitment <=1Yr
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=$AC$2*SUMIFS(Limit!$AJ:$AJ,Limit!$A:$A,$B{idx},Limit!$R:$R,\"Irrevocable\",Limit!$U:$U,\"Y\")/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AD'):
            # ColumnAD is Irrevocable Loan Commitment >1Yr
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=$AD$2*SUMIFS(Limit!$AJ:$AJ,Limit!$A:$A,$B{idx},Limit!$R:$R,\"Irrevocable\",Limit!$U:$U,\"N\")/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AE'):
            # ColumnAE is Revocable Loan Commitment
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=$AE$2*SUMIFS(Limit!$AJ:$AJ,Limit!$A:$A,$B{idx},Limit!$R:$R,\"Revocable\")/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AF'):
            # ColumnAF is Non-financial Guarantee
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=$AF$2*SUMIFS('offbs TF'!$X:$X,'offbs TF'!$A:$A,$B{idx},'offbs TF'!$D:$D,$AF$2)/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AG'):
            # ColumnAG is LC Issurance/confirmation
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=$AG$2*SUMIFS('offbs TF'!$X:$X,'offbs TF'!$A:$A,$B{idx},'offbs TF'!$D:$D,$AG$2)/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AH'):
            # ColumnAH is MM 505 Lending/placing
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS('MM 505'!$AD:$AD,'MM 505'!$AA:$AA,\"Y\",'MM 505'!$J:$J,\"XL\",'MM 505'!$A:$A,'Daily Master List'!B{idx})/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AI'):
            # ColumnAI is Bond （Bank Book）
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS('Bond & NCD'!$G:$G, 'Bond & NCD'!$C:$C, $A{idx},'Bond & NCD'!$I:$I,\"T3773\",'Bond & NCD'!$B:$B,\"<>NCD\")/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AJ'):
            # ColumnAJ is  NCD（Bank Book）
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS('Bond & NCD'!$G:$G, 'Bond & NCD'!$C:$C, $A{idx},'Bond & NCD'!$I:$I,\"T3773\",'Bond & NCD'!$B:$B,\"NCD\")/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AK'):
            # ColumnAK is  Bond （Trading Book）
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS('Bond & NCD'!$G:$G, 'Bond & NCD'!$C:$C, $A{idx},'Bond & NCD'!$I:$I,\"T9534\",'Bond & NCD'!$B:$B,\"<>NCD\")/10000".format(
                idx=row_index)
            cell.value = cell_formula
        elif column_index == column_index_from_string('AL'):
            # ColumnAL is NCD（Trading Book）
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS('Bond & NCD'!$G:$G, 'Bond & NCD'!$C:$C, $A{idx},'Bond & NCD'!$I:$I,\"T9534\",'Bond & NCD'!$B:$B,\"NCD\")/10000".format(
                idx=row_index)
            cell.value = cell_formula
        elif column_index == column_index_from_string('AM'):
            # ColumnAM is Exposure under Derivatives
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS(EAD!$I:$I,EAD!A:A,'Daily Master List'!B{idx})/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AN'):
            # ColumnAN is Nostro placing (non-settlement account)
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS(Nostro!F:F,Nostro!A:A,'Daily Master List'!B{idx})/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AO'):
            # ColumnAO is Provision Potential Risk Exposure
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$B:$B,\"OFFBS\")/10000,0)".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AP'):
            # ColumnAP is  Checking
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell.value = ''
        elif column_index == column_index_from_string('AQ'):
            # ColumnAQ is Exception\n-Policy Bond
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=SUMIFS('Bond & NCD'!G:G,'Bond & NCD'!A:A,B{idx},'Bond & NCD'!B:B,\"POL\")/10000+SUMIFS('Bond & NCD'!G:G,'Bond & NCD'!A:A,B{idx},'Bond & NCD'!B:B,\"GVT\")/10000".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AR'):
            # ColumnAR is Provision\n- Corporate Loan
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$C:$C,\"Corporate Loan\")/10000,0)".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AS'):
            # ColumnAS is Provision\n- Auto Finance
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$C:$C,\"Auto Fin\")/10000,0)".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AT'):
            # ColumnAT is Provision\n- FIG Lending (IFI)
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$C:$C,\"Refinancing\")/10000,0)".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AU'):
            # ColumnAU is Provision\n-TF finance (DSC)
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$C:$C,\"LC discounting\")/10000,0)+IF(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$C:$C,\"BADD\")/10000,0)".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AV'):
            # ColumnAV is Provision\n- MM 505\nLending/placing
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$C:$C,\"Interbank Lending\")/10000,0)".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AW'):
            # ColumnAW is Provision\n- Commitment
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$C:$C,\"Commitment\")/10000,0)".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AX'):
            # ColumnAX is Provision\n- Guarantee
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$C:$C,\"Guarantee\")/10000,0)".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AY'):
            # ColumnAY is Provision\n- LC Issurance/\nconfirmation
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$C:$C,\"LC\")/10000,0)".format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('AZ'):
            # ColumnAZ is Risk transfer indicator - customer
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IFERROR(IF(VLOOKUP(B{idx}, \'CREDIT EXPOSURE\'!A:F,6,FALSE)="Commercial Bank", "Y", ""),"")'.format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('BA'):
            # ColumnBA is Risk transfer indicator - guarantor
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IFERROR(IF(VLOOKUP(A{idx}, \'CREDIT EXPOSURE\'!E:F,2,FALSE)="Commercial Bank", "Y", ""), "")'.format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('BB'):
            # ColumnBB is guarantor UEN
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(AZ{idx}="Y", VLOOKUP(B{idx}, \'CREDIT EXPOSURE\'!A:E, 5,FALSE ), "")'.format(
                idx=(row_index))
            cell.value = cell_formula
        elif column_index == column_index_from_string('BC'):
            # ColumnBC is Provision - Total
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=SUM($AR{idx}:$AY{idx})'.format(
                idx=row_index)
            cell.value = cell_formula
        elif column_index == column_index_from_string('BD'):
            # ColumnBD is FEFC
            cell = master_list_worksheet.cell(row=row_index, column=column_index)
            cell_formula = '=IF(COUNTIF($A$3:A{idx},A{idx})=1,$BD$2*SUMIFS(FEFC!$C:$C,FEFC!$A:$A,A{idx})/10000,0)'.format(
                idx=row_index)
            cell.value = cell_formula


class LreDailyReport(BaseReport):
    """ daily 报表 """

    def __init__(self, data_date):
        super(LreDailyReport, self).__init__(ReportType.DAILY_REPORT, data_date)

    def montior_report(self):
        """
         监控报表
        :return:
        """
        monitor = None
        try:
            self.load_target_report_with_dataonly()

            wb = self.get_workbook()
            summary_control_worksheet = wb[LreDailyReportSpreadSheets.SUMMARY_CONTROL.value]

            # 非同业单一客户贷款余额
            d6_value = summary_control_worksheet['D6'].value
            # 非同业单一客户风险暴露余额
            d8_value = summary_control_worksheet['D8'].value
            # 一组非同业关联客户风险暴露余额
            d10_value = summary_control_worksheet['D10'].value
            # 同业单一客户或集团客户风险暴露
            d12_value = summary_control_worksheet['D12'].value

            self._log.debug("*****************************")
            self._log.debug("*** montior_report() ***")
            self._log.debug("*****************************")
            self._log.debug('d6_value={}'.format(d6_value))
            self._log.debug('d8_value={}'.format(d8_value))
            self._log.debug('d10_value={}'.format(d10_value))
            self._log.debug('d12_value={}'.format(d12_value))

            e6_value = summary_control_worksheet['E6'].value
            e8_value = summary_control_worksheet['E8'].value
            e10_value = summary_control_worksheet['E10'].value
            e12_value = summary_control_worksheet['E12'].value
            self._log.debug('e6_value={}'.format(e6_value))
            self._log.debug('e8_value={}'.format(e8_value))
            self._log.debug('e10_value={}'.format(e10_value))
            self._log.debug('e12_value={}'.format(e12_value))

            g6_value = summary_control_worksheet['G6'].value
            h6_value = summary_control_worksheet['H6'].value
            g7_value = summary_control_worksheet['G7'].value
            h7_value = summary_control_worksheet['H7'].value
            self._log.debug('g6_value={}'.format(g6_value))
            self._log.debug('h6_value={}'.format(h6_value))
            self._log.debug('g7_value={}'.format(g7_value))
            self._log.debug('h7_value={}'.format(h7_value))

            i8_value = summary_control_worksheet['I8'].value
            j8_value = summary_control_worksheet['J8'].value
            i9_value = summary_control_worksheet['I9'].value
            j9_value = summary_control_worksheet['J9'].value
            self._log.debug('i8_value={}'.format(i8_value))
            self._log.debug('j8_value={}'.format(j8_value))
            self._log.debug('i9_value={}'.format(i9_value))
            self._log.debug('j9_value={}'.format(j9_value))

            i10_value = summary_control_worksheet['I10'].value
            j10_value = summary_control_worksheet['J10'].value
            i11_value = summary_control_worksheet['I11'].value
            j11_value = summary_control_worksheet['J11'].value
            self._log.debug('i10_value={}'.format(i10_value))
            self._log.debug('j10_value={}'.format(j10_value))
            self._log.debug('i11_value={}'.format(i11_value))
            self._log.debug('j11_value={}'.format(j11_value))

            i12_value = summary_control_worksheet['I12'].value
            j12_value = summary_control_worksheet['J12'].value
            i13_value = summary_control_worksheet['I13'].value
            j13_value = summary_control_worksheet['J13'].value
            self._log.debug('i12_value={}'.format(i12_value))
            self._log.debug('j12_value={}'.format(j12_value))
            self._log.debug('i13_value={}'.format(i13_value))
            self._log.debug('j13_value={}'.format(j13_value))

            monitor = RatioMonitorData()
            self._log.debug('monitor', monitor)

            monitor.d6 = convert_digital_precision(d6_value, precision=1)
            monitor.g6 = convert_digital_precision(g6_value, precision=2)
            monitor.h6 = convert_digital_precision(h6_value, precision=2)
            monitor.g7 = g7_value
            monitor.h7 = h7_value
            if g6_value > d6_value or h6_value > d6_value:
                monitor.is_over_d6 = True
            else:
                monitor.is_over_d6 = False

            monitor.e6 = convert_digital_precision(e6_value, precision=1)
            if g6_value > e6_value or h6_value > e6_value:
                monitor.is_over_e6 = True
            else:
                monitor.is_over_e6 = False

            monitor.d8 = convert_digital_precision(d8_value, precision=1)
            monitor.i8 = convert_digital_precision(i8_value, precision=2)
            monitor.j8 = convert_digital_precision(j8_value, precision=2)
            monitor.i9 = i9_value
            monitor.j9 = j9_value
            if i8_value > d8_value or j8_value > d8_value:
                monitor.is_over_d8 = True
            else:
                monitor.is_over_d8 = False

            monitor.e8 = convert_digital_precision(e8_value, precision=1)
            if i8_value > e8_value or j8_value > e8_value:
                monitor.is_over_e8 = True
            else:
                monitor.is_over_e8 = False

            monitor.d10 = convert_digital_precision(d10_value, precision=1)
            monitor.i10 = convert_digital_precision(i10_value, precision=2)
            monitor.j10 = convert_digital_precision(j10_value, precision=2)
            monitor.i11 = i11_value
            monitor.j11 = j11_value
            if i10_value > d10_value or j10_value > d10_value:
                monitor.is_over_d10 = True
            else:
                monitor.is_over_d10 = False

            monitor.e10 = convert_digital_precision(e10_value, precision=1)
            if i10_value > e10_value or j10_value > e10_value:
                monitor.is_over_e10 = True
            else:
                monitor.is_over_e10 = False

            monitor.d12 = convert_digital_precision(d12_value, precision=1)
            monitor.i12 = convert_digital_precision(i12_value, precision=2)
            monitor.j12 = convert_digital_precision(j12_value, precision=2)
            monitor.i13 = i13_value
            monitor.j13 = j13_value
            if i12_value > d12_value or j12_value > d12_value:
                monitor.is_over_d12 = True
            else:
                monitor.is_over_d12 = False

            monitor.e12 = convert_digital_precision(e12_value, precision=1)
            if i12_value > e12_value or j12_value > e12_value:
                monitor.is_over_e12 = True
            else:
                monitor.is_over_e12 = False

            return monitor
        except Exception as err:
            raise ReportException(err)

    def init_daily_mm505_sheet(self):

        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.MM_505.value)
        wb = self.get_workbook()
        mm505_worksheet = wb[LreDailyReportSpreadSheets.MM_505.value]

        try:
            mm505_data_list = self.get_report_service().query_daily_money_market_data(self.get_data_date())
            super(LreDailyReport, self).init_mm505_sheet(mm505_worksheet, mm505_data_list)
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_daily_master_list_sheet(self, customer_data_list):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.DAILY_MASTER_LIST.value)
        wb = self.get_workbook()
        master_list_worksheet = wb[LreDailyReportSpreadSheets.DAILY_MASTER_LIST.value]

        try:
            row_num = len(customer_data_list)
            column_num = column_index_from_string('BE')

            for row in range(0, row_num):
                row_idx_1 = row + 3

                for column in range(0, column_num):

                    super(LreDailyReport, self).init_master_list(master_list_worksheet, row_idx_1, column)

                    if column == column_index_from_string('N'):
                        # ColumnN is Counterparty Credit Risk Exposure\n交易对手信用风险暴露
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=SUM(BD{idx})'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('S'):
                        # ColumnS is Loan balance\n贷款余额
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS(Loan!BP:BP,Loan!$A:$A,'Daily Master List'!B{idx})/10000+Z{idx}".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('AA'):
                        # ColumnAA is Others
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=SUMIFS(PBOC!$F:$F,PBOC!A:A,\'Daily Master List\'!B{idx})/10000'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AB'):
                        # ColumnAB is Auto Fin
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('Auto Fin'!F:F,'Auto Fin'!A:A,'Daily Master List'!B{idx})/10000".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('AH'):
                        # ColumnAH is MM 505 Lending/placing
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('MM 505'!$AD:$AD,'MM 505'!$AA:$AA,\"Y\",'MM 505'!$J:$J,\"XL\",'MM 505'!$A:$A,'Daily Master List'!B{idx})/10000".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('AM'):
                        # ColumnAM is Exposure under Derivatives
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS(EAD!$I:$I,EAD!A:A,'Daily Master List'!B{idx})/10000".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('AN'):
                        # ColumnAN is Nostro placing (non-settlement account)
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS(Nostro!F:F,Nostro!A:A,'Daily Master List'!B{idx})/10000".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('AQ'):
                        # ColumnAQ is Exception\n-Policy Bond
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('Bond & NCD'!G:G,'Bond & NCD'!A:A,B{idx},'Bond & NCD'!B:B,\"POL\")/10000+SUMIFS('Bond & NCD'!G:G,'Bond & NCD'!A:A,B{idx},'Bond & NCD'!B:B,\"GVT\")/10000".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('BD'):
                        # ColumnBD is FEFC
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(COUNTIF($A$3:A{idx},A{idx})=1,$BD$2*SUMIFS(FEFC!$C:$C,FEFC!$A:$A,A{idx})/10000,0)'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula

            self._log.debug('*** daily master data nums={}'.format(row_num))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_single_cust_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.SINGLE_CUST.value)
        wb = self.get_workbook()
        single_cust_worksheet = wb[LreDailyReportSpreadSheets.SINGLE_CUST.value]

        try:
            customer_df = filter_data_daily_single_cust(self.get_target_report())
            row_num = customer_df.shape[0]
            column_num = column_index_from_string('AK')

            for row in range(0, row_num):
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        # ColumnA is CBS_ID
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 0]
                    elif column == column_index_from_string('B'):
                        # ColumnB is CUSTOMER_NAME_EN
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=VLOOKUP(A{idx},Customer!B:I,8,FALSE)'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('C'):
                        # ColumnC is UEN
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=VLOOKUP(A{idx},Customer!$B:$E,4,FALSE)'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('D'):
                        # COlumnD is Is UEN Duplicate?
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(COUNTIF($C:$C,C{idx})=1,"N",IF(C{idx}=0,"N","Y"))'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('E'):
                        # ColumnE is Loan balance Pre-control Rank
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(F{idx}<>0,RANK(F{idx},F:F)+COUNTIF($F$3:$F{idx},F{idx})-1,0)'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('F'):
                        # ColumnF is Loan balance Pre-control Balance
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=J{idx}+S{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('G'):
                        # ColumnG is Loan balance Pre-control %
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=F{idx}/'Other inputs'!$B$2".format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('H'):
                        # ColumnH is Loan balance Pre-control Available room
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "='Other inputs'!$B$2 * 'Summary Control'!$F$1-F{idx}".format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('I'):
                        # ColumnI is Loan balance -Reporting Rank
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(J{idx}<>0,RANK(J{idx},J:J)+COUNTIF(J{idx},$J$3:$J{idx})-1,0)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('J'):
                        # ColumnJ is Loan balance -Reporting Balance
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!S:S)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('K'):
                        # ColumnK is Loan balance -Reporting %
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=J{idx}/'Other inputs'!$B$2".format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('L'):
                        # ColumnL is Non-bank exposure w. risk replacement Pre-control Rank
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(M{idx}<>0,RANK(M{idx},M:M)+COUNTIF($M$3:$M{idx},M{idx})-1,0)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('M'):
                        # ColumnM is Non-bank exposure w. risk replacement Pre-control Exposure
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=Q{idx}+S{idx}".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('N'):
                        # ColumnN is Non-bank exposure w. risk replacement Pre-control %
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=M{idx}/'Other inputs'!$B$3".format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('O'):
                        # ColumnO is Non-bank exposure w. risk replacement Pre-control Available room
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "='Other inputs'!$B$3 * 'Summary Control'!$F$2 - M{idx}".format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('P'):
                        # ColumnP is Non-bank exposure w. risk replacement reporting Rank
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(Q{idx}<>0,RANK(Q{idx},Q:Q)+COUNTIF($Q$3:$Q{idx},Q{idx})-1,0)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('Q'):
                        # ColumnQ is Non-bank exposure w. risk replacement reporting Exposure
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A,$C{idx},'Daily Master List'!J:J)-SUMIF('Daily Master List'!$A:$A,$C{idx},'Daily Master List'!T:T)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('R'):
                        # ColumnR is Non-bank exposure w. risk replacement reporting %
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=Q{idx}/'Other inputs'!$B$3".format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('S'):
                        # ColumnS is Facility earmark in RMB'0000
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ''
                    elif column == column_index_from_string('U'):
                        # ColumnU is Corporate Lending
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!W:W)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('V'):
                        # ColumnV is GB Loans (IFI)
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!X:X)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('W'):
                        # ColumnW is GT finance (DSC)
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!Y:Y)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('X'):
                        # ColumnX is Risk mitigation & transfer
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!V:V)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('Y'):
                        # ColumnY is Irrevocable Loan Commitment <=1Yr
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!AC:AC)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('Z'):
                        # ColumnZ is Irrevocable Loan Commitment >1Yr
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!AD:AD)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AA'):
                        # ColumnAA is Revocable Loan Commitment
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!AE:AE)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AB'):
                        # ColumnAB is Non-financial Guarantee
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!AF:AF)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AC'):
                        # ColumnAC is LC Issurance/ confirmation
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!AG:AG)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AD'):
                        # ColumnAD is MM 505 Lending/placing
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!AH:AH)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AE'):
                        # ColumnAE is Bond & NCD（Bank Book)
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!$AI:$AI)+SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!AJ:AJ)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AF'):
                        # ColumnAF is Bond & NCD（Trading Book)
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!$AK:$AK)+SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!AL:AL)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AG'):
                        # ColumnAG is Exposure under Derivatives
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!AM:AM)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AH'):
                        # ColumnAH is Nostro
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!AN:AN)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AI'):
                        # ColumnAI is Provision
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!BC:BC)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AJ'):
                        # ColumnAJ is FEFC
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$A:$A, $C{idx}, 'Daily Master List'!BD:BD)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula

            self._log.debug('*** daily single_cust data nums={}'.format(customer_df.shape[0]))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_fefc_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.FEFC.value)
        wb = self.get_workbook()
        fefc_worksheet = wb[LreDailyReportSpreadSheets.FEFC.value]

        try:
            fefc_list = self.get_report_service().query_fefc_data(self.get_data_date())

            self._log.debug('fefc_list=%s', fefc_list)

            row_num = len(fefc_list)
            column_num = column_index_from_string('D')

            for row in range(0, row_num):
                fefc_obj = fefc_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = fefc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = fefc_obj[FefcSheetNum.UEN.value]
                    elif column == column_index_from_string('B'):
                        cell = fefc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = fefc_obj[FefcSheetNum.PRODUCT_EXPOSURE.value]
                    elif column == column_index_from_string('C'):
                        cell = fefc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = fefc_obj[FefcSheetNum.PRODUCT_EXPOSURE_CNY.value]

            self._log.debug('fefc nums={}'.format(len(fefc_list)))
        except DataException as err:
            raise ReportException(err)
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_group_corp_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.GROUP_CORP.value)
        wb = self.get_workbook()
        group_corp_worksheet = wb[LreDailyReportSpreadSheets.GROUP_CORP.value]

        try:
            customer_df = filter_data_group_corp(self.get_target_report())
            row_num = customer_df.shape[0]
            column_num = column_index_from_string('AC')

            for row in range(0, row_num):
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        # ColumnA is 关联客户 ID for Large Risk Exposure
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 0]
                    elif column == column_index_from_string('B'):
                        # ColumnB is 关联客户 Customer Name for Large Risk Exposure
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx},Customer!$T:$V,3,FALSE), "")'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('C'):
                        # ColumnC is 关联客户 Customer Name for Large Risk Exposure
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=A{idx}'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('D'):
                        # ColumnD is  Non-bank exposure w. risk replacement Pre-control Rank
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(E{idx}<>0,RANK(E{idx},E:E)+COUNTIF($E$3:$E{idx},E{idx})-1,0)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('E'):
                        # ColumnE is  Non-bank exposure w. risk replacement Pre-control Exposure
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=I{idx}+K{idx}".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('F'):
                        # ColumnF is  Non-bank exposure w. risk replacement Pre-control %
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=E{idx}/'Other inputs'!$B$3".format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('G'):
                        # ColumnG is  Non-bank exposure w. risk replacement Pre-control Available room
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "='Other inputs'!$B$3 * 'Summary Control'!$F$3-$E{idx}".format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('H'):
                        # ColumnH is Non-bank exposure w. risk replacement reporting Rank
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(I{idx}<>0,RANK(I{idx},I:I)+COUNTIF($I$3:$I{idx},I{idx})-1,0)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('I'):
                        # ColumnI is Non-bank exposure w. risk replacement reporting Exposure
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E,$A{idx},'Daily Master List'!J:J)-SUMIF('Daily Master List'!$E:$E,$A{idx},'Daily Master List'!T:T)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('J'):
                        # ColumnJ is Non-bank exposure w. risk replacement reporting %
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=I{idx}/'Other inputs'!$B$3".format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('K'):
                        # ColumnK is Facility earmark in RMB'0000
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ''
                    elif column == column_index_from_string('M'):
                        # ColumnM is Corporate Lending
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!W:W)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('N'):
                        # ColumnN is GB Loans (IFI)
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!X:X)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('O'):
                        # ColumnO is GT finance (DSC)
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!Y:Y)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('P'):
                        # ColumnP is Risk mitigation & transfer
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!V:V)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('Q'):
                        # ColumnQ is Irrevocable Loan Commitment <=1Yr
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!AC:AC)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('R'):
                        # ColumnR is Irrevocable Loan Commitment >1Yr
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!AD:AD)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('S'):
                        # ColumnS is Revocable Loan Commitment
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!AE:AE)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('T'):
                        # ColumnT is Non-financial Guarantee
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!AF:AF)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('U'):
                        # ColumnU is LC Issurance/ confirmation
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!AG:AG)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('V'):
                        # ColumnV is MM 505 Lending/placing
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!AH:AH)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('W'):
                        # ColumnW is Bond & NCD (Bank Book)
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!$AI:$AI)+SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!AJ:AJ)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('X'):
                        # ColumnX is Bond & NCD (Trading Book)
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!$AK:$AK)+SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!AL:AL)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('Y'):
                        # ColumnY is Exposure under Derivatives
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!AM:AM)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('Z'):
                        # ColumnZ is Nostro
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!AN:AN)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AA'):
                        # ColumnAA is Provision
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!BC:BC)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AB'):
                        # ColumnAB is FEFC
                        cell = group_corp_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIF('Daily Master List'!$E:$E, $A{idx}, 'Daily Master List'!BD:BD)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula

            self._log.debug('*** group_corp data nums={}'.format(customer_df.shape[0]))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_group_bank_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.GROUP_BANK.value)
        wb = self.get_workbook()
        group_bank_worksheet = wb[LreDailyReportSpreadSheets.GROUP_BANK.value]

        try:
            customer_df = filter_data_group_bank(self.get_target_report())
            row_num = customer_df.shape[0]
            column_num = column_index_from_string('AH')

            for row in range(0, row_num):
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        # ColumnA is 关联客户 ID for Large Risk Exposure
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 0]
                    elif column == column_index_from_string('B'):
                        # ColumnB is 关联客户 Customer Name for Large Risk Exposure
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF($C{idx}="Y",IFERROR(VLOOKUP($A{idx},Customer!$Z:$AA,2,FALSE), "") ,IFERROR(VLOOKUP($A{idx},Customer!$E:$H,4,FALSE), "") )'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('C'):
                        # ColumnC is Is connection UEN?
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 2]
                    elif column == column_index_from_string('D'):
                        # ColumnD is Connected UEN for Large Risk Exposure
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF($C{idx}="Y",$A{idx},IFERROR(VLOOKUP($A{idx},Customer!$E:$Z,22),""))'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('E'):
                        # ColumnE is Non-bank exposure w. risk replacement Pre-control Rank
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(F{idx}<>0,RANK(F{idx},F:F)+COUNTIF($F$3:$F{idx},F{idx})-1,0)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('F'):
                        # ColumnF is Non-bank exposure w. risk replacement Pre-control Exposure
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=J{idx}+L{idx}".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('G'):
                        # ColumnG is Non-bank exposure w. risk replacement Pre-control %
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=F{idx}/'Other inputs'!$B$3".format(idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '0.00%'
                    elif column == column_index_from_string('H'):
                        # ColumnH is Non-bank exposure w. risk replacement Pre-control Available room
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "='Other inputs'!$B$3 * 'Summary Control'!$F$4-F{idx}".format(idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('I'):
                        # ColumnI is Non-bank exposure w. risk replacement reporting Rank
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(J{idx}<>0,RANK(J{idx},J:J)+COUNTIF($J$3:$J{idx},J{idx})-1,0)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('J'):
                        # ColumnJ is Non-bank exposure w. risk replacement Exposure
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!J:J)-SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!T:T),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!J:J)-SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!T:T))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('K'):
                        # ColumnK is Non-bank exposure w. risk replacement %
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=J{idx}/'Other inputs'!$B$3".format(idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '0.00%'
                    elif column == column_index_from_string('L'):
                        # ColumnL is Facility earmark in RMB'0000
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ''
                    elif column == column_index_from_string('N'):
                        # ColumnN is Corporate Lending
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!W:W),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!W:W))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('O'):
                        # ColumnO is GB Loans (IFI)
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!X:X),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!X:X))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('P'):
                        # ColumnP is GT finance (DSC)
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!Y:Y),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!Y:Y))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('Q'):
                        # ColumnQ is Risk mitigation & transfer
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!V:V),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!V:V))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('R'):
                        # ColumnR is Irrevocable Loan Commitment <=1Yr
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AC:AC),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AC:AC))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('S'):
                        # ColumnS is Irrevocable Loan Commitment >1Yr
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AD:AD),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AD:AD))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('T'):
                        # ColumnT is Revocable Loan Commitment
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AE:AE),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AE:AE))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('U'):
                        # ColumnU is Non-financial Guarantee
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AF:AF),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AF:AF))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('V'):
                        # ColumnV is LC Issurance/ confirmation
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AG:AG),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AG:AG))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('W'):
                        # ColumnW is MM 505 Lending/placing
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AH:AH),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AH:AH))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('X'):
                        # ColumnX is Bond & NCD (Bank Book)
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AI:AI)+SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AJ:AJ),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AI:AI)+SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AJ:AJ))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('Y'):
                        # ColumnY is Bond & NCD (Trading Book)
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AK:AK)+SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AL:AL),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AK:AK)+SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AL:AL))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('Z'):
                        # ColumnZ is Exposure under Derivatives
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AM:AM),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AM:AM))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('AA'):
                        # ColumnAA is Nostro
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!AN:AN),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!AN:AN))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('AB'):
                        # ColumnAB is Provision
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!BC:BC),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!BC:BC))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('AC'):
                        # ColumnAC is Exception
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!T:T),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!T:T))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('AD'):
                        # ColumnAD is Rank
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(AE{idx}<>0,RANK(AE{idx},AE:AE)+COUNTIF($AE$3:$AE{idx},AE{idx})-1,0)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('AE'):
                        # ColumnAE is Non-bank exposure without Exception
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=J{idx}-AC{idx}".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '#,##0_ '
                    elif column == column_index_from_string('AF'):
                        # ColumnAF is %
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=AE{idx}/'Other inputs'!$B$3".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AG'):
                        # ColumnAG is FEFC
                        cell = group_bank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF($C{idx}=\"Y\",SUMIF('Daily Master List'!$F:$F,$A{idx},'Daily Master List'!BD:BD),SUMIF('Daily Master List'!$A:$A,$A{idx},'Daily Master List'!BD:BD))".format(
                            idx=row_idx_1)
                        cell.value = cell_formula

            self._log.debug('*** group_bank data nums={}'.format(customer_df.shape[0]))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_summary_control_sheet(self):
        self._log.info(LOG_INIT_SHEET, LreDailyReportSpreadSheets.SUMMARY_CONTROL.value)
        wb = self.get_workbook()
        summary_control_worksheet = wb[LreDailyReportSpreadSheets.SUMMARY_CONTROL.value]

        try:
            summary_control_worksheet['C1'].value = get_daily_report_date(self.get_data_date())
            summary_control_worksheet['C2'].value = "='Other inputs'!$B$2"
            summary_control_worksheet['C3'].value = "='Other inputs'!$B$3"

            start_row_num = 6
            end_row_num = start_row_num + 9
            start_column_num = 7
            end_column_num = start_column_num + 5

            for row in range(start_row_num, end_row_num):
                for column in range(start_column_num, end_column_num):
                    if row == 6 and column == column_index_from_string('G'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = "=MAX('Single Cust'!G:G)"
                    elif row == 6 and column == column_index_from_string('H'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = "=MAX('Single Cust'!K:K)"
                    elif row == 7 and column == column_index_from_string('G'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = '=IFERROR(VLOOKUP(1, IF({1,0}, \'Single Cust\'!$E:$E, \'Single Cust\'!$B:$B),2,FALSE),"")'
                    elif row == 7 and column == column_index_from_string('H'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = '=IFERROR(VLOOKUP(1, IF({1,0}, \'Single Cust\'!$I:$I, \'Single Cust\'!$B:$B),2,FALSE),"")'
                    elif row == 8 and column == column_index_from_string('I'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = "=MAX('Single Cust'!N:N)"
                    elif row == 8 and column == column_index_from_string('J'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = "=MAX('Single Cust'!R:R)"
                    elif row == 9 and column == column_index_from_string('I'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = '=IFERROR(VLOOKUP(1, IF({1,0}, \'Single Cust\'!$L:$L, \'Single Cust\'!$B:$B),2,FALSE),"")'
                    elif row == 9 and column == column_index_from_string('J'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = '=IFERROR(VLOOKUP(1, IF({1,0}, \'Single Cust\'!$P:$P, \'Single Cust\'!$B:$B),2,FALSE),"")'
                    elif row == 10 and column == column_index_from_string('I'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = '=MAX(\'Group Corp\'!F:F)'
                    elif row == 10 and column == column_index_from_string('J'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = '=MAX(\'Group Corp\'!J:J)'
                    elif row == 11 and column == column_index_from_string('I'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = '=IFERROR(VLOOKUP(1, IF({1,0}, \'Group Corp\'!$D:$D, \'Group Corp\'!$B:$B),2,FALSE), "")'
                    elif row == 11 and column == column_index_from_string('J'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = '=IFERROR(VLOOKUP(1, IF({1,0}, \'Group Corp\'!$H:$H, \'Group Corp\'!$B:$B),2,FALSE), "")'
                    elif row == 12 and column == column_index_from_string('I'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = "=MAX('Group Bank'!G:G)"
                    elif row == 12 and column == column_index_from_string('J'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = "=MAX('Group Bank'!K:K)"
                    elif row == 13 and column == column_index_from_string('I'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = '=IFERROR(VLOOKUP(1, IF({1,0}, \'Group Bank\'!$AD:$AD, \'Group Bank\'!$B:$B),2,FALSE), "")'
                    elif row == 13 and column == column_index_from_string('J'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell.value = '=IFERROR(VLOOKUP(1, IF({1,0}, \'Group Bank\'!$AD:$AD, \'Group Bank\'!$B:$B),2,FALSE), "")'

            start_row_num = 19
            end_row_num = 39
            start_column_num = 1
            end_column_num = column_index_from_string('N')

            for row in range(start_row_num, end_row_num):

                for column in range(start_column_num, end_column_num):
                    # A. Non-bank single customer Loan balance 非同业单一客户贷款余额
                    if column == column_index_from_string('B'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}'.format(idx=row)
                        cell_formula = cell_formula + ', IF({1,0}, \'Single Cust\'!$I:$I, \'Single Cust\'!$B:$B),2,FALSE),"")'
                        cell.value = cell_formula
                    elif column == column_index_from_string('C'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}, \'Single Cust\'!$I:$J,2,FALSE),"")'.format(idx=row)
                        cell.value = cell_formula
                    elif column == column_index_from_string('D'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}, \'Single Cust\'!$I:$K,3,FALSE),"")'.format(idx=row)
                        cell.value = cell_formula
                    # B. Non-bank single customer Risk exposure 非同业单一客户风险暴露余额
                    elif column == column_index_from_string('E'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}'.format(idx=row)
                        cell_formula = cell_formula + ', IF({1,0}, \'Single Cust\'!$P:$P, \'Single Cust\'!$B:$B),2,FALSE),"")'
                        cell.value = cell_formula
                    elif column == column_index_from_string('F'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}, \'Single Cust\'!$P:$Q,2,FALSE),"")'.format(idx=row)
                        cell.value = cell_formula
                    elif column == column_index_from_string('G'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}, \'Single Cust\'!$P:$R,3,FALSE),"")'.format(idx=row)
                        cell.value = cell_formula
                    # C. Non-bank group of connected clients Risk exposure 一组非同业关联客户风险暴露余额
                    elif column == column_index_from_string('H'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}'.format(idx=row)
                        cell_formula = cell_formula + ', IF({1,0}, \'Group Corp\'!$H:$H, \'Group Corp\'!$B:$B),2,FALSE), "")'
                        cell.value = cell_formula
                    elif column == column_index_from_string('I'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}, \'Group Corp\'!$H:$I, 2,FALSE), "")'.format(idx=row)
                        cell.value = cell_formula
                    elif column == column_index_from_string('J'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}, \'Group Corp\'!$H:$J, 3,FALSE), "")'.format(idx=row)
                        cell.value = cell_formula
                    # D. Interbank single/group customer Risk exposure 同业单一客户或集团客户风险暴露
                    elif column == column_index_from_string('K'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}'.format(idx=row)
                        cell_formula = cell_formula + ', IF({1,0}, \'Group Bank\'!$I:$I, \'Group Bank\'!$B:$B),2,FALSE), "")'
                        cell.value = cell_formula
                    elif column == column_index_from_string('L'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}, \'Group Bank\'!$I:$J,2,FALSE), "")'.format(idx=row)
                        cell.value = cell_formula
                    elif column == column_index_from_string('M'):
                        cell = summary_control_worksheet.cell(row=row, column=column)
                        cell_formula = '=IFERROR(VLOOKUP($A{idx}, \'Group Bank\'!$I:$K,3,FALSE), "")'.format(idx=row)
                        cell.value = cell_formula
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()


class G14Report(BaseReport):
    """ g14 报表 """

    def __init__(self, data_date):
        super(G14Report, self).__init__(ReportType.G14_REPORT, data_date)

    def init_g14_mm505_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.MM_505.value)
        wb = self.get_workbook()
        mm505_worksheet = wb[G14ReportSpreadSheets.MM_505.value]

        try:
            mm505_data_list = self.get_report_service().query_g14_money_market_data(self.get_data_date())
            super(G14Report, self).init_mm505_sheet(mm505_worksheet, mm505_data_list)
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_single_interbank_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.SINGLE_INTERBANK.value)
        wb = self.get_workbook()
        single_interbank_worksheet = wb[G14ReportSpreadSheets.SINGLE_INTERBANK.value]

        try:
            #customer_df = filter_data_g14_single_interbank(self.get_target_report())
            cal = CalG14CustomerData(self.get_target_report())
            customer_df = cal.filter_data_g14_single_interbank()
            row_num = customer_df.shape[0]
            column_num = column_index_from_string('W')

            for row in range(0, row_num):
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        # ColumnA is Rank
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=H{idx}'.format(idx=row_idx_1)
                        cell.number_format = '_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        # ColumnB is UEN
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 2]
                    elif column == column_index_from_string('C'):
                        # ColumnC is CUSTOMER_NAME_CH
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(ISBLANK(U{idx}),VLOOKUP(B{idx},Customer!$E:$H,4,FALSE),VLOOKUP(U{idx},Customer!$B:$H,7,FALSE))'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('D'):
                        # ColumnD is UNIFORM_SOCIAL_CREDIT_CODE
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(ISBLANK(U{idx}),IF(ISBLANK(VLOOKUP(B{idx},Customer!$E:$G,3,0)),B{idx},VLOOKUP(B{idx},Customer!$E:$G,3,0)),IF(ISBLANK(VLOOKUP(U{idx},Customer!$B:$G,6,0)),"INPUT",VLOOKUP(U{idx},Customer!$B:$G,6,0)))'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('E'):
                        # ColumnE is Total Risk Exposure, Exposure
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=ROUND(IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$J:$J,'G14 Master List'!A:A,'Single Interbank'!B{idx}), SUMIFS('G14 Master List'!$J:$J,'G14 Master List'!B:B,'Single Interbank'!U{idx})),20)".format(idx=row_idx_1)
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif column == column_index_from_string('F'):
                        # ColumnF is Total Risk Exposure, %
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=E{idx}/'Other inputs'!$B$3".format(idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '0.00%'
                    elif column == column_index_from_string('G'):
                        # ColumnG is Total Risk Exposure, LRE IND
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(F{idx}>=2.5%,"Y","N")'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('H'):
                        # ColumnH is Total Risk Exposure, Rank
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=RANK(E{idx},E:E)+COUNTIF($E$3:E{idx},E{idx})-1'.format(idx=row_idx_1)
                        cell.number_format = '_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('I'):
                        # ColumnI is General Risk Exposure 一般风险暴露
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$M:$M,'G14 Master List'!A:A,'Single Interbank'!B{idx})+SUMIFS('G14 Master List'!$BE:$BE,'G14 Master List'!A:A,'Single Interbank'!B{idx}),SUMIFS('G14 Master List'!$M:$M,'G14 Master List'!B:B,'Single Interbank'!U{idx})+SUMIFS('G14 Master List'!$BE:$BE,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('J'):
                        # ColumnJ is Counterparty Credit Risk Exposure 交易对手信用风险暴露
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$N:$N,'G14 Master List'!A:A,'Single Interbank'!B{idx}), SUMIFS('G14 Master List'!$N:$N,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('K'):
                        # ColumnK is Potential Risk Exposure 潜在风险暴露
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$O:$O,'G14 Master List'!A:A,'Single Interbank'!B{idx})+SUMIFS('G14 Master List'!$BF:$BF,'G14 Master List'!A:A,'Single Interbank'!B{idx}),SUMIFS('G14 Master List'!$O:$O,'G14 Master List'!B:B,'Single Interbank'!U{idx})+SUMIFS('G14 Master List'!$BF:$BF,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('L'):
                        # ColumnL is Trading Book Risk Exposure 交易账簿风险暴露
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$P:$P,'G14 Master List'!A:A,'Single Interbank'!B{idx}), SUMIFS('G14 Master List'!$P:$P,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('M'):
                        # ColumnM is Exception 豁免
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$T:$T,'G14 Master List'!A:A,'Single Interbank'!B{idx}), SUMIFS('G14 Master List'!$T:$T,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('N'):
                        # ColumnN is Risk transfer ind 风险缓释
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$V:$V,'G14 Master List'!$A:$A,B{idx},'G14 Master List'!$U:$U,\"Y\"),SUMIFS('G14 Master List'!$V:$V,'G14 Master List'!$B:$B,U{idx},'G14 Master List'!$U:$U,\"Y\"))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('O'):
                        # ColumnO is General Risk Exposure 一般风险暴露 - 各项贷款
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$AH:$AH,'G14 Master List'!A:A,'Single Interbank'!B{idx})-SUMIFS('G14 Master List'!$AV:$AV,'G14 Master List'!A:A,'Single Interbank'!B{idx}),SUMIFS('G14 Master List'!$AH:$AH,'G14 Master List'!B:B,'Single Interbank'!U{idx})-SUMIFS('G14 Master List'!$AV:$AV,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('P'):
                        # ColumnP is General Risk Exposure 一般风险暴露 - 存放同业
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$AN:$AN,'G14 Master List'!A:A,'Single Interbank'!B{idx}), SUMIFS('G14 Master List'!$AN:$AN,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('Q'):
                        # ColumnQ is General Risk Exposure 一般风险暴露 - TF&IFI
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$Y:$Y,'G14 Master List'!A:A,'Single Interbank'!B{idx})-SUMIFS('G14 Master List'!$AU:$AU,'G14 Master List'!A:A,'Single Interbank'!B{idx})+SUMIFS('G14 Master List'!$X:$X,'G14 Master List'!A:A,'Single Interbank'!B{idx})-SUMIFS('G14 Master List'!$AT:$AT,'G14 Master List'!A:A,'Single Interbank'!B{idx}),SUMIFS('G14 Master List'!$Y:$Y,'G14 Master List'!B:B,'Single Interbank'!U{idx})-SUMIFS('G14 Master List'!$AU:$AU,'G14 Master List'!B:B,'Single Interbank'!U{idx})+SUMIFS('G14 Master List'!$X:$X,'G14 Master List'!B:B,'Single Interbank'!U{idx})-SUMIFS('G14 Master List'!$AT:$AT,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('R'):
                        # ColumnR is General Risk Exposure 一般风险暴露 - Bond 同业债券
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$AI:$AI,'G14 Master List'!A:A,'Single Interbank'!B{idx}), SUMIFS('G14 Master List'!$AI:$AI,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('S'):
                        # ColumnS is General Risk Exposure 一般风险暴露 - Policy bank 政策性金融债
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$AQ:$AQ,'G14 Master List'!A:A,'Single Interbank'!B{idx}), SUMIFS('G14 Master List'!$AQ:$AQ,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('T'):
                        # ColumnT is General Risk Exposure 一般风险暴露 - NCD 同业存单
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(ISBLANK(U{idx}),SUMIFS('G14 Master List'!$AJ:$AJ,'G14 Master List'!A:A,'Single Interbank'!B{idx}), SUMIFS('G14 Master List'!$AJ:$AJ,'G14 Master List'!B:B,'Single Interbank'!U{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('U'):
                        # ColumnU is CBS_ID
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 11]
                    elif column == column_index_from_string('V'):
                        # ColumnV is Connection UEN
                        cell = single_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=VLOOKUP(B{idx},Customer!E:Z,22,0)".format(
                            idx=row_idx_1)
                        cell.value = cell_formula

            self._log.debug('*** g14 single_interbank data nums={}'.format(customer_df.shape[0]))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_g1401_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.G1401.value)
        wb = self.get_workbook()
        g1401_worksheet = wb[G14ReportSpreadSheets.G1401.value]

        try:
            cust_time = datetime.strptime(self.get_data_date(), '%Y%m%d')
            g1401_worksheet['D2'].value = "报表日期：{}年{}月".format(cust_time.year, cust_time.month)

            g1401_worksheet['C7'].value = "=SUM(E7:J7)"
            g1401_worksheet['C8'].value = "=SUM(E8:J8)"
            g1401_worksheet['C9'].value = "=SUM(E9:J9)"
            g1401_worksheet['C10'].value = "=E10"
            g1401_worksheet['C11'].value = "=SUM(E11:J11)"
            g1401_worksheet['C12'].value = "=SUM(E12:J12)"
            g1401_worksheet['C13'].value = "=SUM(E13:J13)"
            g1401_worksheet['C14'].value = "=SUM(E14:J14)"
            g1401_worksheet['C15'].value = "=SUM(E15:J15)"
            g1401_worksheet['C16'].value = "=SUM(E16:J16)"
            g1401_worksheet['C17'].value = "='Other inputs'!B3"

            g1401_worksheet['D7'].value = "=SUMIFS('G1402'!$G9:$G59,'G1402'!$H9:$H59,\">=2.5%\")"
            g1401_worksheet['D8'].value = "=SUMIFS('G1403'!$G10:$G109,'G1403'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['D9'].value = "=SUMIFS('G1403'!$G10:$G109,'G1403'!$I10:$I109,MAX('G1403'!$I10:$I109))"
            g1401_worksheet['D10'].value = ''
            g1401_worksheet['D11'].value = "=SUMIFS('G1404'!$G10:$G79,'G1404'!$H10:$H79,\">=2.5%\")"
            g1401_worksheet['D12'].value = "='G1404'!G10"
            g1401_worksheet['D13'].value = "=SUMIFS('G1405'!$G10:$G109,'G1405'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['D14'].value = "=INDEX('G1405'!G10:G109,MATCH(MAX('G1405'!I10:I109),'G1405'!I10:I109,0))"
            g1401_worksheet['D15'].value = "=SUMIFS('G1406'!$G10:$G30,'G1406'!$H10:$H30,\">=2.5%\")"
            g1401_worksheet['D16'].value = "=INDEX('G1406'!G10:G109,MATCH(MAX('G1406'!I10:I109),'G1406'!I10:I109,0))"

            g1401_worksheet['E7'].value = "=SUMIFS('G1402'!$J9:$J59,'G1402'!$H9:$H59,\">=2.5%\")"
            g1401_worksheet['E8'].value = "=SUMIFS('G1403'!$J10:$J109,'G1403'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['E9'].value = "=SUMIFS('G1403'!$J10:$J109,'G1403'!$I10:$I109,MAX('G1403'!$I10:$I109))"
            g1401_worksheet['E10'].value = "=MAX('G14 Master List'!S:S)"
            g1401_worksheet['E11'].value = "=SUMIFS('G1404'!$J10:$J79,'G1404'!$H10:$H79,\">=2.5%\")"
            g1401_worksheet['E12'].value = "='G1404'!J10"
            g1401_worksheet['E13'].value = "=SUMIFS('G1405'!$J10:$J109,'G1405'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['E14'].value = "=INDEX('G1405'!J10:J109,MATCH(MAX('G1405'!I10:I109),'G1405'!I10:I109,0))"
            g1401_worksheet['E15'].value = "=SUMIFS('G1406'!$J10:$J30,'G1406'!$H10:$H30,\">=2.5%\")"
            g1401_worksheet['E16'].value = "=INDEX('G1406'!J10:J109,MATCH(MAX('G1406'!I10:I109),'G1406'!I10:I109,0))"

            g1401_worksheet['F7'].value = "=SUMIFS('G1402'!$K9:$K59,'G1402'!$H9:$H59,\">=2.5%\")"
            g1401_worksheet['F8'].value = "=SUMIFS('G1403'!$M10:$M109,'G1403'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['F9'].value = "=SUMIFS('G1403'!$M10:$M109,'G1403'!$I10:$I109,MAX('G1403'!$I10:$I109))"
            g1401_worksheet['F10'].value = ""
            g1401_worksheet['F11'].value = "=SUMIFS('G1404'!$M10:$M79,'G1404'!$H10:$H79,\">=2.5%\")"
            g1401_worksheet['F12'].value = "='G1404'!M10"
            g1401_worksheet['F13'].value = "=SUMIFS('G1405'!$S10:$S79,'G1405'!$H10:$H79,\">=2.5%\")"
            g1401_worksheet['F14'].value = "=INDEX('G1405'!S10:S109,MATCH(MAX('G1405'!I10:I109),'G1405'!I10:I109,0))"
            g1401_worksheet['F15'].value = "=SUMIFS('G1406'!$S10:$S30,'G1406'!$H10:$H30,\">=2.5%\")"
            g1401_worksheet['F16'].value = "=INDEX('G1406'!S10:S109,MATCH(MAX('G1406'!I10:I109),'G1406'!I10:I109,0))"

            g1401_worksheet['G7'].value = "=SUMIFS('G1402'!$L9:$L59,'G1402'!$H9:$H59,\">=2.5%\")"
            g1401_worksheet['G8'].value = "=SUMIFS('G1403'!$S10:$S109,'G1403'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['G9'].value = "=SUMIFS('G1403'!$S10:$S109,'G1403'!$I10:$I109,MAX('G1403'!$I10:$I109))"
            g1401_worksheet['G10'].value = ""
            g1401_worksheet['G11'].value = "=SUMIFS('G1404'!$S10:$S79,'G1404'!$H10:$H79,\">=2.5%\")"
            g1401_worksheet['G12'].value = "='G1404'!S10"
            g1401_worksheet['G13'].value = "=SUMIFS('G1405'!$Y10:$Y109,'G1405'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['G14'].value = "=INDEX('G1405'!Y10:Y109,MATCH(MAX('G1405'!I10:I109),'G1405'!I10:I109,0))"
            g1401_worksheet['G15'].value = "=SUMIFS('G1406'!$Y10:$Y30,'G1406'!$H10:$H30,\">=2.5%\")"
            g1401_worksheet['G16'].value = "=INDEX('G1406'!Y10:Y109,MATCH(MAX('G1406'!I10:I109),'G1406'!I10:I109,0))"

            g1401_worksheet['H7'].value = "=SUMIFS('G1402'!$M9:$M59,'G1402'!$H9:$H59,\">=2.5%\")"
            g1401_worksheet['H8'].value = "=SUMIFS('G1403'!$T10:$T109,'G1403'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['H9'].value = "=SUMIFS('G1403'!$T10:$T109,'G1403'!$I10:$I109,MAX('G1403'!$I10:$I109))"
            g1401_worksheet['H10'].value = ""
            g1401_worksheet['H11'].value = "=SUMIFS('G1404'!$T10:$T79,'G1404'!$H10:$H79,\">=2.5%\")"
            g1401_worksheet['H12'].value = "='G1404'!T10"
            g1401_worksheet['H13'].value = "=SUMIFS('G1405'!$Z10:$Z109,'G1405'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['H14'].value = "=INDEX('G1405'!Z10:Z109,MATCH(MAX('G1405'!I10:I109),'G1405'!I10:I109,0))"
            g1401_worksheet['H15'].value = "=SUMIFS('G1406'!$Z10:$Z30,'G1406'!$H10:$H30,\">=2.5%\")"
            g1401_worksheet['H16'].value = "=INDEX('G1406'!Z10:Z109,MATCH(MAX('G1406'!I10:I109),'G1406'!I10:I109,0))"

            g1401_worksheet['I7'].value = "=SUMIFS('G1402'!$N9:$N59,'G1402'!$H9:$H59,\">=2.5%\")"
            g1401_worksheet['I8'].value = "=SUMIFS('G1403'!$U10:$U109,'G1403'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['I9'].value = "=SUMIFS('G1403'!$U10:$U109,'G1403'!$I10:$I109,MAX('G1403'!$I10:$I109))"
            g1401_worksheet['I10'].value = ""
            g1401_worksheet['I11'].value = "=SUMIFS('G1404'!$U10:$U79,'G1404'!$H10:$H79,\">=2.5%\")"
            g1401_worksheet['I12'].value = "='G1404'!U10"
            g1401_worksheet['I13'].value = "=SUMIFS('G1405'!$AC10:$AC109,'G1405'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['I14'].value = "=INDEX('G1405'!AC10:AC109,MATCH(MAX('G1405'!I10:I109),'G1405'!I10:I109,0))"
            g1401_worksheet['I15'].value = "=SUMIFS('G1406'!$AC10:$AC30,'G1406'!$H10:$H30,\">=2.5%\")"
            g1401_worksheet['I16'].value = "=INDEX('G1406'!AC10:AC109,MATCH(MAX('G1406'!I10:I109),'G1406'!I10:I109,0))"

            g1401_worksheet['J7'].value = "=SUMIFS('G1402'!$O9:$O59,'G1402'!$H9:$H59,\">=2.5%\")"
            g1401_worksheet['J8'].value = "=SUMIFS('G1403'!$Z10:$Z109,'G1403'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['J9'].value = "=SUMIFS('G1403'!$Z10:$Z109,'G1403'!$I10:$I109,MAX('G1403'!$I10:$I109))"
            g1401_worksheet['J10'].value = ""
            g1401_worksheet['J11'].value = "=SUMIFS('G1404'!$Z10:$Z79,'G1404'!$H10:$H79,\">=2.5%\")"
            g1401_worksheet['J12'].value = "='G1404'!Z10"
            g1401_worksheet['J13'].value = "=SUMIFS('G1405'!$AD10:$AD109,'G1405'!$H10:$H109,\">=2.5%\")"
            g1401_worksheet['J14'].value = "=INDEX('G1405'!AD10:AD109,MATCH(MAX('G1405'!I10:I109),'G1405'!I10:I109,0))"
            g1401_worksheet['J15'].value = "=SUMIFS('G1406'!$AD10:$AD30,'G1406'!$H10:$H30,\">=2.5%\")"
            g1401_worksheet['J16'].value = "=INDEX('G1406'!AD10:AD109,MATCH(MAX('G1406'!I10:I109),'G1406'!I10:I109,0))"

        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_g1402_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.G1402.value)
        wb = self.get_workbook()
        g1402_worksheet = wb[G14ReportSpreadSheets.G1402.value]

        try:
            cust_time = datetime.strptime(self.get_data_date(), '%Y%m%d')
            g1402_worksheet['M2'].value = "报表日期：{}年{}月".format(cust_time.year, cust_time.month)

            start_row_num = 8
            end_row_num = start_row_num + 52
            start_column_num = 3
            end_column_num = start_column_num + 17

            for row in range(start_row_num, end_row_num):
                for column in range(start_column_num, end_column_num):
                    if (row > 8 and row <= 28 ) and column == column_index_from_string('C'):
                        # ColumnC is 客户类型
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!R:R),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!V:V),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!W:W),2,FALSE),\"\" )))"
                        cell.value = cell_formula
                    elif row > 28 and column == column_index_from_string('C'):
                        # ColumnC is 客户类型
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IF(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!F:F),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!F:F),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!F:F),2,FALSE), 0)))>=0.025, IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!R:R),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!V:V),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!W:W),2,FALSE), \"\"))),\"\" )"
                        cell.value = cell_formula

                    elif row > 8 and row <= 28 and column == column_index_from_string('D'):
                        # ColumnD is 客户名称
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!C:C),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!C:C),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!C:C),2,FALSE), "")))"
                        cell.value = cell_formula
                    elif row > 28 and column == column_index_from_string('D'):
                        # ColumnD is 客户名称
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IF(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!F:F),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!F:F),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!F:F),2,FALSE), 0)))>=0.025, IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!C:C),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!C:C),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!C:C),2,FALSE), \"\"))), \"\")"
                        cell.value = cell_formula

                    elif row > 8 and row <= 28 and column == column_index_from_string('E'):
                        # ColumnE is 客户代码
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!D:D),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!D:D),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!D:D),2,FALSE),\"\" )))"
                        cell.value = cell_formula
                    elif row > 28 and column == column_index_from_string('E'):
                         # ColumnE is 客户代码
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IF(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!F:F),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!F:F),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!F:F),2,FALSE), 0)))>=0.025, IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!D:D),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!D:D),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!D:D),2,FALSE),\"\" ))), \"\")"
                        cell.value = cell_formula

                    elif row == 8 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(J8:O8)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 8 and row <= 28 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(J{idx}:O{idx})".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 28 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IF(AND(J{idx}<>\"\",O{idx}<>\"\"),SUM(J{idx}:O{idx}),\"\")".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.00'

                    elif row == 8 and column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(G9:G59)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 8 and row <= 28 and column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!E:E),2,FALSE),IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!E:E),2,FALSE),IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!E:E),2,FALSE), 0)))-IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!M:M),2,FALSE),IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!N:N),2,FALSE),IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!M:M),2,FALSE), 0))),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 28 and  column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IF(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!F:F),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!F:F),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!F:F),2,FALSE), 0)))>=0.025, IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!E:E),2,FALSE),IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!E:E),2,FALSE),IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!E:E),2,FALSE), 0)))-IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!M:M),2,FALSE),IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!N:N),2,FALSE),IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!M:M),2,FALSE), 0))),0),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'

                    elif row == 8 and column == column_index_from_string('H'):
                        # ColumnH is 合计
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=F8/S8"
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'
                    elif row > 8 and row <= 28 and column == column_index_from_string('H'):
                        # ColumnH is 合计
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=F{idx}/S{idx}".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'
                    elif row > 28 and column == column_index_from_string('H'):
                        # ColumnH is 合计
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IF(AND(F{idx}<>\"\", S{idx}<>\"\"),F{idx}/S{idx},\"\")".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'

                    elif row == 8 and column == column_index_from_string('I'):
                        # ColumnI is 其中：不可豁免风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=G8/S8"
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'
                    elif row > 8 and row <= 28 and column == column_index_from_string('I'):
                        # ColumnI is 其中：不可豁免风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=G{idx}/S{idx}".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'
                    elif row > 28 and column == column_index_from_string('I'):
                        # ColumnI is 其中：不可豁免风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IF(AND(G{idx}<>\"\",S{idx}<>\"\"),G{idx}/S{idx},\"\")".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'

                    elif row == 8 and column == column_index_from_string('J'):
                        # ColumnJ is 一般风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(J9:J59)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 8 and row <= 28 and column == column_index_from_string('J'):
                        # ColumnJ is 一般风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!I:I),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!I:I),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!I:I),2,FALSE), 0))),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 28 and column == column_index_from_string('J'):
                        # ColumnJ is 一般风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IF(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!F:F),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!F:F),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!F:F),2,FALSE), 0)))>=0.025, IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!I:I),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!I:I),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!I:I),2,FALSE), 0))),0),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'

                    elif row >= 8 and column == column_index_from_string('K'):
                        # ColumnK is 特定风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell.value = 0

                    elif row == 8 and column == column_index_from_string('L'):
                        # ColumnL is 交易账簿 风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(L9:L59)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 8 and row <= 28 and column == column_index_from_string('L'):
                        # ColumnL is 交易账簿 风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!L:L),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!L:L),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!L:L),2,FALSE), 0))),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 28 and column == column_index_from_string('L'):
                        # ColumnL is 交易账簿 风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IF(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!F:F),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!F:F),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!F:F),2,FALSE), 0)))>=0.025, IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!L:L),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!L:L),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!L:L),2,FALSE), 0)))),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'

                    elif row == 8 and column == column_index_from_string('M'):
                        # ColumnM is 交易对手信用风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(M9:M59)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 8 and row <= 28 and column == column_index_from_string('M'):
                        # ColumnM is 交易对手信用风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!J:J),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!J:J),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!J:J),2,FALSE), 0))),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 28  and column == column_index_from_string('M'):
                        # ColumnM is 交易对手信用风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IF(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!F:F),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!F:F),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!F:F),2,FALSE), 0)))>=0.025, IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!J:J),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!J:J),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!J:J),2,FALSE), 0))), ),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'

                    elif row == 8 and column == column_index_from_string('N'):
                        # ColumnN is 潜在风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(N9:N59)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 8 and row <= 28 and column == column_index_from_string('N'):
                        # ColumnN is 潜在风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!K:K),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!K:K),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!K:K),2,FALSE), 0))),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 28  and column == column_index_from_string('N'):
                        # ColumnN is 潜在风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IF(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!F:F),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!F:F),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!F:F),2,FALSE), 0)))>=0.025, IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!K:K),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!K:K),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!K:K),2,FALSE), 0))), ),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'

                    elif row >= 8 and column == column_index_from_string('O'):
                        # ColumnO is 其他风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell.value = 0

                    elif row == 8 and column == column_index_from_string('P'):
                        # ColumnP is 风险缓释转出的风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(P9:P59)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 8 and row <= 28 and column == column_index_from_string('P'):
                        # ColumnP is 风险缓释转出的风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(-IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!N:N),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!O:O),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!N:N),2,FALSE), 0))),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 28  and column == column_index_from_string('P'):
                        # ColumnP is 风险缓释转出的风险暴露
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(IF(IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!F:F),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!F:F),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!F:F),2,FALSE), 0)))>=0.025, -IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},LRE!S:S, LRE!N:N),2,FALSE), IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Cust'!U:U, 'Group Cust'!O:O),2,FALSE),  IFERROR(VLOOKUP(B"+str(row)+",IF({1,0},'Group Interbank'!V:V, 'Group Interbank'!N:N),2,FALSE), 0))), ),2)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'

                    elif row == 8 and column == column_index_from_string('Q'):
                        # ColumnQ is 风险暴露总和
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=F8+P8"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 8 and row <= 28 and column == column_index_from_string('Q'):
                        # ColumnQ is 风险暴露总和
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=F{idx}+P{idx}".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 28 and column == column_index_from_string('Q'):
                        # ColumnQ is 风险暴露总和
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IF(AND(F{idx}<>\"\",P{idx}<>\"\"),F{idx}+P{idx},\"\")".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.00'

                    elif row == 8 and column == column_index_from_string('R'):
                        # ColumnR is 占一级资本净额比例
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=Q8/S8"
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'
                    elif row > 8 and row <= 28 and column == column_index_from_string('R'):
                        # ColumnR is 占一级资本净额比例
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=Q{idx}/S{idx}".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'
                    elif row > 28 and column == column_index_from_string('R'):
                        # ColumnR is 占一级资本净额比例
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IF(AND(Q{idx}<>\"\",S{idx}<>\"\"),Q{idx}/S{idx},\"\")".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'

                    elif row == 8 and column == column_index_from_string('S'):
                        # ColumnS is 一级资本净额
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "='Other inputs'!B3"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 8 and row <= 28 and column == column_index_from_string('S'):
                        # ColumnS is 一级资本净额
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "='Other inputs'!B3"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 28 and column == column_index_from_string('S'):
                        # ColumnS is 一级资本净额
                        cell = g1402_worksheet.cell(row=row, column=column)
                        cell_formula = "=IF(C{idx}<>\"\",'Other inputs'!$B$3,\"\")".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.00'

        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_g1403_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.G1403.value)
        wb = self.get_workbook()
        g1403_worksheet = wb[G14ReportSpreadSheets.G1403.value]

        try:
            start_row_num = 9
            end_row_num = start_row_num + 101
            start_column_num = 2
            end_column_num = start_column_num + 29

            for row in range(start_row_num, end_row_num):
                for column in range(start_column_num, end_column_num):
                    if row > 9 and column == column_index_from_string('B'):
                        # ColumnB is 排序
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = '=IF(VLOOKUP(A{idx},\'Single Cust\'!$A:$M,7,0)="Y",A{idx},"")'.format(idx=row)
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('D'):
                        # ColumnD is 客户名称
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=IFERROR( VLOOKUP(B{idx},'Single Cust'!$A:$M,3,0), \"\" )".format(idx=row)
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('E'):
                        # ColumnE is 客户代码
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=IFERROR(VLOOKUP(B{idx},'Single Cust'!$A:$M,4,0),\"\" )".format(idx=row)
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(J9,M9,S9,T9,U9,Z9)"
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row > 9 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(J{idx},M{idx},S{idx},T{idx},U{idx},Z{idx})".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.00'
                    elif row == 9 and column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(G10:G109)"
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=F{idx}-ROUND(SUMIFS('Single Cust'!$N:$N,'Single Cust'!$A:$A,'G1403'!B{idx}),2)".format(
                            idx=row)
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = "0.00"
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('H'):
                        # ColumnH is 占一级资本净额比例 合计
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=F9/$F$110"
                        cell.number_format = '0.0000%'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('H'):
                        # ColumnH is 占一级资本净额比例 合计
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=F{idx}/$F$110".format(
                            idx=row)
                        cell.number_format = '0.0000%'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('I'):
                        # ColumnI is 其中：不可豁免风险暴露
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=G9/$F$110"
                        cell.number_format = '0.0000%'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('I'):
                        # ColumnI is 其中：不可豁免风险暴露
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=G{idx}/$F$110".format(
                            idx=row)
                        cell.number_format = '0.0000%'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('J'):
                        # ColumnJ is 合计
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(J10:J109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('J'):
                        # ColumnJ is 合计
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Cust'!$I:$I,'Single Cust'!$A:$A,'G1403'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('K'):
                        # ColumnK is 其中：各项贷款
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(K10:K109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('K'):
                        # ColumnK is 其中：各项贷款
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Cust'!$P:$P,'Single Cust'!$A:$A,'G1403'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula

                    elif row == 9 and column == column_index_from_string('L'):
                        # ColumnL is 其中：债券投资
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        #cell_formula = "=SUM(L10:L109)"
                        cell.value = 0
                    elif row > 9 and column == column_index_from_string('L'):
                        # ColumnL is 其中：债券投资
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('M'):
                        # ColumnM is 合计
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(N9,R9)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('M'):
                        # ColumnM is 合计
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(N{idx},R{idx})".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('N'):
                        # ColumnN is
                        cell = g1403_worksheet.cell(row=row, column=column)
                        #cell_formula = "=SUM(N10:N109)"
                        cell.number_format = '0.00'
                        cell.value = 0
                    elif row > 9 and column == column_index_from_string('N'):
                        # ColumnN is
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('O'):
                        # ColumnO is 其中：信托产品
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(O10:O109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('O'):
                        # ColumnO is 其中：信托产品
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('P'):
                        # ColumnP is 其中：非保本理财
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(P10:P109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('P'):
                        # ColumnP is 其中：非保本理财
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('Q'):
                        # ColumnQ is 其中：证券业资管产品
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Q10:Q109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Q'):
                        # ColumnR is 其中：证券业资管产品
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('R'):
                        # ColumnR is 资产证券化产品
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(R10:R109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('R'):
                        # ColumnR is 资产证券化产品
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('S'):
                        # ColumnS is 交易账簿
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(S10:S109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('S'):
                        # ColumnS is 交易账簿
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Cust'!$L:$L,'Single Cust'!$A:$A,'G1403'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('T'):
                        # ColumnT is 交易对手信用风险暴露
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(T10:T109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('T'):
                        # ColumnT is 交易对手信用风险暴露
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Cust'!$J:$J,'Single Cust'!$A:$A,'G1403'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('U'):
                        # ColumnU is 合计
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(U10:U109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('U'):
                        # ColumnU is 合计
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Cust'!$K:$K,'Single Cust'!$A:$A,'G1403'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('V'):
                        # ColumnV is 其中：银行承兑汇票
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(V10:V109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('V'):
                        # ColumnV is 其中：银行承兑汇票
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('W'):
                        # ColumnW is 其中：跟单信用证
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(W10:W109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('W'):
                        # ColumnW is 其中：跟单信用证
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Cust'!$R:$R,'Single Cust'!$A:$A,'G1403'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('X'):
                        # ColumnX is 其中：保函
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(X10:X109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('X'):
                        # ColumnX is 其中：保函
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Cust'!$S:$S,'Single Cust'!$A:$A,'G1403'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('Y'):
                        # ColumnY is 其中：贷款承诺
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Y10:Y109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Y'):
                        # ColumnY is 其中：贷款承诺
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Cust'!$T:$T,'Single Cust'!$A:$A,'G1403'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('Z'):
                        # ColumnZ is 其他风险暴露
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Z10:Z109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Z'):
                        # ColumnZ is 其他风险暴露
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('AA'):
                        # ColumnAA is 风险缓释转出的风险暴露
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AA10:AA109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AA'):
                        # ColumnAA is 风险缓释转出的风险暴露
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=-ROUND(SUMIFS('Single Cust'!$O:$O,'Single Cust'!$A:$A,'G1403'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AB'):
                        # ColumnAB is 不考虑风险缓释作用的风险暴露总和
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=AA9+F9"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AB'):
                        # ColumnAC is 不考虑风险缓释作用的风险暴露总和
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=AA{idx}+F{idx}".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AC'):
                        # ColumnAC is 各项贷款余额
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AC10:AC109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AC'):
                        # ColumnAC is 各项贷款余额
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Cust'!$M:$M,'Single Cust'!$A:$A,'G1403'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif column == column_index_from_string('AD'):
                        # ColumnAD is 各项贷款余额占资本金额比例
                        cell = g1403_worksheet.cell(row=row, column=column)
                        cell_formula = "=AC{idx}/$F$111".format(
                            idx=row)
                        cell.number_format = '0.00%'
                        cell.value = cell_formula

            g1403_worksheet['F110'].value = "='Other inputs'!B3"
            g1403_worksheet['F111'].value = "='Other inputs'!B2"
            g1403_worksheet['H110'].value = "=F110/$F$110"
            g1403_worksheet['H110'].number_format = '0.00%'
            cust_time = datetime.strptime(self.get_data_date(), '%Y%m%d')
            g1403_worksheet['Q2'].value = "报表日期：{}年{}月".format(cust_time.year, cust_time.month)

        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_g1404_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.G1404.value)
        wb = self.get_workbook()
        g1404_worksheet = wb[G14ReportSpreadSheets.G1404.value]

        try:
            start_row_num = 9
            end_row_num = start_row_num + 71
            start_column_num = 2
            end_column_num = start_column_num + 28

            for row in range(start_row_num, end_row_num):
                for column in range(start_column_num, end_column_num):
                    if row > 9 and column == column_index_from_string('B'):
                        # ColumnB is 排序
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=IFERROR(IF(VLOOKUP(A{idx},'Group Cust'!$A:$M,7,0)=\"Y\",A{idx},\"\"),\"\")".format(idx=row)
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('D'):
                        # ColumnD is 客户名称
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=IFERROR(IF(LEN(VLOOKUP(B{idx},'Group Cust'!$A:$C,3,0))=0, \"\", VLOOKUP(B{idx},'Group Cust'!$A:$C,3,0) ), \"\" )".format(idx=row)
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('E'):
                        # ColumnE is 客户代码
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=IFERROR(IF(LEN(VLOOKUP(B{idx},'Group Cust'!$A:$L,4,0))=0, \"\",VLOOKUP(A{idx},'Group Cust'!$A:$L,4,0)), \"\" )".format(idx=row)
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=J9+M9+S9+T9+U9+Z9"
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=J{idx}+M{idx}+S{idx}+T{idx}+U{idx}+Z{idx}".format(idx=row)
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(G10:G79)"
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=F{idx}-ROUND(SUMIFS('Group Cust'!$N:$N,'Group Cust'!$A:$A,'G1404'!$B{idx}),2)".format(
                            idx=row)
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = "0.00"
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('H'):
                        # ColumnH is 占一级资本净额比例 合计
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=F9/$F$80"
                        cell.number_format = '0.0000%'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('H'):
                        # ColumnH is 占一级资本净额比例 合计
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=F{idx}/$F$80".format(
                            idx=row)
                        cell.number_format = '0.0000%'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('I'):
                        # ColumnI is 占一级资本净额比例 , 其中：不可豁免风险暴露
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=G9/$F$80"
                        cell.number_format = '0.0000%'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('I'):
                        # ColumnI is 占一级资本净额比例 , 其中：不可豁免风险暴露
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=G{idx}/$F$80".format(
                            idx=row)
                        cell.number_format = '0.0000%'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('J'):
                        # ColumnJ is 合计
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(J10:J79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('J'):
                        # ColumnJ is 合计
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Cust'!$I:$I,'Group Cust'!$A:$A,'G1404'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('K'):
                        # ColumnK is 其中：各项贷款
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(K10:K79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('K'):
                        # ColumnK is 其中：各项贷款
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Cust'!$P:$P,'Group Cust'!$A:$A,'G1404'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('L'):
                        # ColumnL is 其中：债券投资
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(L10:L79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('L'):
                        # ColumnL is 其中：债券投资
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('M'):
                        # ColumnM is 合计
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(N9,R9)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('M'):
                        # ColumnM is 合计
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(N{idx},R{idx})".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('N'):
                        # ColumnN is  
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(N10:N79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('N'):
                        # ColumnN is
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('O'):
                        # ColumnO is 其中：信托产品
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(O10:O79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('O'):
                        # ColumnO is
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('P'):
                        # ColumnP is 其中：非保本理财
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(P10:P79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('P'):
                        # ColumnP is 其中：非保本理财
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('Q'):
                        # ColumnQ is 其中：证券业资管产品
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Q10:Q79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Q'):
                        # ColumnQ is 其中：证券业资管产品
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('R'):
                        # ColumnR is 资产证券化产品
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(R10:R79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('R'):
                        # ColumnR is 其中：资产证券化产品
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('S'):
                        # ColumnS is 交易账簿
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(S10:S79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('S'):
                        # ColumnS is 交易账簿
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Cust'!$L:$L,'Group Cust'!$A:$A,'G1404'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('T'):
                        # ColumnT is 交易对手信用风险暴露
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(T10:T79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('T'):
                        # ColumnT is 交易对手信用风险暴露
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Cust'!$J:$J,'Group Cust'!$A:$A,'G1404'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('U'):
                        # ColumnU is 合计
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(U10:U79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('U'):
                        # ColumnU is 合计
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Cust'!$K:$K,'Group Cust'!$A:$A,'G1404'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('V'):
                        # ColumnV is 其中：银行承兑汇票
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(V10:V79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('V'):
                        # ColumnV is 其中：银行承兑汇票
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('W'):
                        # ColumnW is 其中：跟单信用证
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(W10:W79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('W'):
                        # ColumnW is 其中：跟单信用证
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Cust'!$R:$R,'Group Cust'!$A:$A,'G1404'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('X'):
                        # ColumnX is 其中：保函
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(X10:X79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('X'):
                        # ColumnX is 其中：保函
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Cust'!$S:$S,'Group Cust'!$A:$A,'G1404'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('Y'):
                        # ColumnY is 其中：贷款承诺
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Y10:Y79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Y'):
                        # ColumnY is 其中：贷款承诺
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Cust'!$T:$T,'Group Cust'!$A:$A,'G1404'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('Z'):
                        # ColumnZ is 其他风险暴露
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Z10:Z79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Z'):
                        # ColumnZ is 其他风险暴露
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('AA'):
                        # ColumnAA is 风险缓释转出的风险暴露
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AA10:AA79)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AA'):
                        # ColumnAA is 风险缓释转出的风险暴露
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=-ROUND(SUMIFS('Group Cust'!$O:$O,'Group Cust'!$A:$A,'G1404'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AB'):
                        # ColumnAB is 不考虑风险缓释作用的风险暴露总和
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=AA9+F9"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AB'):
                        # ColumnAB is 不考虑风险缓释作用的风险暴露总和
                        cell = g1404_worksheet.cell(row=row, column=column)
                        cell_formula = "=AA{idx}+F{idx}".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula

            g1404_worksheet['F80'].value = "='Other inputs'!B3"
            g1404_worksheet['H80'].value = "=F80/$F$80"
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_g1405_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.G1405.value)
        wb = self.get_workbook()
        g1405_worksheet = wb[G14ReportSpreadSheets.G1405.value]

        try:
            start_row_num = 9
            end_row_num = start_row_num + 101
            start_column_num = 2
            end_column_num = start_column_num + 32

            for row in range(start_row_num, end_row_num):
                for column in range(start_column_num, end_column_num):
                    if row > 9 and column == column_index_from_string('D'):
                        # ColumnD is 客户名称
                        cell = g1405_worksheet.cell(row=row, column=column)
                        #cell_formula = "=VLOOKUP(A{idx},'Single Interbank'!$A:$K,3,0)".format(idx=row)
                        cell_formula = "= IF(VLOOKUP(A{idx},'Single Interbank'!$A:$E,5,0)>0,VLOOKUP(A{idx},'Single Interbank'!$A:$K,3,0),\"#N/A\")".format(idx=row)
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('E'):
                        # ColumnC is 客户代码
                        cell = g1405_worksheet.cell(row=row, column=column)
                        #cell_formula = "=VLOOKUP(A{idx},'Single Interbank'!$A:$K,4,0)".format(idx=row)
                        cell_formula = "= IF( VLOOKUP(A{idx},'Single Interbank'!$A:$E,5,0)>0, VLOOKUP(A{idx},'Single Interbank'!$A:$K,4,0),\"#N/A\")".format(idx=row)
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(F10:F109)"
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=J{idx}+S{idx}+Y{idx}+Z{idx}+AC{idx}+AD{idx}".format(idx=row)
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(G10:G109)"
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Interbank'!$E:$E,'Single Interbank'!$A:$A,'G1405'!$B{idx})-SUMIFS('Single Interbank'!$M:$M,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('H'):
                        # ColumnH is 占一级资本净额比例 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(H10:H109)"
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'
                    elif row > 9 and column == column_index_from_string('H'):
                        # ColumnH is 占一级资本净额比例 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=F{idx}/$F$110".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'
                    elif row == 9 and column == column_index_from_string('I'):
                        # ColumnI is 占一级资本净额比例 其中：不可豁免风险暴露
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(I10:I109)"
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'
                    elif row > 9 and column == column_index_from_string('I'):
                        # ColumnI is 占一级资本净额比例 其中：不可豁免风险暴露
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=G{idx}/$F$110".format(idx=row)
                        cell.value = cell_formula
                        cell.number_format = '0.0000%'
                    elif row == 9 and column == column_index_from_string('J'):
                        # ColumnJ is 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(J10:J109)"
                        cell.value = cell_formula
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                    elif row > 9 and column == column_index_from_string('J'):
                        # ColumnJ is 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Interbank'!$I:$I,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.value = cell_formula
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = '0.00'
                    elif row == 9 and column == column_index_from_string('K'):
                        # ColumnK is 其中：拆放同业
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(K10:K109)"
                        cell.value = cell_formula
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                    elif row > 9 and column == column_index_from_string('K'):
                        # ColumnK is 其中：拆放同业
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(L{idx}+M{idx}+SUMIFS('Single Interbank'!$Q:$Q,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.value = cell_formula
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = '0.00'
                    elif row == 9 and column == column_index_from_string('L'):
                        # ColumnL is 其中：同业拆借
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(L10:L109)"
                        cell.value = cell_formula
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                    elif row > 9 and column == column_index_from_string('L'):
                        # ColumnL is 其中：同业拆借
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Interbank'!$O:$O,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.value = cell_formula
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = '0.00'

                    elif row == 9 and column == column_index_from_string('M'):
                        # ColumnM is 其中：同业借款
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(M10:M109)"
                        cell.value = cell_formula
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = '0.00'
                    elif row > 9 and column == column_index_from_string('M'):
                        # ColumnM is 其中：同业借款
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell.value = 0
                        cell.number_format = "0.00"

                    elif row == 9 and column == column_index_from_string('N'):
                        # ColumnN is 其中：存放同业
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(N10:N109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('N'):
                        # ColumnN is 其中：存放同业
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Interbank'!$P:$P,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('O'):
                        # ColumnO is 其中：买入返售(质押式)
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(O10:O109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('O'):
                        # ColumnO is 其中：买入返售(质押式)
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('P'):
                        # ColumnP is 其中：同业债券
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(P10:P109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('P'):
                        # ColumnP is 其中：同业债券
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Interbank'!$R:$R,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('Q'):
                        # ColumnQ is 其中：政策性金融债
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Q10:Q109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Q'):
                        # ColumnQ is 其中：政策性金融债
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Interbank'!$S:$S,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('R'):
                        # ColumnR is 其中：同业存单
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(R10:R109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('R'):
                        # ColumnR is 其中：同业存单
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Interbank'!$T:$T,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula

                    elif row == 9 and column == column_index_from_string('S'):
                        # ColumnS is 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(S10:S109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('S'):
                        # ColumnS is 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(T{idx},X{idx})".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('T'):
                        # ColumnT is 资产管理产品
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(T10:T109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('T'):
                        # ColumnT is 资产管理产品
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('U'):
                        # ColumnU is 其中：信托产品
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(U10:U109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('U'):
                        # ColumnU is 其中：信托产品
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('V'):
                        # ColumnV is 其中：非保本理财
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(V10:V109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('V'):
                        # ColumnV is 其中：非保本理财
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('W'):
                        # ColumnW is 其中：证券业资管产品
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(W10:W109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('W'):
                        # ColumnW is 其中：证券业资管产品
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('X'):
                        # ColumnX is 资产证券化产品
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(X10:X109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('X'):
                        # ColumnX is 资产证券化产品
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('Y'):
                        # ColumnY is 交易账簿风险暴露
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Y10:Y109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Y'):
                        # ColumnY is 交易账簿风险暴露
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Interbank'!$L:$L,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('Z'):
                        # ColumnZ is 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Z10:Z109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Z'):
                        # ColumnZ is 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=AA{idx}".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AA'):
                        # ColumnAA is 其中：场外衍生工具
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AA10:AA109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AA'):
                        # ColumnAA is 其中：场外衍生工具
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Interbank'!$J:$J,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AB'):
                        # ColumnAB is 其中：证券融资交易
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AB10:AB109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AB'):
                        # ColumnAB is 其中：证券融资交易
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('AC'):
                        # ColumnAC is 潜在风险暴露
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AC10:AC109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AC'):
                        # ColumnAC is 潜在风险暴露
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Single Interbank'!$K:$K,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AD'):
                        # ColumnAD is 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AD10:AD109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AD'):
                        # ColumnAD is 合计
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('AE'):
                        # ColumnAE is 风险缓释转出的风险暴露
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AE10:AE109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AE'):
                        # ColumnAE is 风险缓释转出的风险暴露
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(-SUMIFS('Single Interbank'!$N:$N,'Single Interbank'!$A:$A,'G1405'!$B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AF'):
                        # ColumnAF is 不考虑风险缓释作用的风险暴露总和
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AF10:AF109)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AF'):
                        # ColumnAF is 不考虑风险缓释作用的风险暴露总和
                        cell = g1405_worksheet.cell(row=row, column=column)
                        cell_formula = "=AE{idx}+F{idx}".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula

            g1405_worksheet['F110'].value = "='Other inputs'!B3"
            g1405_worksheet['H110'].value = "=F110/$F$110"
            g1405_worksheet['H110'].number_format = '0.00%'
            cust_time = datetime.strptime(self.get_data_date(), '%Y%m%d')
            g1405_worksheet['P2'].value = "报表日期：{}年{}月".format(cust_time.year, cust_time.month)

            ### table2
            g1405_worksheet['C116'].value = "='Other inputs'!C10"
            g1405_worksheet['D116'].value = "='Other inputs'!D10"

            g1405_worksheet['E116'].value = "='Other inputs'!E10"
            g1405_worksheet['E116'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'

            g1405_worksheet['E117'].value = "=SUM('Other inputs'!E32:E36)"
            g1405_worksheet['E117'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'

            g1405_worksheet['F116'].value = "='Other inputs'!F10"
            #g1405_worksheet['F116'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
            g1405_worksheet['F116'].number_format = '0.00'

            g1405_worksheet['F117'].value = "='Other inputs'!E73"
            g1405_worksheet['F117'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'

            g1405_worksheet['G116'].value = "='Other inputs'!G10"
            #g1405_worksheet['G116'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
            g1405_worksheet['G116'].number_format = '0.00'

            # g1405_worksheet['G117'].value = "='Other inputs'!E74"
            # g1405_worksheet['G117'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
            g1405_worksheet['G117'].value = 0
            g1405_worksheet['G117'].number_format = '0.00'
            
            g1405_worksheet['H116'].value = "='Other inputs'!H10"
            g1405_worksheet['H116'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'

            g1405_worksheet['H117'].value = "='Other inputs'!E75"
            g1405_worksheet['H117'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'

            g1405_worksheet['I116'].value = "='Other inputs'!I10"
            #g1405_worksheet['I116'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
            g1405_worksheet['I116'].number_format = '0.00'

            g1405_worksheet['I117'].value = "=SUM('Other inputs'!E20:E23)"
            g1405_worksheet['I117'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'

            g1405_worksheet['J116'].value = "='Other inputs'!J10"
            #g1405_worksheet['J116'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
            g1405_worksheet['J116'].number_format = '0.00'

            # g1405_worksheet['J117'].value = "=SUM('Other inputs'!E45:E49)"
            # g1405_worksheet['J117'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
            g1405_worksheet['J117'].value = 0
            g1405_worksheet['J117'].number_format = '0.00'

            g1405_worksheet['K116'].value = "='Other inputs'!K10"
            #g1405_worksheet['K116'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
            g1405_worksheet['K116'].number_format = '0.00'

            g1405_worksheet['K117'].value = 0
            g1405_worksheet['K117'].number_format = '0.00'

            g1405_worksheet['L116'].value = "=E116+I116+J116+K116"
            g1405_worksheet['L116'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'

            g1405_worksheet['L117'].value = "=E117+I117+J117+K117"
            g1405_worksheet['L117'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'

            g1405_worksheet['M116'].value = "=L116-O116-P116"
            g1405_worksheet['M116'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'

            g1405_worksheet['N116'].value = "=M116/F110"
            g1405_worksheet['N116'].number_format = '0.0000%'

            g1405_worksheet['O116'].value = "='Other inputs'!O10"
            #g1405_worksheet['O116'].number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
            g1405_worksheet['O116'].number_format = '0.00'

            g1405_worksheet['P116'].value = "='Other inputs'!P10"
            g1405_worksheet['P116'].number_format = '0.00'

            g1405_worksheet['Q117'].value = "='Other inputs'!E39"
            g1405_worksheet['Q117'].number_format = '0.00'

        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_g1406_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.G1406.value)
        wb = self.get_workbook()
        g1406_worksheet = wb[G14ReportSpreadSheets.G1406.value]

        try:
            start_row_num = 9
            end_row_num = start_row_num + 31
            start_column_num = 2
            end_column_num = start_column_num + 31

            for row in range(start_row_num, end_row_num):
                for column in range(start_column_num, end_column_num):
                    if row > 9 and column == column_index_from_string('B'):
                        # ColumnB is 排序
                        cell = g1406_worksheet.cell(row=row, column=column)
                        #cell_formula = "=VLOOKUP(A{idx},'Group Interbank'!A:H,1,0)".format(idx=row)
                        cell_formula = "=IFERROR(IF(VLOOKUP(A" + str(row) + ",IF({1,0},'Group Interbank'!Y:Y, 'Group Interbank'!G:G),2,0)=\"Y\",A" + str(row) + ",\"\"),\"\")"
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('D'):
                        # ColumnD is 客户名称
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=VLOOKUP($B" + str(row) + ",IF({1,0},'Group Interbank'!$Y:$Y, 'Group Interbank'!C:C),2,FALSE)"
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('E'):
                        # ColumnE is 客户代码
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=VLOOKUP($B" + str(row) + ",IF({1,0},'Group Interbank'!$Y:$Y, 'Group Interbank'!D:D),2,FALSE)"
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(F10:F39)"
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('F'):
                        # ColumnF is 风险暴露总和 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(J{idx},S{idx},Y{idx},Z{idx},AC{idx},AD{idx})".format(idx=row)
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(G10:G39)"
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('G'):
                        # ColumnG is 风险暴露总和 其中：不可豁免风险暴露
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=F{idx}-ROUND(SUMIFS('Group Interbank'!$M:$M,'Group Interbank'!$A:$A,B{idx}),2)".format(
                            idx=row)
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = "0.00"
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('H'):
                        # ColumnH is 占一级资本净额比例 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(H10:H39)"
                        cell.number_format = '0.00%'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('H'):
                        # ColumnH is 占一级资本净额比例 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=F{idx}/$F$40".format(
                            idx=row)
                        cell.number_format = '0.00%'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('I'):
                        # ColumnI is 占一级资本净额比例 , 其中：不可豁免风险暴露
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(I10:I39)"
                        cell.number_format = '0.00%'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('I'):
                        # ColumnI is 占一级资本净额比例 , 其中：不可豁免风险暴露
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=G{idx}/$F$40".format(
                            idx=row)
                        cell.number_format = '0.00%'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('J'):
                        # ColumnJ is 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(J10:J39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('J'):
                        # ColumnJ is 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Interbank'!$I:$I,'Group Interbank'!$Y:$Y,B" + str(row) + "),2)"
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('K'):
                        # ColumnK is 其中：拆放同业
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(K10:K39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('K'):
                        # ColumnK is 其中：拆放同业
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Interbank'!$Q:$Q,'Group Interbank'!$Y:$Y,B{idx}),2)+L{idx}+M{idx}".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('L'):
                        # ColumnL is 其中：同业拆借
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(L10:L39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('L'):
                        # ColumnL is 其中：同业拆借
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Interbank'!$O:$O,'Group Interbank'!$Y:$Y,B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('M'):
                        # ColumnM is 其中：同业借款
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(M10:M39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('M'):
                        # ColumnM is 其中：同业借款
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0
                    elif row == 9 and column == column_index_from_string('N'):
                        # ColumnN is 其中：存放同业
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(N10:N39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('N'):
                        # ColumnN is 其中：存放同业
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Interbank'!$P:$P,'Group Interbank'!$Y:$Y,B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('O'):
                        # ColumnO is 其中：买入返售(质押式)
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(O10:O39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('O'):
                        # ColumnO is 其中：买入返售(质押式)
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('P'):
                        # ColumnP is 其中：同业债券
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(P10:P39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('P'):
                        # ColumnP is 其中：同业债券
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Interbank'!$R:$R,'Group Interbank'!$Y:$Y,B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('Q'):
                        # ColumnQ is 其中：政策性金融债
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Q10:Q39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Q'):
                        # ColumnQ is 其中：政策性金融债
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Interbank'!$S:$S,'Group Interbank'!$Y:$Y,B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('R'):
                        # ColumnR is 其中：同业存单
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(R10:R39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('R'):
                        # ColumnR is 其中：同业存单
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Interbank'!$T:$T,'Group Interbank'!$Y:$Y,B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('S'):
                        # ColumnS is 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(S10:S39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('S'):
                        # ColumnS is 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(T{idx},X{idx})".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('T'):
                        # ColumnT is 资产管理产品
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(T10:T39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('T'):
                        # ColumnT is 资产管理产品
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0
                    elif row == 9 and column == column_index_from_string('U'):
                        # ColumnU is 其中：信托产品
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(U10:U39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('U'):
                        # ColumnU is 其中：信托产品
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0
                    elif row == 9 and column == column_index_from_string('V'):
                        # ColumnV is 其中：非保本理财
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(V10:V39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('V'):
                        # ColumnV is 其中：非保本理财
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0
                    elif row == 9 and column == column_index_from_string('W'):
                        # ColumnW is
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(W10:W39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('W'):
                        # ColumnW is
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0
                    elif row == 9 and column == column_index_from_string('X'):
                        # ColumnX is 资产证券化产品
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(X10:X39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('X'):
                        # ColumnX is 资产证券化产品
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0
                    elif row == 9 and column == column_index_from_string('Y'):
                        # ColumnY is 交易账簿风险暴露
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Y10:Y39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Y'):
                        # ColumnY is 交易账簿风险暴露
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Interbank'!$L:$L,'Group Interbank'!$Y:$Y,B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('Z'):
                        # ColumnZ is 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(Z10:Z39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('Z'):
                        # ColumnZ is 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=AA{idx}".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AA'):
                        # ColumnAA is 其中：场外衍生工具
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AA10:AA39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AA'):
                        # ColumnAA is 其中：场外衍生工具
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Interbank'!$J:$J,'Group Interbank'!$Y:$Y,B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AB'):
                        # ColumnAB is 其中：证券融资交易
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AB10:AB39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AB'):
                        # ColumnAB is 其中：证券融资交易
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0
                    elif row == 9 and column == column_index_from_string('AC'):
                        # ColumnAC is 潜在风险暴露
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AC10:AC39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AC'):
                        # ColumnAC is 潜在风险暴露
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(SUMIFS('Group Interbank'!$K:$K,'Group Interbank'!$Y:$Y,B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AD'):
                        # ColumnAD is 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AD10:AD39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AD'):
                        # ColumnAD is 合计
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell.number_format = '0.00'
                        cell.value = 0

                    elif row == 9 and column == column_index_from_string('AE'):
                        # ColumnAE is 风险缓释转出的风险暴露
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AE10:AE39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AE'):
                        # ColumnAE is 风险缓释转出的风险暴露
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=ROUND(-SUMIFS('Group Interbank'!$N:$N,'Group Interbank'!$Y:$Y,B{idx}),2)".format(
                            idx=row)
                        cell.number_format = '#,##0.00;-#,##0.00'
                        cell.value = cell_formula
                    elif row == 9 and column == column_index_from_string('AF'):
                        # ColumnAF is 不考虑风险缓释作用的风险暴露总和
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=SUM(AF10:AF39)"
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif row > 9 and column == column_index_from_string('AF'):
                        # ColumnAF is 不考虑风险缓释作用的风险暴露总和
                        cell = g1406_worksheet.cell(row=row, column=column)
                        cell_formula = "=AE{idx}+F{idx}".format(
                            idx=row)
                        cell.number_format = '0.00'
                        cell.value = cell_formula

            g1406_worksheet['F40'].value = "='Other inputs'!B3"
            g1406_worksheet['H40'].value = "=F40/$F$40"
            g1406_worksheet['H40'].number_format = '0.00'
            cust_time = datetime.strptime(self.get_data_date(), '%Y%m%d')
            g1406_worksheet['P2'].value = "报表日期：{}年{}月".format(cust_time.year, cust_time.month)

        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_single_cust_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.SINGLE_CUST.value)
        wb = self.get_workbook()
        single_cust_worksheet = wb[G14ReportSpreadSheets.SINGLE_CUST.value]

        try:
            customer_df = filter_data_g14_single_cust(self.get_target_report())
            row_num = customer_df.shape[0]
            column_num = column_index_from_string('W')

            for row in range(0, row_num):
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        # ColumnA is Rank
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=H{idx}'.format(idx=row_idx_1)
                        cell.number_format = '_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        # ColumnB is UEN
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 0]
                    elif column == column_index_from_string('C'):
                        # ColumnC is CUSTOMER_NAME_CH
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(ISBLANK(VLOOKUP(B{idx},Customer!$E:$H,4,FALSE)),VLOOKUP(B{idx},Customer!$E:$I,5,FALSE),VLOOKUP(B{idx},Customer!$E:$H,4,FALSE))'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('D'):
                        # ColumnD is UNIFORM_SOCIAL_CREDIT_CODE
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(ISBLANK(VLOOKUP(B{idx},Customer!$E:$G,3,0)),"INPUT",VLOOKUP(B{idx},Customer!E:G,3,0))'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('E'):
                        # ColumnE is Total Risk Exposure, Exposure
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$J:$J,'G14 Master List'!A:A,'Single Cust'!B{idx})".format(idx=row_idx_1)
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif column == column_index_from_string('F'):
                        # ColumnF is Total Risk Exposure, %
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=E{idx}/'Other inputs'!$B$3".format(idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '0.00%'
                    elif column == column_index_from_string('G'):
                        # ColumnG is Total Risk Exposure, LRE IND
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(F{idx}>=2.5%,"Y","N")'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('H'):
                        # ColumnH is Total Risk Exposure, Rank
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=RANK(E{idx},E:E)+COUNTIF($E$3:E{idx},E{idx})-1'.format(idx=row_idx_1)
                        cell.number_format = '_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('I'):
                        # ColumnI is General Risk Exposure 一般风险暴露
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$M:$M,'G14 Master List'!A:A,'Single Cust'!B{idx})+SUMIFS('G14 Master List'!$BE:$BE,'G14 Master List'!A:A,'Single Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('J'):
                        # ColumnJ is Counterparty Credit Risk Exposure 交易对手信用风险暴露
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$N:$N,'G14 Master List'!$A:$A,'Single Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('K'):
                        # ColumnK is Potential Risk Exposure 潜在风险暴露
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$O:$O,'G14 Master List'!$A:$A,'Single Cust'!B{idx})+SUMIFS('G14 Master List'!$BF:$BF,'G14 Master List'!A:A,'Single Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('L'):
                        # ColumnL is Trading Book Risk Exposure 交易账簿风险暴露
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$P:$P,'G14 Master List'!$A:$A,'Single Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('M'):
                        # ColumnM is Loan balance 贷款余额
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$S:$S,'G14 Master List'!$A:$A,'Single Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('N'):
                        # ColumnN is Exception 豁免
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$T:$T,'G14 Master List'!$A:$A,'Single Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('O'):
                        # ColumnO is Risk transfer ind 风险缓释
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$V:$V,'G14 Master List'!$A:$A,'Single Cust'!B{idx},'G14 Master List'!$U:$U,\"Y\")".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('P'):
                        # ColumnP is General Risk Exposure 一般风险暴露 - 各项贷款
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$W:$W,'G14 Master List'!$A:$A,'Single Cust'!B{idx})+SUMIFS('G14 Master List'!$Y:$Y,'G14 Master List'!$A:$A,'Single Cust'!B{idx})-SUMIFS('G14 Master List'!$AR:$AR,'G14 Master List'!$A:$A,'Single Cust'!B{idx})-SUMIFS('G14 Master List'!$AU:$AU,'G14 Master List'!$A:$A,'Single Cust'!B{idx})+SUMIFS('G14 Master List'!$BE:$BE,'G14 Master List'!A:A,'Single Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('Q'):
                        # ColumnQ is Potential Risk Exposure 潜在风险暴露 - BAD 银行承兑汇票
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                    elif column == column_index_from_string('R'):
                        # ColumnR is Potential Risk Exposure 潜在风险暴露 - LC 跟单信用证
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$AG:$AG,'G14 Master List'!$A:$A,'Single Cust'!B{idx})-SUMIFS('G14 Master List'!$AY:$AY,'G14 Master List'!$A:$A,'Single Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('S'):
                        # ColumnS is Potential Risk Exposure 潜在风险暴露 - Guarantee 保函
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$AF:$AF,'G14 Master List'!$A:$A,'Single Cust'!B{idx})-SUMIFS('G14 Master List'!$AX:$AX,'G14 Master List'!$A:$A,'Single Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('T'):
                        # ColumnT is Potential Risk Exposure 潜在风险暴露 - Loan Commitment 贷款承诺
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$AC:$AC,'G14 Master List'!$A:$A,'Single Cust'!B{idx})+SUMIFS('G14 Master List'!$AD:$AD,'G14 Master List'!$A:$A,'Single Cust'!B{idx})+SUMIFS('G14 Master List'!$AE:$AE,'G14 Master List'!$A:$A,'Single Cust'!B{idx})-SUMIFS('G14 Master List'!$AW:$AW,'G14 Master List'!$A:$A,'Single Cust'!B{idx})+SUMIFS('G14 Master List'!$BF:$BF,'G14 Master List'!A:A,'Single Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula

            self._log.debug('*** g14 single_cust data nums={}'.format(customer_df.shape[0]))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_group_interbank_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.GROUP_INTERBANK.value)
        wb = self.get_workbook()
        group_interbank_worksheet = wb[G14ReportSpreadSheets.GROUP_INTERBANK.value]

        try:
            #customer_df = filter_data_g14_group_interbank(self.get_target_report())
            cal = CalG14CustomerData(self.get_target_report())
            customer_df = cal.filter_data_g14_group_interbank()

            row_num = customer_df.shape[0]
            column_num = column_index_from_string('Z')

            for row in range(0, row_num):
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        # ColumnA is Rank
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=H{idx}'.format(idx=row_idx_1)
                        cell.number_format = '_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        # ColumnB is Connection UEN/UEN
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 0]
                    elif column == column_index_from_string('C'):
                        # ColumnC is CUSTOMER_NAME_CH
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        #cell_formula = '=VLOOKUP(B{idx},Customer!$Z:$AA,2,FALSE)'.format(idx=row_idx_1)
                        cell_formula = '=IF($U{idx}="Y",VLOOKUP(B{idx},Customer!$Z:$AA,2,FALSE),VLOOKUP(B{idx},Customer!$E:$H,4,FALSE))'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('D'):
                        # ColumnD is UNIFORM_SOCIAL_CREDIT_CODE 统一社会信用代码
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(OR(ISERROR(VLOOKUP(B{idx},Customer!E:G,3,0)),ISBLANK(VLOOKUP(B{idx},Customer!E:G,3,0))),B{idx},VLOOKUP(B{idx},Customer!E:G,3,0))'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('E'):
                        # ColumnE is Total Risk Exposure, Exposure
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=ROUND(IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$J:$J,'G14 Master List'!F:F,'Group Interbank'!B{idx}), SUMIFS('G14 Master List'!$J:$J,'G14 Master List'!A:A,'Group Interbank'!B{idx})),20)".format(idx=row_idx_1)
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif column == column_index_from_string('F'):
                        # ColumnF is Total Risk Exposure, %
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=E{idx}/'Other inputs'!$B$3".format(idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '0.00%'
                    elif column == column_index_from_string('G'):
                        # ColumnG is Total Risk Exposure, LRE IND
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(F{idx}>=2.5%,"Y","N")'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('H'):
                        # ColumnH is Total Risk Exposure, Rank
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=RANK(E{idx},E:E)+COUNTIF($E$3:E{idx},E{idx})-1'.format(idx=row_idx_1)
                        cell.number_format = '_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('I'):
                        # ColumnI is General Risk Exposure 一般风险暴露
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$M:$M,'G14 Master List'!F:F,'Group Interbank'!B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$M:$M,'G14 Master List'!F:F,'Group Interbank'!B{idx})+SUMIFS('G14 Master List'!$BE:$BE,'G14 Master List'!F:F,'Group Interbank'!B{idx}),SUMIFS('G14 Master List'!$M:$M,'G14 Master List'!A:A,'Group Interbank'!B{idx})+SUMIFS('G14 Master List'!$BE:$BE,'G14 Master List'!A:A,'Group Interbank'!B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('J'):
                        # ColumnJ is Counterparty Credit Risk Exposure 交易对手信用风险暴露
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$N:$N,'G14 Master List'!$F:$F,'Group Interbank'!B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$N:$N,'G14 Master List'!$F:$F,'Group Interbank'!B{idx}),SUMIFS('G14 Master List'!$N:$N,'G14 Master List'!$A:$A,'Group Interbank'!B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('K'):
                        # ColumnK is Potential Risk Exposure 潜在风险暴露
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$O:$O,'G14 Master List'!$F:$F,'Group Interbank'!B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$O:$O,'G14 Master List'!F:F,'Group Interbank'!B{idx})+SUMIFS('G14 Master List'!$BF:$BF,'G14 Master List'!F:F,'Group Interbank'!B{idx}), SUMIFS('G14 Master List'!$O:$O,'G14 Master List'!A:A,'Group Interbank'!B{idx})+SUMIFS('G14 Master List'!$BF:$BF,'G14 Master List'!A:A,'Group Interbank'!B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('L'):
                        # ColumnL is Trading Book Risk Exposure 交易账簿风险暴露
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$P:$P,'G14 Master List'!$F:$F,'Group Interbank'!B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$P:$P,'G14 Master List'!$F:$F,'Group Interbank'!B{idx}),SUMIFS('G14 Master List'!$P:$P,'G14 Master List'!$F:$F,'Group Interbank'!B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('M'):
                        # ColumnM is Exception 豁免
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$T:$T,'G14 Master List'!$A:$A,B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$T:$T,'G14 Master List'!$F:$F,B{idx}),SUMIFS('G14 Master List'!$T:$T,'G14 Master List'!$A:$A,B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('N'):
                        # ColumnN is Risk transfer ind 风险缓释
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$J:$J,'G14 Master List'!$G:$G,B{idx},'G14 Master List'!$R:$R,\"Y\")".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$V:$V,'G14 Master List'!$F:$F,B{idx},'G14 Master List'!$U:$U,\"Y\"),SUMIFS('G14 Master List'!$V:$V,'G14 Master List'!$A:$A,B{idx},'G14 Master List'!$U:$U,\"Y\"))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('O'):
                        # ColumnO is General Risk Exposure 一般风险暴露 - 同业拆借
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$AH:$AH,'G14 Master List'!G:G,'Group Interbank'!B{idx})-SUMIFS('G14 Master List'!$AV:$AV,'G14 Master List'!G:G,'Group Interbank'!B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$AH:$AH,'G14 Master List'!F:F,'Group Interbank'!B{idx})-SUMIFS('G14 Master List'!$AV:$AV,'G14 Master List'!F:F,'Group Interbank'!B{idx}),SUMIFS('G14 Master List'!$AH:$AH,'G14 Master List'!A:A,'Group Interbank'!B{idx})-SUMIFS('G14 Master List'!$AV:$AV,'G14 Master List'!A:A,'Group Interbank'!B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('P'):
                        # ColumnP is General Risk Exposure 一般风险暴露 - 存放同业
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$AN:$AN,'G14 Master List'!G:G,'Group Interbank'!B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$AN:$AN,'G14 Master List'!$F:$F,'Group Interbank'!B{idx}),SUMIFS('G14 Master List'!$AN:$AN,'G14 Master List'!$A:$A,'Group Interbank'!B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('Q'):
                        # ColumnQ is General Risk Exposure 一般风险暴露 - TF&IFI
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$Y:$Y,'G14 Master List'!G:G,'Group Interbank'!B{idx})-SUMIFS('G14 Master List'!$AU:$AU,'G14 Master List'!G:G,'Group Interbank'!B{idx})+SUMIFS('G14 Master List'!$X:$X,'G14 Master List'!G:G,'Group Interbank'!B{idx})-SUMIFS('G14 Master List'!$AT:$AT,'G14 Master List'!G:G,'Group Interbank'!B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$Y:$Y,'G14 Master List'!F:F,'Group Interbank'!B{idx})-SUMIFS('G14 Master List'!$AU:$AU,'G14 Master List'!F:F,'Group Interbank'!B{idx})+SUMIFS('G14 Master List'!$X:$X,'G14 Master List'!F:F,'Group Interbank'!B{idx})-SUMIFS('G14 Master List'!$AT:$AT,'G14 Master List'!F:F,'Group Interbank'!B{idx}),SUMIFS('G14 Master List'!$Y:$Y,'G14 Master List'!A:A,'Group Interbank'!B{idx})-SUMIFS('G14 Master List'!$AU:$AU,'G14 Master List'!A:A,'Group Interbank'!B{idx})+SUMIFS('G14 Master List'!$X:$X,'G14 Master List'!A:A,'Group Interbank'!B{idx})-SUMIFS('G14 Master List'!$AT:$AT,'G14 Master List'!A:A,'Group Interbank'!B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('R'):
                        # ColumnR is General Risk Exposure 一般风险暴露 - Bond 同业债券
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$AI:$AI,'G14 Master List'!G:G,'Group Interbank'!B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$AI:$AI,'G14 Master List'!F:F,'Group Interbank'!B{idx}),SUMIFS('G14 Master List'!$AI:$AI,'G14 Master List'!A:A,'Group Interbank'!B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('S'):
                        # ColumnS is General Risk Exposure 一般风险暴露 - Policy bank 政策性金融债
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$AQ:$AQ,'G14 Master List'!G:G,'Group Interbank'!B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$AQ:$AQ,'G14 Master List'!F:F,'Group Interbank'!B{idx}),SUMIFS('G14 Master List'!$AQ:$AQ,'G14 Master List'!A:A,'Group Interbank'!B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('T'):
                        # ColumnT is General Risk Exposure 一般风险暴露 - NCD 同业存单
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=SUMIFS('G14 Master List'!$AJ:$AJ,'G14 Master List'!G:G,'Group Interbank'!B{idx})".format(
                        #     idx=row_idx_1)
                        cell_formula = "=IF($U{idx}=\"Y\",SUMIFS('G14 Master List'!$AJ:$AJ,'G14 Master List'!F:F,'Group Interbank'!B{idx}),SUMIFS('G14 Master List'!$AJ:$AJ,'G14 Master List'!A:A,'Group Interbank'!B{idx}))".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('U'):
                        # ColumnU is Is connection UEN?
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 1]
                    elif column == column_index_from_string('V'):
                        # ColumnV is Overall Rank
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=COUNTIF(\'Group Cust\'!E:E,">"&E{idx})+COUNTIF(E:E,">"&E{idx})+COUNTIF(LRE!E:E,">"&E{idx})+COUNTIF(\'Group Cust\'!E:E,E{idx})+COUNTIF($E$3:E{idx},E{idx})'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula

                    elif column == column_index_from_string('W'):
                        # ColumnW is Customer Type
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "=_xlfn.IFNA(_xlfn.IFS(AND(_xlfn.COUNTIFS('Single Interbank'!V:V,'Group Interbank'!B{idx},'Single Interbank'!E:E,E{idx})=0,U{idx}=\"Y\"),\"同业集团客户\",AND(_xlfn.COUNTIFS('Single Interbank'!B:B,'Group Interbank'!B{idx},'Single Interbank'!E:E,E{idx})=0,U{idx}=\"N\"),\"同业集团客户\"),\"同业单一客户\")".format(
                        #     idx=row_idx_1)
                        cell_formula = "=_xlfn.IFNA(_xlfn.IFS(U{idx}=\"Y\",\"同业集团客户\",AND(_xlfn.COUNTIFS('Single Interbank'!B:B,'Group Interbank'!B{idx},'Single Interbank'!E:E,E{idx})=0,U{idx}=\"N\"),\"同业集团客户\"),\"同业单一客户\")".format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('X'):
                        # ColumnX is Expoure for G1406 Rank
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        # https://stackoverflow.com/questions/61705150/openpyxl-is-inserted-to-formula-when-saving-to-file
                        # cell_formula = "=_xlfn.IFNA(_xlfn.IFS(AND(_xlfn.COUNTIFS('Single Interbank'!V:V,'Group Interbank'!B{idx},'Single Interbank'!E:E,E{idx})=0,U{idx}=\"Y\"),E{idx},AND(_xlfn.COUNTIFS('Single Interbank'!B:B,'Group Interbank'!B{idx},'Single Interbank'!E:E,E{idx})=0,U{idx}=\"N\"),E{idx}),\"当季只有一个客户有oustanding的UEN/Connection UEN\")".format(
                        #     idx=(row_idx_1))
                        cell_formula = "=_xlfn.IFNA(_xlfn.IFS(U{idx}=\"Y\",E{idx},AND(_xlfn.COUNTIFS('Single Interbank'!B:B,'Group Interbank'!B{idx},'Single Interbank'!E:E,E{idx})=0,U{idx}=\"N\"),E{idx}),\"当季只有一个客户有oustanding的外国分行\")".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula

                    elif column == column_index_from_string('Y'):
                        # ColumnY is G1406 Rank
                        cell = group_interbank_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=RANK(X{idx},X:X)+COUNTIF($X$3:X{idx},X{idx})-1'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula

            self._log.debug('*** g14 group_interbank data nums={}'.format(customer_df.shape[0]))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_group_cust_sheet(self):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.GROUP_CUST.value)
        wb = self.get_workbook()
        single_cust_worksheet = wb[G14ReportSpreadSheets.GROUP_CUST.value]

        try:
            customer_df = filter_data_g14_group_cust(self.get_target_report())
            row_num = customer_df.shape[0]
            column_num = column_index_from_string('W')

            for row in range(0, row_num):
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        # ColumnA is Rank
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=H{idx}'.format(idx=row_idx_1)
                        cell.number_format = '_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        # ColumnB is CBS Group
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 0]
                    elif column == column_index_from_string('C'):
                        # ColumnC is CUSTOMER_NAME_CH
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 1]
                    elif column == column_index_from_string('D'):
                        # ColumnD is UNIFORM_SOCIAL_CREDIT_CODE 统一社会信用代码
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_df.iloc[row, 0]
                    elif column == column_index_from_string('E'):
                        # ColumnE is Total Risk Exposure, Exposure
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=ROUND(SUMIFS('G14 Master List'!$J:$J,'G14 Master List'!E:E,'Group Cust'!B{idx}),20)".format(idx=row_idx_1)
                        #cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.number_format = '0.00'
                        cell.value = cell_formula
                    elif column == column_index_from_string('F'):
                        # ColumnF is Total Risk Exposure, %
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=E{idx}/'Other inputs'!$B$3".format(idx=row_idx_1)
                        cell.value = cell_formula
                        cell.number_format = '0.00%'
                    elif column == column_index_from_string('G'):
                        # ColumnG is Total Risk Exposure, LRE IND
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(F{idx}>=2.5%,"Y","N")'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('H'):
                        # ColumnH is Total Risk Exposure, Rank
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=RANK(E{idx},E:E)+COUNTIF($E$3:E{idx},E{idx})-1'.format(idx=row_idx_1)
                        cell.number_format = '_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('I'):
                        # ColumnI is General Risk Exposure 一般风险暴露
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$M:$M,'G14 Master List'!E:E,'Group Cust'!B{idx})+SUMIFS('G14 Master List'!$BE:$BE,'G14 Master List'!$E:$E,B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('J'):
                        # ColumnJ is Counterparty Credit Risk Exposure 交易对手信用风险暴露
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$N:$N,'G14 Master List'!E:E,'Group Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('K'):
                        # ColumnK is Potential Risk Exposure 潜在风险暴露
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$O:$O,'G14 Master List'!$E:$E,'Group Cust'!B{idx})+SUMIFS('G14 Master List'!$BF:$BF,'G14 Master List'!$E:$E,B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('L'):
                        # ColumnL is Trading Book Risk Exposure 交易账簿风险暴露
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$P:$P,'G14 Master List'!$E:$E,'Group Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('M'):
                        # ColumnM is Loan balance 贷款余额
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$S:$S,'G14 Master List'!$E:$E,'Group Cust'!B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('N'):
                        # ColumnN is Exception 豁免
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$T:$T,'G14 Master List'!$E:$E,B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('O'):
                        # ColumnO is Risk transfer ind 风险缓释
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$V:$V,'G14 Master List'!$E:$E,B{idx},'G14 Master List'!$U:$U,\"Y\")".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('P'):
                        # ColumnP is General Risk Exposure 一般风险暴露 - 各项贷款
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$W:$W,'G14 Master List'!$E:$E,B{idx})+SUMIFS('G14 Master List'!$Y:$Y,'G14 Master List'!$E:$E,B{idx})-SUMIFS('G14 Master List'!$AR:$AR,'G14 Master List'!$E:$E,B{idx})-SUMIFS('G14 Master List'!$AU:$AU,'G14 Master List'!$E:$E,B{idx})+SUMIFS('G14 Master List'!$BE:$BE,'G14 Master List'!$E:$E,B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('Q'):
                        # ColumnQ is Potential Risk Exposure 潜在风险暴露 - BAD 银行承兑汇票
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                    elif column == column_index_from_string('R'):
                        # ColumnR is Potential Risk Exposure 潜在风险暴露 - LC 跟单信用证
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$AG:$AG,'G14 Master List'!$E:$E,B{idx}) - SUMIFS('G14 Master List'!$AY:$AY,'G14 Master List'!$E:$E,B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('S'):
                        # ColumnS is Potential Risk Exposure 潜在风险暴露 - Guarantee 保函
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$AF:$AF,'G14 Master List'!$E:$E,B{idx}) - SUMIFS('G14 Master List'!$AX:$AX,'G14 Master List'!$E:$E,B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('T'):
                        # ColumnT is Potential Risk Exposure 潜在风险暴露 - Loan Commitment 贷款承诺
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$AC:$AC,'G14 Master List'!$E:$E,B{idx}) + SUMIFS('G14 Master List'!$AD:$AD,'G14 Master List'!$E:$E,B{idx}) + SUMIFS('G14 Master List'!$AE:$AE,'G14 Master List'!$E:$E,B{idx}) - SUMIFS('G14 Master List'!$AW:$AW,'G14 Master List'!$E:$E,B{idx})+SUMIFS('G14 Master List'!$BF:$BF,'G14 Master List'!$E:$E,B{idx})".format(
                            idx=row_idx_1)
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula

                    elif column == column_index_from_string('U'):
                        # ColumnU is Overall Rank
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=COUNTIF(E:E,">"&E{idx})+COUNTIF(\'Group Interbank\'!E:E,">"&E{idx})+COUNTIF(LRE!E:E,">"&E{idx})+COUNTIF($E$3:E{idx},E{idx})'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('V'):
                        # ColumnU is Customer Type
                        cell = single_cust_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = '非同业集团客户'


            self._log.debug('*** g14 group_cust data nums={}'.format(customer_df.shape[0]))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_g14_master_list_sheet(self, customer_data_list):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.G14_MASTER_LIST.value)
        wb = self.get_workbook()
        master_list_worksheet = wb[G14ReportSpreadSheets.G14_MASTER_LIST.value]

        try:
            cal_customer = CalG14CustomerData(self.get_target_report())
            #row_num = len(customer_data_list)
            df = cal_customer.get_customer_df()
            row_num = df.shape[0]
            column_num = column_index_from_string('BG')

            for row in range(0, row_num):
                row_idx_1 = row + 3
                #row_obj = customer_data_list[row]
                #cbs_id = row_obj[CustomerSheetEnum.CBS_ID.value]

                for column in range(0, column_num):

                    super(G14Report, self).init_master_list(master_list_worksheet, row_idx_1, column)

                    if column == column_index_from_string('G'):
                        # ColumnG is G14 group ind, 根据需求文档重新计算 G14 group ind的值
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        #cell.value = cal_customer.get_g14_group_ind(cbs_id)
                        cell.value = df.iloc[row,9]
                    elif column == column_index_from_string('N'):
                        # ColumnN is Counterparty Credit Risk Exposure\n交易对手信用风险暴露
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=SUM(AM{idx})'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('S'):
                        # ColumnS is Loan balance\n贷款余额
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS(Loan!BP:BP,Loan!$A:$A,'G14 Master List'!B{idx})/10000+Z{idx}".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula

                    elif column == column_index_from_string('T'):
                        # ColumnT is Exception
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(OR(B{idx}="009000",B{idx}="301148",B{idx}="300621",B{idx}="300622",B{idx}="300761"),J{idx},AQ{idx})+P{idx}'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula

                    elif column == column_index_from_string('AA'):
                        # ColumnAA is Others
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=SUMIFS(PBOC!$F:$F,PBOC!A:A,\'G14 Master List\'!B{idx})/10000'.format(
                            idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('AB'):
                        # ColumnAB is Auto Fin
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('Auto Fin'!F:F,'Auto Fin'!A:A,'G14 Master List'!B{idx})/10000".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('AH'):
                        # ColumnAH is MM 505 Lending/placing
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('MM 505'!$AD:$AD,'MM 505'!$AA:$AA,\"Y\",'MM 505'!$J:$J,\"XL\",'MM 505'!$A:$A,'G14 Master List'!B{idx})/10000".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('AM'):
                        # ColumnAM is Exposure under Derivatives
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS(EAD!$I:$I,EAD!A:A,'G14 Master List'!B{idx})/10000".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('AN'):
                        # ColumnAN is Nostro placing (non-settlement account)
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS(Nostro!F:F,Nostro!A:A,'G14 Master List'!B{idx})/10000".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('AQ'):
                        # ColumnAQ is Exception\n-Policy Bond
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('Bond & NCD'!G:G,'Bond & NCD'!A:A,B{idx},'Bond & NCD'!B:B,\"POL\",'Bond & NCD'!I:I,\"T3773\")/10000".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('AV'):
                        # ColumnAV is Provision\n- MM 505\nLending/placing
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(COUNTIF(LLP!$AE:$AE,B{idx})>0,SUMIFS(LLP!$AD:$AD,LLP!$AE:$AE,B{idx},LLP!$C:$C,\"Interbank Lending\")/10000,IF(AND(COUNTIF($A$3:A{idx},A{idx})=1,SUMIFS($AH:$AH,$A:$A,A{idx})=0),SUMIFS(LLP!$AD:$AD,LLP!$F:$F,A{idx},LLP!$C:$C,\"Interbank Lending\")/10000,0))".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula

                    elif column == column_index_from_string('BD'):
                        # ColumnBD is 外国银行分行？（Y/N) , 根据需求文档重新计算 外国银行分行？（Y/N) 的值
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        #cell.value = cal_customer.get_foreign_bank_branch(cbs_id)
                        cell.value = df.iloc[row, 8]
                    elif column == column_index_from_string('BE'):
                        # ColumnBE is Risk transfer - General Risk Exposure
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,IF($AZ{idx}=\"Y\", -($W{idx}-$AR{idx}), IF($BA{idx}=\"Y\", -SUMIF($BB:$BB,$A{idx},$BE:$BE), 0)),0)".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('BF'):
                        # ColumnBF is Risk transfer - Potential Risk Exposure
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=IF(COUNTIF($A$3:A{idx},A{idx})=1,IF($AZ{idx}=\"Y\", -(SUM($AC{idx}:$AE{idx})-$AW{idx}), IF($BA{idx}=\"Y\", -SUMIF($BB:$BB,$A{idx},$BF:$BF), 0)),0)".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula

            self._log.debug('*** g14 master data nums={}'.format(row_num))
        except Exception as err:
            raise ReportException(err)
        finally:
            self.save_report()

    def init_lre_sheet(self, customer_g14_group_ind_ls):
        self._log.info(LOG_INIT_SHEET, G14ReportSpreadSheets.LRE.value)
        wb = self.get_workbook()
        lre_worksheet = wb[G14ReportSpreadSheets.LRE.value]

        try:
            #row_num = len(customer_g14_group_ind_ls)
            cal = CalG14CustomerData(self.get_target_report())
            customer_df = cal.filter_data_lre()
            row_num = customer_df.shape[0]

            all_row_num = row_num + 2
            column_num = column_index_from_string('T')

            for row in range(0, row_num):
                row_idx_1 = row + 3
                customer_obj = customer_g14_group_ind_ls[row]

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        # ColumnA is Rank
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=H{idx}'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        # ColumnB is UEN
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        #cell.value = customer_obj[CustomerSheetEnum.UEN.value]
                        cell.value = customer_df.iloc[row, 2]
                    elif column == column_index_from_string('C'):
                        # ColumnC is CUSTOMER_NAME_CH 客户名称
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(ISBLANK(VLOOKUP(B{idx},Customer!$E:$H,4,FALSE)),VLOOKUP(B{idx},Customer!$E:$I,5,FALSE),VLOOKUP(B{idx},Customer!$E:$H,4,FALSE))'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('D'):
                        # ColumnD is UNIFORM_SOCIAL_CREDIT_CODE 统一社会信用代码
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(ISBLANK(VLOOKUP(B{idx},Customer!E:G,3,0)),"INPUT",VLOOKUP(B{idx},Customer!E:G,3,0))'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('E'):
                        # ColumnE is Total Risk Exposure 风险暴露总和, Exposure
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=ROUND(SUMIFS('G14 Master List'!$J:$J,'G14 Master List'!$A:$A,LRE!B{idx}),20)".format(
                            idx=(row_idx_1))
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('F'):
                        # ColumnF is Total Risk Exposure 风险暴露总和, %
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=E{idx}/'Other inputs'!$B$3".format(
                            idx=(row_idx_1))
                        cell.number_format = '0.00%'
                        cell.value = cell_formula
                    elif column == column_index_from_string('G'):
                        # ColumnG is Total Risk Exposure 风险暴露总和, LRE IND
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(F{idx}>=2.5%,"Y","N")'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('H'):
                        # ColumnH is Total Risk Exposure 风险暴露总和, LRE Rank
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        #cell_formula = '=RANK(E{idx},E:E)'.format(idx=(row_idx_1))
                        cell_formula = '=RANK(E{idx},E:E,0)+COUNTIF($E$3:E{idx},E{idx})-1'.format(
                            idx=row_idx_1, all_row_num=all_row_num)
                        cell.value = cell_formula
                    elif column == column_index_from_string('I'):
                        # ColumnI is General Risk Exposure 一般风险暴露
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$M:$M,'G14 Master List'!A:A,LRE!B{idx})+SUMIFS('G14 Master List'!$BE:$BE,'G14 Master List'!$A:$A,LRE!B{idx})".format(
                            idx=(row_idx_1))
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('J'):
                        # ColumnJ is Counterparty Credit Risk Exposure 交易对手信用风险暴露
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$N:$N,'G14 Master List'!$A:$A,LRE!B{idx})".format(
                            idx=(row_idx_1))
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('K'):
                        # ColumnK is Potential Risk Exposure 潜在风险暴露
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$O:$O,'G14 Master List'!$A:$A,LRE!B{idx})+SUMIFS('G14 Master List'!$BF:$BF,'G14 Master List'!$A:$A,LRE!B{idx})".format(
                            idx=(row_idx_1))
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('L'):
                        # ColumnL is Trading Book Risk Exposure 交易账簿风险暴露
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$P:$P,'G14 Master List'!$A:$A,LRE!B{idx})".format(
                            idx=(row_idx_1))
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('M'):
                        # ColumnM is Exception 豁免
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$T:$T,'G14 Master List'!$A:$A,B{idx})".format(
                            idx=(row_idx_1))
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('N'):
                        # ColumnN is Exception Risk transfer ind 风险缓释
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS('G14 Master List'!$V:$V,'G14 Master List'!$A:$A,B{idx},'G14 Master List'!$U:$U,\"Y\")".format(
                            idx=(row_idx_1))
                        cell.number_format = '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)'
                        cell.value = cell_formula
                    elif column == column_index_from_string('O'):
                        # ColumnO is LRE IND
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(N{idx}>=2.5%,"Y","N")'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('P'):
                        # ColumnP is Rank
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=RANK(M{idx},M:M)'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('Q'):
                        # ColumnQ is G14_II ind
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(OR(G{idx}="Y",O{idx}="Y"),"Y","N")'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('R'):
                        # ColumnR is G14_CUST TYPE
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=VLOOKUP(B{idx},'G14 Master List'!A:H,8,0)".format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('S'):
                        # ColumnT is overall Rank
                        cell = lre_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=COUNTIF(\'Group Cust\'!E:E,">"&E{idx})+COUNTIF(\'Group Interbank\'!E:E,">"&E{idx})+COUNTIF(LRE!E:E,">"&E{idx})+COUNTIF(\'Group Cust\'!E:E, E{idx})+COUNTIF(\'Group Interbank\'!E:E, E{idx})+COUNTIF($E$3:E{idx}, E{idx})'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula

            self._log.debug('*** g14 LRE data nums={}'.format(len(customer_g14_group_ind_ls)))
        except Exception as err:
            raise ReportException(str(err))
        finally:
            self.save_report()


class ReportBuilder(metaclass=ABCMeta):
    """ Report 建造者 """

    @abstractmethod
    def create_report(self, data_date):
        pass


class LreDailyReportBuilder(ReportBuilder):
    """ LRE daily Report 建造者 """

    def __init__(self):
        self._log = get_logger(__name__ + '.' + self.__class__.__name__)

    def create_report(self, data_date):
        daily_report = None
        try:
            self._log.info("*** begin create daily report ***")
            daily_report = LreDailyReport(data_date)
            daily_report.load_target_report()

            ### Extract Resource data to datasheet
            daily_report.init_rate_sheet()

            daily_report.init_loan_sheet()

            daily_report.init_other_inputs_sheet()

            daily_report.init_ead_sheet()

            customer_data_list, customer_g14_group_ind_ls = daily_report.init_customer_sheet()

            daily_report.init_daily_mm505_sheet()

            daily_report.init_dsc_sheet()

            daily_report.init_llp_sheet()

            daily_report.init_nostro_sheet()

            daily_report.init_limit_sheet()

            daily_report.init_auto_fin_sheet()

            daily_report.init_offbs_tf_sheet()

            daily_report.init_bond_ncd_sheet()

            daily_report.init_pboc_sheet()

            daily_report.init_credit_exposure_sheet()

            daily_report.init_fefc_sheet()

            ### Calculate data into intermediate datasheet from resource datasheet
            daily_report.init_daily_master_list_sheet(customer_data_list)

            ### Generate daily report
            daily_report.init_single_cust_sheet()

            daily_report.init_group_corp_sheet()

            daily_report.init_group_bank_sheet()

            daily_report.init_summary_control_sheet()

            self._log.info('*************************************')
            self._log.info("*** end create daily report, :) ***")
            self._log.info('*************************************')
            return daily_report
        except Exception as err:
            self._log.error("*** failed to create daily report ***")
            raise ReportException(err)


class G14ReportBuilder(ReportBuilder):
    """ G14 Report 建造者 """

    def __init__(self):
        self._log = get_logger(__name__ + '.' + self.__class__.__name__)
        self.g14_report = None

    def is_created_report(self, data_date):
        self.g14_report = G14Report(data_date)
        target_report = self.g14_report.get_target_report()

        if os.path.isfile(target_report):
            return True, target_report
        else:
            return False, target_report

    def create_report(self, data_date):
        try:
            self._log.info("*** begin create g14 report data_date={} ***".format(data_date))
            self.g14_report.load_target_report()

            ### Extract Resource data to datasheet
            self.g14_report.init_rate_sheet()

            self.g14_report.init_loan_sheet()

            self.g14_report.init_other_inputs_sheet()

            self.g14_report.init_bond_ncd_sheet()

            self.g14_report.init_ead_sheet()

            self.g14_report.init_g14_mm505_sheet()

            self.g14_report.init_llp_sheet()

            self.g14_report.init_nostro_sheet()

            self.g14_report.init_offbs_tf_sheet()

            self.g14_report.init_limit_sheet()

            self.g14_report.init_auto_fin_sheet()

            self.g14_report.init_pboc_sheet()

            customer_data_list, customer_g14_group_ind_ls = self.g14_report.init_customer_sheet()

            self.g14_report.init_credit_exposure_sheet()

            self.g14_report.init_dsc_sheet()

            ### Calculate data into intermediate datasheet from resource datasheet
            self.g14_report.init_g14_master_list_sheet(customer_data_list)

            self.g14_report.init_lre_sheet(customer_g14_group_ind_ls)

            self.g14_report.init_single_cust_sheet()

            self.g14_report.init_group_cust_sheet()

            self.g14_report.init_single_interbank_sheet()

            self.g14_report.init_group_interbank_sheet()

            ### Generate g14 report
            self.g14_report.init_g1406_sheet()
            self.g14_report.init_g1405_sheet()
            self.g14_report.init_g1404_sheet()
            self.g14_report.init_g1403_sheet()
            self.g14_report.init_g1402_sheet()
            self.g14_report.init_g1401_sheet()

            self._log.info('*************************************')
            self._log.info("*** end create g14 report ***")
            self._log.info('*************************************')
            return self.g14_report
        except Exception as err:
            self._log.error('---------------------------------------')
            self._log.error("*** failed to create g14 report ***")
            self._log.error('---------------------------------------')

            if self.g14_report:
                self.g14_report.remove_target_report()

            raise ReportException(err)


