# -*- coding: utf-8 -*-

"""
Created on 2020-11-13

@author: Wang Shuo
"""


class BaseLreException(Exception):

    def __init__(self, message):
        super().__init__(self)
        self.__message = message

    def __str__(self):
        return str(self.__message)


class ReportException(BaseLreException):
    pass


class EmailException(BaseLreException):
    pass


class ReportInvalidDataDateException(BaseLreException):
    """ 输入的 data_date 格式不正确异常， data_date正确的输入数据是 20201120 """
    pass


class DataException(BaseLreException):
    pass
