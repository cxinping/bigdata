# -*- coding: utf-8 -*-

"""
Created on 2020-11-06

@author: Wang Shuo
"""

import time

from .logging import get_logger

log = get_logger(__name__)


def is_valid_date(str_date):
    """ 判断是否是一个有效的日期字符串 """

    try:
        time.strptime(str(str_date), "%Y%m%d")
        return True
    except ValueError as err:
        log.warning(err, exc_info=True)
        return False
