# -*- coding: utf-8 -*-

from enum import Enum


class ReportType(Enum):
    """ Report 类型 """
    DAILY_REPORT = 'daily'
    G14_REPORT = 'g14'


class G14ReportSpreadSheets(Enum):
    G1401 = 'G1401'
    G1402 = 'G1402'
    G1403 = 'G1403'
    G1404 = 'G1404'
    G1405 = 'G1405'
    G1406 = 'G1406'
    SINGLE_CUST = 'Single Cust'
    GROUP_CUST = 'Group Cust'
    SINGLE_INTERBANK = 'Single Interbank'
    GROUP_INTERBANK = 'Group Interbank'
    LRE = 'LRE'
    G14_MASTER_LIST = 'G14 Master List'
    CREDIT_EXPOSURE = 'CREDIT EXPOSURE'
    CUSTOMER = 'Customer'
    LOAN = 'Loan'
    RATE = 'RATE'
    OTHER_INPUTS = 'Other inputs'
    BOND_NCD = 'Bond & NCD'
    EAD = 'EAD'
    DSC = 'DSC'
    MM_505 = 'MM 505'
    LLP = 'LLP'
    NOSTRO = 'Nostro'
    OFFBS_TF = 'offbs TF'
    LIMIT = 'Limit'
    AUTO_FIN = 'Auto Fin'
    PBOC = 'PBOC'


class LreDailyReportSpreadSheets(Enum):
    SUMMARY_CONTROL = 'Summary Control'
    GROUP_BANK = 'Group Bank'  # 同业客户
    GROUP_CORP = 'Group Corp'  # 非同业集团客户，Non interbank group Customer
    SINGLE_CUST = 'Single Cust'  # 非同业单一客户, Non interbank Customer Single Customer
    DAILY_MASTER_LIST = 'Daily Master List'
    RATE = 'RATE'
    LOAN = 'Loan'
    OTHER_INPUTS = 'Other inputs'
    CUSTOMER = 'Customer'
    EAD = 'EAD'
    MM_505 = 'MM 505'
    DSC = 'DSC'
    LLP = 'LLP'
    NOSTRO = 'Nostro'
    LIMIT = 'Limit'
    AUTO_FIN = 'Auto Fin'
    OFFBS_TF = 'offbs TF'
    BOND_NCD = 'Bond & NCD'
    PBOC = 'PBOC'
    CREDIT_EXPOSURE = 'CREDIT EXPOSURE'
    FEFC = 'FEFC'


class CommonParamEnum(Enum):
    CNY = 'CNY'


class RateSheetEnum(Enum):
    """ RATE sheet的column类型 """
    S_DATE = 's_date'
    E_DATE = 'e_date'
    BASIC_CCY = 'basic_ccy'
    FORWARD_CCY = 'forward_ccy'
    CCY_RATE = 'ccy_rate'


class LoanSheetEnum(Enum):
    """ Loan sheet的column类型 """
    DATA_DATE = 'data_date'
    CBS_ID = 'cbs_id'
    CBS_CUST_ID = 'cbs_cust_id'
    CURRENCY = 'currency'
    AMOUNT = 'amount'
    INTEREST_RECEIVED_TO_GL = 'interest_received_to_gl'
    STATUS = 'status'
    OUR_REF = 'our_ref'


class CustomerSheetEnum(Enum):
    """ Customer sheet的column类型 """
    LOCAL_BRANCH = 'local_branch'
    CBS_ID = 'cbs_id'
    WSS_ID = 'wss_id'
    PIX_ID = 'pix_id'
    UEN = 'uen'
    OTL_ID = 'otl_id'
    UNIFORM_SOCIAL_CREDIT_CODE = 'uniform_social_credit_code'
    CUSTOMER_NAME_CN = 'customer_name_cn'
    CUSTOMER_NAME_EN = 'customer_name_en'
    CUSTOMER_CATEGORY = 'customer_category'
    NATIONALITY = 'nationality'
    COUNTRY = 'country'
    EXPOSURE_COUNTRY = 'exposure_country'
    AREA = 'area'
    CORP_TYPE = 'corp_type'
    CORP_SIZE = 'corp_size'
    INDUSTRY_CODE = 'industry_code'
    HOLDING_TYPE = 'holding_type'
    UNIQUE_ID_VALUE = 'unique_id_value'
    GROUP_CODE = 'group_code'
    GROUP_NAME = 'group_name'
    GROUP_CHINESE_NAME = 'group_chinese_name'
    STATUS = 'status'
    DATA_DATE = 'data_date'
    CONNECTION_UEN = 'connection_uen'
    CONNECTION_NAME = 'connection_name'
    G14_GROUP_IND = 'g14_group_ind'


class OtherInputsSheetEnum(Enum):
    """ Other Inputs sheet的column类型 """

    """ part1 一级资本净额和资本净额 """
    TIER1_CAPITAL_AMT = 'tier1_capital_amt'                     # 一级资本净额
    TOTAL_CAPITAL_AMT = 'total_capital_amt'                     # 资本净额

    """ part2 同业融资业务 """
    RANK_CD = 'rank_cd'                                             # 排序
    FN_INSTITUTION_NAME_CD = 'fin_institution_name_cd'              # 客户名称
    FN_INSTITUTION_CODE_CD = 'fin_institution_code_cd'              # 客户代码
    IB_DRAWDOWN_AMT = 'ib_drawdown_amt'                             # 拆放同业
    IB_LENDING_AMT = 'ib_lending_amt'                               # 其中：同业拆借
    IB_BORROW_AMT = 'ib_borrow_amt'                                 # 其中：同业借款
    PAYMENT_AMT = 'payment_amt'                                     # 其中：受托方同业代付
    NOSTRO_AMT = 'nostro_amt'                                       # 存放同业
    BUY_BACK_SALE_AMT = 'buy_back_sale_amt'                         # 买入返售
    OTH_IB_FINANCING_AMT = 'oth_ib_financing_amt'                   # 其他同业融出
    TOTAL_IB_FINANCING_AMT = 'total_ib_financing_amt'               # 同业融出合计
    REDUCE_IB_FINANCING_AMT = 'reduce_ib_financing_amt'             # 扣除结算性同业存款和风险权重为零资产后的融出余额
    PROPORTION_CAPITAL = 'proportion_capital'                       # 占一级资本净额比例%
    SETTLE_IB_DEPOSIT = 'settle_ib_deposit'                         # 结算性同业存款
    ZERO_RW_ASSET = 'zero_rw_asset'                                 # 风险权重为零的资产

    """ part3 报送口径：境内汇总数据 """
    ITEM_NAME = 'item_name'
    FOREIGN_IN_CNY_AMOUNT = 'foreign_in_cny_amount'                 # 人民币
    CNY_AMOUNT = 'cny_amount'                                       # 外币折人民币
    TOTAL_IN_CNY_AMOUNT = 'total_in_cny_amount'                     # 本外币合计

    """ part 4 & 5 : 同业拆借, 受托方同业代付  """
    INTERBANK_LENDING_AMOUNT = 'interbank_lending_amount'           # 同业拆借 本外币合计
    ENTRUSTED_PARTY_PAYS_AMOUNT = 'entrusted_party_pays_amount'     # 受托方同业大夫 本外币合计


class EadSheetEnum(Enum):
    """ EAD sheet的column类型 """
    CBS_ID = 'cbs_cif_id'
    COUNTERPARTY_LONG_NAME = 'counterparity_long_name'
    COUNTERPARTY_TYPE = 'counterpary_type'
    IBUK_CUSTOMER_NUMBER = 'ibuk_customer_number'
    EAD_USD = 'ead_usd'
    EAD_CNY_EQV = 'ead_cny_eqv'


class MM505SheetEnum(Enum):
    """ MM 505 sheet的column类型 """
    CBS_ID = 'cbs_id'
    REPORT_DATE = 'report_date'  # 对应<MM 505>的Report Date列，使用传入的 data_date,B列
    VALUE_DATE = 'value_date'
    MAT_DATE = 'mat_date'
    DEAL_TYPE = 'deal_type'
    DEAL_TYPE_RRA = 'deal_type_rra'
    CCY = 'ccy'
    AMOUNT = 'amount'
    TOTAL_INTEREST = 'interest_rec_pay'
    NAME_SHORT = 'name_short'  # 对应<MM 505>的Customer Short Name列，桔黄色，S列
    TYPE = 'customer_type'
    MM_CUST_NUM = 'wss_customer_number'
    INVENTORY = 'inventory'
    CUSTOMER_SHORT_NAME = 'customer_short_name'  # 对应<MM 505>的Customer Short Name列，蓝色, AB列
    CNY_EQV = 'cny_eqv'
    INTEREST_AMT = 'interest_amt'


class DscSheetEnum(Enum):
    """ DSC sheet的column类型 """
    CBS_ID = 'cbs_id'
    BENEFICARY_CBS_ID = 'beneficiary_cbs_id'
    RISKPARTY_UEN = 'riskparty_uen'
    RISKPARTY_CBSID = 'riskparty_cbsid'
    PRODUCT = 'product'
    WITH_BANK_CUSTOMER = 'with_bank_customer'
    RISKPARTY_CBSID_2 = 'riskparty_cbsid_2'
    RISKPARTY_UEN_2 = 'riskpary_uen_2'
    CURRENCY = 'currency'
    AMOUNT = 'amount'
    INTEREST_IN_ADVANCE = 'interest_in_advance'
    INCOME_ACCRUAL_AMOUNT = 'income_accrual_amount'
    OUR_REF = 'our_ref'


class LlpSheetEnum(Enum):
    """ LLp sheet的column类型 """
    BRANCH = 'branch'
    BS_OFFBS = 'bs_offbs'
    DEAL_TYPE = 'deal_type'
    UEN = 'uen'
    CCY_CNY_USD = 'ccy_cny_usd'
    PROV_AMT = 'prov_amt'
    TRANSACTION_REF = 'transaction_ref'


class NostroSheetEnum(Enum):
    """ Nostro sheet的column类型 """
    CUST_NO = 'cbs_customer_id'  # 对应<Nostro>的 CBS Customer ID列，桔黄色，B列
    CCY = 'ccy'
    AMOUNT = 'amount'
    FCY_AMOUNT = 'fcy_amount'  # 对应<Nostro>的 Interest receivable(+)/Unearned interest(-) from customer according to GL 列，E列，桔黄色


class LimitSheetEnum(Enum):
    """ Limit sheet的column类型 """
    CBS_ID = 'cbs_id'
    CUSTOMER_ID = 'customer_id'
    CURRENCY = 'currency'
    AVAILABLE_CREDIT_LIMIT = 'available_credit_limit'
    REVOCABLE = 'revocable'
    ORG_PERIOD_IN_ONE_YEAR = 'org_period_in_one_year'


class AutoFinSheetEnum(Enum):
    """ Auto Fin sheet的column类型 """
    CBS_ID = 'cbs_id'
    CURRENCY = 'currency'
    AMOUNT = 'amount'
    INTEREST_RECEIVED_TO_SQL = 'interest_received_to_gl'


class OffbsTfSheetEnum(Enum):
    """ Offbs Tf sheet的column类型 """
    CBS_ID = 'cbs_id'
    UEN_NO = 'uen_no'
    OFFBS_FACTOR = 'offbs_factor'
    DEAL_TYPE = 'deal_type'
    CURRENCY = 'currency'
    AMOUNT = 'amount'


class BondNcdSheetEnum(Enum):
    """ Bond & NCD sheet的column类型 """
    CBS_ID = 'cbs_id'
    ACCOUNTING_CODE = 'accounting_code'
    ISSUER_UEN = 'issuser_uen'
    CCY = 'ccy'
    BALANCE = 'balance'
    INTEREST_RECEIVABLE = 'interest_receivable'
    PROFIT_CENTER = 'profit_center'


class PbocSheetEnum(Enum):
    """ PBOC sheet的column类型 """
    CBS_ID = 'cbs_id'
    CURRENCY = 'currency'
    AMOUNT = 'amount'


class CreditExposureSheetNum(Enum):
    """ CREDIT_EXPOSURE sheet的column类型 """
    CUSTOMER_ID = 'customer_id'
    BORROWER = 'borrower'
    REVOCABLE = 'revocable'
    AVAILABLE_CREDIT_LIMIT = 'available_credit_limit'
    GUARANTOR_TYPE_1 = 'guarantor_type_1'
    NAME_GUARANTOR_1 = 'name_guarantor_1'
    ORG_PERIOD_IN_ONE_YEAR = 'org_period_in_one_year'
    UEN_GUARANTOR_1 = 'uen_guarantor_1'


class FefcSheetNum(Enum):
    """ FEFC sheet的column类型 """
    UEN = 'uen'
    PRODUCT_EXPOSURE = 'product_exposure'
    PRODUCT_EXPOSURE_CNY = 'product_exposure_cny'
