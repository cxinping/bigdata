# -*- coding: utf-8 -*-
"""
Created on 2020-12-02

@author: Wang Shuo
"""

import random
import pandas as pd
from datetime import datetime
import time, shutil
from bmolre.commons.logging import get_logger
from datetime import timedelta
import calendar
import math


log = get_logger(__name__)


def is_runnable_date(str_date):
    """
    Scenario: 因为Autosys只能简单地每天调用一次G14 service，没有办法处理复杂的调度，所以service本身要做一定程度的判断。
    Given: 当期的G14报表没有生成
    When: 1,4,7,10月的11-18日
    Then: 生成当期G14报表
    :param str_date:
    :return:
    """
    try:
        date_object = datetime.strptime(str(str_date), "%Y%m%d")
        input_month = date_object.month
        input_day = date_object.day

        valid_months = [1, 4, 7, 10]
        valid_days = [11, 12, 13, 14, 15, 16, 17, 18]

        if (input_month in valid_months) and (input_day in valid_days):
            return True
        else:
            return False
    except ValueError as err:
        return False

def get_last_business_day_season(query_date):
    """ 获得上一个季度的最后一个工作日 """
    try:
        query_date = datetime.strptime(query_date, '%Y%m%d')
        quarter = math.floor((query_date.month - 1) / 3 + 1)
        query_day = None

        if quarter == 1:
            query_day = datetime(query_date.year - 1, 12, 31)
        elif quarter == 2:
            query_day = datetime(query_date.year, 3, 31)
        elif quarter == 3:
            query_day = datetime(query_date.year, 6, 30)
        else:
            query_day = datetime(query_date.year, 9, 30)

        last_day = query_day.replace(day=calendar.monthrange(query_day.year, query_day.month)[1])
        last_business_day = None

        if last_day.weekday() == 5:  # if it's Saturday
            last_business_day = last_day - timedelta(days=1)  # then make it Friday
        elif last_day.weekday() == 6:  # if it's Sunday
            last_business_day = last_day - timedelta(days=2)  # then make it Friday
        else:
            last_business_day = last_day  # then make it business day

        return last_business_day.strftime('%Y%m%d')
    except ValueError as err:
        raise RuntimeError(str(err))


def gen_subject_title(str_date):
    """ 生成邮件的日报表标题 """

    str_time = datetime.strptime(str_date, '%Y%m%d')
    time_str = datetime.strftime(str_time, '%b %d,%Y')
    subject_title = 'LRE daily monitoring sheet as of ' + time_str + ' (Confidential and Internal use)'
    return subject_title


def rename_report(target_report):
    """ 拷贝一份报表，并重命名报表 """

    fmt = '%Y%m%d%H%M%S'  # 定义时间显示格式
    date_str = time.strftime(fmt, time.localtime(time.time()))
    report_data = target_report.split('.')
    rename_report = report_data[0] + '-' + date_str + '.' + report_data[1]
    shutil.copy(target_report, rename_report)


def get_daily_report_date(str_date):
    str_time = datetime.strptime(str_date, '%Y%m%d')
    time_str = datetime.strftime(str_time, '%Y/%m/%d')
    return time_str


def create_random_number(length=10):
    """ 生成len位的随机数 """

    raw = ""
    range1 = range(58, 65)  # between 0~9 and A~Z
    range2 = range(91, 97)  # between A~Z and a~z

    i = 0
    while i < length:
        seed = random.randint(48, 122)
        if ((seed in range1) or (seed in range2)):
            continue
        raw += chr(seed)
        i += 1

    return raw


def filter_data_daily_single_cust(report_path):
    """
    从<Customer> sheet 获取非同业单一客户，Non interbank Customer Single Customer
    :param report_path: 读取的日报表
    :return:
    """
    df = pd.read_excel(report_path, sheet_name='Customer',
                       usecols=['CUSTOMER_CATEGORY', 'CBS_ID']
                       , skiprows=None, engine="openpyxl", dtype={'CBS_ID': str})
    query_cond = (df['CUSTOMER_CATEGORY'] == 'CORPORATE') | (df['CUSTOMER_CATEGORY'] == 'GOV')
    customers_df = df[query_cond]
    group_df = customers_df.groupby(['CBS_ID'], as_index=False)['CBS_ID'].agg({'cnt': 'count'})
    return group_df


def filter_data_g14_single_cust(report_path):
    """
    从<G14 Master List> sheet 获取非同业单一客户，Non interbank Customer Single Customer
    :param report_path: 读取的日报表
    :return:
    """
    df = pd.read_excel(report_path, sheet_name='Customer',
                       usecols=['CUSTOMER_CATEGORY', 'UEN']
                       , skiprows=None, engine="openpyxl", dtype={'CBS_ID': str, 'UEN': str})
    query_cond = (df['CUSTOMER_CATEGORY'] == 'CORPORATE') | (df['CUSTOMER_CATEGORY'] == 'GOV')
    customers_df = df[query_cond]
    group_df = customers_df.groupby(['UEN'], as_index=False)['UEN'].agg({'cnt': 'count'})
    return group_df


def filter_data_group_corp(report_path):
    """
    从<Customer> sheet 获取非同业集团客户，None interbank group Customer
    :param report_path: 读取的日报表
    :return:
    """
    df = pd.read_excel(report_path, sheet_name='Customer',
                       usecols=['CUSTOMER_CATEGORY', 'UEN', 'GROUP_CODE']
                       , skiprows=None, engine="openpyxl", dtype={'UEN': str, 'GROUP_CODE': str})
    query_cond1 = (df['CUSTOMER_CATEGORY'] == 'CORPORATE') | (df['CUSTOMER_CATEGORY'] == 'GOV')
    query_cond2 = df['GROUP_CODE'].notnull()

    log.debug("type(df['GROUP_CODE'][0])=%s", type(df['GROUP_CODE'][0]))

    customers_df = df[query_cond1 & query_cond2]
    group_df = customers_df.groupby(['GROUP_CODE'], as_index=False)['GROUP_CODE'].agg({'cnt': 'count'})
    return group_df


def filter_data_group_bank(report_path):
    """
    从<Customer> sheet 获取同业客户，同业客户包括同业单一客户(interbank single Customer)，同业集团客户(interbank group Customer)
    :param report_path: 读取的日报表
    :return:
    """

    # 需求1: 选出LRE Customer Data 中CUSTOMER_CATEGORY是BANK或NBFI或QCCP的UEN。 LRE customer data 中相同的UEN有多条记录的，结果只需要抓一条。
    df = pd.read_excel(report_path, sheet_name='Customer',
                       usecols=['CUSTOMER_CATEGORY', 'UEN']
                       , skiprows=None, engine="openpyxl", dtype={'UEN': str})
    query_cond = (df['CUSTOMER_CATEGORY'] == 'BANK') | (df['CUSTOMER_CATEGORY'] == 'NBFI') | (
            df['CUSTOMER_CATEGORY'] == 'QCCP')
    master_list_df = df[query_cond]
    uen_df = master_list_df.groupby(['UEN'], as_index=False)['UEN'].agg({'cnt': 'count'})

    uen_df['Is connection UEN'] = 'N'
    uen_df['UEN'].astype('object')

    # 需求2: 选出LRE Customer Data 中CUSTOMER_CATEGORY是BANK或NBFI或QCCP的Connection UEN。 LRE customer data 中相同的Connection有多条记录的，结果只需要抓一条。
    df = pd.read_excel(report_path, sheet_name='Customer',
                       usecols=['CUSTOMER_CATEGORY', 'Connection UEN']
                       , skiprows=None, engine="openpyxl", dtype={'Connection UEN': str})
    master_list_df = df[query_cond]
    connection_uen_df = master_list_df.groupby(['Connection UEN'], as_index=False)['Connection UEN'].agg(
        {'cnt': 'count'})

    connection_uen_df['Is connection UEN'] = 'Y'
    connection_uen_df.rename(columns={'Connection UEN': 'UEN'}, inplace=True)
    connection_uen_df['UEN'] = connection_uen_df['UEN'].astype('object')

    result_df = connection_uen_df.append(uen_df)

    # 需求3： 从需求1和需求2中取到的UEN有重复的，保留connection UEN,也就是保留Is connection UEN为Y的 connection UEN
    result_df = result_df.drop_duplicates(subset=['UEN'], keep='first')

    return result_df


def filter_data_g14_group_cust(report_path):
    """
    从<Group Cust> sheet 非同业集团客户风险暴露 ，Non Interbank group customer
    :param report_path: 读取的g14报表
    :return:
    """

    pd.set_option('display.max_columns', 50)  # 设置显示的最大列数参数为a
    pd.set_option('display.max_rows', 10000)  # 设置显示的最大的行数参数为b
    pd.set_option('display.width', 2000)

    df = pd.read_excel(report_path, sheet_name='Customer',
                       usecols=['CUSTOMER_CATEGORY', 'UEN', 'GROUP_CODE', 'Connection UEN',
                                'GROUP_CHINESE_NAME', 'UNIFORM_SOCIAL_CREDIT_CODE']
                       , skiprows=None, engine="openpyxl", dtype={'UEN': str, 'GROUP_CODE': str})
    # Customer Category 取值 CORPORATE or GOV
    query_cond = (df['CUSTOMER_CATEGORY'] == 'CORPORATE') | (df['CUSTOMER_CATEGORY'] == 'GOV')
    customers_df = df[query_cond]

    group_df = customers_df.drop_duplicates(subset='GROUP_CODE')[
        ['GROUP_CODE', 'GROUP_CHINESE_NAME', 'UNIFORM_SOCIAL_CREDIT_CODE']].dropna(how='all')

    return group_df


def filter_data_g14_single_interbank(report_path):
    """
    从<Customer> sheet 获取 同业单一客户(Interbank single customer)
    :param report_path: 读取的g14报表
    :return:
    """

    df = pd.read_excel(report_path, sheet_name='Customer',
                       usecols=['CUSTOMER_CATEGORY', 'UEN']
                       , skiprows=None, engine="openpyxl", dtype={'UEN': str})
    query_cond = (df['CUSTOMER_CATEGORY'] == 'BANK') | (df['CUSTOMER_CATEGORY'] == 'NBFI') | (
            df['CUSTOMER_CATEGORY'] == 'QCCP')
    customer_list_df = df[query_cond]
    uen_df = customer_list_df.groupby(['UEN'], as_index=False)['UEN'].agg({'cnt': 'count'})
    return uen_df


def filter_data_g14_group_interbank(report_path):
    """
    从<Customer> sheet 获取 同业集团客户 ，Interbank group customer
    :param report_path: 读取的g14报表
    :return:
    """
    df = pd.read_excel(report_path, sheet_name='Customer',
                       usecols=['CUSTOMER_CATEGORY', 'Connection UEN']
                       , skiprows=None, engine="openpyxl", dtype={'Connection UEN': str})
    query_cond1 = (df['CUSTOMER_CATEGORY'] == 'BANK') | (df['CUSTOMER_CATEGORY'] == 'NBFI') | (
            df['CUSTOMER_CATEGORY'] == 'QCCP')
    query_cond2 = df['Connection UEN'].notnull()

    log.debug("type(df['Connection UEN'][0])=%s", type(df['Connection UEN'][0]))

    customers_df = df[query_cond1 & query_cond2]
    group_df = customers_df.groupby(['Connection UEN'], as_index=False)['Connection UEN'].agg({'cnt': 'count'})
    return group_df


class CalG14CustomerData(object):
    __concat_df = None
    __df = None
    __report_path = None

    pd.set_option('display.max_columns', 50)  # 设置显示的最大列数参数为a
    pd.set_option('display.max_rows', 10000)  # 设置显示的最大的行数参数为b
    pd.set_option('display.width', 2000)

    def __init__(self, report_path):
        """
        :param report_path: 报表地址
        """
        self.__report_path = report_path
        self.__df = pd.read_excel(report_path, sheet_name='Customer',
                                  usecols=['UEN', 'CBS_ID', 'CUSTOMER_CATEGORY', 'NATIONALITY', 'EXPOSURE_COUNTRY',
                                           'GROUP_CODE', 'Connection UEN']
                                  , skiprows=None, engine="openpyxl", dtype={'UEN': str, 'CBS_ID': str})

        self.__cal_foreign_bank_branch()
        self.__cal_g14_group_ind()

    def __cal_foreign_bank_branch(self):
        """
        计算 外国银行分行?(Y/N)
        """

        """
        3. 同一个UEN，如果全部CBS ID都是境外银行，即全部CBS ID的 Nationality都不是CN, 则仍按一个UEN为一个单一同业客户报送。
        同一个UEN 对应的所有CBS ID 的该项为N.              
        """
        grouped_df = self.__df.groupby('UEN')

        df_dict = {}
        for name, group in grouped_df:
            count_cn_num = 0

            for _, row in group.iterrows():
                nationality = row['NATIONALITY']
                cbs_id = row['CBS_ID']

                if nationality == 'CN':
                    count_cn_num = count_cn_num + 1

            if count_cn_num == 0:
                df_dict[name] = 'N'
            else:
                df_dict[name] = ''

        """
        2. 同一个UEN，只要有一个CBS ID是法人化的，即CBS ID的Nationality为 CN，并且EXPOSURE COUNTRY为 CN， 则仍按一个UEN为一个单一同业客户报送。同一个UEN 对应的所有CBS ID 的该项为N.
        """
        for name, group in grouped_df:
            flag = False
            for _, row in group.iterrows():

                nationality = row['NATIONALITY']
                exposure_country = row['EXPOSURE_COUNTRY']

                if nationality == 'CN' and exposure_country == 'CN' and df_dict[name] != 'N':
                    flag = True
                    break

            if flag:
                df_dict[name] = 'N'

        group_customer_df = self.__df.groupby(['UEN'], as_index=False)['UEN'].agg({'cnt': 'count'})
        self.__concat_df = self.__df.merge(group_customer_df, how='left', on='UEN')

        is_foreign_bank_branch_ls = []
        for _, row in self.__concat_df.iterrows():
            is_foreign_bank_branch = ''
            customer_category = row['CUSTOMER_CATEGORY']

            if customer_category != 'BANK' and customer_category != 'NBFI' and customer_category != 'QCCP':
                """
                5. CUSTOMER_CATEGORY不是 BANK 或 NBFI 或 QCCP 的，该项为空。
                """
                is_foreign_bank_branch = ''
                is_foreign_bank_branch_ls.append(is_foreign_bank_branch)

            else:
                count = row['cnt']
                is_uen_duplicate = None

                if pd.isna(count):
                    is_uen_duplicate = 'N'
                elif count > 1:
                    is_uen_duplicate = 'Y'
                else:
                    is_uen_duplicate = 'N'

                if is_uen_duplicate == 'N':
                    """
                    4.当Is UEN Duplicate? 值为N的，该项为空。
                    """
                    is_foreign_bank_branch = ''
                    is_foreign_bank_branch_ls.append(is_foreign_bank_branch)
                elif is_uen_duplicate == 'Y':
                    uen = row['UEN']
                    cbs_id = row['CBS_ID']

                    if df_dict[uen] != '':
                        is_foreign_bank_branch = df_dict[uen]
                        is_foreign_bank_branch_ls.append(is_foreign_bank_branch)
                    else:
                        """
                        1. 当Is UEN Duplicate? 值为Y，并且CUSTOMER_CATEGORY是 BANK 或 NBFI 或 QCCP 的
                        .非法人化的筛选条件为：在CBS中判断客户的nationality为CN，但是EXPOSURE COUNTRY为非CN。这些同属一个UEN的CBS ID会分别按照一个CBS ID为一个 单一同业客户报送。该项值为Y.
                        """
                        customer_category = row['CUSTOMER_CATEGORY']
                        exposure_country = row['EXPOSURE_COUNTRY']
                        nationality = row['NATIONALITY']

                        is_foreign_bank_branch = 'Y'
                        is_foreign_bank_branch_ls.append(is_foreign_bank_branch)

        self.__concat_df['IS_FORIEGN_BANK_BRANCH'] = pd.Series(is_foreign_bank_branch_ls, dtype='object')

    def __cal_g14_group_ind(self):
        """
        计算 g14_group_ind
        """

        g14_group_ind_ls = []
        # 计算 G14 group ind
        for _, row in self.__concat_df.iterrows():
            customer_category = row['CUSTOMER_CATEGORY']
            group_code = row['GROUP_CODE']

            if (customer_category == "CORPORATE" or customer_category == "GOV") and not pd.isna(group_code):
                """
                1.CUSTOMER_CATEGORY是CORPORATE或GOV，并且 CBS Group有值，标记“Y”；
                """
                g14_group_ind_ls.append("Y")
            elif (customer_category == "CORPORATE" or customer_category == "GOV") and pd.isna(group_code):
                """
                2. CUSTOMER_CATEGORY是CORPORATE或GOV，并且CBS Group为空，标记“N”
                """
                g14_group_ind_ls.append("N")
            elif customer_category == 'BANK' or customer_category == 'NBFI' or customer_category == 'QCCP':
                """
                3.CUSTOMER_CATEGORY是BANK或NBFI或QCCP的，
                """
                is_foreign_bank_branch = row['IS_FORIEGN_BANK_BRANCH']
                connection_uen = row['Connection UEN']

                if pd.isna(connection_uen) and is_foreign_bank_branch == 'N':
                    """
                    a.如果Connection UEN为空并且"外国银行分行？（Y/N)"值为N，该项值为N
                    """
                    g14_group_ind_ls.append("N")
                elif pd.isna(connection_uen) and is_foreign_bank_branch == 'Y':
                    """
                    b.如果Connection UEN为空并且"外国银行分行？（Y/N)"值为Y，该项值为Y
                    """
                    g14_group_ind_ls.append("Y")
                elif not pd.isna(connection_uen):
                    """
                    c.Connection UEN有值，该项标记“Y”。
                    """
                    g14_group_ind_ls.append("Y")
                elif pd.isna(connection_uen) and is_foreign_bank_branch == '':
                    """
                    d 如果Connection UEN为空，并且"外国银行分行？（Y/N)"值为空， G14 group ind值为N
                    """
                    g14_group_ind_ls.append("N")
            else:
                g14_group_ind_ls.append("")

        self.__concat_df['G14_GROUP_IND'] = pd.Series(g14_group_ind_ls, dtype='object')

    def get_foreign_bank_branch(self, cbs_id):
        for _, row in self.__concat_df.iterrows():
            row_cbs_id = row['CBS_ID']

            if cbs_id == row_cbs_id:
                return row['IS_FORIEGN_BANK_BRANCH']

    def get_g14_group_ind(self, cbs_id):
        for _, row in self.__concat_df.iterrows():
            row_cbs_id = row['CBS_ID']
            if cbs_id == str(row_cbs_id).strip():
                return row['G14_GROUP_IND']

    def get_customer_df(self):
        return self.__concat_df

    def filter_data_g14_single_interbank(self):
        """
        从<Customer> sheet 获取 同业单一客户(Interbank single customer)
        :param report_path: 读取的g14报表

        UEN: 当这个UEN 在master list 中“外国银行分行？（Y/N)”列的值为Y时，抓取该UEN 对应的全部CBS ID ，一个CBS ID 为一个记录。
        CBS ID: "外国银行分行？（Y/N)”列值为Y时，UEN 对应的CBS ID。 "外国银行分行？（Y/N)”列值为N或空时，该项留空
        :return:
        """

        customer_df = self.get_customer_df()

        """
        1)选出LRE Customer Data 中CUSTOMER_CATEGORY是 BANK 或 NBFI 或 QCCP 的UEN。
        """
        query_cond = (customer_df['CUSTOMER_CATEGORY'] == 'BANK') | (customer_df['CUSTOMER_CATEGORY'] == 'NBFI') | (
                    customer_df['CUSTOMER_CATEGORY'] == 'QCCP')
        customer_df = customer_df[query_cond]

        # 外国银行分行为 Y 的 customer_df
        query_cond = customer_df['IS_FORIEGN_BANK_BRANCH'] == 'Y'
        customer_y_df = customer_df[query_cond]

        # 外国银行分行为 N 或 空 的 customer_df
        query_cond = customer_df['IS_FORIEGN_BANK_BRANCH'] != 'Y'
        customer_n_df = customer_df[query_cond]
        # df 去重
        customer_n_df.drop_duplicates(subset=['UEN'], keep='first', inplace=True)
        # 拼接两个dataframe
        join_customer_df = pd.concat([customer_y_df, customer_n_df], axis=0)

        join_customer_df = join_customer_df.reset_index()
        single_interbank_cbs_id_ls = []
        for _, row in join_customer_df.iterrows():
            is_foreign_bank_branch = row['IS_FORIEGN_BANK_BRANCH']
            if is_foreign_bank_branch == 'Y':
                single_interbank_cbs_id_ls.append(row['CBS_ID'])

            else:
                single_interbank_cbs_id_ls.append('')

        join_customer_df['SHOW_CBS_ID'] = pd.Series(single_interbank_cbs_id_ls, dtype='object')

        return join_customer_df

    def filter_data_g14_group_interbank(self):
        """
        从<Customer> sheet 获取 同业集团客户 ，Interbank group customer
        :param report_path: 读取的g14报表
        :return:
        """

        """
        1. 选出LRE Customer Data 中CUSTOMER_CATEGORY是BANK或NBFI或QCCP的Connection UEN。
        如果Connection UEN只对应一个UEN，则排除不取这个connection UEN.
        """
        df = pd.read_excel(self.__report_path, sheet_name='Customer',
                           usecols=['CUSTOMER_CATEGORY', 'Connection UEN']
                           , skiprows=None, engine="openpyxl", dtype={'Connection UEN': str})
        query_cond1 = (df['CUSTOMER_CATEGORY'] == 'BANK') | (df['CUSTOMER_CATEGORY'] == 'NBFI') | (
                df['CUSTOMER_CATEGORY'] == 'QCCP')
        query_cond2 = df['Connection UEN'].notnull()

        customers_df = df[query_cond1 & query_cond2]
        group_df = customers_df.groupby(['Connection UEN'], as_index=False)['Connection UEN'].agg({'cnt': 'count'})

        connect_uen_or_uen_ls = []
        is_connection_uen_ls = []
        for _, row in group_df.iterrows():
            connection_uen = row['Connection UEN']
            connect_uen_or_uen_ls.append(connection_uen)
            is_connection_uen_ls.append('Y')

        """
        2. 取master list 中“外国银行分行？（Y/N)”值为Y 的UEN. 如果该UEN对应的connection UEN已在第一部分，则排除不取这个UEN。
        Connection UEN为空，外国银行分行为 Y，读取 UEN
        """
        customer_df = self.get_customer_df()

        for _, row in customer_df.iterrows():
            connection_uen = row['Connection UEN']
            uen = row['UEN']
            is_foreign_bank_branch = row['IS_FORIEGN_BANK_BRANCH']

            if pd.isna(connection_uen) and is_foreign_bank_branch == 'Y':
                # group interbank 取外国分行UEN的，要去重
                if uen not in connect_uen_or_uen_ls:
                    connect_uen_or_uen_ls.append(uen)
                    is_connection_uen_ls.append('N')

        data = {'Connection UEN/UEN': pd.Series(connect_uen_or_uen_ls),
                'Is connection UEN?': pd.Series(is_connection_uen_ls)}
        df = pd.DataFrame(data)

        return df

    def filter_data_lre(self):
        customer_df = self.get_customer_df()
        # G14 group ind 为Y， 不要取到LRE 表
        query_cond = customer_df['G14_GROUP_IND'] == 'N'
        customer_n_df = customer_df[query_cond]
        # G14 group ind 为N的UEN取到LRE表时要去重
        customer_n_df.drop_duplicates(subset=['UEN'], keep='first', inplace=True)
        customer_n_df = customer_n_df.reset_index()

        return customer_n_df

