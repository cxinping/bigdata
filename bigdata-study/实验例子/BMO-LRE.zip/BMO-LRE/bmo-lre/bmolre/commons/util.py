# -*- coding: utf-8 -*-

"""
Created on 2020-11-06

@author: Wang Shuo
"""

import os
import re
from base64 import b64encode, b64decode
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad


from bmolre.exts import db
import bmolre.commons.constant as constant

from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP

from bmolre.commons.logging import get_logger

from bmolre.exceptions import DataException

# The Initialization Vector for AES CBC mode. It is as long as the block size (e.g. 16 bytes for AES). This is not put into configuration to mitigate the risk of exposing all required information for encryption in the config files.
AES_IV = b"BMO's silver iv "

log = get_logger(__name__)

def get_current_time():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def is_blank(val):
    return not (val and val.strip())

def convert_digital_precision(val, precision=2):
    """ 保留小数点以后precision位 """

    decimal = '0.'
    for _ in range(precision):
        decimal += '0'

    if val is None:
        val = 0

    return Decimal(val).quantize(Decimal(decimal), rounding=ROUND_HALF_UP)


def db_fetch_to_dict(sql, params={}, fecth='all', bind=None):
    """
    dict的方式返回数据
    :param sql: select * from xxx where name=:name
    :param params:{'name':'zhangsan'}
    :param fecth:默认返回全部数据，返回格式为[{},{}],如果fecth='one',返回单条数据，格式为dict
    :param bind:连接的数据，默认取配置的SQLALCHEMY_DATABASE_URL，
    :return:
    """
    try:
        result_proxy = db.session.execute(sql, params, bind=db.get_engine(bind=bind))
        result = None
        if fecth == 'one':
            result_tuple = result_proxy.fetchone()
            if result_tuple:
                result = dict(zip(result_proxy.keys(), list(result_tuple)))
        else:
            result_tuple_list = result_proxy.fetchall()
            if result_tuple_list:
                result = []
                keys = result_proxy.keys()
                for row in result_tuple_list:
                    result_row = dict(zip(keys, row))
                    result.append(result_row)

        return result
    except Exception as err:
        raise DataException(err)
    finally:
        db.session.close()

def encrypt(plaintext):
    '''
    Use AES CBC mode to encrypt the plaintext. AES-128, AES-192 or AES-256 depends on the length of the key.
    '''

    pt_bytes = plaintext.encode('utf-8')
    ct = None
    
    if constant.CFG_AES_KEY in os.environ:
        cipher = AES.new(os.environ[constant.CFG_AES_KEY].encode('utf-8'), AES.MODE_CBC, AES_IV)
        ct_bytes = cipher.encrypt(pad(pt_bytes, AES.block_size))
        ct = b64encode(ct_bytes).decode('utf-8')
    else:
        log.warning('AES key can not be found, plaintext will be encoded by Base64 only.')
        ct = b64encode(pt_bytes).decode('utf-8')
    
    return ct

def decrypt(ciphertext):
    '''
    Use AES CBC mode to decrypt the plaintext. AES-128, AES-192 or AES-256 depends on the length of the key.
    '''
    
    ct_bytes = b64decode(ciphertext)
    pt = None
    
    if constant.CFG_AES_KEY in os.environ:
        cipher = AES.new(os.environ[constant.CFG_AES_KEY].encode('utf-8'), AES.MODE_CBC, AES_IV)
        pt_bytes = unpad(cipher.decrypt(ct_bytes), AES.block_size)
        pt = pt_bytes.decode('utf-8')
    else:
        log.warning('AES key can not be found, ciphertext will be decoded by Base64 only.')
        pt = ct_bytes.decode('utf-8')
        
    return pt

def decrypt_db_uri(db_uri):
    db_uri_pattern = r'^(\S+?://\S+?:)(.+?)(@\S+?$)'
    
    m = re.search(db_uri_pattern, db_uri)
    encrypted_db_pass = m.group(2)
    decrypted_db_pass = decrypt(encrypted_db_pass)
    
    decrypted_db_uri = re.sub(db_uri_pattern, r'\g<1>' + decrypted_db_pass + r'\g<3>', db_uri)
    
    return decrypted_db_uri
    
