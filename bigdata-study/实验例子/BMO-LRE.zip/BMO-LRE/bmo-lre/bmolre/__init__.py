# -*- coding: utf-8 -*-

'''
Created on 2020-10-28

@author: WangShuo
'''

import os
import logging as python_logging
from flask import Flask, jsonify
from http import HTTPStatus
from .views.user import users_bp
from .views.test import test_bp
from .views.report import report_bp
from .views.encryption import encryption
from .services.report_task_services import TaskExecutor
from bmolre.commons.constant import CFG_DEBUG, CFG_AES_KEY, CFG_REPORT_DB_URL, CFG_SQLALCHEMY_BINDS, CFG_MAIL_RECIPIENTS, CFG_MAIL_SENDER, CFG_SUPPORT_MAIL_RECIPIENTS, CFG_SUPPORT_MAIL_SENDER, CFG_SFTP_HOST, CFG_SFTP_PORT, CFG_SFTP_PRIVATE_PATH, CFG_SFTP_USER
from bmolre.exts import db, mail
from bmolre.commons.util import decrypt_db_uri
from ._version import __version__

WARN_MSG_MISSING_CONFIG = 'Config %s cannot be found.'

task_executor = TaskExecutor()

def create_app(config_object='config.default', config_map=None):
    # Create and configure the app
    app = Flask(__name__, instance_relative_config=True, instance_path='/opt/bmo-lre/config')

    # configure blue print
    app.register_blueprint(users_bp, url_prefix='/users')
    app.register_blueprint(test_bp, url_prefix='/test')
    app.register_blueprint(report_bp, url_prefix='/report')
    app.register_blueprint(encryption, url_prefix='/encryption')

    # Overwrite default config by input parameter
    app.config.from_object(config_object)

    if config_map is not None:
        # load the test config if passed in
        app.config.from_mapping(config_map)

    # Load the configuration from the instance folder which won't be committed to version control
    app.config.from_pyfile('config.py', silent=True)

    app.logger.debug('app.config=%s', app.config)
    
    # Put configurations into os environment
    if CFG_DEBUG in app.config:
        os.environ[CFG_DEBUG] = str(app.config[CFG_DEBUG])
    else:
        app.logger.warning(WARN_MSG_MISSING_CONFIG, CFG_DEBUG)

    if CFG_AES_KEY in app.config:
        os.environ[CFG_AES_KEY] = str(app.config[CFG_AES_KEY])
    else:
        app.logger.warning(WARN_MSG_MISSING_CONFIG, CFG_AES_KEY)

    # Resolve the encryption in configurations
    if CFG_SQLALCHEMY_BINDS in app.config:
        for key in app.config[CFG_SQLALCHEMY_BINDS]:
            app.config[CFG_SQLALCHEMY_BINDS][key] = decrypt_db_uri(app.config[CFG_SQLALCHEMY_BINDS][key])
    else:
        app.logger.warning(WARN_MSG_MISSING_CONFIG, CFG_SQLALCHEMY_BINDS)
    
    # * Put lre report db url into os environment fore reference by Pandas, etc.
    if CFG_REPORT_DB_URL in app.config:
        app.config[CFG_REPORT_DB_URL] = decrypt_db_uri(app.config[CFG_REPORT_DB_URL])
        os.environ[CFG_REPORT_DB_URL] = str(app.config[CFG_REPORT_DB_URL])
    else:
        app.logger.warning(WARN_MSG_MISSING_CONFIG, CFG_REPORT_DB_URL)

    # Create logger after app initiated to avoid recursive dependency
    app.logger.debug('os.environ=%s', os.environ)

    # a simple page that says hello
    @app.route('/hello')
    def hello():
        result = {'lre_service_status': HTTPStatus.OK}
        result['sftp_status'] = get_sftp_status(app)
        result['rra_db_status'] = get_rra_db_status(app, db)
        #result['lre_db_status'] = get_lre_db_status(app, db)
        result['version'] = __version__

        #TODO: test email server connection
        
        status = HTTPStatus.INTERNAL_SERVER_ERROR if HTTPStatus.INTERNAL_SERVER_ERROR in result.values() else HTTPStatus.OK
        
        return jsonify(result), status

    return app

def init_app(config_object='config.default'):
    app = create_app(config_object)
    db.init_app(app)
    mail.init_app(app)
    return app

def get_sftp_status(app):
    host = None
    port = None
    username = None
    private_key_path = None

    if CFG_SFTP_HOST in app.config:
        host = app.config[CFG_SFTP_HOST]
    if CFG_SFTP_PORT in app.config:
        port = app.config[CFG_SFTP_PORT]
    if CFG_SFTP_USER in app.config:
        username = app.config[CFG_SFTP_USER]
    if CFG_SFTP_PRIVATE_PATH in app.config:
        private_key_path = app.config[CFG_SFTP_PRIVATE_PATH]

    sftp_status = HTTPStatus.INTERNAL_SERVER_ERROR
    try:
        dirs = task_executor.sftp_listdir(host=host, port=port, username=username, private_key_path=private_key_path)
        app.logger.debug('dirs=%s', dirs)
        if dirs is not None:
            sftp_status = HTTPStatus.OK
    except Exception as err:
        app.logger.error(err, exc_info=True)
        
    return sftp_status

def get_rra_db_status(app, db):
    
    rra_db_status = HTTPStatus.INTERNAL_SERVER_ERROR
    try:
        result_proxy = db.session.execute('SELECT 1 FROM DUAL', bind=db.get_engine(bind='rra'))
        if result_proxy is not None:
            rra_db_status = HTTPStatus.OK
    except Exception as err:
        app.logger.error(err, exc_info=True)
    finally:
        db.session.close()
    return rra_db_status

def get_lre_db_status(app, db):
    
    lre_db_status = HTTPStatus.INTERNAL_SERVER_ERROR
    try:
        result_proxy = db.session.execute('SELECT 1')
        if result_proxy is not None:
            lre_db_status = HTTPStatus.OK
    except Exception as err:
        app.logger.error(err, exc_info=True)
    finally:
        db.session.close()
    return lre_db_status