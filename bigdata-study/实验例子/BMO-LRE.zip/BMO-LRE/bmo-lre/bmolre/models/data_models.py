# -*- coding: utf-8 -*-

"""
Created on 2020-11-13

@author: Wang Shuo
"""

from bmolre.commons.util import db_fetch_to_dict
from bmolre.commons.logging import get_logger

log = get_logger(__name__)


def query_safe_mid_rate_data(data_date, basic_ccy='USD', forward_ccy='CNY'):
    """ 查询USD到CNY的货币汇率 rate
    :param data_date : 查询时间
    :param basic_ccy :
    :param forward_ccy :
    :return: 查询USD到CNY的货币汇率的列表
    """

    query_sql = '''
    SELECT * FROM RRA_GBDS.GBDS_EX_RATE WHERE :data_date between S_DATE  and e_date AND RATE_TYPE ='SAFE_MID'
        AND BASIC_CCY = :basic_ccy AND FORWARD_CCY = :forward_ccy
    '''
    return db_fetch_to_dict(query_sql,
                            params={'data_date': data_date, 'basic_ccy': basic_ccy, 'forward_ccy': forward_ccy},
                            fecth='one', bind='rra')


def change_foreign_currency_to_cny(date_date, foreign_ccy, amount):
    """ 转换外币到人民币，先把外币转换成美元，在把美元转换成人民币
    :param date_date : 查询时间
    :param foreign_ccy :
    :param amount :
    :return: 查询USD到CNY的货币汇率的列表
    """
    query_sql = """
      SELECT  RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV({date_date},
                                          'USD',
                                          'CNY',
                                          RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV({date_date},
                                                                      '{foreign_ccy}',
                                                                      'USD',
                                                                      {amount},
                                                                      'STAND'),
                                          'SAFE_MID')
           END
      FROM dual
    """.format(date_date=date_date, foreign_ccy=foreign_ccy, amount=amount)

    return db_fetch_to_dict(query_sql, params=None,
                            fecth='one', bind='rra')


def query_rate_currency(data_date):
    """ 查询要转换的货币币种
    :param data_date : 查询时间
    """

    query_sql = """
    select distinct ccy
      from (select BASIC_CCY CCY
              from RRA_GBDS.GBDS_EX_RATE
             where {date_date} between s_date and e_date
               and RATE_TYPE = 'STAND'
            union all
            select FORWARD_CCY CCY
              from RRA_GBDS.GBDS_EX_RATE
             where {date_date} between s_date and e_date
               and RATE_TYPE = 'STAND')
    """.format(date_date=data_date)

    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_loan_data(data_date):
    query_sql = """
  SELECT CBS_CUST_ID,
       AMT_FOR_TB_RECONCIL AS AMOUNT,
       CURRENCY,
       INTEREST_RECEIVED_TO_GL,
       STATUS,
       OUR_REF,
       DATA_DATE
  FROM RRA_SIDS.S_FLC_LOAN_DETAILS
 WHERE LOWER(STATUS) != 'expired'
   AND FINISHED IS NULL
   AND DATA_DATE = :data_date   
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_daily_auto_fin_data(data_date):
    """
    查询 daily的Auto Fin 数据
    :param data_date: 取数日期
    """
    query_sql = """
      SELECT CBS_CUST_ID,
       AMT_FOR_TB_RECONCIL AS AMOUNT,
       CURRENCY,
       INTEREST_RECEIVED_TO_GL,
       STATUS,
       OUR_REF,
       DATA_DATE
  FROM RRA_SIDS.S_MAN_LOAN_DETAILS
 WHERE lower(status) != 'expired'
   AND finished is null
   and loan_type = 'Auto Finance'
   AND data_date = (select MAX(data_date)
                      from RRA_SIDS.S_MAN_LOAN_DETAILS
                     WHERE lower(status) != 'expired'
                       AND finished is null
                       and loan_type = 'Auto Finance'
                       and data_date <= :data_date)  
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_g14_auto_fin_data(data_date):
    """
    查询 g14的Auto Fin 数据
    :param data_date: 取数日期
    """
    query_sql = """
        SELECT CBS_CUST_ID,
       AMT_FOR_TB_RECONCIL AS AMOUNT,
       CURRENCY,
       INTEREST_RECEIVED_TO_GL,
       STATUS,
       OUR_REF,
       DATA_DATE 
       
  FROM RRA_SIDS.S_MAN_LOAN_DETAILS
 WHERE lower(status) != 'expired'
   AND finished is null
   and loan_type = 'Auto Finance'
   and PRINC_VALUE_DATE<=:data_date
   AND data_date = (select MAX(data_date)
                      from RRA_SIDS.S_MAN_LOAN_DETAILS
                     WHERE lower(status) != 'expired'
                       AND finished is null
                       and loan_type = 'Auto Finance'
                       and data_date <= to_CHAR(TO_DATE(:data_date,'YYYYMMDD')+15,'YYYYMMDD'))
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_customer_list_report(data_date):
    """
    At BMOS008_sql.sql
    4.1.2.3.1 Extract BMO Customer to LRE Calculation
    In the working file, BMO Customer data use RRA BMOS0008 customer list report as data source.
    Select customer with Status = O in BMOS0008.
    :param data_date: 取数日期
    """
    query_sql = """            
    with Table_1 as
 (SELECT T1.DATA_DATE DATA_DATE, --25 DATA_DATE
         T1.LOCAL_BRANCH, --1.LOCAL_BRANCH
         T1.CUSTOMER_NO CBS_ID, --2.CBS_ID
         LPAD(TRIM(T2.FIELD_VAL_52), 10, '0') CIF_ID, --CIF_ID
         T3.IBUK_ID WSS_ID, --3.WSS_ID
         T3.PIX_ID, --4.PIX_ID
         T2.FIELD_VAL_39 OTL_ID, --6.OTL_ID
         NVL(T1.CHINESE_NAME, T1.CUSTOMER_NAME1) CUSTOMER_NAME_CN, --8.CUSTOMER_NAME_CN
         DECODE(LENGTH(T2.FIELD_VAL_16), 18, T2.FIELD_VAL_16, null) UNIFORM_SOCIAL_CREDIT_CODE1, --7 UNIFORM_SOCIAL_CREDIT_CODE --=If Length([UNIFORM_SOCIAL_CREDIT_CODE1])=18 Then [UNIFORM_SOCIAL_CREDIT_CODE1] Else Max([UNIFORM_SOCIAL_CREDIT_CODE2])
         T1.CUSTOMER_NAME1 CUSTOMER_NAME_EN, --9.CUSTOMER_NAME_EN
         T1.CUSTOMER_CATEGORY, --10.CUSTOMER_CATEGORY
         T1.NATIONALITY, --11.NATIONALITY
         T1.COUNTRY, --12.COUNTRY
         T1.EXPOSURE_COUNTRY, --13.EXPOSURE_COUNTRY
         T2.FIELD_VAL_1 AREA, --14.AREA
         T2.FIELD_VAL_5 CORP_TYPE, --15.CORP_TYPE
         T2.FIELD_VAL_10 CORP_SIZE, --16.CORP_SIZE
         T2.FIELD_VAL_4 INDUSTRY_CODE, --17.INDUSTRY_CODE
         T2.FIELD_VAL_58 HOLDING_TYPE, --18.HOLDING_TYPE
         T1.UNIQUE_ID_VALUE UNIQUE_ID_VALUE, --19.UNIQUE_ID_VALUE
         T4.GROUP_ID GROUP_CODE, --20.GROUP_CODE
         T1.RECORD_STAT STATUS, --23.STATUS
         decode(T1.DATA_DATE, null, 'CMS', 'CMS')
    FROM RRA_SIDS.S_FLC_STTM_CUSTOMER T1
    left join RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T2
      ON T1.CUSTOMER_NO = SUBSTR(T2.REC_KEY(+), 1, 6)
     AND T1.DATA_DATE = T2.DATA_DATE
    left join RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
      ON T1.CUSTOMER_NO = T3.CBS_ID
     AND T1.DATA_DATE = T3.DATA_DATE
    left join RRA_SIDS.S_FLC_STTM_CUST_GROUP T4
      ON T1.CUSTOMER_NO = T4.CUSTOMER_NO
     AND T1.DATA_DATE = T4.DATA_DATE
   WHERE
   (((T1.RECORD_STAT IN ('C', 'O')
     AND T2.FUNCTION_ID = 'STDCIF'
     and T1.AUTH_STAT = 'A'
     AND T1.CUSTOMER_CATEGORY IN ('NBFI', 'BANK', 'CORPORATE')
     ) 
     OR T1.CUSTOMER_NO ='301230' )
     AND T1.DATA_DATE = :data_date)
     ),

Table_2 as
 (SELECT distinct CIF_NO    CIF_ID, --CIF_ID 与表1关联字段CIF_ID
                  UEN_NO    UEN, --5.UEN
                  DATA_DATE
    FROM RRA_SIDS.S_UEN_CHINA
   WHERE DATA_DATE = (select max(data_date)
                        from RRA_SIDS.S_UEN_CHINA
                       where data_date <= :data_date)
  UNION
  SELECT distinct CIF_NO, UEN_NO, DATA_DATE
    FROM RRA_SIDS.S_UEN_NA
   WHERE DATA_DATE = (select max(data_date)
                        from RRA_SIDS.S_UEN_NA
                       where data_date <= :data_date)
  
  UNION
  SELECT distinct LPAD(TRIM(CIF_NO), 10, 0) CIF_NO, PARENT_UEN, DATA_DATE
    FROM RRA_SIDS.S_UEN_BRANCH
   WHERE DATA_DATE = (select max(data_date)
                        from RRA_SIDS.S_UEN_BRANCH
                       where data_date <= :data_date)),
Table_3 as
 (
  
  SELECT distinct T1.GROUP_ID GROUP_CODE, --与表1关联字段
                   T2.GROUP_NAME GROUP_CHINESE_NAME, --22.GROUP_CHINESE_NAME
                   T1.DATA_DATE,
                   decode(T2.GROUP_NAME, null, null, null) GROUP_NAME
    FROM RRA_SIDS.S_FLC_STTM_CUST_GROUP T1
    left join RRA_SIDS.S_FLC_STTM_GROUP T2
      ON T1.GROUP_ID = T2.GROUP_ID
  
   WHERE T1.DATA_DATE = :data_date
     and T1.DATA_DATE = T2.DATA_DATE
  
  ),
table_4 as
 (SELECT distinct T1.DATA_DATE,
                  SUBSTR(T1.REC_KEY, 1, 6) REC_KEY, --  与表1关联字段CBS_ID
                  LPAD(TRIM(T1.FIELD_VAL_52), 10, '0') CIF_ID,
                  nvl(T2.RRA_CODE, '100000') FINA_CODE_Bank,
                  nvl(T3.RRA_CODE, '200000') FINA_CODE_NBFI,
                  T4.BUSINESS_LIC UNIFORM_SOCIAL_CREDIT_CODE2
    FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T1
    left join RRA_SIDS.MAP_S_G_CODE T2
      ON T1.FIELD_VAL_2 = T2.SOURCE_CODE
     and T2.TYPE_CODE = 'FINA_CODE'
     and T1.FUNCTION_ID = 'STDCIF'
    left join RRA_SIDS.MAP_S_G_CODE T3
      ON T1.FIELD_VAL_7 = T3.SOURCE_DESCRIPTION_CN
     and T3.TYPE_CODE = 'FINA_CODE'
    left join RRA_SIDS.S_CMCIF_CUST_INFO T4
      ON LPAD(TRIM(T1.FIELD_VAL_52), 10, '0') =
         LPAD(TRIM(T4.CIF_ID), 10, '0')
     and length(T4.BUSINESS_LIC) = 18
   WHERE T1.DATA_DATE = :data_date
     AND T4.DATA_DATE IN (SELECT max(DATA_DATE)
                            FROM RRA_SIDS.S_CMCIF_CUST_INFO
                           WHERE length(BUSINESS_LIC) = 18
                             AND DATA_DATE <= :data_date)
  
  ),
t_Connection_Info as
 (select CONNECTION_UEN, CONNECTION_NAME, uen
    from rra_sids.s_Man_Connection_Info
   where data_date = (select max(data_date)
                        from RRA_SIDS.S_MAN_CONNECTION_INFO
                       where data_date <= :data_date))

select LOCAL_BRANCH,
       CBS_ID,
       WSS_ID,
       PIX_ID,
       UEN,
       OTL_ID,
        CASE WHEN UPPER(CUSTOMER_CATEGORY)='BANK' AND UNIFORM_SOCIAL_CREDIT_CODE IS NULL THEN  UEN 
             when cbs_id ='009000' THEN '009000'
        ELSE  UNIFORM_SOCIAL_CREDIT_CODE END UNIFORM_SOCIAL_CREDIT_CODE,--LRE-242
       CUSTOMER_NAME_CN,
       CUSTOMER_NAME_EN,
       CUSTOMER_CATEGORY,
       NATIONALITY,
       COUNTRY,
       EXPOSURE_COUNTRY,
       AREA,
       CORP_TYPE,
       CORP_SIZE,
       INDUSTRY_CODE,
       HOLDING_TYPE,
       UNIQUE_ID_VALUE,
       case
         when count(1) over(partition by GROUP_CODE) = 1 then
          null
         else
          GROUP_CODE
       end GROUP_CODE,
       case
         when count(1) over(partition by GROUP_CODE) = 1 then
          null
         else
          GROUP_NAME
       end GROUP_NAME,
       case
         when count(1) over(partition by GROUP_CODE) = 1 then
          null
         else
          GROUP_CHINESE_NAME
       END GROUP_CHINESE_NAME,
       STATUS,
       DATA_DATE,
       CONNECTION_UEN,
       CONNECTION_NAME
  from (
        
        SELECT distinct A.LOCAL_BRANCH, --1
                         A.CBS_ID, --2
                         A.WSS_ID, --3
                         A.PIX_ID, --4
                         case when A.CBS_ID='301230' then 'B019' ELSE B.UEN END UEN, --5
                         A.OTL_ID, --6
                         CASE
                           WHEN LENGTH(A.UNIFORM_SOCIAL_CREDIT_CODE1) = 18 THEN
                            A.UNIFORM_SOCIAL_CREDIT_CODE1
                           ELSE
                            D.UNIFORM_SOCIAL_CREDIT_CODE2
                         END UNIFORM_SOCIAL_CREDIT_CODE, --7
                         A.CUSTOMER_NAME_CN, --8
                         A.CUSTOMER_NAME_EN, --9
                         case
                           when B.UEN IN ('239169', '7501') OR A.CBS_ID='301230' then
                            'GOV'
                           when B.UEN = '35049115' then
                            'QCCP'
                           else
                            A.CUSTOMER_CATEGORY
                         END CUSTOMER_CATEGORY, --10
                         A.NATIONALITY, --11
                         A.COUNTRY, --12
                         A.EXPOSURE_COUNTRY, --13
                         A.AREA, --14
                         A.CORP_TYPE, --15
                         A.CORP_SIZE, --16
                         A.INDUSTRY_CODE, --17
                         A.HOLDING_TYPE, --18
                         A.UNIQUE_ID_VALUE, --19
                         A.GROUP_CODE, --20
                         C.GROUP_NAME, --21
                         C.GROUP_CHINESE_NAME, --22
                         A.STATUS, --23
                         A.DATA_DATE,
                         e.CONNECTION_UEN,
                         e.CONNECTION_NAME
          FROM TABLE_1 A
          LEFT JOIN TABLE_2 B
            ON A.CIF_ID = B.CIF_ID
          LEFT JOIN TABLE_3 C
            ON A.GROUP_CODE = C.GROUP_CODE
          LEFT JOIN TABLE_4 D
            ON A.CBS_ID = D.REC_KEY
          left join t_Connection_Info E
            on B.uen = E.uen
         WHERE A.STATUS = 'O')
         order by cbs_id --LRE-242

    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_indirect_customer_from_trade_finance_transaction(data_date):
    """
    At 4.1.2.3.2.1-V1.sql
    4.1.2.3.2.1 Extract Indirect Customer Data to LRE Calculation - Limit Customer from Trade Finance Transaction and Issuer from Bond/NCD
    Limit Customer from Trade Finance Transaction
    Source: Limit customer of trade finance deal transaction.
    Reference : RRA report BMOS0018
    :param data_date: 取数日期
    
     At 4.1.2.3.2.2.sql
    4.1.2.3.2.2 Extract Indirect Customer Data to LRE Calculation - Issuer from Bond/NCD
    Issuer from Bond/NCD
    Source: RRA table s_gfi_cn_counterparty
    :param data_date: 取数日期
    """

    query_sql = """
      WITH TB_UEN AS
 (SELECT DISTINCT DATA_DATE, UEN_NO, CIF_NO, LEGAL_NAME, RISK_COUNTRY
    FROM (SELECT DATA_DATE, UEN_NO, CIF_NO, LEGAL_NAME, RISK_COUNTRY
            FROM RRA_SIDS.S_UEN_NA
           WHERE DATA_DATE IN (SELECT MAX(DATA_DATE)
                                 FROM RRA_SIDS.S_UEN_NA
                                WHERE DATA_DATE <= :data_date)
          UNION ALL
          SELECT DATA_DATE, UEN_NO, CIF_NO, LEGAL_NAME, RISK_COUNTRY
            FROM RRA_SIDS.S_UEN_CHINA
           WHERE DATA_DATE IN (SELECT MAX(DATA_DATE)
                                 FROM RRA_SIDS.S_UEN_CHINA
                                WHERE DATA_DATE <= :data_date)) UEN
  
   WHERE NOT EXISTS (select 1 from (select LPAD(TRIM(T2.FIELD_VAL_52), 10, '0') as CIF_NO 
            from RRA_SIDS.S_FLC_STTM_CUSTOMER T1
            left join RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T2
              ON T1.CUSTOMER_NO = SUBSTR(T2.REC_KEY(+), 1, 6)
             AND T1.DATA_DATE = T2.DATA_DATE
           WHERE T1.DATA_DATE = :data_date
             and T1.RECORD_STAT IN ('O')
             AND T2.FUNCTION_ID = 'STDCIF'
             and T1.AUTH_STAT = 'A'
             AND T1.CUSTOMER_CATEGORY IN ('NBFI', 'BANK', 'CORPORATE') ) T0
             where   UEN.CIF_NO =T0.CIF_NO )
     AND UEN.UEN_NO IS NOT NULL),
t_Connection_Info as
 (select CONNECTION_UEN, CONNECTION_NAME, uen
    from rra_sids.s_Man_Connection_Info
   where data_date = (select max(data_date)
                        from RRA_SIDS.S_MAN_CONNECTION_INFO
                       where data_date <= :data_date)),

t_CIF_CUST_INFO as
 (select CIF_NO, data_date, CUSTOMER_STATUS
    from (select uen.CIF_NO,
                 info.data_date,
                 CUSTOMER_STATUS,
                 row_number() over(partition by uen.CIF_NO order by info.data_date desc) RN
            from TB_UEN uen
           inner join rra_sids.S_CMCIF_CUST_INFO info
              on uen.CIF_NO = LPAD(TRIM(info.cif_id), 10, '0'))
   where rn = 1)

select data_date,
       cbs_id,
       UEN,
       OTL_ID,
       NVL(CUSTOMER_NAME_CN,CUSTOMER_NAME_EN) CUSTOMER_NAME_CN,
       CUSTOMER_NAME_EN,
       CUSTOMER_CATEGORY,
       NATIONALITY,
       COUNTRY,
       EXPOSURE_COUNTRY,
       GROUP_CODE,
       GROUP_NAME,
       UNIFORM_SOCIAL_CREDIT_CODE,
       UNIQUE_ID_VALUE,
       CONNECTION_UEN,
       CONNECTION_NAME
  from (select data_date,
               CUSTOMER_CATEGORY || '_' || UEN as CBS_ID,
               UEN,
               OTL_ID,
               CUSTOMER_NAME_CN,
               CUSTOMER_NAME_EN,
               CUSTOMER_CATEGORY,
               NATIONALITY,
               COUNTRY,
               EXPOSURE_COUNTRY,
               GROUP_CODE,
               GROUP_NAME,
               UNIFORM_SOCIAL_CREDIT_CODE,
               UNIQUE_ID_VALUE,
               CONNECTION_UEN,
               CONNECTION_NAME,
               row_number() over(partition by UEN order by NVL(VALUE_DATE, 0) desc) RN
          from (
                
                --4.1.2.3.2.1
                SELECT  T1.data_date,NULL CBS_ID,
                        T1.UEN_NO UEN,
                        T3.LIMIT_CUSTOMER_ID OTL_ID,
                        NULL CUSTOMER_NAME_CN,
                        T1.LEGAL_NAME CUSTOMER_NAME_EN,
                        case
                          when upper(cust_info.CUSTOMER_TYPE) = 'FI' then
                           'BANK'
                          when upper(cust_info.CUSTOMER_TYPE) = 'NBFI' then
                           'NBFI'
                          when upper(cust_info.CUSTOMER_TYPE) = 'CORPORATE' then
                           'CORPORATE'
                          else
                           'BANK'
                        end CUSTOMER_CATEGORY,
                        NULL NATIONALITY,
                        NULL COUNTRY,
                        T1.RISK_COUNTRY EXPOSURE_COUNTRY,
                        NULL GROUP_CODE,
                        NULL GROUP_NAME,
                        T1.UEN_NO UNIFORM_SOCIAL_CREDIT_CODE,
                        NULL UNIQUE_ID_VALUE,
                        T4.CONNECTION_UEN,
                        T4.CONNECTION_NAME,
                        TO_char(PRINCIPAL_VALUE_DATE, 'YYYYMMDD') VALUE_DATE
                  FROM TB_UEN T1
                  left join rra_sids.S_CMCIF_CUST_INFO cust_info
                    on T1.CIF_NO = LPAD(TRIM(cust_info.cif_id), 10, '0')
                   and cust_info.data_date = :data_date
                  LEFT JOIN RRA_INX.REP_ME_DISCOUNT_DB T2
                    ON T2.RISKPARTY_UEN = T1.UEN_NO
                   AND T2.REPORT_DATE = :data_date
                   and T2.Status is null
                  LEFT JOIN RRA_SIDS.S_PIX_CNPAYUS T3
                    ON T2.OUR_REF = T3.INSTRUMENT_ID
                   AND T3.DATA_DATE = :data_date
                  LEFT JOIN t_Connection_Info T4
                    ON T1.UEN_NO = T4.UEN
                 where NOT exists (select 1
                          from t_CIF_CUST_INFO info
                         where T1.CIF_NO = info.CIF_NO
                           and info.data_date < :data_date)
                
                union all
                
                --4.1.2.3.2.2
                SELECT T_GFI.data_date,NULL cbs_id,
                        T_GFI.CUSTOMER_UEN UEN,
                        null OTL_ID,
                        null CUSTOMER_NAME_CN,
                        T_GFI.CUSTOMER_NAME CUSTOMER_NAME_EN,
                        case
                          when UPPER(BANK_INDICATOR) = 'BANK' THEN
                           'BANK'
                          when UPPER(BANK_INDICATOR) = 'NONBANK' then
                           'CORPORATE'
                          when T_GFI.CUSTOMER_UEN IN ('239169', '7501') then
                           'GOV'
                          when T_GFI.CUSTOMER_UEN = '35049115' then
                           'QCCP'
                          else
                           null
                        END CUSTOMER_CATEGORY,
                        NULL NATIONALITY,
                        NULL COUNTRY,
                        null EXPOSURE_COUNTRY,
                        null GROUP_CODE,
                        null GROUP_NAME,
                        T_GFI.CUSTOMER_UEN UNIFORM_SOCIAL_CREDIT_CODE,
                        null UNIQUE_ID_VALUE,
                        T_CONN.CONNECTION_UEN,
                        T_CONN.CONNECTION_NAME,
                        null VALUE_DATE
                  FROM RRA_SIDS.S_GFI_CN_COUNTERPARTY T_GFI
                  left join rra_sids.s_Man_Connection_Info T_CONN
                    on T_GFI.CUSTOMER_UEN = T_CONN.uen
                   and T_CONN.data_date =
                       (select max(data_date)
                          from RRA_SIDS.S_MAN_CONNECTION_INFO
                         where data_date <= :data_date)
                 WHERE T_GFI.CLOSE_DATE IS NULL
                   AND T_GFI.CUSTOMER_UEN IS NOT NULL
                   AND T_GFI.DATA_DATE =
                       (select max(data_date)
                          from RRA_SIDS.S_GFI_CN_COUNTERPARTY
                         where data_date <= :data_date)
                   AND NOT EXISTS
                 (SELECT 1
                          FROM (SELECT T1.UEN_NO, T1.CIF_NO
                                  FROM (SELECT UEN_NO, CIF_NO
                                          FROM RRA_SIDS.S_UEN_NA
                                         WHERE DATA_DATE IN
                                               (SELECT MAX(DATA_DATE)
                                                  FROM RRA_SIDS.S_UEN_NA
                                                 where DATA_DATE <= :data_date)
                                        UNION ALL
                                        SELECT UEN_NO, CIF_NO
                                          FROM RRA_SIDS.S_UEN_CHINA
                                         WHERE DATA_DATE IN
                                               (SELECT MAX(DATA_DATE)
                                                  FROM RRA_SIDS.S_UEN_CHINA
                                                 where DATA_DATE <= :data_date)) T1
                                 INNER JOIN RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T2
                                    ON T1.CIF_NO =
                                       LPAD(TRIM(T2.FIELD_VAL_52), 10, '0')
                                   AND T2.DATA_DATE = :data_date) T_UEN
                         WHERE T_GFI.CUSTOMER_UEN = T_UEN.UEN_NO)
                
                ))
 where rn = 1
 order by cbs_id --LRE-242



           
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_daily_capital_data(data_date):
    """
    查询资本净额和一级资本净额
    :param data_date: 取数日期
    """

    query_sql = """
   SELECT CET1_CAPITAL_AMT,
       TIER1_CAPITAL_AMT,
       TOTAL_CAPITAL_AMT,
       RATE,
       DATA_DATE
  FROM RRA_SIDS.S_MAN_FIN_CAPITAL T
 WHERE DATA_DATE = (SELECT MAX(DATA_DATE)
                      FROM RRA_SIDS.S_MAN_FIN_CAPITAL
                     WHERE DATA_DATE <= :data_date)        
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='one', bind='rra')


def query_g14_capital_data(data_date):
    """
    查询资本净额和一级资本净额
    :param data_date: 取数日期
    """

    query_sql = """
   SELECT CET1_CAPITAL_AMT,
       TIER1_CAPITAL_AMT,
       TOTAL_CAPITAL_AMT,
       RATE,
      :data_date DATA_DATE
  FROM RRA_SIDS.S_MAN_FIN_CAPITAL T
 WHERE  SUBSTR(DATA_DATE,0,6) = SUBSTR(:data_date,0,6)        
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='one', bind='rra')


def query_interbank_financing_business_data(data_date):
    """
    查询同业融资业务
    :param data_date: 取数日期
    """
    query_sql = """
         --Other inputs  part 2 sql   

 SELECT  :data_date data_date,
              RANK_CD,
              FN_INSTITUTION_NAME_CD,
              FN_INSTITUTION_CODE_CD,
              IB_DRAWDOWN_AMT, --拆放同业
              IB_LENDING_AMT, --其中：同业拆借
              IB_BORROW_AMT, --其中：同业借款
              PAYMENT_AMT, --其中：受托方同业代付
              NOSTRO_AMT, --存放同业
              BUY_BACK_SALE_AMT,--买入返售
              OTH_IB_FINANCING_AMT, --其他同业融出
              TOTAL_IB_FINANCING_AMT,--同业融出合计 
              REDUCE_IB_FINANCING_AMT,--扣除结算性同业存款和风险权重为零资产后的融出余额
              PROPORTION_CAPITAL, --占一级资本净额比例%
              SETTLE_IB_DEPOSIT, --结算性同业存款
              ZERO_RW_ASSET --风险权重为零的资产
         FROM RRA_INX.REP_CBRC_TOP10_FS_CREDIT_ISSUE 
        WHERE CURRENCY_CD = '946'
          AND REPORT_ID = 'CBRC1024'
          AND ORG_CD = '000'
          and RANK_CD = '1'
          AND DATA_DATE =  substr(:data_date,1,4)||case when substr(:data_date,5,2) ='03' THEN 1
                                                        when substr(:data_date,5,2) ='06' THEN 2
                                                        when substr(:data_date,5,2) ='09' THEN 3
                                                        when substr(:data_date,5,2) ='12' THEN 4 ELSE 0 END       
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='one', bind='rra')


def query_interbank_lending_data(data_date):
    """
    查询 同业拆借 本外币合计
    :param data_date: 取数日期
    """

    query_sql = """
     --other inputs part4
    --其中：同业拆借
   
        SELECT :data_date data_date,
        '其中：同业拆借' ITEM_NAME,
        ROUND(SUM(BALANCE) / 10000, 2) TOTAL_IN_CNY_AMOUNT
   FROM RRA_GBDS.GBDS_GL_SUMMARY
  WHERE DATA_DATE = substr(:data_date,0,6)
    AND ACT_ITEM_CODE IN (104110111,
                          104110112,
                          104110120,
                          104110201,
                          104110202,
                          104110300,
                          104110400,
                          104110500,
                          104110600,
                          104210110,
                          104210120,
                          104210210,
                          104210220,
                          104210300,
                          104210400,
                          104210500,
                          104210600)
    AND CURRENCY = '946'
    AND BRANCH_CODE = '000' 
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='one', bind='rra')


def query_entrusted_party_pays_data(data_date):
    """
    查询 受托方同业大夫 本外币合计
    :param data_date: 取数日期
    """

    query_sql = """
        --other inputs part5 
        --其中：受托方同业代付   
        
        SELECT :data_date data_date,
               '其中：受托方同业代付' ITEM_NAME,
               ROUND(SUM(BALANCE) / 10000, 2) TOTAL_IN_CNY_AMOUNT
          FROM RRA_GBDS.GBDS_GL_SUMMARY
         WHERE DATA_DATE = substr(:data_date,0,6)
           AND ACT_ITEM_CODE IN
               (104321000, 104331000, 104341000, 104351000, 104361000)
           AND CURRENCY = '946'
           AND BRANCH_CODE = '000'   
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='one', bind='rra')


def query_domestic_summary_data(data_date):
    """
    查询 境内汇总数据
    :param data_date: 取数日期
    """

    query_sql = """
          --other inputs part3 ITEM 1-58
           select :data_date data_date,
                  ITEM_SEQUENCE,
                  ITEM_NAME,
                  FOREIGN_IN_CNY_AMOUNT,
                  CNY_AMOUNT,
                  TOTAL_IN_CNY_AMOUNT
             from RRA_INX.REP_CBRC_GL_VIEW
            where  data_date = substr(:data_date ,0,6)
              and REPORT_ID = 'CBRC1001'
              and ORG_CD = '000'
              and ITEM_SEQUENCE < 59
            order by ITEM_SEQUENCE      
     """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')

def query_daily_ead_report_data(data_date):
    """
    查询 EAD report数据
    :param data_date: 取数日期
    """

    query_sql = """
        -- EAD为月报，日期参数，为每个月的最后一天 
        
        select DATA_DATE,
               COUNTERPARTY_LONG_NAME,
               COUNTERPARTY_TYPE,
               IBUK_CUSTOMER_NUMBER,
               sum(EAD_USD) EAD_USD,
               CBS_CIF_ID,
               UEN
          from (SELECT substr(:data_date, 0, 6) DATA_DATE,
                       T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
                       T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
                       T2.IBUK_CUST_NO IBUK_CUSTOMER_NUMBER, --3
                       RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                   'CAD',
                                                   'USD',
                                                   T1.EAD,
                                                   'STAND') EAD_USD, --4
                       T4.CUSTOMER_NO CBS_CIF_ID, --5
                       TO_CHAR(T1.UEN) UEN --6
                  FROM RRA_SIDS.S_MAN_SACCR_DAY T1
                  LEFT JOIN RRA_SIDS.S_WSS_FX T2
                    ON SUBSTR(T1.TRADE_ID, 3, 2) = SUBSTR(T2.AREA_CODE, 1, 2)
                   AND SUBSTR(T1.TRADE_ID, 7, 13) = T2.DEAL_NUMBER
                   AND T2.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_WSS_FX
                                        WHERE DATA_DATE <= :data_date)
                  LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
                    ON T2.IBUK_CUST_NO = T3.IBUK_ID
                   AND T3.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_CBI_T_CMN_CUST_INF
                                        WHERE DATA_DATE <= :data_date) --RRA-1570
                  LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
                    ON T3.CBS_ID = T4.CUSTOMER_NO
                   AND T4.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_FLC_STTM_CUSTOMER
                                        WHERE DATA_DATE <= :data_date) --RRA-1570
                 WHERE T1.DATA_DATE = ( select max(data_date) from RRA_SIDS.S_MAN_SACCR_DAY  WHERE DATA_DATE <= :data_date ) 
                   AND T1.SRC_SYS_CD = 'WSS'
                UNION ALL
                --Simple Option TRACE
                SELECT substr(:data_date, 0, 6) DATA_DATE,
                       T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
                       T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
                       T3.IBUK_ID IBUK_CUSTOMER_NUMBER, --3
                       RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                   'CAD',
                                                   'USD',
                                                   T1.EAD,
                                                   'STAND') EAD_USD, --4
                       T2.V_MXG_CUST_REF_CODE CBS_CIF_ID, --5
                       TO_CHAR(T1.UEN) UEN --6
                  FROM RRA_SIDS.S_MAN_SACCR_DAY T1
                  LEFT JOIN RRA_GBDS.GDBS_T_UPS_OUT_MXG4SAFE T2
                    ON T1.TRADE_ID = T2.TRADE_ID
                   AND T2.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_GBDS.GDBS_T_UPS_OUT_MXG4SAFE --RRA-1833
                                        WHERE DATA_DATE <= :data_date)
                  LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
                    ON T2.V_MXG_CUST_REF_CODE = T3.CBS_ID
                   AND T3.DATA_DATE =
                       (SELECT MAX(DATA_DATE)
                          FROM RRA_SIDS.S_CBI_T_CMN_CUST_INF
                         WHERE DATA_DATE <= ':data_date') --RRA-1570
                  LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
                    ON T2.V_MXG_CUST_REF_CODE = T4.CUSTOMER_NO
                   AND T4.DATA_DATE = (SELECT MAX(DATA_DATE)
                                       
                                         FROM RRA_SIDS.S_FLC_STTM_CUSTOMER
                                        WHERE DATA_DATE <= :data_date) --RRA-1570
                 WHERE T1.DATA_DATE = :data_date
                   AND T1.SRC_SYS_CD = 'CURRPLUS'
                   AND T1.INSTM_TYPE <> 'WRTOPT'
                UNION ALL
                --Barrier Option:
                SELECT substr(:data_date, 0, 6) DATA_DATE,
                       T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
                       T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
                       T1.IBUK IBUK_CUSTOMER_NUMBER, --3
                       T1.USD_EQUIVALENT EAD_USD, --4
                       T4.CUSTOMER_NO CBS_CIF_ID, --5
                       T5.UEN_NO UEN --6
                  FROM RRA_SIDS.S_MAN_BARRIER_OPTION_REGISTER T1
                  LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
                    ON T1.IBUK = T3.IBUK_ID
                   AND T3.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_CBI_T_CMN_CUST_INF
                                        WHERE DATA_DATE <= :data_date) --RRA-1570
                  LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
                    ON T3.CBS_ID = T4.CUSTOMER_NO
                   AND T4.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_FLC_STTM_CUSTOMER
                                        WHERE DATA_DATE <= :data_date) --RRA-1570
                  LEFT JOIN RRA_GBDS.GBDS_BIZ_CUST_INFO T5
                    ON T3.CBS_ID = T5.CUST_NUM
                   AND :data_date BETWEEN T5.S_DATE AND T5.E_DATE
                 WHERE T1.DATA_DATE = :data_date
                   AND T1.EXPIRY_DATE > TO_DATE(:data_date, 'YYYY/MM/DD')
                   AND T1."B/S" = 'B')
                   where CBS_CIF_ID <>'300761'
                   
         group by DATA_DATE,
                  COUNTERPARTY_LONG_NAME,
                  COUNTERPARTY_TYPE,
                  IBUK_CUSTOMER_NUMBER,
                  CBS_CIF_ID,
                  UEN

    
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_g14_ead_report_data(data_date):
    """
    查询 EAD report数据
    :param data_date: 取数日期
    """

    query_sql = """
        -- EAD为月报，日期参数，为每个月的最后一天 
        
        select DATA_DATE,
               COUNTERPARTY_LONG_NAME,
               COUNTERPARTY_TYPE,
               IBUK_CUSTOMER_NUMBER,
               sum(EAD_USD) EAD_USD,
               CBS_CIF_ID,
               UEN
          from (SELECT :data_date DATA_DATE,
                       T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
                       T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
                       T2.IBUK_CUST_NO IBUK_CUSTOMER_NUMBER, --3
                       RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                   'CAD',
                                                   'USD',
                                                   T1.EAD,
                                                   'STAND') EAD_USD, --4
                       T4.CUSTOMER_NO CBS_CIF_ID, --5
                       TO_CHAR(T1.UEN) UEN --6
                  FROM RRA_SIDS.S_MAN_SACCR T1
                  LEFT JOIN RRA_SIDS.S_WSS_FX T2
                    ON SUBSTR(T1.TRADE_ID, 3, 2) = SUBSTR(T2.AREA_CODE, 1, 2)
                   AND SUBSTR(T1.TRADE_ID, 7, 13) = T2.DEAL_NUMBER
                   AND T2.DATA_DATE =  :data_date 
                  LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
                    ON T2.IBUK_CUST_NO = T3.IBUK_ID
                   AND T3.DATA_DATE =  :data_date  --RRA-1570
                  LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
                    ON T3.CBS_ID = T4.CUSTOMER_NO
                   AND T4.DATA_DATE =  :data_date  --RRA-1570
                 WHERE SUBSTR(T1.DATA_DATE,0,6) =  substr(:data_date,0,6)   
                   AND T1.SRC_SYS_CD = 'WSS'
                UNION ALL
                --Simple Option TRACE
                SELECT :data_date DATA_DATE,
                       T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
                       T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
                       T3.IBUK_ID IBUK_CUSTOMER_NUMBER, --3
                       RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                   'CAD',
                                                   'USD',
                                                   T1.EAD,
                                                   'STAND') EAD_USD, --4
                       T2.V_MXG_CUST_REF_CODE CBS_CIF_ID, --5
                       TO_CHAR(T1.UEN) UEN --6
                  FROM RRA_SIDS.S_MAN_SACCR T1
                  LEFT JOIN RRA_GBDS.GDBS_T_UPS_OUT_MXG4SAFE T2
                    ON T1.TRADE_ID = T2.TRADE_ID
                   AND T2.DATA_DATE =  :data_date 
                  LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
                    ON T2.V_MXG_CUST_REF_CODE = T3.CBS_ID
                   AND T3.DATA_DATE = :data_date --RRA-1570
                  LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
                    ON T2.V_MXG_CUST_REF_CODE = T4.CUSTOMER_NO
                   AND T4.DATA_DATE =  :data_date  --RRA-1570
                 WHERE SUBSTR(T1.DATA_DATE,0,6) =  substr(:data_date,0,6)  
                   AND T1.SRC_SYS_CD = 'CURRPLUS'
                   AND T1.INSTM_TYPE <> 'WRTOPT'
                UNION ALL
                --Barrier Option:
                SELECT :data_date DATA_DATE,
                       T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
                       T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
                       T1.IBUK IBUK_CUSTOMER_NUMBER, --3
                       T1.USD_EQUIVALENT EAD_USD, --4
                       T4.CUSTOMER_NO CBS_CIF_ID, --5
                       T5.UEN_NO UEN --6
                  FROM RRA_SIDS.S_MAN_BARRIER_OPTION_REGISTER T1
                  LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
                    ON T1.IBUK = T3.IBUK_ID
                   AND T3.DATA_DATE =  :data_date  --RRA-1570
                  LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
                    ON T3.CBS_ID = T4.CUSTOMER_NO
                   AND T4.DATA_DATE =   :data_date  --RRA-1570
                  LEFT JOIN RRA_GBDS.GBDS_BIZ_CUST_INFO T5
                    ON T3.CBS_ID = T5.CUST_NUM
                   AND :data_date BETWEEN T5.S_DATE AND T5.E_DATE
                 WHERE T1.DATA_DATE = :data_date
                   AND T1.EXPIRY_DATE > TO_DATE(:data_date, 'YYYY/MM/DD')
                   AND T1."B/S" = 'B')
                   where CBS_CIF_ID <>'300761'
                   
         group by DATA_DATE,
                  COUNTERPARTY_LONG_NAME,
                  COUNTERPARTY_TYPE,
                  IBUK_CUSTOMER_NUMBER,
                  CBS_CIF_ID,
                  UEN
    
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_daily_ead_report_data2(data_date):
    """
    查询 EAD report数据
    :param data_date: 取数日期
    """

    query_sql = """
    WITH TMP_A AS
 (SELECT /*+materialize*/
   NVL(SUM(T.BALANCE), 0) BALANCE
    FROM RRA_GBDS.GBDS_GL T
   WHERE T.ACT_ITEM_CODE = '102051000'
     AND T.BRANCH_CODE = '000'
     AND T.CURRENCY = '946'
     AND T.DATA_DATE = :data_date ),
TMP_B AS
 (SELECT /*+materialize*/
   NVL(SUM(RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date ,
                                                'USD',
                                                'CNY',
                                                RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date ,
                                                                                     'CAD',
                                                                                     'USD',
                                                                                     T.EAD,
                                                                                     'STAND'),
                                                'SAFE_MID')),
       0) BALANCE
    FROM RRA_SIDS.S_MAN_SACCR_DAY T
   WHERE T.DATA_DATE = (select MAX(DATA_DATE)
                          from RRA_SIDS.S_MAN_SACCR_DAY
                         where data_date <= :data_date )
     AND T.UEN = '35049115'
     AND ((T.SRC_SYS_CD = 'CURRPLUS' AND T.INSTM_TYPE <> 'WRTOPT') OR
         T.SRC_SYS_CD <> 'CURRPLUS'))
SELECT '300761' CBS_ID,
       '560022' IBUK_Customer,
       null EAD_Total,
       ROUND((A.BALANCE + B.BALANCE), 2) EAD_CNY_EQV,
       '300761' CBS_ID,
       :data_date data_date
  FROM TMP_A A
  JOIN TMP_B B
    ON 1 = 1
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_g14_ead_report_data2(data_date):
    """
    查询 EAD report数据
    :param data_date: 取数日期
    """

    query_sql = """
    WITH TMP_A AS
 (SELECT /*+materialize*/
   NVL(SUM(T.BALANCE), 0) BALANCE
    FROM RRA_GBDS.GBDS_GL T
   WHERE T.ACT_ITEM_CODE = '102051000'
     AND T.BRANCH_CODE = '000'
     AND T.CURRENCY = '946'
     AND T.DATA_DATE = :data_date ),
TMP_B AS
 (SELECT /*+materialize*/
   NVL(SUM(RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date ,
                                                'USD',
                                                'CNY',
                                                RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date ,
                                                                                     'CAD',
                                                                                     'USD',
                                                                                     T.EAD,
                                                                                     'STAND'),
                                                'SAFE_MID')),
       0) BALANCE
    FROM RRA_SIDS.S_MAN_SACCR T
   WHERE SUBSTR(T.DATA_DATE,0,6) =  substr(:data_date,0,6)  
     AND T.UEN = '35049115'
     AND ((T.SRC_SYS_CD = 'CURRPLUS' AND T.INSTM_TYPE <> 'WRTOPT') OR
         T.SRC_SYS_CD <> 'CURRPLUS'))
SELECT '300761' CBS_ID,
       '560022' IBUK_Customer,
       null EAD_Total,
       ROUND((A.BALANCE + B.BALANCE), 2) EAD_CNY_EQV,
       '300761' CBS_ID,
       :data_date data_date
  FROM TMP_A A
  JOIN TMP_B B
    ON 1 = 1
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_daily_money_market_data(data_date):
    """
    4.1.3.1 MM505 daily
    查询 ＭＭ 505 数据
    :param data_date: 取数日期
    """
    query_sql = """
    ----4.1.3.1 MM505 daily

    select T1.Data_Date,
           T2.CBS_ID,
           T1.Report_Date,
           T1.START_DATE Value_Date,
           Mat_Date,
           Deal_Type,
           Deal_Type Deal_Type_RRA,
           Ccy,
           PRINCIPAL_AMT Amount,
            case
             when to_date(:data_date, 'YYYYMMDD') -
                  to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
              0
             else
              decode(substr(BASIS_CODE, -3),
                     0,
                     0,
                     ( T1.PRINCIPAL_AMT * Rate * (to_date(:data_date, 'YYYYMMDD') -
                     to_date(Start_date, 'YYYYMMDD') + 1)) /
                     substr(BASIS_CODE, -3) / 100)
           END    TOTAL_INTEREST,
           Name_Short,
           TYPE,
           MM_CUST_NUM,
           'Y' Inventory,
           MM_CUST_NUM Customer_Short_Name,
           T2.CBS_ID,
           CASE
             WHEN t1.ccy = 'CNY' THEN
              T1.PRINCIPAL_AMT
             ELSE
              RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                          'USD',
                                          'CNY',
                                          RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                      T1.CCY,
                                                                      'USD',
                                                                      T1.PRINCIPAL_AMT,
                                                                      'STAND'),
                                          'SAFE_MID')
           END +
           NVL(case
             when to_date(:data_date, 'YYYYMMDD') -
                  to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
              0
             else
              decode(substr(BASIS_CODE, -3),
                     0,
                     0,
                     ((CASE
                       WHEN t1.ccy = 'CNY' THEN
                        T1.PRINCIPAL_AMT
                     
                       ELSE
                        RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                    'USD',
                                                    'CNY',
                                                    RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                                T1.CCY,
                                                                                'USD',
                                                                                T1.PRINCIPAL_AMT,
                                                                                'STAND'),
                                                    'SAFE_MID')
                     END) * Rate * (to_date(:data_date, 'YYYYMMDD') -
                     to_date(Start_date, 'YYYYMMDD') + 1)) /
                     substr(BASIS_CODE, -3) / 100)
           END ,0) CNY_EQV
           ,NVL(case
             when to_date(:data_date, 'YYYYMMDD') -
                  to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
              0
             else
              decode(substr(BASIS_CODE, -3),
                     0,
                     0,
                     ((CASE
                       WHEN t1.ccy = 'CNY' THEN
                        T1.PRINCIPAL_AMT
                     
                       ELSE
                        RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                    'USD',
                                                    'CNY',
                                                    RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                                T1.CCY,
                                                                                'USD',
                                                                                T1.PRINCIPAL_AMT,
                                                                                'STAND'),
                                                    'SAFE_MID')
                     END) * Rate * (to_date(:data_date, 'YYYYMMDD') -
                     to_date(Start_date, 'YYYYMMDD') + 1)) /
                     substr(BASIS_CODE, -3) / 100)
           END ,0) interest_AMT --MM 505Lending/placing
      from rra_sids.S_WSS_MM T1
      left join rra_sids.s_cbi_t_cmn_cust_inf T2
        on T1.Mm_Cust_Num = T2.Ibuk_Id
       and T2.Data_Date = :data_date
     where T1.data_date = 
      --LRE-179 处理周未工作日，WSS 没文件，拿周5数据
       (case
         when trim(to_char(to_date(:data_date, 'YYYYMMDD'), 'day')) =
              'saturday' then
          to_char(to_date(:data_date, 'YYYYMMDD') - 1, 'YYYYMMDD')
         when trim(to_char(to_date(:data_date, 'YYYYMMDD'), 'day')) =
              'sunday' THEN
          to_char(to_date(:data_date, 'YYYYMMDD') - 2, 'YYYYMMDD')
         else
          :data_date
       end)
       and (T1.TYPE NOT in ('INTR', 'CORP') and
           T1.Name_Short NOT IN ('BMCNBJBEJ',
                                  'BMCNSHSHA',
                                  'BMOT3773',
                                  'BMCNHOBEJ',
                                  'BMCNGZGNZ',
                                  'EQUITY',
                                  'PBCS BEJ'))
       and T1.MAT_DATE > T1.data_date
       and T1.Deal_type = 'XL'

    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_g14_money_market_data(data_date):
    """
   查询 DSC 数据
   :param data_date: 取数日期
   """

    query_sql = """
        with S_WSS_MM_TMP as
 (select *
    from (select T.Deal_Number,
                 T.START_DATE,
                 T.Ccy,
                 T.Mat_Date,
                 T.PRINCIPAL_AMT,
                 T.Rate,
                 T.BASIS_CODE,
                 T.Mm_Cust_Num,
                 T.TYPE,
                 T.Name_Short,
                 T.Deal_Type,
                 T.Report_Date,
                 row_number() over(partition by deal_number order by data_date desc) RN
            from rra_sids.S_WSS_MM T
           where (T.TYPE NOT in ('INTR', 'CORP') and
                 T.Name_Short NOT IN ('BMCNBJBEJ',
                                       'BMCNSHSHA',
                                       'BMOT3773',
                                       'BMCNHOBEJ',
                                       'BMCNGZGNZ',
                                       'EQUITY',
                                       'PBCS BEJ'))
             and T.Deal_type = 'XL'
             and NVL(T.deal_status,'0') <>'C'
             AND T.Start_Date <= :data_date
             and T.Mat_Date > :data_date)
   where RN = 1)

select :data_date as data_date,
       T1.Deal_Number,
       T2.CBS_ID,
       T1.Report_Date,
       T1.START_DATE Value_Date,
       Mat_Date,
       Deal_Type,
       Deal_Type Deal_Type_RRA,
       Ccy,
       PRINCIPAL_AMT Amount,
       case
         when to_date(:data_date, 'YYYYMMDD') -
              to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
          0
         else
          decode(substr(BASIS_CODE, -3),
                 0,
                 0,
                 (T1.PRINCIPAL_AMT * Rate *
                 (to_date(:data_date, 'YYYYMMDD') -
                 to_date(Start_date, 'YYYYMMDD') + 1)) /
                 substr(BASIS_CODE, -3) / 100)
       END TOTAL_INTEREST,
       Name_Short,
       TYPE,
       MM_CUST_NUM,
       'Y' Inventory,
       MM_CUST_NUM Customer_Short_Name,
       T2.CBS_ID,
       CASE
         WHEN t1.ccy = 'CNY' THEN
          T1.PRINCIPAL_AMT
         ELSE
          RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                               'USD',
                                               'CNY',
                                               RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                                    T1.CCY,
                                                                                    'USD',
                                                                                    T1.PRINCIPAL_AMT,
                                                                                    'STAND'),
                                               'SAFE_MID')
       END + NVL( case
         when to_date(:data_date, 'YYYYMMDD') -
              to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
          0
         else
          decode(substr(BASIS_CODE, -3),
                 0,
                 0,
                 ((CASE
                   WHEN t1.ccy = 'CNY' THEN
                    T1.PRINCIPAL_AMT
                 
                   ELSE
                    RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                         'USD',
                                                         'CNY',
                                                         RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                                              T1.CCY,
                                                                                              'USD',
                                                                                              T1.PRINCIPAL_AMT,
                                                                                              'STAND'),
                                                         'SAFE_MID')
                 END) * Rate * (to_date(:data_date, 'YYYYMMDD') -
                 to_date(Start_date, 'YYYYMMDD') + 1)) /
                 substr(BASIS_CODE, -3) / 100)
       END ,0) CNY_EQV,
       NVL(case
         when to_date(:data_date, 'YYYYMMDD') -
              to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
          0
         else
          decode(substr(BASIS_CODE, -3),
                 0,
                 0,
                 ((CASE
                   WHEN t1.ccy = 'CNY' THEN
                    T1.PRINCIPAL_AMT
                 
                   ELSE
                    RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                         'USD',
                                                         'CNY',
                                                         RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                                              T1.CCY,
                                                                                              'USD',
                                                                                              T1.PRINCIPAL_AMT,
                                                                                              'STAND'),
                                                         'SAFE_MID')
                 END) * Rate * (to_date(:data_date, 'YYYYMMDD') -
                 to_date(Start_date, 'YYYYMMDD') + 1)) /
                 substr(BASIS_CODE, -3) / 100)
       END,0) interest_AMT
  from S_WSS_MM_TMP T1
  left join rra_sids.s_cbi_t_cmn_cust_inf T2
    on T1.Mm_Cust_Num = T2.Ibuk_Id
   and T2.Data_Date = :data_date
    """

    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_dsc_data(data_date):
    """
    查询 DSC 数据
    :param data_date: 取数日期
    """

    query_sql = """        
       
WITH CUSTOMER_UEN_INFO AS
 (SELECT B.CIF_NO, B.UEN_NO, B.LEGAL_NAME
    FROM (SELECT A.CIF_NO,
                 A.UEN_NO,
                 A.LEGAL_NAME,
                 ROW_NUMBER() OVER(PARTITION BY A.UEN_NO ORDER BY A.PIR ASC) AS RN
            FROM (SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         TRIM(PARENT_UEN) AS UEN_NO,
                         T1.LEGAL_NAME,
                         '1' AS PIR
                    FROM RRA_SIDS.S_UEN_BRANCH T1
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_BRANCH
                           WHERE DATA_DATE <= :data_date)
                  UNION ALL
                  SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         UEN_NO,
                         T2.LEGAL_NAME,
                         '2' AS PIR
                    FROM RRA_SIDS.S_UEN_NA T2
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_NA
                           WHERE DATA_DATE <= :data_date)
                  UNION
                  SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         UEN_NO,
                         T3.LEGAL_NAME,
                         '3' AS PIR
                    FROM RRA_SIDS.S_UEN_CHINA T3
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_CHINA
                           WHERE DATA_DATE <= :data_date)) A
           WHERE A.UEN_NO IS NOT NULL) B
   WHERE B.RN = 1),

CUSTOMER_INFO as
 (select Uen_No, CUSTOMER_NO, CUSTOMER_CATEGORY
    from (select T2.Uen_No,
                 case
                   when upper(T3.CUSTOMER_TYPE) = 'FI' then
                    'BANK'
                   when upper(T3.CUSTOMER_TYPE) = 'NBFI' then
                    'NBFI'
                   when upper(T3.CUSTOMER_TYPE) = 'CORPORATE' then
                    'CORPORATE'
                   else
                    'BANK'
                 end CUSTOMER_CATEGORY,
                 T.CUSTOMER_NO,
                 row_number() over(partition by T2.Uen_No order by T.CUSTOMER_NO desc) Rn
            from RRA_SIDS.S_FLC_STTM_CUSTOMER T
            LEFT JOIN RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T1
              ON T.CUSTOMER_NO = SUBSTR(T1.REC_KEY, 1, 6)
            LEFT JOIN CUSTOMER_UEN_INFO T2
              ON LPAD(T1.FIELD_VAL_52, 10, '0') = T2.CIF_NO
            left join rra_sids.S_CMCIF_CUST_INFO T3
              on LPAD(T1.FIELD_VAL_52, 10, '0') =
                 LPAD(TRIM(T3.cif_id), 10, '0')
             and T3.Data_Date = ':data_date'
           WHERE T.DATA_DATE = :data_date
             and T.data_date = T1.Data_Date
             AND AUTH_STAT = 'A' --授权标志
             AND T.RECORD_STAT = 'O' --状态标志 RRA-1533
             and T1.FUNCTION_ID = 'STDCIF'
             and T.AUTH_STAT = 'A'
             AND T.CUSTOMER_CATEGORY IN ('NBFI', 'BANK', 'CORPORATE'))
   where rn = 1)
select NVL(CBS_ID, CUSTOMER_CATEGORY|| '_' || RISKPARTY_UEN) CBS_ID,
       BENEFICIARY_CBS_ID,
       RISKPARTY_UEN,
       NVL(CBS_ID, CUSTOMER_CATEGORY || '_' || RISKPARTY_UEN) RISKPARTY_CBSID,
       PRODUCT,
       WITH_BANK_CUSTOMER,
       RISKPARTY_CBSID2,
       RISKPARTY_UEN2,
       CURRENCY,
       AMOUNT,
       INTEREST_IN_ADVANCE,
       INCOME_ACCRUAL_AMOUNT,
       OUR_REF,
       CUSTOMER_CATEGORY,
       CBS_ID,
       data_date
  from (select NVL(RISKPARTY_CBSID, CUSTOMER_NO) CBS_ID,
               BENEFICIARY_CBS_ID,
               RISKPARTY_UEN,
               RISKPARTY_CBSID,
               PRODUCT,
               WITH_BANK_CUSTOMER,
               RISKPARTY_CBSID RISKPARTY_CBSID2,
               RISKPARTY_UEN RISKPARTY_UEN2,
               CURRENCY,
               AMOUNT,
               INTEREST_IN_ADVANCE,
               round(decode(TOTAL_DAYS,
                            0,
                            0,
                            TOTAL_INCOME / TOTAL_DAYS * CURR_DAYS_FOR_INT),
                     4) as INCOME_ACCRUAL_AMOUNT,
               OUR_REF,
               NVL(cust.CUSTOMER_CATEGORY,'BANK') CUSTOMER_CATEGORY,
               report_date data_date  
          from rra_inx.REP_ME_DISCOUNT_DB dsc
          left join CUSTOMER_INFO cust
            ON dsc.RISKPARTY_UEN = cust.UEN_NO
         where report_date = :data_date
           --and TO_CHAR(PRINCIPAL_MATURITY_DATE, 'YYYYMMDD') > :data_date
           and status is null)

     """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_daily_llp_data(data_date):
    """
    查询 BMOS0001 LLP detail数据
    :param data_date: 取数日期
    """

    query_sql = """
      select TRANS_REF Transaction_Ref,
                        BRANCH,
                        BALANCE_SHEET   as BSOFFBS,
                        DEAL_TYPE,
                        UEN,
                        CCY_CNY_USD        as CCY_CNY_USD,
                        PROV_AMT,
                        data_date
                   from rra_sids.s_man_llp
                  where data_date = (select max(data_date) from rra_sids.s_man_llp where data_date <= :data_date)
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_g14_llp_data(data_date):
    """
    查询 BMOS0001 LLP detail数据
    :param data_date: 取数日期
    """

    query_sql = """
      select TRANS_REF Transaction_Ref,
                        BRANCH,
                        BALANCE_SHEET   as BSOFFBS,
                        DEAL_TYPE,
                        UEN,
                        CCY_CNY_USD        as CCY_CNY_USD,
                        PROV_AMT,
                        data_date
                   from rra_sids.s_man_llp
                  where data_date = :data_date 
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_nostro_data(data_date):
    """
    查询 Nostro 数据
    :param data_date: 取数日期
    """

    query_sql = """    
       with tb_interest as
 (select sum(CASE
             WHEN t1.CURRENCY = 'CNY' THEN
              abs(T1.FCY_AMOUNT)
             ELSE
              RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                   'USD',
                                                   'CNY',
                                                   RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                                        T1.CURRENCY,
                                                                                        'USD',
                                                                                        abs(T1.FCY_AMOUNT),
                                                                                        'STAND'),
                                                   'SAFE_MID')
           END) FCY_AMOUNT
  from RRA_SIDS.S_FLC_BIVW_DAILY_ACC_ENTRIES T1
 where data_date = (select max(data_date)
                      from RRA_SIDS.S_FLC_BIVW_DAILY_ACC_ENTRIES
                     where data_date <= :data_date
                       and gl_code = '713010300'
                       AND addl_text like '009015 ACC SPDB INT FR%'
                       and abs(nvl(FCY_AMOUNT, 0)) > 0)
   and gl_code = '713010300'
   AND addl_text like '009015 ACC SPDB INT FR%'
   )
select cust_no,
       cust_no,
       'CNY' ccy,
       CASE
         WHEN t1.ccy = 'CNY' THEN
          abs(T1.ACY_CURR_BALANCE)
         ELSE
          RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                      'USD',
                                      'CNY',
                                      RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                  T1.ccy,
                                                                  'USD',
                                                                  abs(T1.ACY_CURR_BALANCE),
                                                                  'STAND'),
                                      'SAFE_MID')
       END Amount,
       t2.FCY_AMOUNT,
       T1.data_date
  from RRA_SIDS.S_FLC_STTM_CUST_ACCOUNT T1
  left join tb_interest T2
    on 1 = 1
 where cust_ac_no = '2005101156000005'
   and data_date = :data_date
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_limit_data(data_date):
    """
    查询 Limit 数据
    :param data_date: 取数日期
    """

    query_sql = """
        select CUSTOMER_ID            CBS_ID,
           CUSTOMER_ID            Customer_ID,
           CURRENCY,
           AVAILABLE_CREDIT_LIMIT,
           REVOCABLE,
           ORG_PERIOD_IN_ONE_YEAR,
           data_date
          from RRA_SIDS.S_FLC_CREDIT_EXPOSURE
         where data_date = :data_date 
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_offbs_tf_data(data_date):
    """
    查询 offbs TF 数据
    :param data_date: 取数日期
    """

    query_sql = """      
        WITH CUSTOMER_UEN_INFO AS
         (SELECT B.CIF_NO, B.UEN_NO, B.LEGAL_NAME
            FROM (SELECT A.CIF_NO,
                         A.UEN_NO,
                         A.LEGAL_NAME,
                         ROW_NUMBER() OVER(PARTITION BY A.UEN_NO ORDER BY A.PIR ASC) AS RN
                    FROM (SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                                 TRIM(PARENT_UEN) AS UEN_NO,
                                 T1.LEGAL_NAME,
                                 '1' AS PIR
                            FROM RRA_SIDS.S_UEN_BRANCH T1
                           WHERE DATA_DATE =
                                 (SELECT MAX(DATA_DATE)
                                    FROM RRA_SIDS.S_UEN_BRANCH
                                   WHERE DATA_DATE <= :data_date )
                          UNION ALL
                          SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                                 UEN_NO,
                                 T2.LEGAL_NAME,
                                 '2' AS PIR
                            FROM RRA_SIDS.S_UEN_NA T2
                           WHERE DATA_DATE =
                                 (SELECT MAX(DATA_DATE)
                                    FROM RRA_SIDS.S_UEN_NA
                                   WHERE DATA_DATE <= :data_date)
                          UNION
                          SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                                 UEN_NO,
                                 T3.LEGAL_NAME,
                                 '3' AS PIR
                            FROM RRA_SIDS.S_UEN_CHINA T3
                           WHERE DATA_DATE =
                                 (SELECT MAX(DATA_DATE)
                                    FROM RRA_SIDS.S_UEN_CHINA
                                   WHERE DATA_DATE <= :data_date)) A
                   WHERE A.UEN_NO IS NOT NULL) B
           WHERE B.RN = 1),
        CBS_FUNC_UDF_FIELDS AS
         (SELECT SUBSTR(T.REC_KEY, 1, 6) CBS_ID,
                 LPAD(T.FIELD_VAL_52, 10, '0') AS CIF_NO
            FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T
           WHERE T.FUNCTION_ID = 'STDCIF'
             AND T.DATA_DATE = (SELECT MAX(DATA_DATE)
                                  FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS
                                 WHERE DATA_DATE <= :data_date))
        
        select T3.CBS_ID,
               T1.UEN_NO,
               T3.CBS_ID,
               case
                 when upper(T1.DEAL_TYPE) = 'GUARANTEE' THEN
                  0.5
                 when upper(T1.DEAL_TYPE) IN ('CONFIRMATION', 'LC ISSUANCE') THEN
                  0.2
                 else
                  0
               end OFFBS_factor,
               T1.DEAL_TYPE,
               T1.UEN_NO,
               T1.CURRENCY,
               T1.AMOUNT,
               :data_date as data_date
          from (SELECT T.DATA_DATE,
                       T.CBS_BU AS BRANCH_CODE,
                       T.INSTRUMENT_ID AS TRANS_REF,
                       T.CURRENCY_CODE AS CURRENCY,
                       T.UEN_NUMBER AS UEN_NO,
                       T.RELEASE_DATE AS VALUE_DATE,
                       T.EXPIRY_DATE AS MATURTIY_DATE,
                       T2.DEAL_TYPE,
                       ACTIVITY_TYPE,
                       PROD_PROD_TYPE_CODE,
                       CONFIRMATION_TYPE,
                       NVL(T.LC_AVAIL_AMT, 0) AMOUNT,
                       ROW_NUMBER() OVER(PARTITION BY T.INSTRUMENT_ID ORDER BY T.SEQUENCE_DATE DESC, T.SEQUENCE_TIME DESC) RN
                  FROM RRA_SIDS.S_PIX_CNLCCOL T
                 INNER JOIN (SELECT DISTINCT BS.PROD_TYPE,
                                            BS.DEAL_TYPE,
                                            BS.RISK_PARTY_CORP_TYPE,
                                            BS.BALANCE_SHEET,
                                            BS.IS_LOAN
                              FROM RRA_SIDS.LLP_FACILITY_MAPPING BS
                             WHERE BS.BALANCE_SHEET = 'OFFBS') T2
                    ON T.PROD_PROD_TYPE_CODE = T2.PROD_TYPE
                 WHERE T.SOURCE_SYSTEM_ID = '4'
                   AND T.DATA_DATE <= :data_date
                   AND T.EXPIRY_DATE > :data_date ) T1
          left join CUSTOMER_UEN_INFO T2
            ON T1.UEN_NO = T2.UEN_NO
          left join CBS_FUNC_UDF_FIELDS T3
            ON T2.CIF_NO = T3.CIF_NO
         WHERE T1.RN = 1
           AND T1.ACTIVITY_TYPE <> 'DEA'
           AND T1.AMOUNT <> 0
           AND (T1.PROD_PROD_TYPE_CODE IN ('GUAOUT', 'DLCIMP') -- RRA-1869  
               OR (T1.PROD_PROD_TYPE_CODE = 'DLCEXP' AND
               T1.CONFIRMATION_TYPE IN ('ACON', 'SCON')))
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_daily_bond_ncd_data(data_date):
    """
    查询 BOND & NCD 数据
    :param data_date: 取数日期
    """

    query_sql = """   
    --BOND&NCD

WITH CUSTOMER_UEN_INFO AS
 (SELECT B.CIF_NO, B.UEN_NO, B.LEGAL_NAME
    FROM (SELECT A.CIF_NO,
                 A.UEN_NO,
                 A.LEGAL_NAME,
                 ROW_NUMBER() OVER(PARTITION BY A.UEN_NO ORDER BY A.PIR ASC) AS RN
            FROM (SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         TRIM(PARENT_UEN) AS UEN_NO,
                         T1.LEGAL_NAME,
                         '1' AS PIR
                    FROM RRA_SIDS.S_UEN_BRANCH T1
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_BRANCH
                           WHERE DATA_DATE <= :data_date)
                  UNION ALL
                  SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         UEN_NO,
                         T2.LEGAL_NAME,
                         '2' AS PIR
                    FROM RRA_SIDS.S_UEN_NA T2
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_NA
                           WHERE DATA_DATE <= :data_date)
                  UNION
                  SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         UEN_NO,
                         T3.LEGAL_NAME,
                         '3' AS PIR
                    FROM RRA_SIDS.S_UEN_CHINA T3
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_CHINA
                           WHERE DATA_DATE <= :data_date)) A
           WHERE A.UEN_NO IS NOT NULL) B
   WHERE B.RN = 1),
CBS_FUNC_UDF_FIELDS AS
 (SELECT SUBSTR(T.REC_KEY, 1, 6) CBS_CUST_NO,
         LPAD(T.FIELD_VAL_52, 10, '0') AS CMCIF_CUST_ID
    FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T
   WHERE T.FUNCTION_ID = 'STDCIF'
     AND T.DATA_DATE = (SELECT MAX(DATA_DATE)
                          FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS
                         WHERE DATA_DATE <= :data_date)),

TB_HOLDING_DATE AS
 (SELECT MAX(DATA_DATE) DATA_DATE
    FROM RRA_SIDS.S_INT_HOLDING
   WHERE DATA_DATE <= :data_date),
TB_SECURITY_DATE AS
 (SELECT MAX(DATA_DATE) DATA_DATE
    FROM RRA_SIDS.S_GFI_CN_SECURITY
   WHERE DATA_DATE <= :data_date),
tb_BOND_VPC_DATE as
 (select MAX(DATA_DATE) DATA_DATE
    from RRA_SIDS.S_MAN_BOND_VPC
   where data_date <= :data_date)

select  CASE WHEN ISSUER_UEN='B019' THEN '301230'  ELSE CBS_ID END CBS_ID ,
       ACCOUNTING_CODE,
       ISSUER_UEN,
       CCY,
       NVL(BALANCE,0) + NVL(VPC_IPV_ADJUSTMENT,0) as BALANCE,
       INTEREST_RECEIVABLE,
       PROFIT_CENTRE,
       CUSIP,
       T6.Data_Date
  from (SELECT T4.CBS_CUST_NO AS CBS_ID,
               T1.SECURITY_ACC_CODE AS ACCOUNTING_CODE,
               T2.ISSUER_UEN,
               T1.CURRENCY CCY,
               SUM(NVL(T1.FAIR_VALUE, 0)) BALANCE,
               SUM(INTEREST_RECEIVABLE) INTEREST_RECEIVABLE,
               T1.PROFIT_CENTRE,
               T1.CUSIP,
                T1.Data_Date
          FROM RRA_SIDS.S_INT_HOLDING T1
          LEFT JOIN RRA_SIDS.S_GFI_CN_SECURITY T2
            ON T1.BOND_CODE = T2.BOND_CODE
           AND T2.DATA_DATE = (SELECT DATA_DATE FROM TB_SECURITY_DATE)
          LEFT JOIN CUSTOMER_UEN_INFO T3
            ON T2.ISSUER_UEN = T3.UEN_NO
          LEFT JOIN CBS_FUNC_UDF_FIELDS T4
            ON T3.CIF_NO = T4.CMCIF_CUST_ID
         WHERE T1.DATA_DATE = (SELECT DATA_DATE FROM TB_HOLDING_DATE)
           AND T1.PROFIT_CENTRE IN ('T3773', 'T9534')
           AND T1.SECURITY_ACC_CODE <> 'NCD'
         group by T4.CBS_CUST_NO,
                  T1.SECURITY_ACC_CODE,
                  T2.ISSUER_UEN,
                  T1.CURRENCY,
                  T1.PROFIT_CENTRE,
                  T1.CUSIP,
                   T1.Data_Date) T6
  LEFT JOIN RRA_SIDS.S_MAN_BOND_VPC T5
    ON T6.CUSIP = T5.SEC_CUSIP
   AND T5.DATA_DATE = (select DATA_DATE from tb_BOND_VPC_DATE)
   union all 
   
select   CASE WHEN ISSUER_UEN='B019' THEN '301230'  ELSE CBS_ID END CBS_ID,
       ACCOUNTING_CODE,
       ISSUER_UEN,
       CCY,
       NVL(BALANCE,0) + NVL(VPC_IPV_ADJUSTMENT,0) as BALANCE,
       INTEREST_RECEIVABLE,
       PROFIT_CENTRE,
       CUSIP,
       T6.Data_Date
  from (SELECT T4.CBS_CUST_NO AS CBS_ID,
               T1.SECURITY_ACC_CODE AS ACCOUNTING_CODE,
               T2.ISSUER_UEN,
               T1.CURRENCY CCY,
               SUM(NVL(T1.FAIR_VALUE, 0)) BALANCE,
               SUM(INTEREST_RECEIVABLE) INTEREST_RECEIVABLE,
               T1.PROFIT_CENTRE,
               T1.CUSIP,
                T1.Data_Date
          FROM RRA_SIDS.S_INT_HOLDING T1
          LEFT JOIN RRA_SIDS.S_GFI_CN_SECURITY T2
            ON T1.BOND_CODE = T2.BOND_CODE
           AND T2.DATA_DATE = (SELECT DATA_DATE FROM TB_SECURITY_DATE)
          LEFT JOIN CUSTOMER_UEN_INFO T3
            ON T2.ISSUER_UEN = T3.UEN_NO
          LEFT JOIN CBS_FUNC_UDF_FIELDS T4
            ON T3.CIF_NO = T4.CMCIF_CUST_ID
         WHERE T1.DATA_DATE = (SELECT DATA_DATE FROM TB_HOLDING_DATE)
           AND T1.PROFIT_CENTRE IN ('T3773', 'T9534')
           AND T1.SECURITY_ACC_CODE = 'NCD'
         group by T4.CBS_CUST_NO,
                  T1.SECURITY_ACC_CODE,
                  T2.ISSUER_UEN,
                  T1.CURRENCY,
                  T1.PROFIT_CENTRE,
                  T1.CUSIP,
                   T1.Data_Date) T6
  LEFT JOIN RRA_SIDS.S_MAN_BOND_VPC T5
    ON T6.CUSIP = T5.SEC_CUSIP
   AND T5.DATA_DATE =  (select DATA_DATE from tb_BOND_VPC_DATE)
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_g14_bond_ncd_data(data_date):
    """
    查询 BOND & NCD 数据
    :param data_date: 取数日期
    """

    query_sql = """   
    --BOND&NCD

WITH CUSTOMER_UEN_INFO AS
 (SELECT B.CIF_NO, B.UEN_NO, B.LEGAL_NAME
    FROM (SELECT A.CIF_NO,
                 A.UEN_NO,
                 A.LEGAL_NAME,
                 ROW_NUMBER() OVER(PARTITION BY A.UEN_NO ORDER BY A.PIR ASC) AS RN
            FROM (SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         TRIM(PARENT_UEN) AS UEN_NO,
                         T1.LEGAL_NAME,
                         '1' AS PIR
                    FROM RRA_SIDS.S_UEN_BRANCH T1
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_BRANCH
                           WHERE DATA_DATE <= :data_date)
                  UNION ALL
                  SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         UEN_NO,
                         T2.LEGAL_NAME,
                         '2' AS PIR
                    FROM RRA_SIDS.S_UEN_NA T2
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_NA
                           WHERE DATA_DATE <= :data_date)
                  UNION
                  SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         UEN_NO,
                         T3.LEGAL_NAME,
                         '3' AS PIR
                    FROM RRA_SIDS.S_UEN_CHINA T3
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_CHINA
                           WHERE DATA_DATE <= :data_date)) A
           WHERE A.UEN_NO IS NOT NULL) B
   WHERE B.RN = 1),
CBS_FUNC_UDF_FIELDS AS
 (SELECT SUBSTR(T.REC_KEY, 1, 6) CBS_CUST_NO,
         LPAD(T.FIELD_VAL_52, 10, '0') AS CMCIF_CUST_ID
    FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T
   WHERE T.FUNCTION_ID = 'STDCIF'
     AND T.DATA_DATE = (SELECT MAX(DATA_DATE)
                          FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS
                         WHERE DATA_DATE <= :data_date)),
GFI_CN_COUNTERPARTY as
 (SELECT DISTINCT CUSTOMER_UEN, BANK_INDICATOR
    FROM RRA_SIDS.S_GFI_CN_COUNTERPARTY
         WHERE DATA_DATE = (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_GFI_CN_COUNTERPARTY
                           WHERE DATA_DATE <= :data_date))
SELECT T6.DATA_DATE,
       CASE WHEN CBS_ID IS NULL THEN NVL(CUSTOMER_CATEGORY2,CUSTOMER_CATEGORY) || '_' || ISSUER_UEN ELSE CBS_ID END CBS_ID ,
       ACCOUNTING_CODE,
       ISSUER_UEN,
       CCY,
       INTEREST_RECEIVABLE,
       PROFIT_CENTRE,
       CUSIP,
      NVL(BALANCE,0)+ ROUND((DECODE(SUM_REMAIN_PAR, 0, 0, NVL(VPC_IPV_ADJUSTMENT, 0)) /
             SUM_REMAIN_PAR) * REMAIN_PAR,
             4) BALANCE
  FROM (SELECT T1.DATA_DATE,
               case when T2.ISSUER_UEN ='B019' THEN '301230' else  T4.CBS_CUST_NO end  AS CBS_ID,
               T1.SECURITY_ACC_CODE AS ACCOUNTING_CODE,
               T2.ISSUER_UEN,
               T1.CURRENCY CCY,
               NVL(T1.FAIR_VALUE, 0) BALANCE,
                case when substr(:data_date,-4) IN (0331,0630,0930) THEN 
                      case when trim(to_char(to_date(:data_date,'YYYY-MM-DD'),'DAY'))='FRIDAY' and T_trades.SETTLE_DATE<= :data_date then INTEREST_RECEIVABLE-NVL(daily_accrual_interest,0)*2
                           when trim(to_char(to_date(:data_date,'YYYY-MM-DD'),'DAY'))='SATURDAY' and T_trades.SETTLE_DATE<= :data_date THEN INTEREST_RECEIVABLE-NVL(daily_accrual_interest,0)
                           else INTEREST_RECEIVABLE END
                    when substr(:data_date,-4)=1231 then
                      case when  T_trades.SETTLE_DATE > :data_date THEN INTEREST_RECEIVABLE
                           when trim(to_char(to_date(:data_date,'YYYY-MM-DD'),'DAY'))='THURSDAY' and T_trades.SETTLE_DATE<= :data_date then INTEREST_RECEIVABLE-NVL(daily_accrual_interest,0)*3
                           when trim(to_char(to_date(:data_date,'YYYY-MM-DD'),'DAY'))='FRIDAY' and T_trades.SETTLE_DATE<= :data_date THEN INTEREST_RECEIVABLE-NVL(daily_accrual_interest,0)*2
                           else INTEREST_RECEIVABLE-NVL(daily_accrual_interest,0) END  
                else 0 end   INTEREST_RECEIVABLE,
               T1.PROFIT_CENTRE,
               T1.CUSIP,
               SUM(REMAIN_PAR) OVER(PARTITION BY T1.CUSIP, T1.BOND_CODE) SUM_REMAIN_PAR,
               T1.REMAIN_PAR,
               CASE
                 WHEN UPPER(CUST_INFO.CUSTOMER_TYPE) = 'FI' THEN
                  'BANK'
                 WHEN UPPER(CUST_INFO.CUSTOMER_TYPE) = 'NBFI' THEN
                  'NBFI'
                 WHEN UPPER(CUST_INFO.CUSTOMER_TYPE) = 'CORPORATE' THEN
                  'CORPORATE'
                 ELSE
                  'BANK'
               END CUSTOMER_CATEGORY,
               CASE
                 WHEN UPPER(BANK_INDICATOR) = 'BANK' THEN
                  'BANK'
                 WHEN UPPER(BANK_INDICATOR) = 'NONBANK' THEN
                  'CORPORATE'
                 WHEN T_GFI.CUSTOMER_UEN IN ('239169', '7501') THEN
                  'GOV'
                 WHEN T_GFI.CUSTOMER_UEN = '35049115' THEN
                  'QCCP'
                 ELSE
                  'BANK'
               END CUSTOMER_CATEGORY2
          FROM RRA_SIDS.S_INT_HOLDING T1
          LEFT JOIN RRA_SIDS.S_GFI_CN_SECURITY T2
            ON T1.BOND_CODE = T2.BOND_CODE
           AND T2.DATA_DATE = :data_date
          LEFT JOIN CUSTOMER_UEN_INFO T3
            ON T2.ISSUER_UEN = T3.UEN_NO
          LEFT JOIN CBS_FUNC_UDF_FIELDS T4
            ON T3.CIF_NO = T4.CMCIF_CUST_ID
          LEFT JOIN RRA_SIDS.S_CMCIF_CUST_INFO CUST_INFO
            ON T3.CIF_NO = LPAD(TRIM(CUST_INFO.CIF_ID), 10, '0')
          LEFT JOIN GFI_CN_COUNTERPARTY T_GFI
            ON T_GFI.CUSTOMER_UEN = T2.ISSUER_UEN 
          LEFT JOIN rra_sids.S_INT_TRADES T_trades ON T1.TICKET=T_trades.Intra_No and T1.BOND_CODE=T_TRADES.BOND_CODE  and T1.Data_Date=T_trades.Data_Date
         WHERE T1.DATA_DATE = :data_date
           AND T1.PROFIT_CENTRE IN ('T3773', 'T9534')
           AND T1.SECURITY_ACC_CODE <> 'NCD') T6
  LEFT JOIN RRA_SIDS.S_MAN_BOND_VPC T5
    ON T6.CUSIP = T5.SEC_CUSIP
   AND T5.DATA_DATE = :data_date
UNION ALL
SELECT T6.DATA_DATE,
       CASE WHEN CBS_ID IS NULL THEN NVL(CUSTOMER_CATEGORY2,CUSTOMER_CATEGORY) || '_' || ISSUER_UEN ELSE CBS_ID END CBS_ID,
       ACCOUNTING_CODE,
       ISSUER_UEN,
       CCY,
       INTEREST_RECEIVABLE,
       PROFIT_CENTRE,
       CUSIP,
      NVL(BALANCE,0)+ ROUND((DECODE(SUM_REMAIN_PAR, 0, 0, NVL(VPC_IPV_ADJUSTMENT, 0)) /
             SUM_REMAIN_PAR) * REMAIN_PAR,
             4) BALANCE
  FROM (SELECT T1.DATA_DATE,
               T4.CBS_CUST_NO AS CBS_ID,
               T1.SECURITY_ACC_CODE AS ACCOUNTING_CODE,
               T2.ISSUER_UEN,
               T1.CURRENCY CCY,
               NVL(T1.FAIR_VALUE, 0) BALANCE,
               case when substr(:data_date,-4) IN (0331,0630,0930) THEN 
                      case when trim(to_char(to_date(:data_date,'YYYY-MM-DD'),'DAY'))='FRIDAY' and T_trades.SETTLE_DATE<= :data_date then INTEREST_RECEIVABLE-NVL(daily_accrual_interest,0)*2
                           when trim(to_char(to_date(:data_date,'YYYY-MM-DD'),'DAY'))='SATURDAY' and T_trades.SETTLE_DATE<= :data_date THEN INTEREST_RECEIVABLE-NVL(daily_accrual_interest,0)
                           else INTEREST_RECEIVABLE END
                    when substr(:data_date,-4)=1231 then
                      case when  T_trades.SETTLE_DATE > :data_date THEN INTEREST_RECEIVABLE
                           when trim(to_char(to_date(:data_date,'YYYY-MM-DD'),'DAY'))='THURSDAY' and T_trades.SETTLE_DATE<= :data_date then INTEREST_RECEIVABLE-NVL(daily_accrual_interest,0)*3
                           when trim(to_char(to_date(:data_date,'YYYY-MM-DD'),'DAY'))='FRIDAY' and T_trades.SETTLE_DATE<= :data_date THEN INTEREST_RECEIVABLE-NVL(daily_accrual_interest,0)*2
                           else INTEREST_RECEIVABLE-NVL(daily_accrual_interest,0) END  
                else 0 end   INTEREST_RECEIVABLE,
               T1.PROFIT_CENTRE,
               T1.CUSIP,
               SUM(REMAIN_PAR) OVER(PARTITION BY T1.CUSIP, T1.BOND_CODE) SUM_REMAIN_PAR,
               T1.REMAIN_PAR,
               CASE
                 WHEN UPPER(CUST_INFO.CUSTOMER_TYPE) = 'FI' THEN
                  'BANK'
                 WHEN UPPER(CUST_INFO.CUSTOMER_TYPE) = 'NBFI' THEN
                  'NBFI'
                 WHEN UPPER(CUST_INFO.CUSTOMER_TYPE) = 'CORPORATE' THEN
                  'CORPORATE'
                 ELSE
                  'BANK'
               END CUSTOMER_CATEGORY,
               CASE
                 WHEN UPPER(BANK_INDICATOR) = 'BANK' THEN
                  'BANK'
                 WHEN UPPER(BANK_INDICATOR) = 'NONBANK' THEN
                  'CORPORATE'
                 WHEN T_GFI.CUSTOMER_UEN IN ('239169', '7501') THEN
                  'GOV'
                 WHEN T_GFI.CUSTOMER_UEN = '35049115' THEN
                  'QCCP'
                 ELSE
                  'BANK'
               END CUSTOMER_CATEGORY2
          FROM RRA_SIDS.S_INT_HOLDING T1
          LEFT JOIN RRA_SIDS.S_GFI_CN_SECURITY T2
            ON T1.BOND_CODE = T2.BOND_CODE
           AND T2.DATA_DATE = :data_date
          LEFT JOIN CUSTOMER_UEN_INFO T3
            ON T2.ISSUER_UEN = T3.UEN_NO
          LEFT JOIN CBS_FUNC_UDF_FIELDS T4
            ON T3.CIF_NO = T4.CMCIF_CUST_ID
          LEFT JOIN RRA_SIDS.S_CMCIF_CUST_INFO CUST_INFO
            ON T3.CIF_NO = LPAD(TRIM(CUST_INFO.CIF_ID), 10, '0')
          LEFT JOIN GFI_CN_COUNTERPARTY T_GFI
            ON T_GFI.CUSTOMER_UEN = T2.ISSUER_UEN
          LEFT JOIN rra_sids.S_INT_TRADES T_trades ON T1.TICKET=T_trades.Intra_No and T1.BOND_CODE=T_TRADES.BOND_CODE  and T1.Data_Date=T_trades.Data_Date  
         WHERE T1.DATA_DATE = :data_date
           AND T1.PROFIT_CENTRE IN ('T3773', 'T9534')
           AND T1.SECURITY_ACC_CODE = 'NCD') T6
  LEFT JOIN RRA_SIDS.S_MAN_BOND_VPC T5
    ON T6.CUSIP = T5.SEC_CUSIP AND T5.DATA_DATE = :data_date

    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_pboc_data(data_date):
    """
    查询 PBOC 数据
    :param data_date: 取数日期
    """

    query_sql = """   
    SELECT '009000' CBS_ID, 'CNY' CURRENCY, ROUND(SUM(BALANCE), 2) AMOUNT,:data_date as DATA_DATE
      FROM RRA_GBDS.GBDS_GL
     WHERE DATA_DATE = :data_date
       AND ACT_ITEM_CODE IN
           (102030000, 102011000, 102030100, 102040100, 102020000, 102040000)
       AND CURRENCY = '946'
       AND BRANCH_CODE = '000'
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_credit_exposure_data(data_date):
    """
    查询 CREDIT EXPOSURE 数据
    :param data_date: 取数日期
    """

    query_sql = """   
        SELECT CUSTOMER_ID,
               BORROWER,
               REVOCABLE,
               AVAILABLE_CREDIT_LIMIT,
               GUARANTOR_TYPE_1,
               NAME_GUARANTOR_1,
               ORG_PERIOD_IN_ONE_YEAR,
               T2.REMARKS UEN_GUARANTOR_1 ,
               T1.data_date
          from rra_sids.S_FLC_CREDIT_EXPOSURE T1,
               rra_sids.S_FLC_GETM_COLLAT     T2
              where T1.data_date = :data_date
                 and T1.data_date = T2.data_date
                 AND T1.SECURITY_CONTRACT_NO_1 = T2.UDF_VALUE_4
                 and T1.GUARANTOR_TYPE_1 = T2.udf_value_2
                 AND T2.udf_value_2 = 'Commercial Bank'
                 AND T2.RECORD_STAT='O'
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_holidays(data_date):
    """
    查询 指定日期是否是节假日，是的话返回1，否则返回0
    :param data_date: 取数日期
    """

    query_sql = """   
    SELECT count(1) as count_num
    FROM RRA_COMM.S_RRA_HOLIDAY P
    WHERE P.HOLIDAY_TYPE = 'China'
    AND P.DATA_DATE = :data_date
    and holiday = 'H'
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='one', bind='rra')


def query_fefc_data(data_date):
    """
         查询 Product Exposure 数据
    :param data_date: 取数日期
    """
    query_sql = """ 
    SELECT UEN,
       SUM(H2_8) PRODUCT_EXPOSURE,
       SUM(PRODUCT_EXPOSURE) PRODUCT_EXPOSURE_CNY,
       :data_date as data_date
  FROM (  SELECT distinct T1.POINT_CODE,
                T1.H2_8,
                T2.UEN,
                RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                     'USD',
                                                     'CNY',
                                                     T1.H2_8,
                                                     'SAFE_MID') PRODUCT_EXPOSURE
          FROM RRA_SIDS.S_ADA_LIMITS_INFO T1
          LEFT JOIN (SELECT T.IDEN_CODE, T.UEN
                  FROM RRA_SIDS.S_ADA_CUST_INFO T
                 WHERE T.UEN IS NOT NULL
                   AND T.DATA_DATE =
                       (SELECT MAX(DATA_DATE)
                          FROM RRA_SIDS.S_ADA_CUST_INFO
                         WHERE DATA_DATE <= :data_date)) T2
            ON T1.POINT_CODE = T2.IDEN_CODE
         WHERE H2_5    IN( 'BMCN\\Derivative Products','BMCN\\Derivative Products\\' )
           AND DATA_DATE = 
           
            (case
                     when trim(to_char(to_date(:data_date, 'YYYYMMDD'), 'day')) =
                          'saturday' then
                      to_char(to_date(:data_date, 'YYYYMMDD') - 1, 'YYYYMMDD')
                     when trim(to_char(to_date(:data_date, 'YYYYMMDD'), 'day')) =
                          'sunday' THEN
                      to_char(to_date(:data_date, 'YYYYMMDD') - 2, 'YYYYMMDD')
                     else
                      to_char(:data_date)
                   end)
           
           ) WHERE UEN IS NOT NULL AND H2_8>0
     GROUP BY UEN
     """

    return db_fetch_to_dict(query_sql, params={"data_date": data_date},
                            fecth='all', bind='rra')
