# -*- coding: utf-8 -*-

from ..commons.logging import get_logger
from flask import Blueprint, jsonify
import time
import requests
from bmolre.views.report import send_over_threshold_email,send_over_alert_email
from flask import current_app as app
from bmolre.services.report_task_services import RatioMonitorData

test_bp = Blueprint('test', __name__)
log = get_logger(__name__)


@test_bp.route('/report/remote', methods=['GET'])
def test_remote_request():
    log.info("*** test_remote_request")
    result = {}

    try:
        url = 'http://10.119.51.99:5001/report/daily/open/save/Large_Risk_Exposure_Daily_Report-20200630.xlsx'
        start_time = time.time()
        response = requests.get(url, timeout=60*30)
        end_time = time.time()
        result['execution_time'] = round(end_time - start_time)

        status = response.status_code
        log.debug('status=', status)
        result = response.json()
        log.debug('result=', result)

        result['message'] = 'test requests ok'
        result['status'] = status
        result['result'] = result
    except Exception as err:
        log.error(err, exc_info=True)
        result['message'] = str(err)

    response = jsonify(result)
    log.info('response=%s', response)
    return response


@test_bp.route('/report/email', methods=['GET'])
def test_email():
    log.info("*** test_email")
    result = {}
    try:
        monitor = RatioMonitorData()
        data_date = '20200630'
        start_time = time.time()
        send_over_threshold_email(data_date=data_date, monitor=monitor, daily_report=None)
        end_time = time.time()
        result['execution_time'] = round(end_time - start_time)
        result['message'] = 'test email ok'
    except Exception as err:
        log.error(err, exc_info=True)
        result['message'] = str(err)

    response = jsonify(result)
    log.info('response=%s', response)
    return response

