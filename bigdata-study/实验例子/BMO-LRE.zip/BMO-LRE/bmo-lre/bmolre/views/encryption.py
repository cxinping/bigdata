# -*- coding: utf-8 -*-
'''
Created on Dec 30, 2020

@author: bzhan08
'''
from flask import Blueprint, jsonify
import bmolre.commons.util as util

encryption = Blueprint('encryption', __name__)


@encryption.route('/<plaintext>')
def encrypt(plaintext):
    ct = util.encrypt(plaintext)
    return jsonify(ciphertext=ct)
