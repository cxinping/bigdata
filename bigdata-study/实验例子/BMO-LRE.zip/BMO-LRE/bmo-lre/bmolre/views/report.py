# -*- coding: utf-8 -*-

"""
Created on 2020-12-03

@author: Wang Shuo
"""

from flask import Blueprint, jsonify, render_template, request
from flask import current_app as app
from http import HTTPStatus
from datetime import datetime, timedelta
import time
from ..commons.logging import get_logger
from ..commons.report_enums import ReportType
from ..commons.check_valid import is_valid_date
from ..services.report_services import G14ReportBuilder, LreDailyReportBuilder
from ..services.report_cal_services import ReportService
from ..services.report_task_services import TaskExecutor
from ..commons.report_utils import gen_subject_title, get_last_business_day_season, is_runnable_date
from ..commons.constant import (CFG_MAIL_RECIPIENTS, CFG_MAIL_SENDER, CFG_SUPPORT_MAIL_RECIPIENTS,
    CFG_SUPPORT_MAIL_SENDER, CFG_SFTP_HOST, CFG_SFTP_PORT, CFG_SFTP_USER, CFG_SFTP_PRIVATE_PATH, CFG_SFTP_PUT_DIRS,
    CFG_OPEN_EXCEL_URL, CFG_MONITOR_MAIL_RECIPIENTS)
import requests
import os


report_bp = Blueprint('report', __name__)
log = get_logger(__name__)
report_service = ReportService()
task_executor = TaskExecutor()

REQ_ARG_EMAIL = 'email'
REQ_ARG_SFTP = 'sftp'
REQ_ARG_RATIO_ALERT = 'ratio_alert'
REQ_ARG_FORCE_CREATE_G14 = 'force'

@report_bp.route('/daily', methods=['GET'])
def create_current_daily_report():
    data_date = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')
    return create_daily_report(data_date)


@report_bp.route('/daily/<data_date>', methods=['GET'])
def create_daily_report(data_date):
    log.info("create daily report , data_date={}".format(data_date))

    result = {'report_type': ReportType.DAILY_REPORT.value}
    http_status = HTTPStatus.OK

    # Unless the email parameter in request is set to True, email is False
    email_enabled = eval(request.args.get(REQ_ARG_EMAIL)) if REQ_ARG_EMAIL in request.args else False
    log.debug('email_enabled=%s', email_enabled)
    
    ratio_alert_enabled = eval(request.args.get(REQ_ARG_RATIO_ALERT)) if REQ_ARG_RATIO_ALERT in request.args else False
    log.debug('ratio_alert_enabled=%s', email_enabled)

    if is_valid_date(data_date):
        if not report_service.is_holidays(data_date):
            try:

                # Get the email configurations
                sender = None
                recipients = None
                if CFG_MAIL_SENDER in app.config:
                    sender = app.config[CFG_MAIL_SENDER]
                if CFG_MAIL_RECIPIENTS in app.config:
                    recipients = app.config[CFG_MAIL_RECIPIENTS]

                start_time = time.time()
                daily_report_builder = LreDailyReportBuilder()
                daily_report = daily_report_builder.create_report(data_date)
                result['message'] = 'LRE daily report is created successfully.'

                if email_enabled and recipients:
                    task_executor.send_email(subject=gen_subject_title(data_date), sender=sender,
                                             recipients=recipients,
                                             html_body=render_template('daily_report_email.html'), app=report_bp,
                                             attachment_path=daily_report.get_target_report())
                    result['message'] = result['message'] + ' Email is sent.'
                    result['email_sender'] = sender
                    result['email_recipients'] = recipients

                    if ratio_alert_enabled:
                        # 1, 调用Windows上的接口，打开和保存Excel
                        save_open_excel_on_windows(daily_report.get_target_report(), max_try_number=5)
    
                        # 2, 读取Excel的sheet的formula
                        monitor = daily_report.montior_report()
    
                        # 3, 发送超过 Threshold 的邮件
                        send_over_threshold_email(data_date=data_date, monitor=monitor, daily_report=daily_report)
    
                        # 4, 发送超过 Alert 的邮件
                        #send_over_alert_email(data_date=data_date, monitor=monitor, daily_report=daily_report)


                http_status = HTTPStatus.OK
                result['report_path'] = daily_report.get_target_report()
                end_time = time.time()
                result['execution_time'] = round(end_time - start_time)

            except Exception as err:
                log.error(err, exc_info=True)
                http_status = HTTPStatus.INTERNAL_SERVER_ERROR
                result['message'] = str(err)
        else:
            http_status = HTTPStatus.OK
            result['message'] = 'The input date is a holiday. No daily report is generated.'
    else:
        http_status = HTTPStatus.BAD_REQUEST
        result['message'] = 'Data date is invalid.'

    result['status'] = http_status

    if email_enabled and http_status != HTTPStatus.OK:
        send_report_failure_alert(data_date)
        result['message'] = result['message'] + ' Alert email is sent.'

    response = jsonify(result)
    log.info('response=%s', response)
    return response, http_status


def send_over_threshold_email(data_date, monitor, daily_report=None):
    sender = None
    monitor_recipients = None
    if CFG_MAIL_SENDER in app.config:
        sender = app.config[CFG_MAIL_SENDER]

    if CFG_MONITOR_MAIL_RECIPIENTS in app.config:
        monitor_recipients = app.config[CFG_MONITOR_MAIL_RECIPIENTS]

    try:
        subject = 'LRE Daily Ratio Monitoring Notification: LRE Ratio over Regulatory Threshold {}'.format(str(data_date))
        attachment_path = None
        if daily_report:
            attachment_path = daily_report.get_target_report()
        task_executor.send_email(subject=subject, sender=sender,
                                 recipients=monitor_recipients,
                                 html_body=render_template('daily_report_threshold_email.html', monitor=monitor),
                                 app=report_bp,
                                 attachment_path=attachment_path)
    except Exception as err:
        log.error(err, exc_info=True)
        raise RuntimeError(str(err))


def send_over_alert_email(data_date, monitor, daily_report=None):
    sender = None
    monitor_recipients = None
    if CFG_MAIL_SENDER in app.config:
        sender = app.config[CFG_MAIL_SENDER]

    if CFG_MONITOR_MAIL_RECIPIENTS in app.config:
        monitor_recipients = app.config[CFG_MONITOR_MAIL_RECIPIENTS]

    try:
        subject = 'LRE Daily Ratio Monitoring Notification: LRE Ratio over Regulatory Alert {}'.format(str(data_date))
        attachment_path = None
        if daily_report:
            attachment_path = daily_report.get_target_report()
        task_executor.send_email(subject=subject, sender=sender,
                                 recipients=monitor_recipients,
                                 html_body=render_template('daily_report_alert_email.html', monitor=monitor),
                                 app=report_bp,
                                 attachment_path=attachment_path)
    except Exception as err:
        log.error(err, exc_info=True)
        raise RuntimeError(str(err))


def save_open_excel_on_windows(local_file , max_try_number=5):
    remote_url = None
    log.debug('************************')
    log.debug('*** begin save_open_excel_on_windows() ***')

    try_num = 0
    while True:
        try:
            if CFG_OPEN_EXCEL_URL in app.config:
                remote_url = app.config[CFG_OPEN_EXCEL_URL]
            file_name = os.path.basename(local_file)
            remote_url = remote_url + file_name
            log.debug('* save_open_excel_on_windows remote_url=', remote_url)

            response = requests.get(url=remote_url, timeout=120)
            status = response.status_code
            log.debug('* save_open_excel_on_windows status=', status)
            log.debug('*** end save_open_excel_on_windows() ***')
            return response.json()
        except Exception as err:
            log.error(err, exc_info=True)

            try_num = try_num + 1
            if try_num >= max_try_number:
                raise RuntimeError(str(err))


@report_bp.route('/g14', methods=['GET'])
def create_current_g14_report():
    data_date = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')
    return create_g14_report(data_date)


@report_bp.route('/g14/<data_date>', methods=['GET'])
def create_g14_report(data_date):
    log.info("create G14 report , data_date={}".format(data_date))
    result = {'report_type': ReportType.G14_REPORT.value}
    http_status = HTTPStatus.OK

    # Unless the email parameter in request is set to True, email is False
    email_enabled = eval(request.args.get(REQ_ARG_EMAIL)) if REQ_ARG_EMAIL in request.args else False
    log.debug('email_enabled=%s', email_enabled)
    
    # Is sftp enabled? default True
    sftp_enabled = eval(request.args.get(REQ_ARG_SFTP)) if REQ_ARG_SFTP in request.args else True
    log.debug('sftp_enabled=%s', sftp_enabled)

    # 在某些突发情况下，无论什么日期，support需要强制生成G14报表, 制定了force参数为True
    force_create_g14_enabled = eval(request.args.get(REQ_ARG_FORCE_CREATE_G14)) if REQ_ARG_FORCE_CREATE_G14 in request.args else False
    log.debug('force_create_g14_enabled=%s', force_create_g14_enabled)

    if is_valid_date(data_date):
        if not report_service.is_holidays(data_date):
            try:
                start_time = time.time()
                g14_report_builder = G14ReportBuilder()
                last_business_day = get_last_business_day_season(data_date)
                log.info("create G14 report , last_business_day={}".format(last_business_day))
                is_created, target_report = g14_report_builder.is_created_report(last_business_day)

                if force_create_g14_enabled == True:
                    g14_report = g14_report_builder.create_report(last_business_day)
                    if sftp_enabled:
                        sftp_put_file(g14_report.get_target_report())
                    result['report_path'] = g14_report.get_target_report()
                    result['message'] = 'G14 report is created successfully'

                if is_created == True:
                    result['report_path'] = target_report
                    result['message'] = 'G14 report for {} has been created. The generation will be skipped.'.format(
                        last_business_day)
                elif is_created == False and force_create_g14_enabled == False:
                    if is_runnable_date(data_date):
                        g14_report = g14_report_builder.create_report(last_business_day)
                        
                        if sftp_enabled:
                            sftp_put_file(g14_report.get_target_report())
                        result['report_path'] = g14_report.get_target_report()
                        result['message'] = 'G14 report is created successfully'
                    else:
                        result['report_path'] = target_report
                        result['message'] = 'The input date is invalid. Valid dates are on 11-18 of Jan, Apr, Jul and Oct. No G14 report is generated.'

                end_time = time.time()
                http_status = HTTPStatus.OK
                result['execution_time'] = round(end_time - start_time)
            except Exception as err:
                log.error(err, exc_info=True)
                http_status = HTTPStatus.INTERNAL_SERVER_ERROR
                result['message'] = str(err)
        else:
            http_status = HTTPStatus.OK
            result['message'] = 'The input date is a holiday. No G14 report is generated.'
    else:
        http_status = HTTPStatus.BAD_REQUEST
        result['message'] = 'Data date is invalid.'

    result['status'] = http_status

    if email_enabled and http_status != HTTPStatus.OK:
        send_report_failure_alert(data_date)
        result['message'] = result['message'] + ' Alert email is sent.'

    response = jsonify(result)
    log.info('response=%s', response)
    return response, http_status


def send_report_failure_alert(data_date):
    sender = None
    recipients = None
    if CFG_SUPPORT_MAIL_SENDER in app.config:
        sender = app.config[CFG_SUPPORT_MAIL_SENDER]
    if CFG_SUPPORT_MAIL_RECIPIENTS in app.config:
        recipients = app.config[CFG_SUPPORT_MAIL_RECIPIENTS]

    subject = '[FAILED] LRE EOC Failed {data_date}'.format(data_date=data_date)

    try:
        task_executor.send_email(subject=subject, sender=sender, recipients=recipients,
                                 html_body=render_template('report_failure_alert.html', data_date=data_date),
                                 app=report_bp, attachment_path=None)
    except Exception as err:
        log.error(err, exc_info=True)


def sftp_put_file(local_file):
    host = None
    port = None
    username = None
    private_key_path = None
    remote_dirs = None

    if CFG_SFTP_HOST in app.config:
        host = app.config[CFG_SFTP_HOST]
    if CFG_SFTP_PORT in app.config:
        port = app.config[CFG_SFTP_PORT]
    if CFG_SFTP_USER in app.config:
        username = app.config[CFG_SFTP_USER]
    if CFG_SFTP_PRIVATE_PATH in app.config:
        private_key_path = app.config[CFG_SFTP_PRIVATE_PATH]
    if CFG_SFTP_PUT_DIRS in app.config:
        remote_dirs = app.config[CFG_SFTP_PUT_DIRS]

    log.info("*** sftp put file to remote dirs")

    try:
        task_executor.sftp_put_file(host=host, port=port, username=username,
                                    private_key_path=private_key_path,
                                    local_file=local_file, remote_dirs=remote_dirs)
    except Exception as err:
        log.error(err, exc_info=True)
        raise RuntimeError(str(err))
