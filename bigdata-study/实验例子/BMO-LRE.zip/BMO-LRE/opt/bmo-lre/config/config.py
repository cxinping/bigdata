# -*- coding: utf-8 -*-

# The AES cryptographic key. It must be 16, 24 or 32 bytes long (respectively for AES-128, AES-192 or AES-256)
AES_KEY = "BMO's golden key"

# The Initialization Vector for AES CBC mode. It is as long as the block size (e.g. 16 bytes for AES)
AES_IV = "BMO's silver iv "

#SQLALCHEMY_DATABASE_URI = 'postgresql://bmo_lre:Q8YdiHZzkToHrqADcZgoYg==@10.119.61.146:5432/bmo_lre'  # test
SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:G7k//DXEGWDzLCrHAYJvRQ==@127.0.0.1:5432/testdb3'  # development

SQLALCHEMY_BINDS = {
    'rra':   'oracle://LREQUERY:6ET+0yoaJIt9bJor05AlPw==@10.119.61.15:1521/RRAU1?encoding=UTF-8&nencoding=UTF-8'  # sit
    #'rra':   'oracle://LREQUERY:6ET+0yoaJIt9bJor05AlPw==@10.119.61.174:1521/RRAD1?encoding=UTF-8&nencoding=UTF-8'   # test dev
}

#MAIL_RECIPIENTS = ['cbs.china@nesbittburns.com']

# 'rra':   'oracle://LREQUERY:6ET+0yoaJIt9bJor05AlPw==@10.119.61.174:1521/RRAD1'     以前用测试RRA库  dev
# 'rra':   'oracle://LREQUERY:6ET+0yoaJIt9bJor05AlPw==@10.119.61.15:1521/RRAU1'      本地开发, 可以造假数据 sit



