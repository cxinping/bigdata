# -*- coding: utf-8 -*- 

'''
    【简介】
	 演示程序图标例子
    
'''


import sys
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QWidget, QApplication

#1 创建一个名为 Icon的窗口类，继承自QWidget
class Icon(QWidget):  
    def __init__(self,  parent = None):  
        super(Icon,self).__init__(parent)    
        self.initUI()
     
    #2 初始化窗口
    def initUI(self):
        self.setGeometry(300,  300,  250,  150)  
        self.setWindowTitle('演示程序图标例子')  
        self.setWindowIcon(QIcon('./images/cartoon1.ico'))  
              
if __name__ == '__main__':   
    app = QApplication(sys.argv)
    icon = Icon()  
    icon.show()  
    sys.exit(app.exec())
