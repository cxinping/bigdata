# -*- coding: utf-8 -*-

'''
Created on

@author:
'''


from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()
