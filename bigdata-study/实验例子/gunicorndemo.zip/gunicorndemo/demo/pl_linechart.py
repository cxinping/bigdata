# -*- coding: utf-8 -*-

# 导入 pyplot模块，并起一个别名 plt
import matplotlib.pyplot as plt
# 设置X轴 的坐标为 [1,2,3]， 设置Y轴的坐标为 [3,2,1]
plt.plot( [1,2,3],[3,2,1] )
# 画图
plt.show()

