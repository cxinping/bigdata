## Prerequisites
* Python 3.6.8 which is officially provided by Redhat
* Flask 1.1.2
* openpyxl 3.0.5

pip install flask 
pip install flask-sqlalchemy
