需求
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:8443/secure/RapidBoard.jspa?rapidView=10062&projectKey=LRE&view=planning&selectedIssue=LRE-6&issueLimit=100

提交代码
http://10.119.61.92:7990/projects/LRE/repos/bmo-lre/browse
http://10.119.61.92:7990/projects/BMOSERV

查看当前任务
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:8443/secure/RapidBoard.jspa?rapidView=10062&projectKey=LRE&view=planning&selectedIssue=LRE-6&issueLimit=100
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:8443/secure/RapidBoard.jspa?rapidView=10062&view=planning&selectedIssue=LRE-6&issueLimit=100

BMOSXXX报表的文档
http://10.119.61.92:8090/display/KB/OTHER

report_sheet_models.py

流程引擎
Airflow

# 同时发布源码包和 whl 二进制包
python setup.py sdist bdist_wheel upload

## 打包项目
python setup.py sdist bdist_wheel

README.md
> pip install cx_oracle
> https://pypi.org/project/cx-Oracle/5.1.3/#files
> https://cloud.tencent.com/developer/article/1661831
> https://blog.51cto.com/1767340368/2092439
>
>  pip install Flask-Mail


#* flask-jwt-extended 3.24.1
#* Flask-Login 0.5.0

pip install celery

pip install eventlet


左屏幕
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:8443/secure/RapidBoard.jspa?rapidView=10062&projectKey=LRE&view=planning&selectedIssue=LRE-6&issueLimit=100
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:9443/pages/viewpage.action?pageId=29262568
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:9443/display/KB/Large+Risk+Exposure
https://www.processon.com/diagraming/5f9b74b95653bb3730919b0c
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:8443/issues/?filter=-1


LRE detail design
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:9443/display/KB/LRE+Detailed+Design

其他项目 UML 类图
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:9443/display/KB/Data+masking+standards

UML
https://www.visual-paradigm.com/guide/uml-unified-modeling-language/uml-class-diagram-tutorial/
https://www.jianshu.com/p/9163e2986334
https://www.shuzhiduo.com/A/xl56Dmkkzr/
https://rebooters.github.io/2019/05/22/UML-%E5%9F%BA%E7%A1%80%E7%BB%93%E6%9E%84/


PlantUML
https://www.shuzhiduo.com/A/xl56Dmkkzr/

右屏幕
http://10.119.61.92:7990/projects/LRE/repos/bmo-lre/browse
http://10.119.61.92:7990/projects/BMOSERV/repos/blacklist-matching/browse/blmatch
http://10.119.61.92:7990/projects/BMOSERV/repos/blacklist-matching/browse/blmatch/logging.py
http://10.119.61.102:9000/sonarqube/dashboard?id=com.bmo.lre
# 新增数据源 jira
https://10.119.61.92:8443/browse/RRA-1930?jql=resolution%20%3D%20Unresolved%20AND%20labels%20%3D%20LRE

************************ 重点学习： UML设计
https://www.visual-paradigm.com/guide/uml-unified-modeling-language/uml-class-diagram-tutorial/


日报表名称
Large Exposure Ratio Internal Monitoring Daily Report v2.9-20181231.xlsx




SELECT * FROM RRA_SIDS.s_gfi_cn_counterparty


select * from RRA_GBDS.GBDS_EX_RATE t where  rate_type = 'STAND' and 20201113 between s_date and E_date

1， 货币转换函数
select RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(20201113,
                                    'CNY',
                                   'USD',
                                   1,
                                   'STAND')
from dual

select    RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(20201102,
                                      'USD',
                                      'CNY',
                                      RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(20201102,
                                                                  'AUD',
                                                                  'USD',
                                                                  100,
                                                                  'STAND'),
                                      'SAFE_MID')
       END
  from dual

## 货币转换
select currency, (
    CASE
        WHEN t1.currency = 'CNY' THEN
            t1.available_credit_limit
	    WHEN
           t1.currency = 'USD' THEN
               RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(t1.data_date,
								  'USD',
								  'CNY',
								  t1.available_credit_limit,
								  'SAFE_MID')
        ELSE
              RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(t1.data_date,
								  'USD',
								  'CNY',
								  RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(t1.data_date,
															  t1.currency,
															  'USD',
															  t1.available_credit_limit,
															  'STAND'),
								  'SAFE_MID')
    END
)  available_credit_limit_cn
from RRA_SIDS.S_FLC_CREDIT_EXPOSURE  t1
where revocable = 'Irrevocable'  and customer_id = 600471 and data_date = 20200120


select * from RRA_GBDS.GBDS_EX_RATE where 20201103 between s_date and E_DATE and rate_type ='SAFE_MID'



### 产品
select * from RRA_SIDS.S_WSS_MM
where Type not in ('INTR' , 'CORP')
and Name_Short not in ( 'BMCNBJBEJ' , 'BMCNSHSHA' , 'BMOT3773' , 'BMCNHOBEJ' , 'BMCNGZGNZ' , 'EQUITY' , 'PBSCBEJ')
and Report_date != MAT_DATE and Report_date < Start_date
and deal_type = 'XL' and MAT_DATE > 20201103

2， 根据MM_CUST_NUM 转换 CBS_ID

select CMAP.CUSTOMER_NO, wmm.* from  RRA_SIDS.S_WSS_MM WMM
       LEFT JOIN (SELECT DATA_DATE,
                         DEAL_NUMBER,
                         AREA_CODE,
                         CUSTOMER_NO,
                         IBUK_GL_CODE,
                         PRIN_RESPTY
                    FROM RRA_SIDS.T_S_WSS_MM
                   WHERE DATA_DATE = 20201103) WMMT
          ON WMM.DATA_DATE = WMMT.DATA_DATE
         AND WMM.DEAL_NUMBER = WMMT.DEAL_NUMBER
         AND WMM.CBS_BU = WMMT.AREA_CODE --RRA-1217
       LEFT JOIN (SELECT SUBSTR(T1.REC_KEY, 1, 6) CUSTOMER_NO,T1.FIELD_VAL_26
                     FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T1,
                          RRA_SIDS.S_FLC_STTM_CUSTOMER T2 --RRA-1469
                    WHERE T1.FUNCTION_ID = 'STDCIF'
                      AND SUBSTR(T1.REC_KEY, 1, 6) = T2.CUSTOMER_NO --RRA-1469
                      AND T2.RECORD_STAT <> 'C' --RRA-1469
                      AND T1.DATA_DATE = 20201103
                      AND T2.DATA_DATE = 20201103 --RRA-1469
                      ) CMAP
          ON NVL(WMMT.CUSTOMER_NO, WMM.MM_CUST_NUM) = CMAP.FIELD_VAL_26
       WHERE WMM.DATA_DATE = 20201103
       and WMM.Customer_No = '4015'


# 计算产品 loan

SELECT  CBS_CUST_ID ,  SUM(interest_received_to_gl_cn)/ 10000 as sum_interest_received_to_gl,
    SUM(amount_cn ) / 10000 as sum_amount,
    ( SUM(interest_received_to_gl_cn)/ 10000 +  SUM(amount_cn ) / 10000  ) as sum_val
FROM (
    SELECT CBS_CUST_ID , STATUS, FINISHED, CURRENCY , DATA_DATE, (
        CASE
            WHEN t1.currency = 'CNY' THEN
                t1.interest_received_to_gl
            WHEN
               t1.currency = 'USD' THEN
                   RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(t1.data_date,
                                      'USD',
                                      'CNY',
                                      t1.interest_received_to_gl,
                                      'SAFE_MID')
            ELSE
                  RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(t1.data_date,
                                      'USD',
                                      'CNY',
                                      RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(t1.data_date,
                                                                  t1.currency,
                                                                  'USD',
                                                                  t1.interest_received_to_gl,
                                                                  'STAND'),
                                      'SAFE_MID')
        END
    )  interest_received_to_gl_cn , (
        CASE
            WHEN t1.currency = 'CNY' THEN
                t1.amount
            WHEN
               t1.currency = 'USD' THEN
                   RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(t1.data_date,
                                      'USD',
                                      'CNY',
                                      t1.amount,
                                      'SAFE_MID')
            ELSE
                  RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(t1.data_date,
                                      'USD',
                                      'CNY',
                                      RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(t1.data_date,
                                                                  t1.currency,
                                                                  'USD',
                                                                  t1.amount,
                                                                  'STAND'),
                                      'SAFE_MID')
        END
	)  amount_cn
    FROM RRA_SIDS.S_FLC_LOAN_DETAILS  t1
    WHERE status != 'EX' AND status != 'Expired'
    AND FINISHED is null
    AND DATA_DATE = 20200331
)
GROUP BY CBS_CUST_ID


最接近报表日期的 data_date
select MAX(data_date) from rra_sids.S_MAN_LLP where data_date <= '20200930'








