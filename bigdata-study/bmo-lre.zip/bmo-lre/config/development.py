# -*- coding: utf-8 -*-
'''
Created on 2020-10-28

@author: WangShuo
'''

DEBUG = True

# configure database information
SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:123456@127.0.0.1/testdb2'
SQLALCHEMY_TRACK_MODIFICATIONS = False
SQLALCHEMY_ECHO = True

SQLALCHEMY_BINDS = {
    'rra':   'oracle://LREQUERY:Dti_202011@10.119.61.174:1521/RRAD1'
}

# configure 表单机密密钥
SECRET_KEY = 'bmo123456'

# configure jwt 加密密钥
JWT_SECRET_KEY= 'bmo123456'




