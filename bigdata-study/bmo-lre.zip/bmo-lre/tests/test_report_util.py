# -*- coding: utf-8 -*-

"""
Created on 2020-12-02

@author: Wang Shuo
"""

import unittest
from bmolre.commons.report_utils import ReportDataDate, create_random_number
from bmolre.commons.util import get_current_time, convert_digital_precision, is_blank


class TestReportUtil(unittest.TestCase):
    def setUp(self):
        self.data_date = '20201202'

    def tearDown(self):
        pass

    def test_get_t_1_data_date(self):
        print('* run test_get_t_1_data_date()')
        t_1_data_date = ReportDataDate.get_t_1_data_date(self.data_date)
        self.assertEqual(t_1_data_date, '20201201')

    def test_get_current_time(self):
        print('* run test_get_current_time()')
        curr_time = get_current_time()
        self.assertIsNotNone(curr_time)

    def test_create_random_number(self):
        print('* run test_create_random_number()')
        uuid = create_random_number(len=10)
        self.assertIsNotNone(uuid)

    def test_convert_digital_precision(self):
        print('* run test_convert_digital_precision()')
        digital = convert_digital_precision(12.333)
        self.assertIsNotNone(digital)

    def test_is_blank(self):
        print('* run test_is_blank()')
        result = is_blank(None)
        self.assertTrue(result)


if __name__ == "__main__":
    unittest.main(verbosity=2)
