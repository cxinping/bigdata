# -*- coding: utf-8 -*-

"""
Created on 2020-12-02

@author: Wang Shuo
"""

import unittest
from bmolre import create_app
import os
import logging
from bmolre.commons.constant import CFG_DEBUG
from bmolre.commons.logging import get_logger


class TestLogger(unittest.TestCase):
    def setUp(self):
        os.environ[CFG_DEBUG] = 'True'

    def tearDown(self):
        os.environ.pop(CFG_DEBUG)

    def test_get_logger(self):
        logger = get_logger()
        self.assertEqual(logger.level, logging.DEBUG)


if __name__ == "__main__":
    unittest.main(verbosity=2)
