# -*- coding: utf-8 -*-

"""
Created on 2020-12-01

@author: Wang Shuo
"""

import unittest
from bmolre import create_app
from bmolre.services.data_services import DataService
from bmolre.commons.report_enums import RateSheetEnum
from bmolre.exts import db
from decimal import Decimal


class TestDataService(unittest.TestCase):
    def setUp(self):
        app = create_app(config_object='config.default', config_map={'TESTING': True})
        db.init_app(app)
        self.app = app
        self.data_service = DataService()
        self.data_date = '20200331'

    def tearDown(self):
        pass

    def test_query_rate_data(self):
        print('* run test_query_rate_data()')

        with self.app.app_context():
            ccy_rate_list = self.data_service.query_rate_data(self.data_date)

            for ccy_rate_item in ccy_rate_list:
                basic_ccy = ccy_rate_item[RateSheetEnum.BASIC_CCY.value]
                forward_ccy = ccy_rate_item[RateSheetEnum.FORWARD_CCY.value]
                ccy_rate = ccy_rate_item[RateSheetEnum.CCY_RATE.value]
                if basic_ccy == 'USD' and forward_ccy == 'CNY':
                    ccy_rate = Decimal(ccy_rate).quantize(Decimal('0.0000'))
                    target_ccy_rate = Decimal(7.0851).quantize(Decimal('0.0000'))
                    self.assertEqual(ccy_rate, target_ccy_rate)

    def test_query_loan_data(self):
        print('* run test_query_loan_data()')

        with self.app.app_context():
            loan_data = self.data_service.query_loan_data(self.data_date)
            self.assertIsNotNone(loan_data)

    def test_query_customer_list_report(self):
        print('* run test_query_customer_list_report()')

        with self.app.app_context():
            customer_data = self.data_service.query_customer_list_report(self.data_date)
            self.assertTrue(len(customer_data) >= 0)

    def test_query_indirect_customer_from_trade_finance_transaction(self):
        print('* run test_query_indirect_customer_from_trade_finance_transaction()')

        with self.app.app_context():
            customer_data = self.data_service.query_indirect_customer_from_trade_finance_transaction(self.data_date)
            self.assertTrue(len(customer_data) >= 0)

    def test_query_indirect_customer_from_s_gfi_cn_counterparty(self):
        print('* run test_query_indirect_customer_from_s_gfi_cn_counterparty()')
        with self.app.app_context():
            customer_data = self.data_service.query_indirect_customer_from_s_gfi_cn_counterparty(self.data_date)
            self.assertTrue(len(customer_data) >= 0)

    def test_query_capital_data(self):
        print('* run test_query_capital_data()')

        with self.app.app_context():
            self.data_date = '20201031'
            capital_data = self.data_service.query_capital_data(self.data_date)
            self.assertTrue(len(capital_data) >= 0)

    def test_query_ead_report_data(self):
        print('* run test_query_ead_report_data()')

        with self.app.app_context():
            ead_data = self.data_service.query_ead_report_data(self.data_date)
            self.assertTrue(len(ead_data) >= 0)

    def test_query_money_market_data(self):
        print('* run test_query_money_market_data()')

        with self.app.app_context():
            mm505_data = self.data_service.query_money_market_data(self.data_date)
            self.assertTrue(len(mm505_data) >= 0)

    def test_query_dsc_data(self):
        print('* run test_query_dsc_data()')

        with self.app.app_context():
            desc_data = self.data_service.query_dsc_data(self.data_date)
            self.assertTrue(len(desc_data) >= 0)

    def test_query_llp_data(self):
        print('* run test_query_llp_data()')

        with self.app.app_context():
            llp_data = self.data_service.query_llp_data(self.data_date)
            self.assertTrue(len(llp_data) >= 0)

    def test_query_nostro_data(self):
        print('* run test_query_nostro_data()')

        with self.app.app_context():
            nostro_data = self.data_service.query_nostro_data(self.data_date)
            self.assertTrue(len(nostro_data) >= 0)

    def test_query_limit_data(self):
        print('* run test_query_limit_data()')

        with self.app.app_context():
            limit_data = self.data_service.query_limit_data(self.data_date)
            self.assertTrue(len(limit_data) >= 0)

    def test_query_auto_fin_data(self):
        print('* run test_query_auto_fin_data()')

        with self.app.app_context():
            auto_fin_data = self.data_service.query_auto_fin_data(self.data_date)
            self.assertTrue(len(auto_fin_data) >= 0)

    def test_query_offbs_tf_data(self):
        print('* run test_query_offbs_tf_data()')

        with self.app.app_context():
            offbs_tf_fin_data = self.data_service.query_offbs_tf_data(self.data_date)
            self.assertTrue(len(offbs_tf_fin_data) >= 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
