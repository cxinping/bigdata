# -*- coding: utf-8 -*-

"""
Created on 2020-11-27

@author: Wang Shuo
"""

import unittest
from bmolre import create_app
from bmolre.services.report_cal_services import ReportService
from bmolre.exts import db


class TestReportService(unittest.TestCase):
    def setUp(self):
        app = create_app(config_object='config.default', config_map={'TESTING': True})
        db.init_app(app)
        self.app = app
        self.report_service = ReportService()
        self.data_date = '20200331'

    def tearDown(self):
        pass

    def test_init_rate_data(self):
        print('* run test_init_rate_data()')

        with self.app.app_context():
            rate_data = self.report_service.init_rate_data(self.data_date)
            self.assertIsNotNone(rate_data)

    def test_cal_loan_data(self):
        print('* run test_cal_loan_data()')

        with self.app.app_context():
            loan_cn_data = self.report_service.query_loan_data(data_date=self.data_date)
            self.assertIsNotNone(loan_cn_data)

    def test_query_capital_data(self):
        print('* run test_query_capital_data()')
        self.data_date = '20200331'

        with self.app.app_context():
            try:
                capital_data = self.report_service.query_capital_data(data_date=self.data_date)
                self.assertIsNotNone(capital_data)
            except Exception as err:
                print(str(err))

    def test_query_money_market_data(self):
        print('* run test_query_money_market_data()')
        self.data_date = '20200331'

        with self.app.app_context():
            try:
                mm505_data = self.report_service.query_money_market_data(data_date=self.data_date)
                self.assertIsNotNone(mm505_data)
            except Exception as err:
                print(str(err))

    def test_query_dsc_data(self):
        print('* run test_query_dsc_data()')
        self.data_date = '20200331'

        with self.app.app_context():
            try:
                dsc_data = self.report_service.query_dsc_data(data_date=self.data_date)
                self.assertIsNotNone(dsc_data)
            except Exception as err:
                print(str(err))

    def test_query_llp_data(self):
        print('* run test_query_llp_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                llp_data = self.report_service.query_llp_data(data_date=self.data_date)
                self.assertIsNotNone(llp_data)
            except Exception as err:
                print(str(err))

    def test_cal_limit_data(self):
        print('* run test_cal_limit_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                limit_data = self.report_service.cal_limit_data(data_date=self.data_date)
                self.assertIsNotNone(limit_data)
            except Exception as err:
                print(str(err))

    def test_query_auto_fin_data(self):
        print('* run test_query_auto_fin_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                auto_fin_data = self.report_service.query_auto_fin_data(data_date=self.data_date)
                self.assertIsNotNone(auto_fin_data)
            except Exception as err:
                print(str(err))

    def test_query_offbs_tf_data(self):
        print('* run test_query_offbs_tf_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                offbs_tf_data = self.report_service.query_offbs_tf_data(data_date=self.data_date)
                self.assertIsNotNone(offbs_tf_data)
            except Exception as err:
                print(str(err))

    def test_query_bond_ncd_data(self):
        print('* run test_query_bond_ncd_data()')
        self.data_date = '20200331'
        with self.app.app_context():
            try:
                offbs_tf_data = self.report_service.query_bond_ncd_data(data_date=self.data_date)
                self.assertIsNotNone(offbs_tf_data)
            except Exception as err:
                print(str(err))


if __name__ == "__main__":
    unittest.main(verbosity=2)
