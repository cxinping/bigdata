# -*- coding: utf-8 -*-

"""
Created on 2020-11-13

@author: Wang Shuo
"""

from bmolre.commons.util import db_fetch_to_dict
from bmolre.commons.logging import get_logger

log = get_logger()


def query_ccy_rate_data(data_date):
    """ 查询普通货币到USD的汇率 rate
    :param data_date : 查询时间
    :return: 其他货币到USD的汇率的列表
    """

    query_sql = "SELECT * FROM RRA_GBDS.GBDS_EX_RATE WHERE RATE_TYPE = 'STAND' AND S_DATE = :data_date"
    return db_fetch_to_dict(query_sql, params={'data_date': data_date}, fecth='all', bind='rra')


def query_safe_mid_rate_data(data_date, basic_ccy='USD', forward_ccy='CNY'):
    """ 查询USD到CNY的货币汇率 rate
    :param data_date : 查询时间
    :param basic_ccy :
    :param forward_ccy :
    :return: 查询USD到CNY的货币汇率的列表
    """

    query_sql = '''
    SELECT * FROM RRA_GBDS.GBDS_EX_RATE WHERE S_DATE = :data_date AND RATE_TYPE ='SAFE_MID'
        AND BASIC_CCY = :basic_ccy AND FORWARD_CCY = :forward_ccy
    '''
    return db_fetch_to_dict(query_sql,
                            params={'data_date': data_date, 'basic_ccy': basic_ccy, 'forward_ccy': forward_ccy},
                            fecth='one', bind='rra')


def change_foreign_currency_to_cny(date_date, foreign_ccy, amount):
    """ 转换外币到人民币，先把外币转换成美元，在把美元转换成人民币
    :param date_date : 查询时间
    :param foreign_ccy :
    :param amount :
    :return: 查询USD到CNY的货币汇率的列表
    """
    query_sql = """
      SELECT    RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV({date_date},
                                          'USD',
                                          'CNY',
                                          RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV({date_date},
                                                                      '{foreign_ccy}',
                                                                      'USD',
                                                                      {amount},
                                                                      'STAND'),
                                          'SAFE_MID')
           END
      FROM dual
    """.format(date_date=date_date, foreign_ccy=foreign_ccy, amount=amount)

    return db_fetch_to_dict(query_sql, params=None,
                            fecth='one', bind='rra')


def query_loan_data(data_date):
    query_sql = """
    SELECT cbs_cust_id, amount , currency, interest_received_to_gl
    FROM RRA_SIDS.S_FLC_LOAN_DETAILS WHERE lower(status) != 'ex' AND lower(status) != 'expired' 
    AND finished is null 
    AND data_date = :data_date    
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_customer_list_report(data_date):
    """
    4.1.2.3.1 Extract BMO Customer to LRE Calculation
    In the working file, BMO Customer data use RRA BMOS0008 customer list report as data source.
    Select customer with Status = O in BMOS0008.
    :param data_date: 取数日期
    """
    query_sql = """    
        with Table_1 as
         (SELECT T1.DATA_DATE DATA_DATE, --25 DATA_DATE
                 T1.LOCAL_BRANCH, --1.LOCAL_BRANCH
                 T1.CUSTOMER_NO CBS_ID, --2.CBS_ID
                 LPAD(TRIM(T2.FIELD_VAL_52), 10, '0') CIF_ID, --CIF_ID
                 T3.IBUK_ID WSS_ID, --3.WSS_ID
                 T3.PIX_ID, --4.PIX_ID
                 T2.FIELD_VAL_39 OTL_ID, --6.OTL_ID
                 T1.CHINESE_NAME CUSTOMER_NAME_CN, --8.CUSTOMER_NAME_CN
                 DECODE(LENGTH(T2.FIELD_VAL_16), 18, T2.FIELD_VAL_16, null) UNIFORM_SOCIAL_CREDIT_CODE1, --7 UNIFORM_SOCIAL_CREDIT_CODE --=If Length([UNIFORM_SOCIAL_CREDIT_CODE1])=18 Then [UNIFORM_SOCIAL_CREDIT_CODE1] Else Max([UNIFORM_SOCIAL_CREDIT_CODE2])
                 T1.CUSTOMER_NAME1 CUSTOMER_NAME_EN, --9.CUSTOMER_NAME_EN
                 T1.CUSTOMER_CATEGORY, --10.CUSTOMER_CATEGORY
                 T1.NATIONALITY, --11.NATIONALITY
                 T1.COUNTRY, --12.COUNTRY
                 T1.EXPOSURE_COUNTRY, --13.EXPOSURE_COUNTRY
                 T2.FIELD_VAL_1 AREA, --14.AREA
                 T2.FIELD_VAL_5 CORP_TYPE, --15.CORP_TYPE
                 T2.FIELD_VAL_10 CORP_SIZE, --16.CORP_SIZE
                 T2.FIELD_VAL_4 INDUSTRY_CODE, --17.INDUSTRY_CODE
                 T2.FIELD_VAL_58 HOLDING_TYPE, --18.HOLDING_TYPE
                 T1.UNIQUE_ID_VALUE UNIQUE_ID_VALUE, --19.UNIQUE_ID_VALUE
                 T4.GROUP_ID GROUP_CODE, --20.GROUP_CODE
                 T1.RECORD_STAT STATUS, --23.STATUS
                 decode(T1.DATA_DATE, null, 'CMS', 'CMS')
            FROM RRA_SIDS.S_FLC_STTM_CUSTOMER T1
            left join RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T2
              ON T1.CUSTOMER_NO = SUBSTR(T2.REC_KEY(+), 1, 6)
             AND T1.DATA_DATE = T2.DATA_DATE
            left join RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
              ON T1.CUSTOMER_NO = T3.CBS_ID
             AND T1.DATA_DATE = T3.DATA_DATE
            left join RRA_SIDS.S_FLC_STTM_CUST_GROUP T4
              ON T1.CUSTOMER_NO = T4.CUSTOMER_NO
             AND T1.DATA_DATE = T4.DATA_DATE
           WHERE T1.RECORD_STAT IN ('C', 'O')
             AND T2.FUNCTION_ID = 'STDCIF'
             and T1.AUTH_STAT = 'A'
             AND T1.CUSTOMER_CATEGORY IN
                 ('NBFI', 'BANK', 'INTERNAL', 'CORPORATE', 'INDIVIDUAL')
             AND T1.DATA_DATE = :data_date),
        
        Table_2 as
         (SELECT distinct CIF_NO    CIF_ID, --CIF_ID 与表1关联字段CIF_ID
                          UEN_NO    UEN, --5.UEN
                          DATA_DATE
            FROM RRA_SIDS.S_UEN_CHINA
           WHERE DATA_DATE = (select max(data_date)
                                from RRA_SIDS.S_UEN_CHINA
                               where data_date <= :data_date)
          UNION
          SELECT distinct CIF_NO, UEN_NO, DATA_DATE
            FROM RRA_SIDS.S_UEN_NA
           WHERE DATA_DATE = (select max(data_date)
                                from RRA_SIDS.S_UEN_NA
                               where data_date <= :data_date)
          
          UNION
          SELECT distinct LPAD(TRIM(CIF_NO), 10, 0) CIF_NO, PARENT_UEN, DATA_DATE
            FROM RRA_SIDS.S_UEN_BRANCH
           WHERE DATA_DATE = (select max(data_date)
                                from RRA_SIDS.S_UEN_BRANCH
                               where data_date <= :data_date)),
        Table_3 as
         (
          
          SELECT distinct T1.GROUP_ID GROUP_CODE, --与表1关联字段
                           T2.GROUP_NAME GROUP_CHINESE_NAME, --22.GROUP_CHINESE_NAME
                           T1.DATA_DATE,
                           decode(T2.GROUP_NAME, null, null, null) GROUP_NAME
            FROM RRA_SIDS.S_FLC_STTM_CUST_GROUP T1
            left join RRA_SIDS.S_FLC_STTM_GROUP T2
              ON T1.GROUP_ID = T2.GROUP_ID
          
           WHERE T1.DATA_DATE = :data_date
             and T1.DATA_DATE = T2.DATA_DATE
          
          ),
        table_4 as
         (SELECT distinct T1.DATA_DATE,
                          SUBSTR(T1.REC_KEY, 1, 6) REC_KEY, --  与表1关联字段CBS_ID
                          LPAD(TRIM(T1.FIELD_VAL_52), 10, '0') CIF_ID,
                          nvl(T2.RRA_CODE, '100000') FINA_CODE_Bank,
                          nvl(T3.RRA_CODE, '200000') FINA_CODE_NBFI,
                          T4.BUSINESS_LIC UNIFORM_SOCIAL_CREDIT_CODE2
            FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T1
            left join RRA_SIDS.MAP_S_G_CODE T2
              ON T1.FIELD_VAL_2 = T2.SOURCE_CODE
             and T2.TYPE_CODE = 'FINA_CODE'
             and T1.FUNCTION_ID = 'STDCIF'
            left join RRA_SIDS.MAP_S_G_CODE T3
              ON T1.FIELD_VAL_7 = T3.SOURCE_DESCRIPTION_CN
             and T3.TYPE_CODE = 'FINA_CODE'
            left join RRA_SIDS.S_CMCIF_CUST_INFO T4
              ON LPAD(TRIM(T1.FIELD_VAL_52), 10, '0') =
                 LPAD(TRIM(T4.CIF_ID), 10, '0')
             and length(T4.BUSINESS_LIC) = 18
           WHERE T1.DATA_DATE = :data_date
             AND T4.DATA_DATE IN (SELECT max(DATA_DATE)
                                    FROM RRA_SIDS.S_CMCIF_CUST_INFO
                                   WHERE length(BUSINESS_LIC) = 18
                                     AND DATA_DATE <= :data_date)
          
          )
        
        SELECT A.LOCAL_BRANCH, --1
               A.CBS_ID, --2
               A.WSS_ID, --3
               A.PIX_ID, --4
               B.UEN, --5
               A.OTL_ID, --6
               CASE
                 WHEN LENGTH(A.UNIFORM_SOCIAL_CREDIT_CODE1) = 18 THEN
                  A.UNIFORM_SOCIAL_CREDIT_CODE1
                 ELSE
                  D.UNIFORM_SOCIAL_CREDIT_CODE2
               END UNIFORM_SOCIAL_CREDIT_CODE, --7
               A.CUSTOMER_NAME_CN, --8
               A.CUSTOMER_NAME_EN, --9
               A.CUSTOMER_CATEGORY, --10
               A.NATIONALITY, --11
               A.COUNTRY, --12
               A.EXPOSURE_COUNTRY, --13
               A.AREA, --14
               A.CORP_TYPE, --15
               A.CORP_SIZE, --16
               A.INDUSTRY_CODE, --17
               A.HOLDING_TYPE, --18
               A.UNIQUE_ID_VALUE, --19
               A.GROUP_CODE, --20
               C.GROUP_NAME, --21
               C.GROUP_CHINESE_NAME, --22
               A.STATUS, --23
               A.DATA_DATE
        
          FROM TABLE_1 A
          LEFT JOIN TABLE_2 B
            ON A.CIF_ID = B.CIF_ID
          LEFT JOIN TABLE_3 C
            ON A.GROUP_CODE = C.GROUP_CODE
          LEFT JOIN TABLE_4 D
            ON A.CBS_ID = D.REC_KEY    
          WHERE A.STATUS='O'  -- Select customer with Status = O in BMOS0008
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_indirect_customer_from_trade_finance_transaction(data_date):
    """
    4.1.2.3.2.1 Extract Indirect Customer Data to LRE Calculation - Limit Customer from Trade Finance Transaction and Issuer from Bond/NCD
    Limit Customer from Trade Finance Transaction
    Source: Limit customer of trade finance deal transaction.
    Reference : RRA report BMOS0018
    :param data_date: 取数日期
    """

    query_sql = """
        with TB_UEN as
         (select distinct DATA_DATE, UEN_NO, CIF_NO, LEGAL_NAME, RISK_COUNTRY
            from (SELECT DATA_DATE, UEN_NO, CIF_NO, LEGAL_NAME, RISK_COUNTRY
                    FROM RRA_SIDS.S_UEN_NA
                   WHERE DATA_DATE IN (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_UEN_NA
                                        where data_date <= 20200331)
                  UNION ALL
                  SELECT DATA_DATE, UEN_NO, CIF_NO, LEGAL_NAME, RISK_COUNTRY
                    FROM RRA_SIDS.S_UEN_CHINA
                   WHERE DATA_DATE IN (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_UEN_CHINA
                                        where data_date <= 20200331)) uen
          
           where not exists (select 1
                    from RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T0
                   where uen.CIF_NO = LPAD(TRIM(T0.FIELD_VAL_52), 10, '0')
                     and T0.data_date = :data_date)
             and uen.UEN_NO is NOT null)
        
        select distinct null CBS_ID,
               T1.data_date,
               T1.UEN_NO UEN,
               T3.LIMIT_CUSTOMER_ID OTL_ID,
               NULL CUSTOMER_NAME_CN,
               T1.LEGAL_NAME CUSTOMER_NAME_EN,
               'BANK' CUSTOMER_CATEGORY,
               NULL NATIONALITY,
               NULL COUNTRY,
               T1.RISK_COUNTRY EXPOSURE_COUNTRY,
               
               NULL             GROUP_CODE,
               NULL             GROUP_NAME,
               T2.RISKPARTY_UEN UNIFORM_SOCIAL_CREDIT_CODE,
               NULL             UNIQUE_ID_VALUE
          from tb_uen T1
          left join rra_inx.REP_ME_DISCOUNT_DB T2
            ON T2.RISKPARTY_UEN = T1.UEN_NO
           and T2.Report_Date = :data_date
          left join rra_sids.S_PIX_CNPAYUS T3
            ON T2.OUR_REF = T3.Instrument_ID
           and T3.data_date = :data_date
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_indirect_customer_from_s_gfi_cn_counterparty(data_date):
    """
    4.1.2.3.2.2 Extract Indirect Customer Data to LRE Calculation - Issuer from Bond/NCD
    Issuer from Bond/NCD
    Source: RRA table s_gfi_cn_counterparty
    :param data_date: 取数日期
    """
    query_sql = """
        SELECT null cbs_id,
           CUSTOMER_UEN UEN,
           null OTL_ID,
           null CUSTOMER_NAME_CN,
           CUSTOMER_NAME CUSTOMER_NAME_EN,
           case
             when UPPER(BANK_INDICATOR) = 'BANK' THEN
              'BANK'
             when UPPER(BANK_INDICATOR) = 'NONBANK' then
              'CORPORATE'
             else
              null
           END CUSTOMER_CATEGORY,
           null EXPOSURE_COUNTRY,
           null GROUP_CODE,
           null GROUP_NAME,
           CUSTOMER_UEN UNIFORM_SOCIAL_CREDIT_CODE,
           null UNIQUE_ID_VALUE
      FROM RRA_SIDS.S_GFI_CN_COUNTERPARTY T_GFI
     WHERE CLOSE_DATE IS NULL
       AND CUSTOMER_UEN IS NOT NULL
       AND DATA_DATE = to_char(to_date( :data_date , 'YYYYMMDD') - 1, 'YYYYMMDD')
       AND NOT EXISTS
     (SELECT 1
              FROM (SELECT T1.UEN_NO, T1.CIF_NO
                      FROM (SELECT UEN_NO, CIF_NO
                              FROM RRA_SIDS.S_UEN_NA
                             WHERE DATA_DATE IN
                                   (SELECT MAX(DATA_DATE)
                                      FROM RRA_SIDS.S_UEN_NA
                                     where DATA_DATE <= :data_date )
                            UNION ALL
                            SELECT UEN_NO, CIF_NO
                              FROM RRA_SIDS.S_UEN_CHINA
                             WHERE DATA_DATE IN
                                   (SELECT MAX(DATA_DATE) FROM RRA_SIDS.S_UEN_CHINA
                             where DATA_DATE <= :data_date )) T1
                     INNER JOIN RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T2
                        ON T1.CIF_NO = LPAD(TRIM(T2.FIELD_VAL_52), 10, '0')
                       AND T2.DATA_DATE = :data_date ) T_UEN
             WHERE T_GFI.CUSTOMER_UEN = T_UEN.UEN_NO)
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_capital_data(data_date):
    """
    查询资本净额和一级资本净额
    :param data_date: 取数日期
    """

    query_sql = """
    SELECT * FROM rra_sids.S_MAN_FIN_CAPITAL WHERE data_date = :data_date        
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='one', bind='rra')


def query_ead_report_data(data_date):
    """
    查询 EAD report数据
    :param data_date: 取数日期
    """

    query_sql = """
        -- EAD为月报，日期参数，为每个月的最后一天 
        
        select DATA_DATE,
               COUNTERPARTY_LONG_NAME,
               COUNTERPARTY_TYPE,
               IBUK_CUSTOMER_NUMBER,
               sum(EAD_USD) EAD_USD,
               CBS_CIF_ID,
               UEN
          from (SELECT substr(:data_date, 0, 6) DATA_DATE,
                       T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
                       T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
                       T2.IBUK_CUST_NO IBUK_CUSTOMER_NUMBER, --3
                       RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                   'CAD',
                                                   'USD',
                                                   T1.EAD,
                                                   'STAND') EAD_USD, --4
                       T4.CUSTOMER_NO CBS_CIF_ID, --5
                       TO_CHAR(T1.UEN) UEN --6
                  FROM RRA_SIDS.S_MAN_SACCR T1
                  LEFT JOIN RRA_SIDS.S_WSS_FX T2
                    ON SUBSTR(T1.TRADE_ID, 3, 2) = SUBSTR(T2.AREA_CODE, 1, 2)
                   AND SUBSTR(T1.TRADE_ID, 7, 13) = T2.DEAL_NUMBER
                   AND T2.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_WSS_FX
                                        WHERE DATA_DATE <= :data_date)
                  LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
                    ON T2.IBUK_CUST_NO = T3.IBUK_ID
                   AND T3.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_CBI_T_CMN_CUST_INF
                                        WHERE DATA_DATE <= :data_date) --RRA-1570
                  LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
                    ON T3.CBS_ID = T4.CUSTOMER_NO
                   AND T4.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_FLC_STTM_CUSTOMER
                                        WHERE DATA_DATE <= :data_date) --RRA-1570
                 WHERE T1.DATA_DATE = :data_date
                   AND T1.SRC_SYS_CD = 'WSS'
                UNION ALL
                --Simple Option TRACE
                SELECT substr(:data_date, 0, 6) DATA_DATE,
                       T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
                       T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
                       T3.IBUK_ID IBUK_CUSTOMER_NUMBER, --3
                       RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                   'CAD',
                                                   'USD',
                                                   T1.EAD,
                                                   'STAND') EAD_USD, --4
                       T2.V_MXG_CUST_REF_CODE CBS_CIF_ID, --5
                       TO_CHAR(T1.UEN) UEN --6
                  FROM RRA_SIDS.S_MAN_SACCR T1
                  LEFT JOIN RRA_GBDS.GDBS_T_UPS_OUT_MXG4SAFE T2
                    ON T1.TRADE_ID = T2.TRADE_ID
                   AND T2.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_GBDS.GDBS_T_UPS_OUT_MXG4SAFE --RRA-1833
                                        WHERE DATA_DATE <= :data_date)
                  LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
                    ON T2.V_MXG_CUST_REF_CODE = T3.CBS_ID
                   AND T3.DATA_DATE =
                       (SELECT MAX(DATA_DATE)
                          FROM RRA_SIDS.S_CBI_T_CMN_CUST_INF
                         WHERE DATA_DATE <= ':data_date') --RRA-1570
                  LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
                    ON T2.V_MXG_CUST_REF_CODE = T4.CUSTOMER_NO
                   AND T4.DATA_DATE = (SELECT MAX(DATA_DATE)
                                       
                                         FROM RRA_SIDS.S_FLC_STTM_CUSTOMER
                                        WHERE DATA_DATE <= :data_date) --RRA-1570
                 WHERE T1.DATA_DATE = :data_date
                   AND T1.SRC_SYS_CD = 'CURRPLUS'
                   AND T1.INSTM_TYPE <> 'WRTOPT'
                UNION ALL
                --Barrier Option:
                SELECT substr(:data_date, 0, 6) DATA_DATE,
                       T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
                       T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
                       T1.IBUK IBUK_CUSTOMER_NUMBER, --3
                       T1.USD_EQUIVALENT EAD_USD, --4
                       T4.CUSTOMER_NO CBS_CIF_ID, --5
                       T5.UEN_NO UEN --6
                  FROM RRA_SIDS.S_MAN_BARRIER_OPTION_REGISTER T1
                  LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
                    ON T1.IBUK = T3.IBUK_ID
                   AND T3.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_CBI_T_CMN_CUST_INF
                                        WHERE DATA_DATE <= :data_date) --RRA-1570
                  LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
                    ON T3.CBS_ID = T4.CUSTOMER_NO
                   AND T4.DATA_DATE = (SELECT MAX(DATA_DATE)
                                         FROM RRA_SIDS.S_FLC_STTM_CUSTOMER
                                        WHERE DATA_DATE <= :data_date) --RRA-1570
                  LEFT JOIN RRA_GBDS.GBDS_BIZ_CUST_INFO T5
                    ON T3.CBS_ID = T5.CUST_NUM
                   AND :data_date BETWEEN T5.S_DATE AND T5.E_DATE
                 WHERE T1.DATA_DATE = :data_date
                   AND T1.EXPIRY_DATE > TO_DATE(:data_date, 'YYYY/MM/DD')
                   AND T1."B/S" = 'B')
         group by DATA_DATE,
                  COUNTERPARTY_LONG_NAME,
                  COUNTERPARTY_TYPE,
                  IBUK_CUSTOMER_NUMBER,
                  CBS_CIF_ID,
                  UEN

    
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_money_market_data(data_date):
    """
    4.1.3.1 MM505 daily
    查询 ＭＭ 505 数据
    :param data_date: 取数日期
    """
    query_sql = """
    ----4.1.3.1 MM505 daily

    select T2.CBS_ID,
           T1.Report_Date,
           T1.START_DATE Value_Date,
           Mat_Date,
           Deal_Type,
           Deal_Type Deal_Type_RRA,
           Ccy,
           PRINCIPAL_AMT Amount,
           TOTAL_INTEREST,
           Name_Short,
           TYPE,
           MM_CUST_NUM,
           'Y' Inventory,
           MM_CUST_NUM Customer_Short_Name,
           T2.CBS_ID,
           CASE
             WHEN t1.ccy = 'CNY' THEN
              T1.PRINCIPAL_AMT
             ELSE
              RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                          'USD',
                                          'CNY',
                                          RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                      T1.CCY,
                                                                      'USD',
                                                                      T1.PRINCIPAL_AMT,
                                                                      'STAND'),
                                          'SAFE_MID')
           END CNY_EQV,
           case
             when to_date(:data_date, 'YYYYMMDD') -
                  to_date(Start_date, 'YYYYMMDD') + 1 < 0 THEN
              0
             else
              decode(substr(BASIS_CODE, -3),
                     0,
                     0,
                     ((CASE
                       WHEN t1.ccy = 'CNY' THEN
                        T1.PRINCIPAL_AMT
                     
                       ELSE
                        RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                    'USD',
                                                    'CNY',
                                                    RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                                T1.CCY,
                                                                                'USD',
                                                                                T1.PRINCIPAL_AMT,
                                                                                'STAND'),
                                                    'SAFE_MID')
                     END) * Rate * (to_date(:data_date, 'YYYYMMDD') -
                     to_date(Start_date, 'YYYYMMDD') + 1)) /
                     substr(BASIS_CODE, -3) / 100)
           END interest_AMT --MM 505Lending/placing
    
      from rra_sids.S_WSS_MM T1
      left join rra_sids.s_cbi_t_cmn_cust_inf T2
        on T1.Mm_Cust_Num = T2.Ibuk_Id
       and T2.Data_Date = :data_date
     where T1.data_date = :data_date
       and (T1.TYPE NOT in ('INTR', 'CORP') and
           T1.Name_Short NOT IN ('BMCNBJBEJ',
                                  'BMCNSHSHA',
                                  'BMOT3773',
                                  'BMCNHOBEJ',
                                  'BMCNGZGNZ',
                                  'EQUITY',
                                  'PBCS BEJ'))
       and T1.MAT_DATE > T1.data_date
       and T1.Deal_type = 'XL'

    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_dsc_data(data_date):
    """
    查询 DSC 数据
    :param data_date: 取数日期
    """

    query_sql = """        
        select RISKPARTY_CBSID CBS_ID,
               BENEFICIARY_CBS_ID,  
               RISKPARTY_UEN,
               RISKPARTY_CBSID,
               PRODUCT,
               WITH_BANK_CUSTOMER,
               RISKPARTY_CBSID RISKPARTY_CBSID2,
               RISKPARTY_UEN RISKPARTY_UEN2,
               CURRENCY,
               AMOUNT,
               INTEREST_IN_ADVANCE,
               INCOME_ACCRUAL_AMOUNT
          from rra_inx.REP_ME_DISCOUNT_DB T
         where report_date = :data_date
           and T.With_Bank_Customer = 'DSC'
           and TO_CHAR(PRINCIPAL_MATURITY_DATE, 'YYYYMMDD') > :data_date
     """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_llp_data(data_date):
    """
    查询 BMOS0001 LLP detail数据
    :param data_date: 取数日期
    """

    query_sql = """
    select BRANCH, BSOFFBS, DEAL_TYPE,UEN, CCY_CNY_USD, PROV_AMT
      from (SELECT BRANCH_NAME_EN         BRANCH, --1
                   BALANCE_SHEET          BSOFFBS, --2
                   DEAL_TYPE, --3
                   TRANS_REF              Transaction_Ref, --4
                   RISK_PARTY, --5
                   UEN, --6
                   CURRENCY, --7
                   AMOUNT, --8
                   VALUE_DATE, --9
                   MATURTIY_DATE, --10
                   GL_NUMBER, --11
                   TRANSIT_CODE, --12
                   COUNTRY_NAME, --13
                   RESIDENT, --14
                   AUTH_AMOUNT, --15
                   BRR                    Master_Scle_BRR, --16
                   GRADE_5, --17
                   PROV_RATIO             Provision_Ratio, --18
                   PROV_AMT_ORI_CCY, --19
                   CCY_CNY_USD, --20
                   OUT_STAND, --21
                   PROV_AMT, --22
                   OUT_STAND_CNY, --23
                   PROV_AMT_CNY, --24
                   LOAD_OUT_STAND_ORI_CCY, --25 
                   OUT_STAND_CNY_USD, --26
                   LOAD_OUT_STAND_USD, --27
                   LOAD_PROV_ORI_CCY, --28
                   LOAD_PROV_USD, --29
                   COMMITTED_LOAN_TYPE, --30
                   LOAN_PROV_RATIO, --31
                   LOAN_FLAG, --32
                   LGD, --33
                   EAD, --34
                   PD --35
              FROM RRA_GBDS.GBDS_CORP_LOAN
             WHERE DATA_DATE = :data_date
            UNION
            SELECT BRANCH_NAME_EN,
                   BALANCE_SHEET,
                   DEAL_TYPE,
                   TRANS_REF,
                   RISK_PARTY,
                   UEN,
                   CURRENCY,
                   AMOUNT,
                   VALUE_DATE,
                   MATURTIY_DATE,
                   GL_NUMBER,
                   TRANSIT_CODE,
                   COUNTRY_NAME,
                   RESIDENT,
                   AUTH_AMOUNT,
                   BRR,
                   GRADE_5,
                   PROV_RATIO,
                   PROV_AMT_ORI_CCY,
                   CCY_CNY_USD,
                   OUT_STAND,
                   PROV_AMT,
                   OUT_STAND_CNY,
                   PROV_AMT_CNY,
                   LOAD_OUT_STAND_ORI_CCY,
                   OUT_STAND_CNY_USD,
                   LOAD_OUT_STAND_USD,
                   LOAD_PROV_ORI_CCY,
                   LOAD_PROV_USD,
                   COMMITTED_LOAN_TYPE,
                   LOAN_PROV_RATIO,
                   LOAN_FLAG,
                   LGD,
                   EAD,
                   PD
              FROM RRA_GBDS.GBDS_INTERBANK_LENDING
             WHERE DATA_DATE = :data_date
            UNION
            SELECT BRANCH_NAME_EN,
                   BALANCE_SHEET,
                   DEAL_TYPE,
                   TRANS_REF,
                   RISK_PARTY,
                   UEN,
                   CURRENCY,
                   AMOUNT,
                   VALUE_DATE,
                   MATURTIY_DATE,
                   GL_NUMBER,
                   TRANSIT_CODE,
                   COUNTRY_NAME,
                   RESIDENT,
                   AUTH_AMOUNT,
                   BRR,
                   GRADE_5,
                   PROV_RATIO,
                   PROV_AMT_ORI_CCY,
                   CCY_CNY_USD,
                   OUT_STAND,
                   PROV_AMT,
                   OUT_STAND_CNY,
                   PROV_AMT_CNY,
                   LOAD_OUT_STAND_ORI_CCY,
                   OUT_STAND_CNY_USD,
                   LOAD_OUT_STAND_USD,
                   LOAD_PROV_ORI_CCY,
                   LOAD_PROV_USD,
                   COMMITTED_LOAN_TYPE,
                   LOAN_PROV_RATIO,
                   LOAN_FLAG,
                   LGD,
                   EAD,
                   PD
              FROM RRA_GBDS.GBDS_TF_OFF_BS
             WHERE DATA_DATE = :data_date
            UNION
            SELECT BRANCH_NAME_EN,
                   BALANCE_SHEET,
                   DEAL_TYPE,
                   TRANS_REF,
                   RISK_PARTY,
                   UEN,
                   CURRENCY,
                   AMOUNT,
                   VALUE_DATE,
                   MATURTIY_DATE,
                   GL_NUMBER,
                   TRANSIT_CODE,
                   COUNTRY_NAME,
                   RESIDENT,
                   AUTH_AMOUNT,
                   BRR,
                   GRADE_5,
                   PROV_RATIO,
                   PROV_AMT_ORI_CCY,
                   CCY_CNY_USD,
                   OUT_STAND,
                   PROV_AMT,
                   OUT_STAND_CNY,
                   PROV_AMT_CNY,
                   LOAD_OUT_STAND_ORI_CCY,
                   OUT_STAND_CNY_USD,
                   LOAD_OUT_STAND_USD,
                   LOAD_PROV_ORI_CCY,
                   LOAD_PROV_USD,
                   COMMITTED_LOAN_TYPE,
                   LOAN_PROV_RATIO,
                   LOAN_FLAG,
                   LGD,
                   EAD,
                   PD
              FROM RRA_GBDS.GBDS_TF_BS
             WHERE DATA_DATE = :data_date )
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_nostro_data(data_date):
    """
    查询 Nostro 数据
    :param data_date: 取数日期
    """

    query_sql = """    
        with tb_interest as
         (select sum(CASE
                       WHEN t1.CURRENCY = 'CNY' THEN
                        abs(T1.FCY_AMOUNT)
                       ELSE
                        RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV( :data_date,
                                                    'USD',
                                                    'CNY',
                                                    RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV( :data_date ,
                                                                                T1.CURRENCY,
                                                                                'USD',
                                                                                abs(T1.FCY_AMOUNT),
                                                                                'STAND'),
                                                    'SAFE_MID')
                     END) FCY_AMOUNT
            from RRA_SIDS.S_FLC_BIVW_DAILY_ACC_ENTRIES T1
           where data_date = (select max(data_date)
                                from RRA_SIDS.S_FLC_BIVW_DAILY_ACC_ENTRIES
                               where data_date <= :data_date )
             and gl_code = '713010300'
             AND addl_text like '009015 REV ACC SPDB INT FR%'
          )
        select cust_no,
               cust_no cust_no2,
               'CNY' ccy,
               CASE
                 WHEN t1.ccy = 'CNY' THEN
                  abs(T1.ACY_CURR_BALANCE)
                 ELSE
                  RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV( :data_date,
                                              'USD',
                                              'CNY',
                                              RRA_COMM.PACK_UTIL.FUN_GET_CURR_CONV(:data_date,
                                                                          T1.ccy,
                                                                          'USD',
                                                                          abs(T1.ACY_CURR_BALANCE),
                                                                          'STAND'),
                                              'SAFE_MID')
               END Amount,
               t2.FCY_AMOUNT
          from RRA_SIDS.S_FLC_STTM_CUST_ACCOUNT T1
          left join tb_interest T2
            on 1 = 1
         where cust_ac_no = '2005101156000005'
           and data_date =  :data_date   
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_limit_data(data_date):
    """
    查询 Limit 数据
    :param data_date: 取数日期
    """

    query_sql = """
        select CUSTOMER_ID            CBS_ID,
           CUSTOMER_ID            Customer_ID,
           CURRENCY,
           AVAILABLE_CREDIT_LIMIT,
           REVOCABLE,
           ORG_PERIOD_IN_ONE_YEAR
          from RRA_SIDS.S_FLC_CREDIT_EXPOSURE
         where data_date = :data_date 
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_auto_fin_data(data_date):
    """
    查询 Auto Fin 数据
    :param data_date: 取数日期
    """

    query_sql = """
      SELECT cbs_cust_id , currency,amount, interest_received_to_gl
        FROM RRA_SIDS.S_MAN_LOAN_DETAILS
       WHERE lower(status) != 'ex'
         AND lower(status) != 'expired'
         AND finished is null
         AND data_date = :data_date    
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')


def query_offbs_tf_data(data_date):
    """
    查询 offbs TF 数据
    :param data_date: 取数日期
    """

    query_sql = """      
        WITH CUSTOMER_UEN_INFO AS
         (SELECT B.CIF_NO, B.UEN_NO, B.LEGAL_NAME
            FROM (SELECT A.CIF_NO,
                         A.UEN_NO,
                         A.LEGAL_NAME,
                         ROW_NUMBER() OVER(PARTITION BY A.UEN_NO ORDER BY A.PIR ASC) AS RN
                    FROM (SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                                 TRIM(PARENT_UEN) AS UEN_NO,
                                 T1.LEGAL_NAME,
                                 '1' AS PIR
                            FROM RRA_SIDS.S_UEN_BRANCH T1
                           WHERE DATA_DATE =
                                 (SELECT MAX(DATA_DATE)
                                    FROM RRA_SIDS.S_UEN_BRANCH
                                   WHERE DATA_DATE <= :data_date )
                          UNION ALL
                          SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                                 UEN_NO,
                                 T2.LEGAL_NAME,
                                 '2' AS PIR
                            FROM RRA_SIDS.S_UEN_NA T2
                           WHERE DATA_DATE =
                                 (SELECT MAX(DATA_DATE)
                                    FROM RRA_SIDS.S_UEN_NA
                                   WHERE DATA_DATE <= :data_date)
                          UNION
                          SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                                 UEN_NO,
                                 T3.LEGAL_NAME,
                                 '3' AS PIR
                            FROM RRA_SIDS.S_UEN_CHINA T3
                           WHERE DATA_DATE =
                                 (SELECT MAX(DATA_DATE)
                                    FROM RRA_SIDS.S_UEN_CHINA
                                   WHERE DATA_DATE <= :data_date)) A
                   WHERE A.UEN_NO IS NOT NULL) B
           WHERE B.RN = 1),
        CBS_FUNC_UDF_FIELDS AS
         (SELECT SUBSTR(T.REC_KEY, 1, 6) CBS_ID,
                 LPAD(T.FIELD_VAL_52, 10, '0') AS CIF_NO
            FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T
           WHERE T.FUNCTION_ID = 'STDCIF'
             AND T.DATA_DATE = (SELECT MAX(DATA_DATE)
                                  FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS
                                 WHERE DATA_DATE <= :data_date))
        
        select T3.CBS_ID,
               T1.UEN_NO,
               T3.CBS_ID,
               case
                 when upper(T1.DEAL_TYPE) = 'GUARANTEE' THEN
                  0.5
                 when upper(T1.DEAL_TYPE) IN ('CONFIRMATION', 'LC ISSUANCE') THEN
                  0.2
                 else
                  0
               end OFFBS_factor,
               T1.DEAL_TYPE,
               T1.UEN_NO,
               T1.CURRENCY,
               T1.AMOUNT
          from (SELECT T.DATA_DATE,
                       T.CBS_BU AS BRANCH_CODE,
                       T.INSTRUMENT_ID AS TRANS_REF,
                       T.CURRENCY_CODE AS CURRENCY,
                       T.UEN_NUMBER AS UEN_NO,
                       T.RELEASE_DATE AS VALUE_DATE,
                       T.EXPIRY_DATE AS MATURTIY_DATE,
                       T2.DEAL_TYPE,
                       ACTIVITY_TYPE,
                       PROD_PROD_TYPE_CODE,
                       CONFIRMATION_TYPE,
                       NVL(T.LC_AVAIL_AMT, 0) AMOUNT,
                       ROW_NUMBER() OVER(PARTITION BY T.INSTRUMENT_ID ORDER BY T.SEQUENCE_DATE DESC, T.SEQUENCE_TIME DESC) RN
                  FROM RRA_SIDS.S_PIX_CNLCCOL T
                 INNER JOIN (SELECT DISTINCT BS.PROD_TYPE,
                                            BS.DEAL_TYPE,
                                            BS.RISK_PARTY_CORP_TYPE,
                                            BS.BALANCE_SHEET,
                                            BS.IS_LOAN
                              FROM RRA_SIDS.LLP_FACILITY_MAPPING BS
                             WHERE BS.BALANCE_SHEET = 'OFFBS') T2
                    ON T.PROD_PROD_TYPE_CODE = T2.PROD_TYPE
                 WHERE T.SOURCE_SYSTEM_ID = '4'
                   AND T.DATA_DATE <= :data_date
                   AND T.EXPIRY_DATE > :data_date ) T1
          left join CUSTOMER_UEN_INFO T2
            ON T1.UEN_NO = T2.UEN_NO
          left join CBS_FUNC_UDF_FIELDS T3
            ON T2.CIF_NO = T3.CIF_NO
         WHERE T1.RN = 1
           AND T1.ACTIVITY_TYPE <> 'DEA'
           AND T1.AMOUNT <> 0
           AND (T1.PROD_PROD_TYPE_CODE IN ('GUAOUT', 'DLCIMP') -- RRA-1869  
               OR (T1.PROD_PROD_TYPE_CODE = 'DLCEXP' AND
               T1.CONFIRMATION_TYPE IN ('ACON', 'SCON')))
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                                fecth='all', bind='rra')

def query_bond_ncd_data(data_date):
    """
    查询 BOND & NCD 数据
    :param data_date: 取数日期
    """

    query_sql = """   
    --Bond&NCD

        WITH CUSTOMER_UEN_INFO AS
         (SELECT B.CIF_NO, B.UEN_NO, B.LEGAL_NAME
            FROM (SELECT A.CIF_NO,
                         A.UEN_NO,
                         A.LEGAL_NAME,
                         ROW_NUMBER() OVER(PARTITION BY A.UEN_NO ORDER BY A.PIR ASC) AS RN
                    FROM (SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                                 TRIM(PARENT_UEN) AS UEN_NO,
                                 T1.LEGAL_NAME,
                                 '1' AS PIR
                            FROM RRA_SIDS.S_UEN_BRANCH T1
                           WHERE DATA_DATE =
                                 (SELECT MAX(DATA_DATE)
                                    FROM RRA_SIDS.S_UEN_BRANCH
                                   WHERE DATA_DATE <= :data_date )
                          UNION ALL
                          SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                                 UEN_NO,
                                 T2.LEGAL_NAME,
                                 '2' AS PIR
                            FROM RRA_SIDS.S_UEN_NA T2
                           WHERE DATA_DATE =
                                 (SELECT MAX(DATA_DATE)
                                    FROM RRA_SIDS.S_UEN_NA
                                   WHERE DATA_DATE <= :data_date )
                          UNION
                          SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                                 UEN_NO,
                                 T3.LEGAL_NAME,
                                 '3' AS PIR
                            FROM RRA_SIDS.S_UEN_CHINA T3
                           WHERE DATA_DATE =
                                 (SELECT MAX(DATA_DATE)
                                    FROM RRA_SIDS.S_UEN_CHINA
                                   WHERE DATA_DATE <= :data_date )) A
                   WHERE A.UEN_NO IS NOT NULL) B
           WHERE B.RN = 1),
        CBS_FUNC_UDF_FIELDS AS
         (SELECT SUBSTR(T.REC_KEY, 1, 6) CBS_CUST_NO,
                 LPAD(T.FIELD_VAL_52, 10, '0') AS CMCIF_CUST_ID
            FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T
           WHERE T.FUNCTION_ID = 'STDCIF'
             AND T.DATA_DATE = (SELECT MAX(DATA_DATE)
                                  FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS
                                 WHERE DATA_DATE <= :data_date))
        
        select T4.CBS_CUST_NO as CBS_ID,
               T1.SECURITY_ACC_CODE as Accounting_code,
               T2.ISSUER_UEN,
               T1.CURRENCY CCY,
               NVL(T1.FAIR_VALUE, 0) + NVL(T5.VPC_IPV_ADJUSTMENT, 0) BALANCE,
               INTEREST_RECEIVABLE,
               T1.Profit_Centre
        
          from rra_sids.S_INT_holding T1
          left join rra_sids.s_gfi_cn_security T2
            on T1.Bond_Code = T2.BOND_CODE
           and T2.Data_Date = to_char(to_date( :data_date , 'YYYYMMDD') - 1, 'YYYYMMDD')
          left join CUSTOMER_UEN_INFO T3
            on T2.ISSUER_UEN = T3.UEN_NO
          left join CBS_FUNC_UDF_FIELDS T4
            on T3.CIF_NO = T4.CMCIF_CUST_ID
          left join rra_sids.S_MAN_BOND_VPC T5
            on T1.CUSIP = T5.SEC_CUSIP
           and T5.Data_Date =
               to_char(last_day(add_months(to_date(:data_date , 'yyyymmDD'), -1)),
                       'YYYYMMDD')
         where T1.data_date =
               to_char(to_date(:data_date, 'YYYYMMDD') - 1, 'YYYYMMDD')
           and T1.Profit_Centre IN ('T3773', 'T9534')
           and T1.SECURITY_ACC_CODE <> 'NCD'
        union all
        --NCD
        select T4.CBS_CUST_NO as CBS_ID,
               T1.SECURITY_ACC_CODE as Accounting_code,
               T2.ISSUER_UEN,
               T1.CURRENCY CCY,
               NVL(T1.FAIR_VALUE, 0) + NVL(T5.VPC_IPV_ADJUSTMENT, 0) BALANCE,
               INTEREST_RECEIVABLE,
               T1.Profit_Centre
        
          from rra_sids.S_INT_holding T1
          left join rra_sids.s_gfi_cn_security T2
            on T1.Bond_Code = T2.BOND_CODE and T2.Data_Date = to_char(to_date(:data_date, 'YYYYMMDD') - 1, 'YYYYMMDD')
          left join CUSTOMER_UEN_INFO T3
            on T2.ISSUER_UEN = T3.UEN_NO
          left join CBS_FUNC_UDF_FIELDS T4
            on T3.CIF_NO = T4.CMCIF_CUST_ID
          left join rra_sids.S_MAN_BOND_VPC T5
            on T1.CUSIP = T5.SEC_CUSIP and
         T5.Data_Date =
         to_char(last_day(add_months(to_date(:data_date, 'yyyymmDD'), -1)),
                 'YYYYMMDD')
         where T1.data_date =
         to_char(to_date(:data_date, 'YYYYMMDD') - 1, 'YYYYMMDD') and
         T1.Profit_Centre IN ('T3773', 'T9534') and
         T1.SECURITY_ACC_CODE <> 'NCD'
    """
    return db_fetch_to_dict(query_sql, params={'data_date': data_date},
                            fecth='all', bind='rra')



