# -*- coding: utf-8 -*-

"""
Created on 2020-11-05

@author: Wang Shuo
"""

from datetime import datetime, timedelta
from bmolre.exts import db


# 定义日志操作数据模型
class OperationLog(db.Model):
    __tablename__ = 'sys_oper_log'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    module_name = db.Column(db.String(100))
    method_name = db.Column(db.String(200))
    line_number = db.Column(db.INTEGER)
    level = db.Column(db.String(50))
    message = db.Column(db.String(2000))
    oper_time = db.Column(db.DateTime)

    def __init__(self, module_name, method_name, line_number, level, message, oper_time=datetime.now()):
        self.module_name = module_name
        self.method_name = method_name
        self.line_number = line_number
        self.level = level
        self.message = message
        self.oper_time = oper_time

    def to_json(self):
        return {
            'id': self.id,
            'module_name': self.module_name,
            'method_name': self.method_name,
            'line_number': self.line_number,
            'level': self.level,
            'message': self.message,
            'oper_time': self.oper_time.strftime('%Y-%m-%d %H:%M:%S') if self.oper_time is not None else ''
        }
