# -*- coding: utf-8 -*-

"""
Created on 2020-11-06

@author: Wang Shuo
"""

from bmolre.exts import db
from bmolre.commons.constant import LRE_REPORT_DB_URL

from datetime import datetime
import time
from decimal import Decimal
import os

import pandas as pd


def get_current_time():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def is_blank(val):
    if val is None or len(val) == 0:
        return True
    else:
        return False


def convert_digital_precision(val, precision=2):
    """ 保留小数点以后6位 """

    decimal = '0.'
    for i in range(precision):
        decimal += '0'

    if val is None:
        val = 0

    return Decimal(val).quantize(Decimal(decimal))


def db_fetch_to_dict(sql, params={}, fecth='all', bind=None):
    """
    dict的方式返回数据
    :param sql: select * from xxx where name=:name
    :param params:{'name':'zhangsan'}
    :param fecth:默认返回全部数据，返回格式为[{},{}],如果fecth='one',返回单条数据，格式为dict
    :param bind:连接的数据，默认取配置的SQLALCHEMY_DATABASE_URL，
    :return:
    """
    resultProxy = db.session.execute(sql, params, bind=db.get_engine(bind=bind))
    if fecth == 'one':
        result_tuple = resultProxy.fetchone()
        if result_tuple:
            result = dict(zip(resultProxy.keys(), list(result_tuple)))
        else:
            return None
    else:
        result_tuple_list = resultProxy.fetchall()
        if result_tuple_list:
            result = []
            keys = resultProxy.keys()
            for row in result_tuple_list:
                result_row = dict(zip(keys, row))
                result.append(result_row)
        else:
            return None

    db.session.close()
    return result
