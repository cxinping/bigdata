# -*- coding: utf-8 -*-

from enum import Enum


class ReportType(Enum):
    """ Report 类型 """
    DAILY_REPORT = 'daily'
    G14_REPORT = 'g14'


class G14ReportSpreadSheets(Enum):
    G1401 = 'G1401'
    G1402 = 'G1402'
    G1403 = 'G1403'
    G1404 = 'G1404'
    G1405 = 'G1405'
    G1406 = 'G1406'
    LRE = 'LRE'
    SINGLE_CUST = 'Single Cust'
    GROUP_CUST = 'Group Cust'
    SINGLE_INTERBANK = 'Single Interbank'
    GROUP_INTERBANK = 'Group Interbank'
    G14_MASTER_LIST = 'G14 Master List'
    IN_SCOPE_LIST = 'in scope list'
    RISK_TRANSFER = 'Risk transfer'
    CUSTOMER = 'Customer'
    LOAN = 'Loan'
    RATE = 'RATE'
    AUTO_FIN = 'Auto Fin'
    DSC = 'DSC'
    BOND_NCD = 'Bond & NCD'
    MM_505 = 'MM 505'
    OTHER_INPUTS = 'Other inputs'
    LIMIT = 'Limit'
    EAD = 'EAD'
    LLP = 'LLP'
    # NOSTRO = 'Nostro'
    # OFFBS_TF = 'offbs TF'
    # PBOC = 'PBOC'
    # TRACKING_LOG = 'Tracking log'
    # GUIDE_LINE = 'Guideline'
    # CHECKING = 'Checking'


class LreDailyReportSpreadSheets(Enum):
    SUMMARY_CONTROL = 'Summary Control'
    GROUP_BANK = 'Group Bank'
    SINGLE_CUST = 'Single Cust'  # 非同业单一客户, Non interbank Customer Single Customer
    GROUP_CORP = 'Group Corp'

    DAILY_MASTER_LIST = 'Daily Master List'
    IN_SCOPE_LIST = 'in scope list'

    RATE = 'RATE'
    LOAN = 'Loan'
    OTHER_INPUTS = 'Other inputs'
    CUSTOMER = 'Customer'
    EAD = 'EAD'
    MM_505 = 'MM 505'
    DSC = 'DSC'
    LLP = 'LLP'
    NOSTRO = 'Nostro'
    LIMIT = 'Limit'
    AUTO_FIN = 'Auto Fin'
    OFFBS_TF = 'offbs TF'
    BOND_NCD = 'Bond & NCD'

    # CHECKING = 'Checking'
    # FEFC = 'FEFC'
    # GCL = 'GCL'
    # LIMIT_EARN_MARK = 'Limit earmark'
    # VERSION_LOG = 'Version log'
    # GUIDE_LINE = 'Guideline'


class CommonParamEnum(Enum):
    CNY = 'CNY'


class RateSheetEnum(Enum):
    """ RATE sheet的column类型 """
    S_DATE = 's_date'
    E_DATE = 'e_date'
    BASIC_CCY = 'basic_ccy'
    FORWARD_CCY = 'forward_ccy'
    CCY_RATE = 'ccy_rate'


class LoanSheetEnum(Enum):
    """ Loan sheet的column类型 """
    DATA_DATE = 'data_date'
    CBS_ID = 'cbs_id'
    CBS_CUST_ID = 'cbs_cust_id'
    CURRENCY = 'currency'
    AMOUNT = 'amount'
    INTEREST_RECEIVED_TO_GL = 'interest_received_to_gl'


class CustomerSheetEnum(Enum):
    """ Customer sheet的column类型 """
    CONNECTION_UEN = 'connection_uen'
    CONNECTION_NAME = 'connection_name'

    LOCAL_BRANCH = 'local_branch'
    CBS_ID = 'cbs_id'
    WSS_ID = 'wss_id'
    PIX_ID = 'pix_id'
    UEN = 'uen'
    OTL_ID = 'otl_id'
    UNIFORM_SOCIAL_CREDIT_CODE = 'uniform_social_credit_code'
    CUSTOMER_NAME_CN = 'customer_name_cn'
    CUSTOMER_NAME_EN = 'customer_name_en'
    CUSTOMER_CATEGORY = 'customer_category'
    NATIONALITY = 'nationality'
    COUNTRY = 'country'
    EXPOSURE_COUNTRY = 'exposure_country'
    AREA = 'area'
    CORP_TYPE = 'corp_type'
    CORP_SIZE = 'corp_size'
    INDUSTRY_CODE = 'industry_code'
    HOLDING_TYPE = 'holding_type'
    UNIQUE_ID_VALUE = 'unique_id_value'
    GROUP_CODE = 'group_code'
    GROUP_NAME = 'group_name'
    GROUP_CHINESE_NAME = 'group_chinese_name'
    STATUS = 'status'
    DATA_DATE = 'data_date'


class OtherInputsSheetEnum(Enum):
    """ Other Inputs sheet的column类型 """
    TIER1_CAPITAL_AMT = 'tier1_capital_amt'  # 一级资本净额
    TOTAL_CAPITAL_AMT = 'total_capital_amt'  # 资本净额


class EadSheetEnum(Enum):
    """ EAD sheet的column类型 """
    CBS_ID = 'cbs_cif_id'
    COUNTERPARTY_LONG_NAME = 'counterparity_long_name'
    COUNTERPARTY_TYPE = 'counterpary_type'
    IBUK_CUSTOMER_NUMBER = 'ibuk_customer_number'
    EAD_USD = 'ead_usd'
    EAD_CNY_EQV = 'ead_cny_eqv'


class MM505SheetEnum(Enum):
    """ MM 505 sheet的column类型 """
    CBS_ID = 'cbs_id'
    REPORT_DATE = 'report_date'  # 对应<MM 505>的Report Date列，使用传入的 data_date,B列
    VALUE_DATE = 'value_date'
    MAT_DATE = 'mat_date'
    DEAL_TYPE = 'deal_type'
    DEAL_TYPE_RRA = 'deal_type_rra'
    CCY = 'ccy'
    AMOUNT = 'amount'
    TOTAL_INTEREST = 'interest_rec_pay'
    NAME_SHORT = 'name_short'  # 对应<MM 505>的Customer Short Name列，桔黄色，S列
    TYPE = 'customer_type'
    MM_CUST_NUM = 'wss_customer_number'
    INVENTORY = 'inventory'
    CUSTOMER_SHORT_NAME = 'customer_short_name'  # 对应<MM 505>的Customer Short Name列，蓝色, AB列
    CNY_EQV = 'cny_eqv'
    INTEREST_AMT = 'interest_amt'


class DscSheetEnum(Enum):
    """ DSC sheet的column类型 """
    CBS_ID = 'cbs_id'
    BENEFICARY_CBS_ID = 'beneficiary_cbs_id'
    RISKPARTY_UEN = 'riskparty_uen'
    RISKPARTY_CBSID = 'riskparty_cbsid'
    PRODUCT = 'product'
    WITH_BANK_CUSTOMER = 'with_bank_customer'
    RISKPARTY_CBSID_2 = 'riskparty_cbsid_2'
    RISKPARTY_UEN_2 = 'riskpary_uen_2'
    CURRENCY = 'currency'
    AMOUNT = 'amount'
    INTEREST_IN_ADVANCE = 'interest_in_advance'
    INCOME_ACCRUAL_AMOUNT = 'income_accrual_amount'


class LlpSheetEnum(Enum):
    """ LLp sheet的column类型 """
    BRANCH = 'branch'
    BS_OFFBS = 'bs_offbs'
    DEAL_TYPE = 'deal_type'
    UEN = 'uen'
    CCY_CNY_USD = 'ccy_cny_usd'
    PROV_AMT = 'prov_amt'


class NostroSheetEnum(Enum):
    """ Nostro sheet的column类型 """
    CUST_NO = 'cbs_customer_id' # 对应<Nostro>的 CBS Customer ID列，桔黄色，B列
    CCY = 'ccy'
    AMOUNT = 'amount'
    FCY_AMOUNT = 'fcy_amount'  # 对应<Nostro>的 Interest receivable(+)/Unearned interest(-) from customer according to GL 列，E列，桔黄色


class LimitSheetEnum(Enum):
    """ Limit sheet的column类型 """
    CBS_ID = 'cbs_id'
    CUSTOMER_ID = 'customer_id'
    CURRENCY = 'currency'
    AVAILABLE_CREDIT_LIMIT = 'available_credit_limit'
    REVOCABLE = 'revocable'
    ORG_PERIOD_IN_ONE_YEAR = 'org_period_in_one_year'


class AutoFinSheetEnum(Enum):
    """ Auto Fin sheet的column类型 """
    CBS_ID = 'cbs_id'
    CURRENCY = 'currency'
    AMOUNT = 'amount'
    INTEREST_RECEIVED_TO_SQL = 'interest_received_to_gl'


class OffbsTfSheetEnum(Enum):
    """ Offbs Tf sheet的column类型 """
    CBS_ID = 'cbs_id'
    UEN_NO = 'uen_no'
    OFFBS_FACTOR = 'offbs_factor'
    DEAL_TYPE = 'deal_type'
    CURRENCY = 'currency'
    AMOUNT = 'amount'


class BondNcdSheetEnum(Enum):
    """ Bond & NCD sheet的column类型 """
    CBS_ID = 'cbs_id'
    ACCOUNTING_CODE = 'accounting_code'
    ISSUER_UEN = 'issuser_uen'
    CCY = 'ccy'
    BALANCE = 'balance'
    INTEREST_RECEIVABLE = 'interest_receivable'
    PROFIT_CENTER = 'profit_center'














