# -*- coding: utf-8 -*-
"""
Created on 2020-12-02

@author: Wang Shuo
"""

from datetime import datetime
from dateutil.relativedelta import relativedelta
import random


class ReportDataDate(object):

    @staticmethod
    def get_t_1_data_date(date_str):
        """ 获得 T-1 日期 """

        date = datetime.strptime(date_str, "%Y%m%d")
        idx = -1
        while idx >= -3:
            t_1_day = date + relativedelta(days=idx)
            if t_1_day.weekday() in [5, 6]:
                idx = idx - 1
            else:
                return t_1_day.strftime("%Y%m%d")


def create_random_number(len=10):
    """ 生成len位的随机数 """

    raw = ""
    range1 = range(58, 65)  # between 0~9 and A~Z
    range2 = range(91, 97)  # between A~Z and a~z

    i = 0
    while i < len:
        seed = random.randint(48, 122)
        if ((seed in range1) or (seed in range2)):
            continue
        raw += chr(seed)
        i += 1

    return raw
