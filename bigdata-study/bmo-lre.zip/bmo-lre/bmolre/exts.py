# -*- coding: utf-8 -*-

'''
Created on 2020-10-30

@author: WangShuo
'''


from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()
