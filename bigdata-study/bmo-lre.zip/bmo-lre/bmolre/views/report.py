# -*- coding: utf-8 -*-

"""
Created on 2020-12-03

@author: Wang Shuo
"""

from flask import Blueprint, jsonify
import time

from ..commons.logging import log_entry_exit, get_logger
from ..commons.report_enums import ReportType
from ..commons.check_valid import is_valid_date
from ..services.report_services import G14ReportBuilder, LreDailyReportBuilder
from ..exts import db

report_bp = Blueprint('report', __name__)

log = get_logger()


@report_bp.route('/init/db', methods=['GET'])
def init_db():
    db.drop_all(bind=None)
    db.create_all(bind=None)

    return "init LRE db "


@report_bp.route('/daily/<data_date>', methods=['GET'])
def create_daily_report(data_date):
    log.info("create daily report , data_date={}".format(data_date))
    result = {'report_type': ReportType.DAILY_REPORT.value}

    if is_valid_date(data_date):
        try:
            start_time = time.time()
            daily_report_builder = LreDailyReportBuilder()
            daily_report = daily_report_builder.create_report(data_date)
            end_time = time.time()
            result['status'] = 200
            result['message'] = 'create daily report successfully'
            result['report_path'] = daily_report.get_target_report()
            result['execution_time'] = round(end_time-start_time)
        except Exception as err:
            log.error(err)
            result['status'] = 500
            result['message'] = str(err)
    else:
        result['status'] = 500
        result['message'] = 'input valid data_date'

    return jsonify(result)


@report_bp.route('/g14/<data_date>', methods=['GET'])
def create_g14_report(data_date):
    log.info("create G14 report , data_date={}".format(data_date))
    result = {'report_type': ReportType.G14_REPORT.value}

    if is_valid_date(data_date):
        try:
            g14_report_builder = G14ReportBuilder()
            g14_report = g14_report_builder.create_report(data_date)

            result['status'] = 200
            result['message'] = 'create G14 report successfully'
            result['report_path'] = g14_report.get_target_report()
        except Exception as err:
            log.error(err)
            result['status'] = 500
            result['message'] = str(err)
    else:
        result['status'] = 500
        result['message'] = 'input valid data_date'

    return jsonify(result)
