# -*- coding: utf-8 -*-

from flask import Blueprint
from datetime import datetime

from bmolre.exts import db

#from bmolre.services.data_services import DataService
#from bmolre.services.report_cal_services import ReportService
#from bmolre.services.report_services import G14ReportBuilder, LreDailyReportBuilder
#from bmolre.commons.logging import log_entry_exit, get_logger
#from bmolre.commons.util import db_fetch_to_dict, pd_read_sql

from ..services.data_services import DataService
from ..services.report_cal_services import ReportService
from ..services.report_services import  G14ReportBuilder, LreDailyReportBuilder
from ..commons.logging import log_entry_exit, get_logger
from ..commons.util import db_fetch_to_dict

test_bp = Blueprint('test', __name__)

log = get_logger()


# http://127.0.01:5000/test/valid/input
@test_bp.route('/valid/input', methods=['GET'])
@log_entry_exit
def test_input():
    cur_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    tup1 = (1, 2)
    a = 1
    b = '  '
    c = None
    log.info("--- info message {}".format(cur_time))
    log.debug("--- debug message {}".format(cur_time))
    log.error("--- error message {}".format(cur_time))
    log.info(all([a, b, c]))

    try:
        a = 1 / 0
    except Exception as err:
        print(err)

    print('--- deubg info ----')

    return 'test_input ok '


# http://127.0.01:5000/test/init/db
@test_bp.route('/init/db', methods=['GET'])
def test_init_db():
    db.drop_all(bind=None)
    db.create_all(bind=None)

    return "ok init db "


# http://127.0.01:5000/test/rra/create
@test_bp.route('/rra/create', methods=['GET'])
def test_rra_create():
    # stu1 = RRA_Student(username='zhangsan')
    # stu2 = RRA_Student(username='lisi')
    #
    # db.session.add(stu1)
    # db.session.add(stu2)
    #
    # db.session.commit()
    # db.session.close()

    return 'test rra create'

# http://127.0.01:5000/test/rra/query
@test_bp.route('/rra/query', methods=['GET'])
def test_rra_table1():
    sql = "select * from RRA_SIDS.S_FLC_LOAN_DETAILS where STATUS not in ( :status_param )"
    ls = ['EX', 'Expired']
    param = ','.join(['"' + item + '"' for item in ls])
    print(param)

    params = {'status_param': param}

    sql2 = '''
    select  SUM(interest_received_to_gl)/ 10000 as sum_interest_received_to_gl,
         SUM(amount)/ 10000 as sum_amount   ,
        ( SUM(interest_received_to_gl)/ 10000 + SUM(amount)/ 10000 ) as sum_val
        from RRA_SIDS.S_FLC_LOAN_DETAILS 
        where status != 'EX' and status != 'Expired' 
        and FINISHED is null 
        and data_date = '20200331' 
        and CBS_CUST_ID ='600673'
    '''

    ls = db_fetch_to_dict(sql, params=None, fecth='all', bind='rra')
    print(ls)
    #
    print('size=> ', len(ls))

    return "ok , query rra record"


# http://127.0.01:5000/test/rra/g14/report/create
@test_bp.route('/rra/g14/report/create', methods=['GET'])
def test_create_g14_report():
    g14ReportBuilder = G14ReportBuilder()
    # 20201003 没有汇率，按找异常处理  20201103 20201003 20201003a
    # 20201102 20200331 有数据
    g14ReportBuilder.create_report('20200331')

    return 'create g14 report'

# http://127.0.01:5000/test/rra/daily/report/create
@test_bp.route('/rra/daily/report/create', methods=['GET'])
def test_create_report():
    # 20201003 没有汇率，按找异常处理  20201103 20201003 20201003a
    # 20201102 20200331 有数据
    dailyReportBuilder = LreDailyReportBuilder()
    dailyReportBuilder.create_report(20200331)

    return 'create daily report'

# http://127.0.01:5000/test/rra/report/service
@test_bp.route('/rra/report/service', methods=['GET'])
def test_report_service():
    report_service = ReportService()
    # 20200331 20200630 有数
    # 20200603 没数

    data_date = '20200331'
    try:
        # capital_data = report_service.query_capital_data(data_date)
        # print('data_date={}，\ncapital_data={}'.format(data_date, capital_data))

        #customer_datas = report_service.query_customer_list_report(data_date)
        #report_service.query_indirect_customer_from_trade_finance_transaction(data_date)
        # datas = report_service.query_money_market_data(data_date)
        # for data_item in datas:
        #     print(data_item)

        #report_service.query_dsc_data(data_date)
        #report_service.query_llp_data(data_date)
        #report_service.query_nostro_data(data_date)

        #report_service.query_limit_data(data_date)
        #report_service.query_auto_fin_data(data_date)
        #report_service.query_offbs_tf_data(data_date)
        #data_list = report_service.query_bond_ncd_data(data_date)

        data_list = report_service.query_indirect_customer_from_s_gfi_cn_counterparty(data_date)
        for data in data_list :
            print(data)

        print('data num={}'.format(len(data_list)))

        #cust_datas = report_service.cal_customer_data(data_date)
        # print(cust_datas)
        # print(len(cust_datas))

        #ead_datas = report_service.cal_ead_ead_report_data(data_date)

        # val = report_service.get_cny_rate(data_date,'USD')
        # print('val=',val )

        data_date = '20200331'
        #report_service.query_indirect_customer_from_trade_finance_transaction(data_date)

    except Exception as err:
        print('test.py ',str(err))

    return 'test report service'
