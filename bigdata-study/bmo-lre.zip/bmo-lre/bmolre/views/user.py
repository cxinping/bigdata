# -*- coding: utf-8 -*-

'''
Created on 2020-10-28

@author: WangShuo
'''

from flask import Blueprint

users_bp = Blueprint('users', __name__)















