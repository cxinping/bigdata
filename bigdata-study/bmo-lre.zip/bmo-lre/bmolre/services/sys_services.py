# -*- coding: utf-8 -*-


from bmolre.exts import db


def create_all_tables():
    db.drop_all(bind=None)
    db.create_all(bind=None)

