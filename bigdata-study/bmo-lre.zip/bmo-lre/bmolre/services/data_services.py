# -*- coding: utf-8 -*-

"""
Created on 2020-11-13

@author: Wang Shuo
"""

from bmolre.commons.logging import get_logger
from bmolre.commons.report_enums import (
    RateSheetEnum, LoanSheetEnum, OtherInputsSheetEnum, CustomerSheetEnum,
    EadSheetEnum, MM505SheetEnum, DscSheetEnum, LlpSheetEnum, NostroSheetEnum,
    LimitSheetEnum, AutoFinSheetEnum, OffbsTfSheetEnum, BondNcdSheetEnum
)
import bmolre.models.data_models as rra_db
from bmolre.exceptions import DataException

log = get_logger()


class DataService(object):

    def __init__(self):
        pass

    def query_rate_data(self, data_date):
        """ 查询外币到人民币的汇率 """
        rates = rra_db.query_ccy_rate_data(data_date)

        if rates is None:
            raise DataException('The rates value searched by data_date is empty, check rates.')

        ls = []

        forward_ccy = 'CNY'
        foreign_ccy = 'AUD'
        s_date, e_date, aud_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        aud_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, aud_usd_ccy_rate)['end']
        aud_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=aud_cny_ccy_rate)

        foreign_ccy = 'CAD'
        s_date, e_date, cad_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        cad_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, cad_usd_ccy_rate)['end']
        cad_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=cad_cny_ccy_rate)

        foreign_ccy = 'CHF'
        s_date, e_date, chy_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        chy_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, chy_usd_ccy_rate)['end']
        chy_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=chy_cny_ccy_rate)

        foreign_ccy = 'EUR'
        s_date, e_date, eur_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        eur_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, eur_usd_ccy_rate)['end']
        eur_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=eur_cny_ccy_rate)

        foreign_ccy = 'GBP'
        s_date, e_date, gbp_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        gbp_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, gbp_usd_ccy_rate)['end']
        gbp_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=gbp_cny_ccy_rate)

        foreign_ccy = 'HKD'
        s_date, e_date, hkd_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        hkd_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, hkd_usd_ccy_rate)['end']
        hkd_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=hkd_cny_ccy_rate)

        foreign_ccy = 'JPY'
        s_date, e_date, jpy_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        jpy_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, jpy_usd_ccy_rate)['end']
        jpy_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=jpy_cny_ccy_rate)

        foreign_ccy = 'SGD'
        s_date, e_date, sgd_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        sgd_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, sgd_usd_ccy_rate)['end']
        sgd_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=sgd_cny_ccy_rate)

        foreign_ccy = 'DKK'
        s_date, e_date, dkk_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        dkk_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, dkk_usd_ccy_rate)['end']
        dkk_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=dkk_cny_ccy_rate)

        foreign_ccy = 'NZD'
        s_date, e_date, nzd_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        nzd_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, nzd_usd_ccy_rate)['end']
        nzd_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=nzd_cny_ccy_rate)

        foreign_ccy = 'SEK'
        s_date, e_date, sek_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        sek_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, sek_usd_ccy_rate)['end']
        sek_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=sek_cny_ccy_rate)

        foreign_ccy = 'THB'
        s_date, e_date, thb_usd_ccy_rate = self.__filter_ccy_rate(rates, foreign_ccy)
        thb_cny_ccy_rate = rra_db.change_foreign_currency_to_cny(data_date, foreign_ccy, thb_usd_ccy_rate)['end']
        thb_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=thb_cny_ccy_rate)

        foreign_ccy = 'USD'
        usd_cny_rate_obj = rra_db.query_safe_mid_rate_data(data_date, 'USD', 'CNY')
        s_date = usd_cny_rate_obj['s_date']
        e_date = usd_cny_rate_obj['e_date']
        usd_cny_rate = usd_cny_rate_obj['ccy_rate']
        usd_cny_ccy_obj = self.__create_rate_table_item(s_date, e_date, basic_ccy=foreign_ccy, forward_ccy=forward_ccy,
                                                        ccy_rate=usd_cny_rate)

        ls.append(usd_cny_ccy_obj)
        ls.append(aud_cny_ccy_obj)
        ls.append(cad_cny_ccy_obj)
        ls.append(chy_cny_ccy_obj)
        ls.append(eur_cny_ccy_obj)
        ls.append(gbp_cny_ccy_obj)
        ls.append(hkd_cny_ccy_obj)
        ls.append(jpy_cny_ccy_obj)
        ls.append(sgd_cny_ccy_obj)
        ls.append(dkk_cny_ccy_obj)
        ls.append(nzd_cny_ccy_obj)
        ls.append(sek_cny_ccy_obj)
        ls.append(thb_cny_ccy_obj)

        return ls

    def query_usd_to_cny_rate(self, data_date):
        usd_cny_rate_obj = rra_db.query_safe_mid_rate_data(data_date, 'USD', 'CNY')
        return usd_cny_rate_obj['ccy_rate']

    def __create_rate_table_item(self, s_date, e_date, basic_ccy, forward_ccy, ccy_rate):
        return {
            RateSheetEnum.S_DATE.value: s_date,
            RateSheetEnum.E_DATE.value: e_date,
            RateSheetEnum.BASIC_CCY.value: basic_ccy,
            RateSheetEnum.FORWARD_CCY.value: forward_ccy,
            RateSheetEnum.CCY_RATE.value: ccy_rate
        }

    def __filter_ccy_rate(self, rates, input_ccy):
        s_date = None
        e_date = None
        ccy_rate = None
        if rates:
            for rate in rates:

                if rate['basic_ccy'] == input_ccy and rate['forward_ccy'] == 'USD':
                    ccy_rate = rate['ccy_rate']
                    s_date = rate['s_date']
                    e_date = rate['e_date']
                    break

                if rate['forward_ccy'] == input_ccy and rate['basic_ccy'] == 'USD':
                    ccy_rate = 1 / rate['ccy_rate']
                    s_date = rate['s_date']
                    e_date = rate['e_date']
                    break

        return s_date, e_date, ccy_rate

    def query_loan_data(self, data_date):
        loans = rra_db.query_loan_data(data_date)
        if loans is None:
            raise DataException('The loans value searched by data_date is empty, please check loans')

        results = []

        for loan_item in loans:
            loan_obj = self.__create_loan_table_item(data_date=data_date, cbs_cust_id=loan_item['cbs_cust_id'],
                                                     amount=loan_item['amount'],
                                                     currency=loan_item['currency'],
                                                     interest_received_to_gl=loan_item['interest_received_to_gl'])
            results.append(loan_obj)

        return results

    def __create_loan_table_item(self, data_date, cbs_cust_id, currency, amount, interest_received_to_gl):
        return {
            LoanSheetEnum.DATA_DATE.value: data_date,
            LoanSheetEnum.CBS_CUST_ID.value: cbs_cust_id,
            LoanSheetEnum.CURRENCY.value: currency,
            LoanSheetEnum.AMOUNT.value: amount,
            LoanSheetEnum.INTEREST_RECEIVED_TO_GL.value: interest_received_to_gl
        }

    def query_customer_list_report(self, data_date):
        """
        4.1.2.3.1 Extract BMO Customer to LRE Calculation
        In the working file, BMO Customer data use RRA BMOS0008 customer list report as data source.
        Select customer with Status = O in RRAS0008.
        :param data_date: 取数日期
        """

        customer_data_list = rra_db.query_customer_list_report(data_date=data_date)
        customer_ls = []
        if customer_data_list is None:
            raise DataException(
                '4.1.2.3.1 customer_data_list is empty, whether there is RRAS0008 data on {}'.format(data_date))

        for customer_data in customer_data_list:
            customer_obj = self.__create_customer_item(local_branch=customer_data['local_branch'],
                                                       cbs_id=customer_data['cbs_id'], wss_id=customer_data['wss_id'],
                                                       pix_id=customer_data['pix_id'], uen=customer_data['uen'],
                                                       otl_id=customer_data['otl_id'],
                                                       uniform_social_credit_code=customer_data[
                                                           'uniform_social_credit_code'],
                                                       customer_name_cn=customer_data['customer_name_cn'],
                                                       customer_name_en=customer_data['customer_name_en'],
                                                       customer_category=customer_data['customer_category'],
                                                       nationality=customer_data['nationality'],
                                                       country=customer_data['country'],
                                                       exposure_country=customer_data['exposure_country'],
                                                       area=customer_data['area'], corp_type=customer_data['corp_type'],
                                                       corp_size=customer_data['corp_size'],
                                                       industry_code=customer_data['industry_code'],
                                                       holding_type=customer_data['holding_type'],
                                                       unique_id_value=customer_data['unique_id_value'],
                                                       group_code=customer_data['group_code'],
                                                       group_name=customer_data['group_name'],
                                                       group_chinese_name=customer_data['group_chinese_name'],
                                                       status=customer_data['status'],
                                                       data_date=customer_data['data_date'])
            customer_ls.append(customer_obj)
        return customer_ls

    def query_indirect_customer_from_trade_finance_transaction(self, data_date):
        """
        4.1.2.3.2.1 Extract Indirect Customer Data to LRE Calculation - Limit Customer from Trade Finance Transaction and Issuer from Bond/NCD
        Limit Customer from Trade Finance Transaction
        Source: Limit customer of trade finance deal transaction.
        Reference : RRA report BMOS0018
        :param data_date: 取数日期
        """

        customer_data_list = rra_db.query_indirect_customer_from_trade_finance_transaction(data_date=data_date)
        customer_ls = []
        if customer_data_list is None:
            raise DataException(
                '4.1.2.3.2.1 customer_data_list is empty, whether there is BMOS0018 data on {}'.format(data_date))

        for customer_item in customer_data_list:
            customer_obj = self.__create_customer_item(local_branch=None,
                                                       cbs_id=customer_item['cbs_id'], wss_id=None,
                                                       pix_id=None, uen=customer_item['uen'],
                                                       otl_id=customer_item['otl_id'],
                                                       uniform_social_credit_code=customer_item[
                                                           'uniform_social_credit_code'],
                                                       customer_name_cn=customer_item['customer_name_cn'],
                                                       customer_name_en=customer_item['customer_name_en'],
                                                       customer_category=customer_item['customer_category'],
                                                       nationality=customer_item['nationality'],
                                                       country=customer_item['country'],
                                                       exposure_country=customer_item['exposure_country'],
                                                       area=None, corp_type=None,
                                                       corp_size=None,
                                                       industry_code=None,
                                                       holding_type=None,
                                                       unique_id_value=customer_item['unique_id_value'],
                                                       group_code=customer_item['group_code'],
                                                       group_name=customer_item['group_name'],
                                                       group_chinese_name=None,
                                                       status=None,
                                                       data_date=customer_item['data_date'])
            customer_ls.append(customer_obj)
        return customer_ls

    def query_indirect_customer_from_s_gfi_cn_counterparty(self, data_date):
        """
        4.1.2.3.2.2 Extract Indirect Customer Data to LRE Calculation - Issuer from Bond/NCD
        Issuer from Bond/NCD
        Source: RRA table s_gfi_cn_counterparty
        :param data_date: 取数日期
        """

        customer_data_list = rra_db.query_indirect_customer_from_s_gfi_cn_counterparty(data_date=data_date)
        if customer_data_list is None:
            raise DataException(
                '4.1.2.3.2.2 customer_data_list is empty, whether there is s_gfi_cn_counterparty data on {}'.format(
                    data_date))

        customer_ls = []
        for customer_item in customer_data_list:
            customer_obj = self.__create_customer_item(local_branch='', cbs_id=customer_item['cbs_id'], wss_id='',
                                                       pix_id='', uen=customer_item['uen'],
                                                       otl_id=customer_item['otl_id'],
                                                       uniform_social_credit_code=customer_item[
                                                           'uniform_social_credit_code'],
                                                       customer_name_cn=customer_item['customer_name_cn'],
                                                       customer_name_en=customer_item['customer_name_en'],
                                                       customer_category=customer_item['customer_category'],
                                                       nationality='',
                                                       country='', exposure_country=customer_item['exposure_country'],
                                                       area='', corp_type='',
                                                       corp_size='', industry_code='', holding_type='',
                                                       unique_id_value=customer_item['unique_id_value'],
                                                       group_code=customer_item['group_code'],
                                                       group_name=customer_item['group_name'], group_chinese_name='',
                                                       status='', data_date=data_date)
            customer_ls.append(customer_obj)
        return customer_ls

    def __create_customer_item(self, local_branch, cbs_id, wss_id, pix_id, uen,
                               otl_id, uniform_social_credit_code, customer_name_cn,
                               customer_name_en, customer_category, nationality,
                               country, exposure_country, area, corp_type,
                               corp_size, industry_code, holding_type, unique_id_value,
                               group_code, group_name, group_chinese_name, status, data_date):
        return {
            CustomerSheetEnum.LOCAL_BRANCH.value: local_branch,
            CustomerSheetEnum.CBS_ID.value: cbs_id,
            CustomerSheetEnum.WSS_ID.value: wss_id,
            CustomerSheetEnum.PIX_ID.value: pix_id,
            CustomerSheetEnum.UEN.value: uen,
            CustomerSheetEnum.OTL_ID.value: otl_id,
            CustomerSheetEnum.UNIFORM_SOCIAL_CREDIT_CODE.value: uniform_social_credit_code,
            CustomerSheetEnum.CUSTOMER_NAME_CN.value: customer_name_cn,
            CustomerSheetEnum.CUSTOMER_NAME_EN.value: customer_name_en,
            CustomerSheetEnum.CUSTOMER_CATEGORY.value: customer_category,
            CustomerSheetEnum.NATIONALITY.value: nationality,
            CustomerSheetEnum.COUNTRY.value: country,
            CustomerSheetEnum.EXPOSURE_COUNTRY.value: exposure_country,
            CustomerSheetEnum.AREA.value: area,
            CustomerSheetEnum.CORP_TYPE.value: corp_type,
            CustomerSheetEnum.CORP_SIZE.value: corp_size,
            CustomerSheetEnum.INDUSTRY_CODE.value: industry_code,
            CustomerSheetEnum.HOLDING_TYPE.value: holding_type,
            CustomerSheetEnum.UNIQUE_ID_VALUE.value: unique_id_value,
            CustomerSheetEnum.GROUP_CODE.value: group_code,
            CustomerSheetEnum.GROUP_NAME.value: group_name,
            CustomerSheetEnum.GROUP_CHINESE_NAME.value: group_chinese_name,
            CustomerSheetEnum.STATUS.value: status,
            CustomerSheetEnum.DATA_DATE.value: data_date
        }

    def query_capital_data(self, data_date):
        """
        查询资本净额和一级资本净额
        :param data_date: 取数日期
        """
        capital_data = rra_db.query_capital_data(data_date=data_date)
        if capital_data is None:
            raise DataException('capital_data is empty, whether there is capital data on {}'.format(data_date))

        return self.__create_capital_item(tier1_capital_amt=capital_data['tier1_capital_amt'],
                                          total_capital_amt=capital_data['total_capital_amt'])

    def __create_capital_item(self, tier1_capital_amt, total_capital_amt):
        return {
            OtherInputsSheetEnum.TIER1_CAPITAL_AMT.value: tier1_capital_amt,
            OtherInputsSheetEnum.TOTAL_CAPITAL_AMT.value: total_capital_amt
        }

    def query_ead_report_data(self, data_date):
        """
        查询 EAD report数据
        :param data_date: 取数日期
        """

        ead_data_list = rra_db.query_ead_report_data(data_date=data_date)
        if ead_data_list is None:
            raise DataException('ead_data_list is empty, whether there is EAD report data on {}'.format(data_date))

        ead_ls = []
        for ead_item in ead_data_list:
            ead_obj = self.__create_ead_report_item(cbs_id=ead_item['cbs_cif_id'],
                                                    counterparty_longname=ead_item['counterparty_long_name'],
                                                    counterparty_type=ead_item['counterparty_type'],
                                                    ibuk_customer_number=ead_item['ibuk_customer_number'],
                                                    ead_usd=ead_item['ead_usd'], ead_cny_eqv=None)
            ead_ls.append(ead_obj)

        return ead_ls

    def __create_ead_report_item(self, cbs_id, counterparty_longname, counterparty_type,
                                 ibuk_customer_number, ead_usd, ead_cny_eqv):
        return {
            EadSheetEnum.CBS_ID.value: cbs_id,
            EadSheetEnum.COUNTERPARTY_LONG_NAME.value: counterparty_longname,
            EadSheetEnum.COUNTERPARTY_TYPE.value: counterparty_type,
            EadSheetEnum.IBUK_CUSTOMER_NUMBER.value: ibuk_customer_number,
            EadSheetEnum.EAD_USD.value: ead_usd,
            EadSheetEnum.EAD_CNY_EQV.value: ead_cny_eqv
        }

    def query_money_market_data(self, data_date):
        mm505_data_list = rra_db.query_money_market_data(data_date)
        mm505_ls = []

        if mm505_data_list is None:
            raise DataException('mm505_data_list is empty, whether there is MM505 data on {}'.format(data_date))

        for mm505_item in mm505_data_list:
            mm505_obj = self.__create_mm505_item(cbs_id=mm505_item['cbs_id'], report_date=mm505_item['report_date'],
                                                 value_date=mm505_item['value_date'], mat_date=mm505_item['mat_date'],
                                                 deal_type=mm505_item['deal_type'],
                                                 deal_type_rra=mm505_item['deal_type_rra'], ccy=mm505_item['ccy'],
                                                 amount=mm505_item['amount'],
                                                 interest_rec_pay=mm505_item['total_interest'],
                                                 name_short=mm505_item['name_short'], customer_type=mm505_item['type'],
                                                 wss_customer_number=mm505_item['mm_cust_num'],
                                                 inventory=mm505_item['inventory'],
                                                 customer_short_name=mm505_item['customer_short_name'],
                                                 cny_eqv=mm505_item['cny_eqv'], interest_amt=mm505_item['interest_amt'])

            mm505_ls.append(mm505_obj)
        return mm505_ls

    def __create_mm505_item(self, cbs_id, report_date, value_date, mat_date, deal_type, deal_type_rra, ccy,
                            amount, interest_rec_pay, name_short, customer_type, wss_customer_number, inventory,
                            customer_short_name, cny_eqv, interest_amt):
        return {
            MM505SheetEnum.CBS_ID.value: cbs_id,
            MM505SheetEnum.REPORT_DATE.value: report_date,
            MM505SheetEnum.VALUE_DATE.value: value_date,
            MM505SheetEnum.MAT_DATE.value: mat_date,
            MM505SheetEnum.DEAL_TYPE.value: deal_type,
            MM505SheetEnum.DEAL_TYPE_RRA.value: deal_type_rra,
            MM505SheetEnum.CCY.value: ccy,
            MM505SheetEnum.AMOUNT.value: amount,
            MM505SheetEnum.TOTAL_INTEREST.value: interest_rec_pay,
            MM505SheetEnum.NAME_SHORT.value: name_short,
            MM505SheetEnum.TYPE.value: customer_type,
            MM505SheetEnum.MM_CUST_NUM.value: wss_customer_number,
            MM505SheetEnum.INVENTORY.value: inventory,
            MM505SheetEnum.CUSTOMER_SHORT_NAME.value: customer_short_name,
            MM505SheetEnum.CNY_EQV.value: cny_eqv,
            MM505SheetEnum.INTEREST_AMT.value: interest_amt,
        }

    def query_dsc_data(self, data_date):
        """
        查询 DSC 数据
        :param data_date: 取数日期
        """
        dsc_data_list = rra_db.query_dsc_data(data_date)
        dsc_ls = []

        if dsc_data_list is None:
            raise DataException('dsc_data_list is empty, whether there is DSC data on {}'.format(data_date))

        for dsc_item in dsc_data_list:
            dsc_obj = self.__create_dsc_item(cbs_id=dsc_item['cbs_id'],
                                             beneficiary_cbs_id=dsc_item['beneficiary_cbs_id'],
                                             riskparty_uen=dsc_item['riskparty_uen'],
                                             riskparty_cbsid=dsc_item['riskparty_cbsid'], product=dsc_item['product'],
                                             with_bank_customer=dsc_item['with_bank_customer'],
                                             riskparty_cbsid_2=dsc_item['riskparty_cbsid2'],
                                             riskpary_uen_2=dsc_item['riskparty_uen2'], currency=dsc_item['currency'],
                                             amount=dsc_item['amount'],
                                             interest_in_advance=dsc_item['interest_in_advance'],
                                             income_accrual_amount=dsc_item['income_accrual_amount'])

            dsc_ls.append(dsc_obj)
        return dsc_ls

    def __create_dsc_item(self, cbs_id, beneficiary_cbs_id, riskparty_uen, riskparty_cbsid, product, with_bank_customer,
                          riskparty_cbsid_2,
                          riskpary_uen_2, currency, amount, interest_in_advance, income_accrual_amount):
        return {
            DscSheetEnum.CBS_ID.value: cbs_id,
            DscSheetEnum.BENEFICARY_CBS_ID.value: beneficiary_cbs_id,
            DscSheetEnum.RISKPARTY_UEN.value: riskparty_uen,
            DscSheetEnum.RISKPARTY_CBSID.value: riskparty_cbsid,
            DscSheetEnum.PRODUCT.value: product,
            DscSheetEnum.WITH_BANK_CUSTOMER.value: with_bank_customer,
            DscSheetEnum.RISKPARTY_CBSID_2.value: riskparty_cbsid_2,
            DscSheetEnum.RISKPARTY_UEN_2.value: riskpary_uen_2,
            DscSheetEnum.CURRENCY.value: currency,
            DscSheetEnum.AMOUNT.value: amount,
            DscSheetEnum.INTEREST_IN_ADVANCE.value: interest_in_advance,
            DscSheetEnum.INCOME_ACCRUAL_AMOUNT.value: income_accrual_amount,
        }

    def query_llp_data(self, data_date):
        """
        查询 LLP 数据
        :param data_date: 取数日期
        """

        llp_data_list = rra_db.query_llp_data(data_date)
        llp_ls = []

        if llp_data_list is None:
            raise DataException('llp_data_list is empty, whether there is LLP data on {}'.format(data_date))

        for llp_item in llp_data_list:
            llp_obj = self.__create_llp_item(branch=llp_item['branch'], bs_offbs=llp_item['bsoffbs'],
                                             deal_type=llp_item['deal_type'],
                                             uen=llp_item['uen'], ccy_cny_usd=llp_item['ccy_cny_usd'],
                                             prov_amt=llp_item['prov_amt'])
            llp_ls.append(llp_obj)
        return llp_ls

    def __create_llp_item(self, branch, bs_offbs, deal_type, uen, ccy_cny_usd, prov_amt):
        return {
            LlpSheetEnum.BRANCH.value: branch,
            LlpSheetEnum.BS_OFFBS.value: bs_offbs,
            LlpSheetEnum.DEAL_TYPE.value: deal_type,
            LlpSheetEnum.UEN.value: uen,
            LlpSheetEnum.CCY_CNY_USD.value: ccy_cny_usd,
            LlpSheetEnum.PROV_AMT.value: prov_amt
        }

    def query_nostro_data(self, data_date):

        nostro_data_list = rra_db.query_nostro_data(data_date)
        nostro_ls = []

        if nostro_data_list is None:
            raise DataException('nostro_data_list is empty, whether there is Nostro data on {}'.format(data_date))

        for nostro_item in nostro_data_list:
            nostro_obj = self.__create_nostro_item(cbs_customer_id=nostro_item['cust_no'], ccy=nostro_item['ccy'],
                                                   amount=nostro_item['amount'],
                                                   fcy_amount=nostro_item['fcy_amount'])
            nostro_ls.append(nostro_obj)
        return nostro_ls

    def __create_nostro_item(self, cbs_customer_id, ccy, amount, fcy_amount):
        return {
            NostroSheetEnum.CUST_NO.value: cbs_customer_id,
            NostroSheetEnum.CCY.value: ccy,
            NostroSheetEnum.AMOUNT.value: amount,
            NostroSheetEnum.FCY_AMOUNT.value: fcy_amount
        }

    def query_limit_data(self, data_date):
        limit_data_list = rra_db.query_limit_data(data_date)
        limit_ls = []

        if limit_data_list is None:
            raise DataException('limit_data_list is empty, whether there is Limit data on {}'.format(data_date))

        for limit_item in limit_data_list:
            limit_obj = self.__create_limit_item(cbs_id=limit_item['cbs_id'], customer_id=limit_item['customer_id'],
                                                 currency=limit_item['currency'],
                                                 available_credit_limit=limit_item['available_credit_limit'],
                                                 revocable=limit_item['revocable'],
                                                 org_period_in_one_year=limit_item['org_period_in_one_year'])
            limit_ls.append(limit_obj)
        return limit_ls

    def __create_limit_item(self, cbs_id, customer_id, currency, available_credit_limit, revocable,
                            org_period_in_one_year):
        return {
            LimitSheetEnum.CBS_ID.value: cbs_id,
            LimitSheetEnum.CUSTOMER_ID.value: customer_id,
            LimitSheetEnum.CURRENCY.value: currency,
            LimitSheetEnum.AVAILABLE_CREDIT_LIMIT.value: available_credit_limit,
            LimitSheetEnum.REVOCABLE.value: revocable,
            LimitSheetEnum.ORG_PERIOD_IN_ONE_YEAR.value: org_period_in_one_year
        }

    def query_auto_fin_data(self, data_date):
        auto_fin_data_list = rra_db.query_auto_fin_data(data_date)
        auto_fin_list = []
        for auto_fin_item in auto_fin_data_list:
            auto_fin_obj = self.__create_autfo_fin_item(cbs_id=auto_fin_item['cbs_cust_id'],
                                                        currency=auto_fin_item['currency'],
                                                        amount=auto_fin_item['amount'],
                                                        interest_received_to_gl=auto_fin_item[
                                                            'interest_received_to_gl'])
            auto_fin_list.append(auto_fin_obj)
        return auto_fin_list

    def __create_autfo_fin_item(self, cbs_id, currency, amount, interest_received_to_gl):
        return {
            AutoFinSheetEnum.CBS_ID.value: cbs_id,
            AutoFinSheetEnum.CURRENCY.value: currency,
            AutoFinSheetEnum.AMOUNT.value: amount,
            AutoFinSheetEnum.INTEREST_RECEIVED_TO_SQL.value: interest_received_to_gl
        }

    def query_offbs_tf_data(self, data_date):
        offbs_data_list = rra_db.query_offbs_tf_data(data_date)
        offbs_tf_obj_list = []

        for offbs_tf_item in offbs_data_list:
            offbs_tf_obj = self.__create_offbs_tf_item(cbs_id=offbs_tf_item['cbs_id'], uen_no=offbs_tf_item['uen_no'],
                                                       offbs_factor=offbs_tf_item['offbs_factor'],
                                                       deal_type=offbs_tf_item['deal_type'],
                                                       currency=offbs_tf_item['currency'],
                                                       amount=offbs_tf_item['amount'])
            offbs_tf_obj_list.append(offbs_tf_obj)
        return offbs_tf_obj_list

    def __create_offbs_tf_item(self, cbs_id, uen_no, offbs_factor, deal_type, currency, amount):
        return {
            OffbsTfSheetEnum.CBS_ID.value: cbs_id,
            OffbsTfSheetEnum.UEN_NO.value: uen_no,
            OffbsTfSheetEnum.OFFBS_FACTOR.value: offbs_factor,
            OffbsTfSheetEnum.DEAL_TYPE.value: deal_type,
            OffbsTfSheetEnum.CURRENCY.value: currency,
            OffbsTfSheetEnum.AMOUNT.value: amount
        }

    def query_bond_ncd_data(self, data_date):
        bond_ncd_data_list = rra_db.query_bond_ncd_data(data_date)
        bond_ncd_obj_list = []

        for bond_ncd_item in bond_ncd_data_list:
            bond_ncd_obj = self.__create_bond_ncd_item(cbs_id=bond_ncd_item['cbs_id'], accounting_code=bond_ncd_item['accounting_code'], issuser_uen=bond_ncd_item['issuer_uen'], ccy=bond_ncd_item['ccy'],
                                        balance=bond_ncd_item['balance'], interest_receivable=bond_ncd_item['interest_receivable'], profit_center=bond_ncd_item['profit_centre'])
            bond_ncd_obj_list.append(bond_ncd_obj)

        return bond_ncd_obj_list

    def __create_bond_ncd_item(self, cbs_id, accounting_code, issuser_uen, ccy, balance, interest_receivable, profit_center):
        return {
            BondNcdSheetEnum.CBS_ID.value: cbs_id,
            BondNcdSheetEnum.ACCOUNTING_CODE.value: accounting_code,
            BondNcdSheetEnum.ISSUER_UEN.value: issuser_uen,
            BondNcdSheetEnum.CCY.value: ccy,
            BondNcdSheetEnum.BALANCE.value: balance,
            BondNcdSheetEnum.INTEREST_RECEIVABLE.value: interest_receivable,
            BondNcdSheetEnum.PROFIT_CENTER.value: profit_center
        }
