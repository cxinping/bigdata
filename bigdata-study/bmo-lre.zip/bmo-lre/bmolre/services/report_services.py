# -*- coding: utf-8 -*-

"""
Created on 2020-11-10

@author: Wang Shuo
"""

from abc import ABCMeta, abstractmethod
import os
import shutil

from bmolre.commons.logging import get_logger, log_entry_exit
import bmolre.commons.constant as constant
from bmolre.exceptions import ReportException, ReportInvalidDataDateException
from bmolre.commons.report_enums import (
    ReportType, G14ReportSpreadSheets, LreDailyReportSpreadSheets, RateSheetEnum, LoanSheetEnum,
    OtherInputsSheetEnum, CustomerSheetEnum, EadSheetEnum, CommonParamEnum, MM505SheetEnum, DscSheetEnum,
    LlpSheetEnum, NostroSheetEnum, LimitSheetEnum, AutoFinSheetEnum, OffbsTfSheetEnum, BondNcdSheetEnum
)
from bmolre.services.data_services import DataService
from bmolre.services.report_cal_services import ReportService
from bmolre.commons.check_valid import is_valid_date

import openpyxl
from openpyxl.utils import column_index_from_string

log = get_logger()


class BaseReport(metaclass=ABCMeta):
    __wb = None

    def __init__(self, report_type, data_date):
        """
        :param report_type: 报表类型
        :param data_date : 查询报表时间
        """
        self.__report_type = report_type

        if not is_valid_date(data_date):
            raise ReportInvalidDataDateException(
                'The input data_date({}) is invalid, The correct data_date format is 20201119'.format(data_date))

        self.__data_date = data_date
        self.__data_service = DataService()
        self.__report_service = ReportService()

    def get_report_type(self):
        return self.__report_type

    def get_data_date(self):
        return self.__data_date

    def get_data_service(self):
        return self.__data_service

    def get_report_service(self):
        return self.__report_service

    @abstractmethod
    def remove_temporary_sheets(self):
        pass

    def create_target_report(self):
        """
        根据报表模板复制一份报表的模板
        :return: 返回复制的报表模板，包括：报表模板的地址和名称
        """
        report_template = self.__get_report_template()
        target_report = self.get_target_report()

        if not os.path.exists(constant.CREATED_REPORT_PATH):
            os.mkdir(constant.CREATED_REPORT_PATH)

        if os.path.isfile(target_report):
            os.remove(target_report)

        shutil.copy(report_template, target_report)

    def del_target_report(self):
        """
        删除生成的目标报表
        """
        target_report = self.get_target_report()

        if os.path.isfile(target_report):
            os.remove(target_report)

    @log_entry_exit
    def get_target_report(self):
        """
        :return:返回生成的目标报表，包括：目标报表的地址和名称
        """
        report_day = str(self.get_data_date())
        lre_daily_report_name = 'Large_Risk_Exposure_Daily_Report-{}.xlsx'.format(report_day)
        g14_report_name = 'G14_Report_v1.0-{}.xlsx'.format(report_day)
        target_report = None

        if self.get_report_type() == ReportType.DAILY_REPORT:
            target_report = os.path.join(constant.CREATED_REPORT_PATH, lre_daily_report_name)
        elif self.get_report_type() == ReportType.G14_REPORT:
            target_report = os.path.join(constant.CREATED_REPORT_PATH, g14_report_name)

        return target_report

    def __get_report_template(self):
        report_template = None
        if self.get_report_type() == ReportType.DAILY_REPORT:
            report_template = os.path.join(constant.REPORT_TEMPLATE_PATH, constant.LRE_DAILY_REPORT_TEMPLATE)
        elif self.get_report_type() == ReportType.G14_REPORT:
            report_template = os.path.join(constant.REPORT_TEMPLATE_PATH, constant.G14_QUARTERLY_REPORT_TEMPLATE)
        return report_template

    def load_target_report(self):
        try:
            if self.get_report_type() == ReportType.DAILY_REPORT:
                log.info('*** load daily_report => {}'.format(self.get_target_report()))
            elif self.get_report_type() == ReportType.G14_REPORT:
                log.info('*** load G14_report => {}'.format(self.get_target_report()))

            self.create_target_report()
            self.__wb = openpyxl.load_workbook(self.get_target_report())
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def get_workbook(self):
        return self.__wb

    def save_report(self):
        if self.get_report_type() == ReportType.DAILY_REPORT:
            log.info("save lre daily report ")
        elif self.get_report_type() == ReportType.G14_REPORT:
            log.info("save G14 report ")

        self.__wb.save(self.get_target_report())

    def init_rate_sheet(self):
        log.info('*** daily init_rate_sheet')
        rate_worksheet = self.__wb[LreDailyReportSpreadSheets.RATE.value]

        try:
            rate_data_list = self.get_report_service().init_rate_data(self.get_data_date())

            log.debug('rate_data_list=%s', rate_data_list)

            row_num = len(rate_data_list)
            column_num = 5
            for row in range(0, row_num):
                rate_obj = rate_data_list[row]

                for column in range(0, column_num):
                    cell = rate_worksheet.cell(row=row + 2, column=column + 1)
                    if column == 0:
                        cell.value = rate_obj[RateSheetEnum.S_DATE.value]
                    elif column == 1:
                        cell.value = rate_obj[RateSheetEnum.E_DATE.value]
                    elif column == 2:
                        cell.value = rate_obj[RateSheetEnum.BASIC_CCY.value]
                    elif column == 3:
                        cell.value = rate_obj[RateSheetEnum.FORWARD_CCY.value]
                    elif column == 4:
                        cell.value = rate_obj[RateSheetEnum.CCY_RATE.value]
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_loan_sheet(self):
        log.info('*** daily init_loan_sheet')
        loan_worksheet = self.__wb[LreDailyReportSpreadSheets.LOAN.value]

        try:
            loan_cn_data_list = self.get_report_service().query_loan_data(data_date=self.get_data_date())
            row_num = len(loan_cn_data_list)
            column_num = column_index_from_string('BQ')
            for row in range(0, row_num):
                loan_cn_obj = loan_cn_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):

                    if column == column_index_from_string('A'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cbs_id_formula = '=K' + str(row_idx_1)
                        cell.value = cbs_id_formula
                    elif column == column_index_from_string('K'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = loan_cn_obj[LoanSheetEnum.CBS_CUST_ID.value]
                    elif column == column_index_from_string('L'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = loan_cn_obj[LoanSheetEnum.CURRENCY.value]
                    elif column == column_index_from_string('M'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = loan_cn_obj[LoanSheetEnum.AMOUNT.value]
                    elif column == column_index_from_string('AU'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = loan_cn_obj[LoanSheetEnum.INTEREST_RECEIVED_TO_GL.value]
                    elif column == column_index_from_string('BO'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = loan_cn_obj[LoanSheetEnum.CURRENCY.value]

                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IFERROR(IF(L{row_idx_1}="CNY",M{row_idx_1}+AU{row_idx_1}, {cny_rate}*(M{row_idx_1}+AU{row_idx_1})),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula
                    elif column == column_index_from_string('BP'):
                        cell = loan_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = loan_cn_obj[LoanSheetEnum.CURRENCY.value]

                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IFERROR(IF(L{row_idx_1}="CNY",M{row_idx_1}, {cny_rate}*(M{row_idx_1})),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_other_inputs_sheet(self):
        log.info('*** daily init_other_inputs_sheet')

        try:
            other_inputs_worksheet = self.__wb[LreDailyReportSpreadSheets.OTHER_INPUTS.value]
            other_input_data = self.get_report_service().query_capital_data(self.get_data_date())

            other_inputs_worksheet['B2'].value = other_input_data[OtherInputsSheetEnum.TOTAL_CAPITAL_AMT.value]
            other_inputs_worksheet['B3'].value = other_input_data[OtherInputsSheetEnum.TIER1_CAPITAL_AMT.value]
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))


class LreDailyReport(BaseReport):
    """ daily 报表 """

    def remove_temporary_sheets(self):
        log.info('* daily remove_temporary_sheets')
        wb = self.get_workbook()
        test_sheets = [LreDailyReportSpreadSheets.RATE.value, LreDailyReportSpreadSheets.LOAN.value,
                       LreDailyReportSpreadSheets.OTHER_INPUTS.value, LreDailyReportSpreadSheets.EAD.value,
                       LreDailyReportSpreadSheets.CUSTOMER.value, LreDailyReportSpreadSheets.MM_505.value,
                       LreDailyReportSpreadSheets.DSC.value, LreDailyReportSpreadSheets.LLP.value,
                       LreDailyReportSpreadSheets.NOSTRO.value, LreDailyReportSpreadSheets.LIMIT.value,
                       LreDailyReportSpreadSheets.AUTO_FIN.value, LreDailyReportSpreadSheets.OFFBS_TF.value,
                       LreDailyReportSpreadSheets.BOND_NCD.value]

        dev_sheets = [LreDailyReportSpreadSheets.DAILY_MASTER_LIST.value]
        dev_sheets.extend(test_sheets)

        for sheet_name in wb.sheetnames:
            if sheet_name not in dev_sheets:
                wb.remove(wb[sheet_name])

    def init_customer_sheet(self):
        log.info('*** daily init_customer_sheet')
        wb = self.get_workbook()
        customer_worksheet = wb[LreDailyReportSpreadSheets.CUSTOMER.value]

        try:
            customer_data_list = self.get_report_service().cal_customer_datas(self.get_data_date())
            row_num = len(customer_data_list)
            column_num = column_index_from_string('AC')

            for row in range(0, row_num):
                customer_obj = customer_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.LOCAL_BRANCH.value]
                    elif column == column_index_from_string('B'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('C'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ''  ###可能需要写入公式，暂时写入空
                    elif column == column_index_from_string('D'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.PIX_ID.value]
                    elif column == column_index_from_string('E'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.UEN.value]
                    elif column == column_index_from_string('F'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.OTL_ID.value]
                    elif column == column_index_from_string('G'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.UNIFORM_SOCIAL_CREDIT_CODE.value]
                    elif column == column_index_from_string('H'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CUSTOMER_NAME_CN.value]
                    elif column == column_index_from_string('I'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CUSTOMER_NAME_EN.value]
                    elif column == column_index_from_string('J'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CUSTOMER_CATEGORY.value]
                    elif column == column_index_from_string('K'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.NATIONALITY.value]
                    elif column == column_index_from_string('L'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.COUNTRY.value]
                    elif column == column_index_from_string('M'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.EXPOSURE_COUNTRY.value]
                    elif column == column_index_from_string('N'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.AREA.value]
                    elif column == column_index_from_string('O'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CORP_TYPE.value]
                    elif column == column_index_from_string('P'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.CORP_SIZE.value]
                    elif column == column_index_from_string('Q'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.INDUSTRY_CODE.value]
                    elif column == column_index_from_string('R'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.HOLDING_TYPE.value]
                    elif column == column_index_from_string('S'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.UNIQUE_ID_VALUE.value]
                    elif column == column_index_from_string('T'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.GROUP_CODE.value]
                    elif column == column_index_from_string('U'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.GROUP_NAME.value]
                    elif column == column_index_from_string('V'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.GROUP_CHINESE_NAME.value]
                    elif column == column_index_from_string('W'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.STATUS.value]
                    elif column == column_index_from_string('Y'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = customer_obj[CustomerSheetEnum.DATA_DATE.value]
                    elif column == column_index_from_string('AB'):
                        cell = customer_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=B' + str(row_idx_1)
                        cell.value = cell_formula

            # log.info('* row_num={}'.format(row_num))
            return customer_data_list
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_ead_sheet(self):
        log.info('*** daily init_ead_sheet')
        wb = self.get_workbook()
        ead_worksheet = wb[LreDailyReportSpreadSheets.EAD.value]

        try:
            ead_data_list = self.get_report_service().cal_ead_ead_report_data(self.get_data_date())
            row_num = len(ead_data_list)
            column_num = column_index_from_string('K')

            for row in range(0, row_num):
                ead_obj = ead_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = ead_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=J{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('C'):
                        cell = ead_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ead_obj[EadSheetEnum.COUNTERPARTY_LONG_NAME.value]
                    elif column == column_index_from_string('D'):
                        cell = ead_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ead_obj[EadSheetEnum.COUNTERPARTY_TYPE.value]
                    elif column == column_index_from_string('E'):
                        cell = ead_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ead_obj[EadSheetEnum.IBUK_CUSTOMER_NUMBER.value]
                    elif column == column_index_from_string('F'):
                        cell = ead_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ead_obj[EadSheetEnum.EAD_USD.value]
                    elif column == column_index_from_string('I'):
                        cell = ead_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ead_obj[EadSheetEnum.EAD_CNY_EQV.value]
                    elif column == column_index_from_string('J'):
                        cell = ead_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = ead_obj[EadSheetEnum.CBS_ID.value]

        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_mm505_sheet(self):
        log.info('*** daily init_mm505_sheet')
        wb = self.get_workbook()
        mm505_worksheet = wb[LreDailyReportSpreadSheets.MM_505.value]

        try:
            mm505_data_list = self.get_report_service().query_money_market_data(self.get_data_date())
            row_num = len(mm505_data_list)
            column_num = column_index_from_string('AH')

            for row in range(0, row_num):
                mm505_obj = mm505_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=AC{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = self.get_data_date()
                    elif column == column_index_from_string('H'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.VALUE_DATE.value]
                    elif column == column_index_from_string('I'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.MAT_DATE.value]
                    elif column == column_index_from_string('J'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.DEAL_TYPE.value]
                    elif column == column_index_from_string('K'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.DEAL_TYPE_RRA.value]
                    elif column == column_index_from_string('M'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.CCY.value]
                    elif column == column_index_from_string('N'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.AMOUNT.value]
                    elif column == column_index_from_string('O'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.TOTAL_INTEREST.value]
                    elif column == column_index_from_string('S'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.NAME_SHORT.value]
                    elif column == column_index_from_string('U'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.TYPE.value]
                    elif column == column_index_from_string('V'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.MM_CUST_NUM.value]
                    elif column == column_index_from_string('AA'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.INVENTORY.value]
                    elif column == column_index_from_string('AB'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.CUSTOMER_SHORT_NAME.value]
                    elif column == column_index_from_string('AC'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('AD'):
                        cell = mm505_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = mm505_obj[MM505SheetEnum.CNY_EQV.value]

            # log.info('MM505 nums={}'.format(len(mm505_data_list)))
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_dsc_sheet(self):
        log.info('*** daily init_dsc_sheet')
        wb = self.get_workbook()
        dsc_worksheet = wb[LreDailyReportSpreadSheets.DSC.value]

        try:
            dsc_data_list = self.get_report_service().query_dsc_data(self.get_data_date())
            row_num = len(dsc_data_list)
            column_num = column_index_from_string('CQ')

            for row in range(0, row_num):
                dsc_obj = dsc_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('B'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.BENEFICARY_CBS_ID.value]
                    elif column == column_index_from_string('C'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.RISKPARTY_UEN.value]
                    elif column == column_index_from_string('D'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.RISKPARTY_CBSID.value]
                    elif column == column_index_from_string('H'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.PRODUCT.value]
                    elif column == column_index_from_string('K'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.WITH_BANK_CUSTOMER.value]
                    elif column == column_index_from_string('L'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.RISKPARTY_CBSID_2.value]
                    elif column == column_index_from_string('U'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.RISKPARTY_UEN_2.value]
                    elif column == column_index_from_string('V'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.CURRENCY.value]
                    elif column == column_index_from_string('W'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.AMOUNT.value]
                    elif column == column_index_from_string('AK'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.INTEREST_IN_ADVANCE.value]
                    elif column == column_index_from_string('AR'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = dsc_obj[DscSheetEnum.INCOME_ACCRUAL_AMOUNT.value]

                    elif column == column_index_from_string('CO'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = dsc_obj[DscSheetEnum.CURRENCY.value]

                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IF(AK7="Y",IFERROR(IF(V{row_idx_1}="CNY",W{row_idx_1}, W{row_idx_1} * {cny_rate} ) ,0),IFERROR(IF(V{row_idx_1}="CNY",W{row_idx_1}+AR{row_idx_1}, (W{row_idx_1}+AR{row_idx_1})* {cny_rate} ),0))'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula
                    elif column == column_index_from_string('CP'):
                        cell = dsc_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = dsc_obj[DscSheetEnum.CURRENCY.value]

                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IF(AK{row_idx_1}="Y",IFERROR(IF(V{row_idx_1}="CNY",W{row_idx_1}, W{row_idx_1} * {cny_rate} ),0),IFERROR(IF(V{row_idx_1}="CNY",W{row_idx_1}, (W{row_idx_1}) * {cny_rate} ),0))'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

            # log.info('DSC nums={}'.format(len(dsc_data_list)))
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_llp_sheet(self):
        log.info('*** daily init_llp_sheet')
        wb = self.get_workbook()
        llp_worksheet = wb[LreDailyReportSpreadSheets.LLP.value]

        try:
            llp_data_list = self.get_report_service().query_llp_data(self.get_data_date())
            row_num = len(llp_data_list)
            column_num = column_index_from_string('AE')

            for row in range(0, row_num):
                llp_obj = llp_data_list[row]
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.BRANCH.value]
                    elif column == column_index_from_string('B'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.BS_OFFBS.value]
                    elif column == column_index_from_string('C'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.DEAL_TYPE.value]
                    elif column == column_index_from_string('F'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.UEN.value]
                    elif column == column_index_from_string('T'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.CCY_CNY_USD.value]
                    elif column == column_index_from_string('V'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = llp_obj[LlpSheetEnum.PROV_AMT.value]

                    elif column == column_index_from_string('AD'):
                        cell = llp_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = llp_obj[LlpSheetEnum.CCY_CNY_USD.value]

                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IFERROR(IF(T{row_idx_1}="CNY",V{row_idx_1}, {cny_rate} * V{row_idx_1} ),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

            # log.info('LLP nums={}'.format(len(llp_data_list)))
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_nostro_sheet(self):
        log.info('*** daily init_nostro_sheet')
        wb = self.get_workbook()
        nostro_worksheet = wb[LreDailyReportSpreadSheets.NOSTRO.value]

        try:
            nostro_data_list = self.get_report_service().query_nostro_data(self.get_data_date())
            row_num = len(nostro_data_list)
            column_num = column_index_from_string('G')

            for row in range(0, row_num):
                nostro_obj = nostro_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=B{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = nostro_obj[NostroSheetEnum.CUST_NO.value]
                    elif column == column_index_from_string('C'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = nostro_obj[NostroSheetEnum.CCY.value]
                    elif column == column_index_from_string('D'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = nostro_obj[NostroSheetEnum.AMOUNT.value]
                    elif column == column_index_from_string('E'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = nostro_obj[NostroSheetEnum.FCY_AMOUNT.value]
                    elif column == column_index_from_string('F'):
                        cell = nostro_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=(D{row_idx_1}+E{row_idx_1})'.format(row_idx_1=row_idx_1)
                        cell.value = cell_formula
            # log.info('Nostro nums={}'.format(len(nostro_data_list)))
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_limit_sheet(self):
        log.info('*** daily init_limit_sheet')
        wb = self.get_workbook()
        limit_worksheet = wb[LreDailyReportSpreadSheets.LIMIT.value]

        try:
            limit_data_list = self.get_report_service().cal_limit_data(self.get_data_date())
            row_num = len(limit_data_list)
            column_num = column_index_from_string('AK')

            for row in range(0, row_num):
                limit_obj = limit_data_list[row]
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=D{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('D'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = limit_obj[LimitSheetEnum.CUSTOMER_ID.value]
                    elif column == column_index_from_string('G'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = limit_obj[LimitSheetEnum.CURRENCY.value]
                    elif column == column_index_from_string('O'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = limit_obj[LimitSheetEnum.AVAILABLE_CREDIT_LIMIT.value]
                    elif column == column_index_from_string('R'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = limit_obj[LimitSheetEnum.REVOCABLE.value]
                    elif column == column_index_from_string('U'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = limit_obj[LimitSheetEnum.ORG_PERIOD_IN_ONE_YEAR.value]

                    elif column == column_index_from_string('AJ'):
                        cell = limit_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = limit_obj[LimitSheetEnum.CURRENCY.value]
                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)

                        cell_formula = '=IFERROR(IF(G{row_idx_1}="CNY",O{row_idx_1}*1000, {cny_rate} * O{row_idx_1} * 1000),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

            log.debug('*** Limit data nums={}'.format(len(limit_data_list)))
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_auto_fin_sheet(self):
        log.info('*** daily init_auto_fin_sheet')
        wb = self.get_workbook()
        auto_fin_worksheet = wb[LreDailyReportSpreadSheets.AUTO_FIN.value]

        try:
            auto_fin_data_list = self.get_report_service().query_auto_fin_data(self.get_data_date())
            row_num = len(auto_fin_data_list)
            column_num = column_index_from_string('G')

            for row in range(0, row_num):
                auto_fin_obj = auto_fin_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=B{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = auto_fin_obj[AutoFinSheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('C'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = auto_fin_obj[AutoFinSheetEnum.CURRENCY.value]
                    elif column == column_index_from_string('D'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = auto_fin_obj[AutoFinSheetEnum.AMOUNT.value]
                    elif column == column_index_from_string('E'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = auto_fin_obj[AutoFinSheetEnum.INTEREST_RECEIVED_TO_SQL.value]
                    elif column == column_index_from_string('F'):
                        cell = auto_fin_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = auto_fin_obj[AutoFinSheetEnum.CURRENCY.value]
                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IFERROR(IF(C{row_idx_1}="CNY",D{row_idx_1}+E{row_idx_1}, {cny_rate} * (D{row_idx_1}+E{row_idx_1}) ),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

            log.debug('*** Auto_Fin data nums={}'.format(len(auto_fin_data_list)))
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_offbs_tf_sheet(self):
        log.info('*** daily init_offbs_tf_sheet')
        wb = self.get_workbook()
        offbs_tf_worksheet = wb[LreDailyReportSpreadSheets.OFFBS_TF.value]

        try:
            offbs_tf_data_list = self.get_report_service().query_offbs_tf_data(self.get_data_date())
            row_num = len(offbs_tf_data_list)
            column_num = column_index_from_string('Y')

            for row in range(0, row_num):
                offbs_tf_obj = offbs_tf_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=C{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.UEN_NO.value]
                    elif column == column_index_from_string('C'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('D'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.OFFBS_FACTOR.value]
                    elif column == column_index_from_string('G'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.DEAL_TYPE.value]
                    elif column == column_index_from_string('J'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.UEN_NO.value]
                    elif column == column_index_from_string('K'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.CURRENCY.value]
                    elif column == column_index_from_string('L'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = offbs_tf_obj[OffbsTfSheetEnum.AMOUNT.value]

                    elif column == column_index_from_string('X'):
                        cell = offbs_tf_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = offbs_tf_obj[OffbsTfSheetEnum.CURRENCY.value]
                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = "=IFERROR(IF('offbs TF'!K{row_idx_1}=\"CNY\",'offbs TF'!L{row_idx_1}, {cny_rate} * L{row_idx_1}),0)".format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula

            log.debug('*** offbs TF data nums={}'.format(len(offbs_tf_data_list)))
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_bond_ncd_sheet(self):
        log.info('*** daily init_bond_ncd_sheet')
        wb = self.get_workbook()
        bond_ncd_worksheet = wb[LreDailyReportSpreadSheets.BOND_NCD.value]

        try:
            bond_ncd_data_list = self.get_report_service().query_bond_ncd_data(self.get_data_date())
            row_num = len(bond_ncd_data_list)
            column_num = column_index_from_string('J')

            for row in range(0, row_num):
                bond_ncd_obj = bond_ncd_data_list[row]
                row_idx_1 = row + 2

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=H{idx}'.format(idx=row_idx_1)
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.ACCOUNTING_CODE.value]
                    elif column == column_index_from_string('C'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.ISSUER_UEN.value]
                    elif column == column_index_from_string('D'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.CCY.value]
                    elif column == column_index_from_string('E'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.BALANCE.value]
                    elif column == column_index_from_string('F'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.INTEREST_RECEIVABLE.value]
                    elif column == column_index_from_string('G'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cny_rate = 0
                        currency = bond_ncd_obj[BondNcdSheetEnum.CCY.value]
                        if currency == CommonParamEnum.CNY.value:
                            cny_rate = 1
                        else:
                            cny_rate = self.get_report_service().query_cny_rate_from_cache(
                                data_date=self.get_data_date(), basic_ccy=currency)
                        cell_formula = '=IFERROR(IF(D{row_idx_1}="CNY",E{row_idx_1}+F{row_idx_1}, {cny_rate} * (E{row_idx_1}+F{row_idx_1}) ),0)'.format(
                            row_idx_1=row_idx_1, cny_rate=cny_rate)
                        cell.value = cell_formula
                    elif column == column_index_from_string('H'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.CBS_ID.value]
                    elif column == column_index_from_string('I'):
                        cell = bond_ncd_worksheet.cell(row=row_idx_1, column=column)
                        cell.value = bond_ncd_obj[BondNcdSheetEnum.PROFIT_CENTER.value]

            log.debug('*** Bond & NCD data nums={}'.format(len(bond_ncd_data_list)))
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))

    def init_master_list_sheet(self, customer_data_list):
        log.info('****** daily init_master_list_sheet')
        wb = self.get_workbook()
        master_list_worksheet = wb[LreDailyReportSpreadSheets.DAILY_MASTER_LIST.value]

        try:
            row_num = len(customer_data_list)
            column_num = column_index_from_string('AV')

            for row in range(0, row_num):
                row_idx_1 = row + 3

                for column in range(0, column_num):
                    if column == column_index_from_string('A'):
                        # ColumnA is UEN
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(ISBLANK(VLOOKUP(B{idx},Customer!$B:$E,4,0)),"",VLOOKUP(B{idx},Customer!$B:$E,4,0))'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('B'):
                        # ColumnB is CBS_ID
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=Customer!B{idx}'.format(idx=(row_idx_1-1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('C'):
                        # ColumnC is CUSTOMER_NAME_EN
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=VLOOKUP(B{idx},Customer!$B:$I,8,0)'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('D'):
                        # ColumnD is CUSTOMER_CATEGORY
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=VLOOKUP(B{idx},Customer!$B:$J,9,0)'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('E'):
                        # ColumnE is CBS Group
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(IF(D{idx}="CORPORATE",VLOOKUP(B{idx},Customer!$B:$AA,19,0),"")=0,"",IF(D{idx}="CORPORATE",VLOOKUP(B{idx},Customer!$B:$AA,19,0),""))'.format(
                            idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('F'):
                        # ColumnF is Connection UEN
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=VLOOKUP(B{idx},Customer!B:Z,25,0)'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('G'):
                        # ColumnG is G14 group ind
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(AND(E{idx}="",OR(F{idx}="",F{idx}=0)),"N","Y")'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('H'):
                        # ColumnH is H14 cust type\nG14 客户类型
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(G{idx}="Y",IF(OR(D{idx}="CORPORATE",D{idx}="GOV"),"非同业集团客户","同业集团客户"),IF(OR(D{idx}="CORPORATE",D{idx}="GOV"),"非同业单一客户","同业单一客户"))'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('I'):
                        # ColumnI is Is UEN Duplicate?
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=IF(COUNTIF($A:$A,A{idx})=1,"N",IF(A{idx}=0,"N","Y"))'.format(idx=(row_idx_1))
                        cell.value = cell_formula

                    elif column == column_index_from_string('J'):
                        # ColumnI is Total Risk Exposure\n风险暴露总和
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '???'
                        cell.value = cell_formula
                    elif column == column_index_from_string('K'):
                        # ColumnI is %
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '???'
                        cell.value = cell_formula
                    elif column == column_index_from_string('L'):
                        # ColumnI is LRE IND
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '???'
                        cell.value = cell_formula
                    elif column == column_index_from_string('M'):
                        # ColumnM is General Risk Exposure\n一般风险暴露
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=SUM(W{idx}:Y{idx}, AH{idx}:AJ{idx},AA{idx}:AB{idx},AN{idx})-SUM(AR{idx}:AV{idx})'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('N'):
                        # ColumnN is Counterparty Credit Risk Exposure\n交易对手信用风险暴露
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=SUM(AM{idx})'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('O'):
                        # ColumnO is Counterparty Credit Risk Exposure\n交易对手信用风险暴露
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '=AC{idx}*$AC$2 + AD{idx} * $AD$2 + AE{idx} * $AE$2 + AF{idx} *$AF$2 + AG{idx} * $AG$2 - SUM(AW{idx}-AY{idx})'.format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('P'):
                        # ColumnP is Trading Book Risk Exposure\n交易账簿风险暴露
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '???'
                        cell.value = cell_formula
                    elif column == column_index_from_string('Q'):
                        # ColumnQ is Specified Risk Exposure 特定风险暴露
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '???'
                        cell.value = cell_formula
                    elif column == column_index_from_string('R'):
                        # ColumnR is Other Risk Exposure 其他风险暴露
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = '???'
                        cell.value = cell_formula
                    elif column == column_index_from_string('S'):
                        # ColumnS is Loan balance\n贷款余额
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS(Loan!BP:BP,Loan!$A:$A,'Daily Master List'!B{idx})/10000+Z{idx}".format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('T'):
                        # ColumnT is Exception
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "???"
                        cell.value = cell_formula
                    elif column == column_index_from_string('U'):
                        # ColumnU is Risk transfer ind\n风险缓释
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "???"
                        cell.value = cell_formula
                    elif column == column_index_from_string('V'):
                        # ColumnV is Risk mitigation & transfer
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "???"
                        cell.value = cell_formula
                    elif column == column_index_from_string('W'):
                        # ColumnW is Corporate Lending
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS(Loan!BO:BO,Loan!$A:$A,'Daily Master List'!B{idx})/10000".format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('X'):
                        # ColumnX is FIG Loans (IFI)
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS(DSC!CO:CO,DSC!A:A,'Daily Master List'!B{idx},DSC!K:K,\"IFI\")/10000".format(idx=(row_idx_1))
                        cell.value = cell_formula
                    elif column == column_index_from_string('Y'):
                        # ColumnY is TF finance (DSC)
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        cell_formula = "=SUMIFS(DSC!CP:CP,DSC!B:B,'Daily Master List'!B{idx},DSC!K:K,\"DSC\")/10000".format(idx=(row_idx_1))
                        cell.value = cell_formula



                    elif column == column_index_from_string('Z'):
                        # ColumnZ is
                        cell = master_list_worksheet.cell(row=row_idx_1, column=column)
                        # cell_formula = "".format(idx=(row_idx_1))
                        # cell.value = cell_formula



            log.debug('*** master data nums={}'.format(len(customer_data_list)))
        except Exception as err:
            log.error(err)
            raise ReportException(str(err))


class G14Report(BaseReport):
    """ g14 报表 """

    def remove_temporary_sheets(self):
        log.info('* g14 remove_temporary_sheets')
        wb = self.get_workbook()

        for sheet_name in wb.sheetnames:
            if sheet_name not in [G14ReportSpreadSheets.RATE.value, G14ReportSpreadSheets.LOAN.value]:
                wb.remove(wb[sheet_name])


class ReportBuilder(metaclass=ABCMeta):
    """ Report 建造者 """

    @abstractmethod
    def create_report(self, data_date):
        pass


class LreDailyReportBuilder(ReportBuilder):
    """ LRE daily Report 建造者 """

    def create_report(self, data_date):
        daily_report = None
        try:
            log.info("*** begin create daily report ***")
            daily_report = LreDailyReport(ReportType.DAILY_REPORT, data_date)
            daily_report.load_target_report()

            ### Extract Resource data to datasheet
            daily_report.init_rate_sheet()
            daily_report.save_report()

            daily_report.init_loan_sheet()
            daily_report.save_report()

            daily_report.init_other_inputs_sheet()
            daily_report.save_report()

            daily_report.init_ead_sheet()
            daily_report.save_report()

            customer_data_list = daily_report.init_customer_sheet()
            daily_report.save_report()

            daily_report.init_mm505_sheet()
            daily_report.save_report()

            daily_report.init_dsc_sheet()
            daily_report.save_report()

            daily_report.init_llp_sheet()
            daily_report.save_report()

            daily_report.init_nostro_sheet()
            daily_report.save_report()

            daily_report.init_limit_sheet()
            daily_report.save_report()

            daily_report.init_auto_fin_sheet()
            daily_report.save_report()

            daily_report.init_offbs_tf_sheet()
            daily_report.save_report()

            daily_report.init_bond_ncd_sheet()
            daily_report.save_report()

            ### Calculate data into intermediate datasheet from resource datasheet

            daily_report.init_master_list_sheet(customer_data_list)
            daily_report.save_report()


            ### Generate daily report



            daily_report.remove_temporary_sheets()
            daily_report.save_report()

            log.info('*******************************')
            log.info("*** end create daily report ***")
            log.info('*******************************')
            return daily_report
        except Exception as err:
            log.error("*** failed to create daily report ***")
            log.error(err)
            raise ReportException(str(err))


class G14ReportBuilder(ReportBuilder):
    """ G14 Report 建造者 """

    def create_report(self, data_date):
        g14_report = None
        try:
            log.info("*** begin create g14 report data_date={} ***".format(data_date))
            g14_report = G14Report(ReportType.G14_REPORT, data_date)
            g14_report.load_target_report()

            g14_report.init_rate_sheet()
            g14_report.save_report()

            g14_report.init_loan_sheet()
            g14_report.save_report()

            g14_report.remove_temporary_sheets()
            g14_report.save_report()
            log.info("*** end create g14 report ***")
            return g14_report
        except Exception as err:
            log.error("*** failed to create g14 report ***")
            log.error(err)
            raise ReportException(str(err))


class ReportManager(object):

    def __init__(self):
        self.daily_report_builder = LreDailyReportBuilder()
        self.g14_report_builder = G14ReportBuilder()

    def create_lre_daily_report(self, data_date):
        return self.daily_report_builder.create_report(data_date)

    def create_g14_report(self, data_date):
        return self.g14_report_builder.create_report(data_date)


class TaskExecutor(object):

    def __init__(self):
        pass

    def copy_report_to_share_folder(self, report_path):
        pass

    def send_email(self, report_path):
        pass


class EmailService(object):
    def __init__(self):
        pass

    def send_email(self):
        pass
