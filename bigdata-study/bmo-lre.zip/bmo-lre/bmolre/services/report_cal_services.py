# -*- coding: utf-8 -*-

"""
Created on 2020-11-27

@author: Wang Shuo
"""

from ..commons.logging import get_logger, log_entry_exit
from ..exceptions import ReportException
from ..services.data_services import DataService
from ..commons.report_enums import (RateSheetEnum, CustomerSheetEnum, EadSheetEnum, LimitSheetEnum)
from ..commons.report_utils import create_random_number
from ..commons.util import is_blank, convert_digital_precision

from cachelib import SimpleCache

log = get_logger()

cache = SimpleCache()


class ReportService(object):

    def __init__(self):
        self.data_service = DataService()
        self.rates = {}
        self.cache = SimpleCache()

    def query_cny_rate_from_cache(self, data_date, basic_ccy):
        key = 'rate:cny:' + str(data_date)
        rates = cache.get(key)
        ccy_rate = None

        if rates is None:
            try:
                rate_data_list = self.data_service.query_rate_data(data_date)
                for rate_item in rate_data_list:
                    if basic_ccy == rate_item[RateSheetEnum.BASIC_CCY.value]:
                        ccy_rate = rate_item[RateSheetEnum.CCY_RATE.value]
                        cache.set(key, rate_data_list, timeout=60 * 60)
                        break
            except Exception as err:
                log.error(err)
                raise ReportException(str(err))

        else:
            for rate_item in rates:
                if basic_ccy == rate_item[RateSheetEnum.BASIC_CCY.value]:
                    ccy_rate = rate_item[RateSheetEnum.CCY_RATE.value]
                    break
        return ccy_rate

    @log_entry_exit
    def init_rate_data(self, data_date):
        """
        查询Rate取数据
        :param data_date: 查询报表时间
        :return:
        """
        try:
            return self.data_service.query_rate_data(data_date)
        except Exception as err:
            raise ReportException(str(err))

    def query_loan_data(self, data_date):
        return self.data_service.query_loan_data(data_date)

    def query_capital_data(self, data_date):
        """
         查询资本净额和一级资本净额
         :param data_date: 取数日期
         """
        return self.data_service.query_capital_data(data_date=data_date)

    def query_customer_list_report(self, data_date):
        """
        Extract BMO Customer to LRE Calculation
        In the working file, BMO Customer data use RRA BMOS0008 customer list report as data source.
        Select customer with Status = O in RRAS0008.
        :param data_date: 取数日期
        """
        return self.data_service.query_customer_list_report(data_date)

    def query_indirect_customer_from_trade_finance_transaction(self, data_date):
        customer_data_list = self.data_service.query_indirect_customer_from_trade_finance_transaction(data_date)
        for custoemr_item in customer_data_list:
            customer_category = custoemr_item[CustomerSheetEnum.CUSTOMER_CATEGORY.value]
            if is_blank(customer_category):
                customer_category = 'NONE'
            # 与CBS_ID区别开，满足唯一性，不要６位数字
            dummy_cbs_id = customer_category + '_' + create_random_number(len=10)
            custoemr_item[CustomerSheetEnum.CBS_ID.value] = dummy_cbs_id
            custoemr_item[CustomerSheetEnum.CUSTOMER_NAME_CN.value] = ''
            custoemr_item[CustomerSheetEnum.NATIONALITY.value] = ''
            custoemr_item[CustomerSheetEnum.COUNTRY.value] = ''
            custoemr_item[CustomerSheetEnum.GROUP_CODE.value] = ''
            custoemr_item[CustomerSheetEnum.GROUP_NAME.value] = ''
            custoemr_item[CustomerSheetEnum.UNIQUE_ID_VALUE.value] = ''

        return customer_data_list

    def query_indirect_customer_from_s_gfi_cn_counterparty(self, data_date):
        """
        Extract Indirect Customer Data to LRE Calculation - Issuer from Bond/NCD
        Issuer from Bond/NCD
        Source: RRA table s_gfi_cn_counterparty
        :param data_date: 取数日期
        """

        customer_data_list = self.data_service.query_indirect_customer_from_s_gfi_cn_counterparty(data_date)
        for custoemr_item in customer_data_list:
            customer_category = custoemr_item[CustomerSheetEnum.CUSTOMER_CATEGORY.value]
            if is_blank(customer_category):
                customer_category = 'NONE'
            # 与CBS_ID区别开，满足唯一性，不要６位数字
            dummy_cbs_id = customer_category + '_' + create_random_number(len=10)
            custoemr_item[CustomerSheetEnum.CBS_ID.value] = dummy_cbs_id
            custoemr_item[CustomerSheetEnum.OTL_ID.value] = ''
            custoemr_item[CustomerSheetEnum.CUSTOMER_NAME_CN.value] = ''
            custoemr_item[CustomerSheetEnum.EXPOSURE_COUNTRY.value] = ''
            custoemr_item[CustomerSheetEnum.GROUP_CODE.value] = ''
            custoemr_item[CustomerSheetEnum.GROUP_NAME.value] = ''

        return customer_data_list

    def cal_customer_datas(self, data_date):
        customer_ls = []
        customer_list_report_data_list = self.query_customer_list_report(data_date)
        indirect_customers1 = self.query_indirect_customer_from_trade_finance_transaction(data_date)
        indirect_customers2 = self.query_indirect_customer_from_s_gfi_cn_counterparty(data_date)

        customer_ls.extend(customer_list_report_data_list)
        customer_ls.extend(indirect_customers1)
        customer_ls.extend(indirect_customers2)

        return customer_ls

    def cal_ead_ead_report_data(self, data_date):
        ead_data_list = self.data_service.query_ead_report_data(data_date)
        usd_cny_rate = self.data_service.query_usd_to_cny_rate(data_date)

        for ead_item in ead_data_list:
            ead_usd_cn = ead_item[EadSheetEnum.EAD_USD.value] * usd_cny_rate
            ead_item[EadSheetEnum.EAD_CNY_EQV.value] = convert_digital_precision(ead_usd_cn, 2)
            ead_item[EadSheetEnum.EAD_USD.value] = convert_digital_precision(ead_item[EadSheetEnum.EAD_USD.value], 2)

        return ead_data_list

    def query_money_market_data(self, data_date):
        return self.data_service.query_money_market_data(data_date)

    def query_dsc_data(self, data_date):
        return self.data_service.query_dsc_data(data_date)

    def query_llp_data(self, data_date):
        return self.data_service.query_llp_data(data_date)

    def query_nostro_data(self, data_date):
        return self.data_service.query_nostro_data(data_date)

    def cal_limit_data(self, data_date):
        limit_data_list = self.data_service.query_limit_data(data_date)

        for limit_item in limit_data_list:
            limit_item[LimitSheetEnum.AVAILABLE_CREDIT_LIMIT.value] = convert_digital_precision(limit_item[LimitSheetEnum.AVAILABLE_CREDIT_LIMIT.value])

        return limit_data_list

    def query_auto_fin_data(self, data_date):
        return self.data_service.query_auto_fin_data(data_date)

    def query_offbs_tf_data(self, data_date):
        return self.data_service.query_offbs_tf_data(data_date)

    def query_bond_ncd_data(self, data_date):
        return self.data_service.query_bond_ncd_data(data_date)


