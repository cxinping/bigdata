--EADΪ�±������ڲ�����Ϊÿ���µ����һ�� 
select DATA_DATE,
       COUNTERPARTY_LONG_NAME,
       COUNTERPARTY_TYPE,
       IBUK_CUSTOMER_NUMBER,
       sum(EAD_USD) EAD_USD,
       CBS_CIF_ID,
       UEN
  from (SELECT substr(20201031, 0, 6) DATA_DATE,
               T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
               T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
               T2.IBUK_CUST_NO IBUK_CUSTOMER_NUMBER, --3
               PACK_UTIL.FUN_GET_CURR_CONV(20201031,
                                           'CAD',
                                           'USD',
                                           T1.EAD,
                                           'STAND') EAD_USD, --4
               T4.CUSTOMER_NO CBS_CIF_ID, --5
               TO_CHAR(T1.UEN) UEN --6
          FROM RRA_SIDS.S_MAN_SACCR T1
          LEFT JOIN RRA_SIDS.S_WSS_FX T2
            ON SUBSTR(T1.TRADE_ID, 3, 2) = SUBSTR(T2.AREA_CODE, 1, 2)
           AND SUBSTR(T1.TRADE_ID, 7, 13) = T2.DEAL_NUMBER
           AND T2.DATA_DATE = (SELECT MAX(DATA_DATE)
                                 FROM RRA_SIDS.S_WSS_FX
                                WHERE DATA_DATE <= 20201031)
          LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
            ON T2.IBUK_CUST_NO = T3.IBUK_ID
           AND T3.DATA_DATE = (SELECT MAX(DATA_DATE)
                                 FROM RRA_SIDS.S_CBI_T_CMN_CUST_INF
                                WHERE DATA_DATE <= 20201031) --RRA-1570
          LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
            ON T3.CBS_ID = T4.CUSTOMER_NO
           AND T4.DATA_DATE = (SELECT MAX(DATA_DATE)
                                 FROM RRA_SIDS.S_FLC_STTM_CUSTOMER
                                WHERE DATA_DATE <= 20201031) --RRA-1570
         WHERE T1.DATA_DATE = 20201031
           AND T1.SRC_SYS_CD = 'WSS'
        UNION ALL
        --Simple Option TRACE
        SELECT substr(20201031, 0, 6) DATA_DATE,
               T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
               T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
               T3.IBUK_ID IBUK_CUSTOMER_NUMBER, --3
               PACK_UTIL.FUN_GET_CURR_CONV(20201031,
                                           'CAD',
                                           'USD',
                                           T1.EAD,
                                           'STAND') EAD_USD, --4
               T2.V_MXG_CUST_REF_CODE CBS_CIF_ID, --5
               TO_CHAR(T1.UEN) UEN --6
          FROM RRA_SIDS.S_MAN_SACCR T1
          LEFT JOIN RRA_GBDS.GDBS_T_UPS_OUT_MXG4SAFE T2
            ON T1.TRADE_ID = T2.TRADE_ID
           AND T2.DATA_DATE = (SELECT MAX(DATA_DATE)
                                 FROM RRA_GBDS.GDBS_T_UPS_OUT_MXG4SAFE --RRA-1833
                                WHERE DATA_DATE <= 20201031)
          LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
            ON T2.V_MXG_CUST_REF_CODE = T3.CBS_ID
           AND T3.DATA_DATE =
               (SELECT MAX(DATA_DATE)
                  FROM RRA_SIDS.S_CBI_T_CMN_CUST_INF
                 WHERE DATA_DATE <= '20201031') --RRA-1570
          LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
            ON T2.V_MXG_CUST_REF_CODE = T4.CUSTOMER_NO
           AND T4.DATA_DATE = (SELECT MAX(DATA_DATE)
                               
                                 FROM RRA_SIDS.S_FLC_STTM_CUSTOMER
                                WHERE DATA_DATE <= 20201031) --RRA-1570
         WHERE T1.DATA_DATE = 20201031
           AND T1.SRC_SYS_CD = 'CURRPLUS'
           AND T1.INSTM_TYPE <> 'WRTOPT'
        UNION ALL
        --Barrier Option:
        SELECT substr(20201031, 0, 6) DATA_DATE,
               T4.CUSTOMER_NAME1 COUNTERPARTY_LONG_NAME, --1
               T4.CUSTOMER_CATEGORY COUNTERPARTY_TYPE, --2
               T1.IBUK IBUK_CUSTOMER_NUMBER, --3
               T1.USD_EQUIVALENT EAD_USD, --4
               T4.CUSTOMER_NO CBS_CIF_ID, --5
               T5.UEN_NO UEN --6
          FROM RRA_SIDS.S_MAN_BARRIER_OPTION_REGISTER T1
          LEFT JOIN RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
            ON T1.IBUK = T3.IBUK_ID
           AND T3.DATA_DATE = (SELECT MAX(DATA_DATE)
                                 FROM RRA_SIDS.S_CBI_T_CMN_CUST_INF
                                WHERE DATA_DATE <= 20201031) --RRA-1570
          LEFT JOIN RRA_SIDS.S_FLC_STTM_CUSTOMER T4
            ON T3.CBS_ID = T4.CUSTOMER_NO
           AND T4.DATA_DATE = (SELECT MAX(DATA_DATE)
                                 FROM RRA_SIDS.S_FLC_STTM_CUSTOMER
                                WHERE DATA_DATE <= 20201031) --RRA-1570
          LEFT JOIN RRA_GBDS.GBDS_BIZ_CUST_INFO T5
            ON T3.CBS_ID = T5.CUST_NUM
           AND 20201031 BETWEEN T5.S_DATE AND T5.E_DATE
         WHERE T1.DATA_DATE = 20201031
           AND T1.EXPIRY_DATE > TO_DATE(20201031, 'YYYY/MM/DD')
           AND T1."B/S" = 'B')
 group by DATA_DATE,
          COUNTERPARTY_LONG_NAME,
          COUNTERPARTY_TYPE,
          IBUK_CUSTOMER_NUMBER,
          CBS_CIF_ID,
          UEN
