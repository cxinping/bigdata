--4.1.2.3.2.1
with TB_UEN as
 (select distinct DATA_DATE, UEN_NO, CIF_NO, LEGAL_NAME, RISK_COUNTRY
    from (SELECT DATA_DATE, UEN_NO, CIF_NO, LEGAL_NAME, RISK_COUNTRY
            FROM RRA_SIDS.S_UEN_NA
           WHERE DATA_DATE IN (SELECT MAX(DATA_DATE)
                                 FROM RRA_SIDS.S_UEN_NA
                                where data_date <= 20201102)
          UNION ALL
          SELECT DATA_DATE, UEN_NO, CIF_NO, LEGAL_NAME, RISK_COUNTRY
            FROM RRA_SIDS.S_UEN_CHINA
           WHERE DATA_DATE IN (SELECT MAX(DATA_DATE)
                                 FROM RRA_SIDS.S_UEN_CHINA
                                where data_date <= 20201102)) uen
  
   where not exists (select 1
            from RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T0
           where uen.CIF_NO = LPAD(TRIM(T0.FIELD_VAL_52), 10, '0')
             and T0.data_date = '20201102')
     and uen.UEN_NO is NOT null)

select distinct null CBS_ID,
       T1.data_date,
       T1.UEN_NO UEN,
       T3.LIMIT_CUSTOMER_ID OTL_ID,
       NULL CUSTOMER_NAME_CN,
       T1.LEGAL_NAME CUSTOMER_NAME_EN,
       'BANK' CUSTOMER_CATEGORY,
       NULL NATIONALITY,
       NULL COUNTRY,
       T1.RISK_COUNTRY EXPOSURE_COUNTRY,
       
       NULL             GROUP_CODE,
       NULL             GROUP_NAME,
       T2.RISKPARTY_UEN UNIFORM_SOCIAL_CREDIT_CODE,
       NULL             UNIQUE_ID_VALUE
  from tb_uen T1
  left join rra_inx.REP_ME_DISCOUNT_DB T2
    ON T2.RISKPARTY_UEN = T1.UEN_NO
   and T2.Report_Date = '20201102'
  left join rra_sids.S_PIX_CNPAYUS T3
    ON T2.OUR_REF = T3.Instrument_ID
   and T3.data_date = '20201102'
    
