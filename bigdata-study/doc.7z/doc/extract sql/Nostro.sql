--NOSTRO
with tb_interest as
 (select sum(CASE
               WHEN t1.CURRENCY = 'CNY' THEN
                abs(T1.FCY_AMOUNT)
               ELSE
                PACK_UTIL.FUN_GET_CURR_CONV(20200630,
                                            'USD',
                                            'CNY',
                                            PACK_UTIL.FUN_GET_CURR_CONV(20200630,
                                                                        T1.CURRENCY,
                                                                        'USD',
                                                                        abs(T1.FCY_AMOUNT),
                                                                        'STAND'),
                                            'SAFE_MID')
             END) FCY_AMOUNT
    from RRA_SIDS.S_FLC_BIVW_DAILY_ACC_ENTRIES T1
   where data_date = (select max(data_date)
                        from RRA_SIDS.S_FLC_BIVW_DAILY_ACC_ENTRIES
                       where data_date <= '20200630')
     and gl_code = '713010300'
     AND addl_text like '009015 ACC SPDB INT FR%'
  )
select cust_no,
       cust_no,
       'CNY' ccy,
       CASE
         WHEN t1.ccy = 'CNY' THEN
          abs(T1.ACY_CURR_BALANCE)
         ELSE
          PACK_UTIL.FUN_GET_CURR_CONV(20200630,
                                      'USD',
                                      'CNY',
                                      PACK_UTIL.FUN_GET_CURR_CONV(20200630,
                                                                  T1.ccy,
                                                                  'USD',
                                                                  abs(T1.ACY_CURR_BALANCE),
                                                                  'STAND'),
                                      'SAFE_MID')
       END Amount,
       t2.FCY_AMOUNT
  from RRA_SIDS.S_FLC_STTM_CUST_ACCOUNT T1
  left join tb_interest T2
    on 1 = 1
 where cust_ac_no = '2005101156000005'
   and data_date = '20200630'