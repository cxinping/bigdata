SELECT null cbs_id,
       CUSTOMER_UEN UEN,
       null OTL_ID,
       null CUSTOMER_NAME_CN,
       CUSTOMER_NAME CUSTOMER_NAME_EN,
       case
         when UPPER(BANK_INDICATOR) = 'BANK' THEN
          'BANK'
         when UPPER(BANK_INDICATOR) = 'NONBANK' then
          'CORPORATE'
         else
          null
       END CUSTOMER_CATEGORY,
       null EXPOSURE_COUNTRY,
       null GROUP_CODE,
       null GROUP_NAME,
       CUSTOMER_UEN UNIFORM_SOCIAL_CREDIT_CODE,
       null UNIQUE_ID_VALUE
  FROM RRA_SIDS.S_GFI_CN_COUNTERPARTY T_GFI
 WHERE CLOSE_DATE IS NULL
   AND CUSTOMER_UEN IS NOT NULL
   AND DATA_DATE = to_char(to_date('20200630', 'YYYYMMDD') - 1, 'YYYYMMDD')
   AND NOT EXISTS
 (SELECT 1
          FROM (SELECT T1.UEN_NO, T1.CIF_NO
                  FROM (SELECT UEN_NO, CIF_NO
                          FROM RRA_SIDS.S_UEN_NA
                         WHERE DATA_DATE IN
                               (SELECT MAX(DATA_DATE)
                                  FROM RRA_SIDS.S_UEN_NA
                                 where DATA_DATE <= '20200630')
                        UNION ALL
                        SELECT UEN_NO, CIF_NO
                          FROM RRA_SIDS.S_UEN_CHINA
                         WHERE DATA_DATE IN
                               (SELECT MAX(DATA_DATE) FROM RRA_SIDS.S_UEN_CHINA
                         where DATA_DATE <= '20200630')) T1
                 INNER JOIN RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T2
                    ON T1.CIF_NO = LPAD(TRIM(T2.FIELD_VAL_52), 10, '0')
                   AND T2.DATA_DATE = '20200630') T_UEN
         WHERE T_GFI.CUSTOMER_UEN = T_UEN.UEN_NO)
