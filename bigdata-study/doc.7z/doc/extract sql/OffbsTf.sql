--offbs TF
WITH CUSTOMER_UEN_INFO AS
 (SELECT B.CIF_NO, B.UEN_NO, B.LEGAL_NAME
    FROM (SELECT A.CIF_NO,
                 A.UEN_NO,
                 A.LEGAL_NAME,
                 ROW_NUMBER() OVER(PARTITION BY A.UEN_NO ORDER BY A.PIR ASC) AS RN
            FROM (SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         TRIM(PARENT_UEN) AS UEN_NO,
                         T1.LEGAL_NAME,
                         '1' AS PIR
                    FROM RRA_SIDS.S_UEN_BRANCH T1
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_BRANCH
                           WHERE DATA_DATE <= 20200630)
                  UNION ALL
                  SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         UEN_NO,
                         T2.LEGAL_NAME,
                         '2' AS PIR
                    FROM RRA_SIDS.S_UEN_NA T2
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_NA
                           WHERE DATA_DATE <= 20200630)
                  UNION
                  SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         UEN_NO,
                         T3.LEGAL_NAME,
                         '3' AS PIR
                    FROM RRA_SIDS.S_UEN_CHINA T3
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_CHINA
                           WHERE DATA_DATE <= 20200630)) A
           WHERE A.UEN_NO IS NOT NULL) B
   WHERE B.RN = 1),
CBS_FUNC_UDF_FIELDS AS
 (SELECT SUBSTR(T.REC_KEY, 1, 6) CBS_ID,
         LPAD(T.FIELD_VAL_52, 10, '0') AS CIF_NO
    FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T
   WHERE T.FUNCTION_ID = 'STDCIF'
     AND T.DATA_DATE = (SELECT MAX(DATA_DATE)
                          FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS
                         WHERE DATA_DATE <= 20200630))

select T3.CBS_ID,
       T1.UEN_NO,
       T3.CBS_ID,
       case
         when upper(T1.DEAL_TYPE) = 'GUARANTEE' THEN
          0.5
         when upper(T1.DEAL_TYPE) IN ('CONFIRMATION', 'LC ISSUANCE') THEN
          0.2
         else
          0
       end OFFBS_factor,
       T1.DEAL_TYPE,
       T1.UEN_NO,
       T1.CURRENCY,
       T1.AMOUNT
  from (SELECT T.DATA_DATE,
               T.CBS_BU AS BRANCH_CODE,
               T.INSTRUMENT_ID AS TRANS_REF,
               T.CURRENCY_CODE AS CURRENCY,
               T.UEN_NUMBER AS UEN_NO,
               T.RELEASE_DATE AS VALUE_DATE,
               T.EXPIRY_DATE AS MATURTIY_DATE,
               T2.DEAL_TYPE,
               ACTIVITY_TYPE,
               PROD_PROD_TYPE_CODE,
               CONFIRMATION_TYPE,
               NVL(T.LC_AVAIL_AMT, 0) AMOUNT,
               ROW_NUMBER() OVER(PARTITION BY T.INSTRUMENT_ID ORDER BY T.SEQUENCE_DATE DESC, T.SEQUENCE_TIME DESC) RN
          FROM RRA_SIDS.S_PIX_CNLCCOL T
         INNER JOIN (SELECT DISTINCT BS.PROD_TYPE,
                                    BS.DEAL_TYPE,
                                    BS.RISK_PARTY_CORP_TYPE,
                                    BS.BALANCE_SHEET,
                                    BS.IS_LOAN
                      FROM RRA_SIDS.LLP_FACILITY_MAPPING BS
                     WHERE BS.BALANCE_SHEET = 'OFFBS') T2
            ON T.PROD_PROD_TYPE_CODE = T2.PROD_TYPE
         WHERE T.SOURCE_SYSTEM_ID = '4'
           AND T.DATA_DATE <= 20200630
           AND T.EXPIRY_DATE > '20200630') T1
  left join CUSTOMER_UEN_INFO T2
    ON T1.UEN_NO = T2.UEN_NO
  left join CBS_FUNC_UDF_FIELDS T3
    ON T2.CIF_NO = T3.CIF_NO
 WHERE T1.RN = 1
   AND T1.ACTIVITY_TYPE <> 'DEA'
   AND T1.AMOUNT <> 0
   AND (T1.PROD_PROD_TYPE_CODE IN ('GUAOUT', 'DLCIMP') -- RRA-1869  
       OR (T1.PROD_PROD_TYPE_CODE = 'DLCEXP' AND
       T1.CONFIRMATION_TYPE IN ('ACON', 'SCON')))
