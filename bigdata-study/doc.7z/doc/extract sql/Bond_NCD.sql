--Bond&NCD

WITH CUSTOMER_UEN_INFO AS
 (SELECT B.CIF_NO, B.UEN_NO, B.LEGAL_NAME
    FROM (SELECT A.CIF_NO,
                 A.UEN_NO,
                 A.LEGAL_NAME,
                 ROW_NUMBER() OVER(PARTITION BY A.UEN_NO ORDER BY A.PIR ASC) AS RN
            FROM (SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         TRIM(PARENT_UEN) AS UEN_NO,
                         T1.LEGAL_NAME,
                         '1' AS PIR
                    FROM RRA_SIDS.S_UEN_BRANCH T1
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_BRANCH
                           WHERE DATA_DATE <= 20200630)
                  UNION ALL
                  SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         UEN_NO,
                         T2.LEGAL_NAME,
                         '2' AS PIR
                    FROM RRA_SIDS.S_UEN_NA T2
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_NA
                           WHERE DATA_DATE <= 20200630)
                  UNION
                  SELECT LPAD(TRIM(CIF_NO), 10, 0) CIF_NO,
                         UEN_NO,
                         T3.LEGAL_NAME,
                         '3' AS PIR
                    FROM RRA_SIDS.S_UEN_CHINA T3
                   WHERE DATA_DATE =
                         (SELECT MAX(DATA_DATE)
                            FROM RRA_SIDS.S_UEN_CHINA
                           WHERE DATA_DATE <= 20200630)) A
           WHERE A.UEN_NO IS NOT NULL) B
   WHERE B.RN = 1),
CBS_FUNC_UDF_FIELDS AS
 (SELECT SUBSTR(T.REC_KEY, 1, 6) CBS_CUST_NO,
         LPAD(T.FIELD_VAL_52, 10, '0') AS CMCIF_CUST_ID
    FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T
   WHERE T.FUNCTION_ID = 'STDCIF'
     AND T.DATA_DATE = (SELECT MAX(DATA_DATE)
                          FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS
                         WHERE DATA_DATE <= 20200630))

select T4.CBS_CUST_NO as CBS_ID,
       T1.SECURITY_ACC_CODE as Accounting_code,
       T2.ISSUER_UEN,
       T1.CURRENCY CCY,
       NVL(T1.FAIR_VALUE, 0) + NVL(T5.VPC_IPV_ADJUSTMENT, 0) BALANCE,
       INTEREST_RECEIVABLE,
       T1.Profit_Centre

  from rra_sids.S_INT_holding T1
  left join rra_sids.s_gfi_cn_security T2
    on T1.Bond_Code = T2.BOND_CODE
   and T2.Data_Date = to_char(to_date('20200630', 'YYYYMMDD') - 1, 'YYYYMMDD')
  left join CUSTOMER_UEN_INFO T3
    on T2.ISSUER_UEN = T3.UEN_NO
  left join CBS_FUNC_UDF_FIELDS T4
    on T3.CIF_NO = T4.CMCIF_CUST_ID
  left join rra_sids.S_MAN_BOND_VPC T5
    on T1.CUSIP = T5.SEC_CUSIP
   and T5.Data_Date =
       to_char(last_day(add_months(to_date('20200630', 'yyyymmDD'), -1)),
               'YYYYMMDD')
 where T1.data_date =
       to_char(to_date('20200630', 'YYYYMMDD') - 1, 'YYYYMMDD')
   and T1.Profit_Centre IN ('T3773', 'T9534')
   and T1.SECURITY_ACC_CODE <> 'NCD'
union all
--NCD
select T4.CBS_CUST_NO as CBS_ID,
       T1.SECURITY_ACC_CODE as Accounting_code,
       T2.ISSUER_UEN,
       T1.CURRENCY CCY,
       NVL(T1.FAIR_VALUE, 0) + NVL(T5.VPC_IPV_ADJUSTMENT, 0) BALANCE,
       INTEREST_RECEIVABLE,
       T1.Profit_Centre

  from rra_sids.S_INT_holding T1
  left join rra_sids.s_gfi_cn_security T2
    on T1.Bond_Code = T2.BOND_CODE and T2.Data_Date = to_char(to_date('20200630', 'YYYYMMDD') - 1, 'YYYYMMDD')
  left join CUSTOMER_UEN_INFO T3
    on T2.ISSUER_UEN = T3.UEN_NO
  left join CBS_FUNC_UDF_FIELDS T4
    on T3.CIF_NO = T4.CMCIF_CUST_ID
  left join rra_sids.S_MAN_BOND_VPC T5
    on T1.CUSIP = T5.SEC_CUSIP and
 T5.Data_Date =
 to_char(last_day(add_months(to_date('20200630', 'yyyymmDD'), -1)),
         'YYYYMMDD')
 where T1.data_date =
 to_char(to_date('20200630', 'YYYYMMDD') - 1, 'YYYYMMDD') and
 T1.Profit_Centre IN ('T3773', 'T9534') and
 T1.SECURITY_ACC_CODE <> 'NCD'
