--Limit
select CUSTOMER_ID            CBS_ID,
       CUSTOMER_ID            Customer_ID,
       CURRENCY,
       AVAILABLE_CREDIT_LIMIT,
       REVOCABLE,
       ORG_PERIOD_IN_ONE_YEAR
  from RRA_SIDS.S_FLC_CREDIT_EXPOSURE
 where data_date = '20200630'
