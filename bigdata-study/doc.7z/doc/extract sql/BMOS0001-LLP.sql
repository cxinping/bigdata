
select BRANCH, BSOFFBS, DEAL_TYPE,UEN, CCY_CNY_USD, PROV_AMT
  from (SELECT BRANCH_NAME_EN         BRANCH, --1
               BALANCE_SHEET          BSOFFBS, --2
               DEAL_TYPE, --3
               TRANS_REF              Transaction_Ref, --4
               RISK_PARTY, --5
               UEN, --6
               CURRENCY, --7
               AMOUNT, --8
               VALUE_DATE, --9
               MATURTIY_DATE, --10
               GL_NUMBER, --11
               TRANSIT_CODE, --12
               COUNTRY_NAME, --13
               RESIDENT, --14
               AUTH_AMOUNT, --15
               BRR                    Master_Scle_BRR, --16
               GRADE_5, --17
               PROV_RATIO             Provision_Ratio, --18
               PROV_AMT_ORI_CCY, --19
               CCY_CNY_USD, --20
               OUT_STAND, --21
               PROV_AMT, --22
               OUT_STAND_CNY, --23
               PROV_AMT_CNY, --24
               LOAD_OUT_STAND_ORI_CCY, --25 
               OUT_STAND_CNY_USD, --26
               LOAD_OUT_STAND_USD, --27
               LOAD_PROV_ORI_CCY, --28
               LOAD_PROV_USD, --29
               COMMITTED_LOAN_TYPE, --30
               LOAN_PROV_RATIO, --31
               LOAN_FLAG, --32
               LGD, --33
               EAD, --34
               PD --35
          FROM RRA_GBDS.GBDS_CORP_LOAN
         WHERE DATA_DATE = 20201102
        UNION
        SELECT BRANCH_NAME_EN,
               BALANCE_SHEET,
               DEAL_TYPE,
               TRANS_REF,
               RISK_PARTY,
               UEN,
               CURRENCY,
               AMOUNT,
               VALUE_DATE,
               MATURTIY_DATE,
               GL_NUMBER,
               TRANSIT_CODE,
               COUNTRY_NAME,
               RESIDENT,
               AUTH_AMOUNT,
               BRR,
               GRADE_5,
               PROV_RATIO,
               PROV_AMT_ORI_CCY,
               CCY_CNY_USD,
               OUT_STAND,
               PROV_AMT,
               OUT_STAND_CNY,
               PROV_AMT_CNY,
               LOAD_OUT_STAND_ORI_CCY,
               OUT_STAND_CNY_USD,
               LOAD_OUT_STAND_USD,
               LOAD_PROV_ORI_CCY,
               LOAD_PROV_USD,
               COMMITTED_LOAN_TYPE,
               LOAN_PROV_RATIO,
               LOAN_FLAG,
               LGD,
               EAD,
               PD
          FROM RRA_GBDS.GBDS_INTERBANK_LENDING
         WHERE DATA_DATE = 20201102
        UNION
        SELECT BRANCH_NAME_EN,
               BALANCE_SHEET,
               DEAL_TYPE,
               TRANS_REF,
               RISK_PARTY,
               UEN,
               CURRENCY,
               AMOUNT,
               VALUE_DATE,
               MATURTIY_DATE,
               GL_NUMBER,
               TRANSIT_CODE,
               COUNTRY_NAME,
               RESIDENT,
               AUTH_AMOUNT,
               BRR,
               GRADE_5,
               PROV_RATIO,
               PROV_AMT_ORI_CCY,
               CCY_CNY_USD,
               OUT_STAND,
               PROV_AMT,
               OUT_STAND_CNY,
               PROV_AMT_CNY,
               LOAD_OUT_STAND_ORI_CCY,
               OUT_STAND_CNY_USD,
               LOAD_OUT_STAND_USD,
               LOAD_PROV_ORI_CCY,
               LOAD_PROV_USD,
               COMMITTED_LOAN_TYPE,
               LOAN_PROV_RATIO,
               LOAN_FLAG,
               LGD,
               EAD,
               PD
          FROM RRA_GBDS.GBDS_TF_OFF_BS
         WHERE DATA_DATE = 20201102
        UNION
        SELECT BRANCH_NAME_EN,
               BALANCE_SHEET,
               DEAL_TYPE,
               TRANS_REF,
               RISK_PARTY,
               UEN,
               CURRENCY,
               AMOUNT,
               VALUE_DATE,
               MATURTIY_DATE,
               GL_NUMBER,
               TRANSIT_CODE,
               COUNTRY_NAME,
               RESIDENT,
               AUTH_AMOUNT,
               BRR,
               GRADE_5,
               PROV_RATIO,
               PROV_AMT_ORI_CCY,
               CCY_CNY_USD,
               OUT_STAND,
               PROV_AMT,
               OUT_STAND_CNY,
               PROV_AMT_CNY,
               LOAD_OUT_STAND_ORI_CCY,
               OUT_STAND_CNY_USD,
               LOAD_OUT_STAND_USD,
               LOAD_PROV_ORI_CCY,
               LOAD_PROV_USD,
               COMMITTED_LOAN_TYPE,
               LOAN_PROV_RATIO,
               LOAN_FLAG,
               LGD,
               EAD,
               PD
          FROM RRA_GBDS.GBDS_TF_BS
         WHERE DATA_DATE = 20201102)
