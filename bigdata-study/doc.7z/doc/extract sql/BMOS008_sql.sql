
with Table_1 as
 (SELECT T1.DATA_DATE DATA_DATE, --25 DATA_DATE
         T1.LOCAL_BRANCH, --1.LOCAL_BRANCH
         T1.CUSTOMER_NO CBS_ID, --2.CBS_ID
         LPAD(TRIM(T2.FIELD_VAL_52), 10, '0') CIF_ID, --CIF_ID
         T3.IBUK_ID WSS_ID, --3.WSS_ID
         T3.PIX_ID, --4.PIX_ID
         T2.FIELD_VAL_39 OTL_ID, --6.OTL_ID
         T1.CHINESE_NAME CUSTOMER_NAME_CN, --8.CUSTOMER_NAME_CN
         DECODE(LENGTH(T2.FIELD_VAL_16), 18, T2.FIELD_VAL_16, null) UNIFORM_SOCIAL_CREDIT_CODE1, --7 UNIFORM_SOCIAL_CREDIT_CODE --=If Length([UNIFORM_SOCIAL_CREDIT_CODE1])=18 Then [UNIFORM_SOCIAL_CREDIT_CODE1] Else Max([UNIFORM_SOCIAL_CREDIT_CODE2])
         T1.CUSTOMER_NAME1 CUSTOMER_NAME_EN, --9.CUSTOMER_NAME_EN
         T1.CUSTOMER_CATEGORY, --10.CUSTOMER_CATEGORY
         T1.NATIONALITY, --11.NATIONALITY
         T1.COUNTRY, --12.COUNTRY
         T1.EXPOSURE_COUNTRY, --13.EXPOSURE_COUNTRY
         T2.FIELD_VAL_1 AREA, --14.AREA
         T2.FIELD_VAL_5 CORP_TYPE, --15.CORP_TYPE
         T2.FIELD_VAL_10 CORP_SIZE, --16.CORP_SIZE
         T2.FIELD_VAL_4 INDUSTRY_CODE, --17.INDUSTRY_CODE
         T2.FIELD_VAL_58 HOLDING_TYPE, --18.HOLDING_TYPE
         T1.UNIQUE_ID_VALUE UNIQUE_ID_VALUE, --19.UNIQUE_ID_VALUE
         T4.GROUP_ID GROUP_CODE, --20.GROUP_CODE
         T1.RECORD_STAT STATUS, --23.STATUS
         decode(T1.DATA_DATE, null, 'CMS', 'CMS')
    FROM RRA_SIDS.S_FLC_STTM_CUSTOMER T1
    left join RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T2
      ON T1.CUSTOMER_NO = SUBSTR(T2.REC_KEY(+), 1, 6)
     AND T1.DATA_DATE = T2.DATA_DATE
    left join RRA_SIDS.S_CBI_T_CMN_CUST_INF T3
      ON T1.CUSTOMER_NO = T3.CBS_ID
     AND T1.DATA_DATE = T3.DATA_DATE
    left join RRA_SIDS.S_FLC_STTM_CUST_GROUP T4
      ON T1.CUSTOMER_NO = T4.CUSTOMER_NO
     AND T1.DATA_DATE = T4.DATA_DATE
   WHERE T1.RECORD_STAT IN ('C', 'O')
     AND T2.FUNCTION_ID = 'STDCIF'
     and T1.AUTH_STAT = 'A'
     AND T1.CUSTOMER_CATEGORY IN
         ('NBFI', 'BANK', 'INTERNAL', 'CORPORATE', 'INDIVIDUAL')
     AND T1.DATA_DATE = '20201102'),

Table_2 as
 (SELECT distinct CIF_NO    CIF_ID, --CIF_ID ���1�����ֶ�CIF_ID
                  UEN_NO    UEN, --5.UEN
                  DATA_DATE
    FROM RRA_SIDS.S_UEN_CHINA
   WHERE DATA_DATE = (select max(data_date)
                        from RRA_SIDS.S_UEN_CHINA
                       where data_date <= '20201102')
  UNION
  SELECT distinct CIF_NO, UEN_NO, DATA_DATE
    FROM RRA_SIDS.S_UEN_NA
   WHERE DATA_DATE = (select max(data_date)
                        from RRA_SIDS.S_UEN_NA
                       where data_date <= '20201102')
  
  UNION
  SELECT distinct LPAD(TRIM(CIF_NO), 10, 0) CIF_NO, PARENT_UEN, DATA_DATE
    FROM RRA_SIDS.S_UEN_BRANCH
   WHERE DATA_DATE = (select max(data_date)
                        from RRA_SIDS.S_UEN_BRANCH
                       where data_date <= '20201102')),
Table_3 as
 (
  
  SELECT distinct T1.GROUP_ID GROUP_CODE, --���1�����ֶ�
                   T2.GROUP_NAME GROUP_CHINESE_NAME, --22.GROUP_CHINESE_NAME
                   T1.DATA_DATE,
                   decode(T2.GROUP_NAME, null, null, null) GROUP_NAME
    FROM RRA_SIDS.S_FLC_STTM_CUST_GROUP T1
    left join RRA_SIDS.S_FLC_STTM_GROUP T2
      ON T1.GROUP_ID = T2.GROUP_ID
  
   WHERE T1.DATA_DATE = '20201102'
     and T1.DATA_DATE = T2.DATA_DATE
  
  ),
table_4 as
 (SELECT distinct T1.DATA_DATE,
                  SUBSTR(T1.REC_KEY, 1, 6) REC_KEY, --  ���1�����ֶ�CBS_ID
                  LPAD(TRIM(T1.FIELD_VAL_52), 10, '0') CIF_ID,
                  nvl(T2.RRA_CODE, '100000') FINA_CODE_Bank,
                  nvl(T3.RRA_CODE, '200000') FINA_CODE_NBFI,
                  T4.BUSINESS_LIC UNIFORM_SOCIAL_CREDIT_CODE2
    FROM RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS T1
    left join RRA_SIDS.MAP_S_G_CODE T2
      ON T1.FIELD_VAL_2 = T2.SOURCE_CODE
     and T2.TYPE_CODE = 'FINA_CODE'
     and T1.FUNCTION_ID = 'STDCIF'
    left join RRA_SIDS.MAP_S_G_CODE T3
      ON T1.FIELD_VAL_7 = T3.SOURCE_DESCRIPTION_CN
     and T3.TYPE_CODE = 'FINA_CODE'
    left join RRA_SIDS.S_CMCIF_CUST_INFO T4
      ON LPAD(TRIM(T1.FIELD_VAL_52), 10, '0') =
         LPAD(TRIM(T4.CIF_ID), 10, '0')
     and length(T4.BUSINESS_LIC) = 18
   WHERE T1.DATA_DATE = '20201102'
     AND T4.DATA_DATE IN (SELECT max(DATA_DATE)
                            FROM RRA_SIDS.S_CMCIF_CUST_INFO
                           WHERE length(BUSINESS_LIC) = 18
                             AND DATA_DATE <= '20201102')
  
  )

SELECT A.LOCAL_BRANCH, --1
       A.CBS_ID, --2
       A.WSS_ID, --3
       A.PIX_ID, --4
       B.UEN, --5
       A.OTL_ID, --6
       CASE
         WHEN LENGTH(A.UNIFORM_SOCIAL_CREDIT_CODE1) = 18 THEN
          A.UNIFORM_SOCIAL_CREDIT_CODE1
         ELSE
          D.UNIFORM_SOCIAL_CREDIT_CODE2
       END UNIFORM_SOCIAL_CREDIT_CODE, --7
       A.CUSTOMER_NAME_CN, --8
       A.CUSTOMER_NAME_EN, --9
       A.CUSTOMER_CATEGORY, --10
       A.NATIONALITY, --11
       A.COUNTRY, --12
       A.EXPOSURE_COUNTRY, --13
       A.AREA, --14
       A.CORP_TYPE, --15
       A.CORP_SIZE, --16
       A.INDUSTRY_CODE, --17
       A.HOLDING_TYPE, --18
       A.UNIQUE_ID_VALUE, --19
       A.GROUP_CODE, --20
       C.GROUP_NAME, --21
       C.GROUP_CHINESE_NAME, --22
       A.STATUS, --23
       
       A.DATA_DATE

  FROM TABLE_1 A
  LEFT JOIN TABLE_2 B
    ON A.CIF_ID = B.CIF_ID
  LEFT JOIN TABLE_3 C
    ON A.GROUP_CODE = C.GROUP_CODE
  LEFT JOIN TABLE_4 D
    ON A.CBS_ID = D.REC_KEY
	WHERE A.STATUS='O'  -- Select customer with Status = O in RRAS0008
	
	
	