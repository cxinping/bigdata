from django.contrib import admin

# Register your models here.
from book.models import BookInfo, PeopleInfo

admin.site.register(BookInfo)  # 注册书籍模型
admin.site.register(PeopleInfo)  # 注册人物模型
