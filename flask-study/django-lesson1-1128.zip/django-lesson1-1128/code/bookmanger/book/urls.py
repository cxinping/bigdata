# @Time    : 2020-11-28 20:59
# @Author  : 老赵
# @File    : urls.py

from django.conf.urls import url
from django.urls import path
from book.views import index

urlpatterns = [
    path('books/', index)
    # url(r'books/', index)
]