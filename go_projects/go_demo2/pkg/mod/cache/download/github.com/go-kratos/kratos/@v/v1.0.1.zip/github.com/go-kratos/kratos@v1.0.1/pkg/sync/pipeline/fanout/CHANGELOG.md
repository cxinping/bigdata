### pipeline/fanout

#### Version 1.1.0
> 1. 增加处理速度metric上报
#### Version 1.0.0
> 1. library/cache包改为fanout
