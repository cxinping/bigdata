#### blademaster/middleware/auth

##### 项目简介

blademaster 的 authorization middleware，主要用于设置路由的认证策略

注：仅仅是个demo，请根据自身业务实现具体鉴权逻辑
