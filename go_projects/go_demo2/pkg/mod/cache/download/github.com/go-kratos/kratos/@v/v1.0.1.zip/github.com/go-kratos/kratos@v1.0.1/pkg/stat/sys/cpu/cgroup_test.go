// +build linux

package cpu

import (
	"testing"
)

func TestCGroup(t *testing.T) {
	// TODO
}
