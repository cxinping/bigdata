#### warden/balancer/p2c

##### 项目简介

warden 的 Power of Two Choices (P2C)负载均衡模块，主要用于为每个RPC请求返回一个Server节点以供调用
