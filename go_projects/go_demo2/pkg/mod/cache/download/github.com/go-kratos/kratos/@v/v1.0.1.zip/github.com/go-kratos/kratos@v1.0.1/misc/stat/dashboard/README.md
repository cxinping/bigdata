#### dashboard

> 监控模版，针对服务框架内的监控指标的UI展示。

##### Requirments

- [Grafana](https://grafana.com) >= v6.1.4
- [Prometheus](https://prometheus.io) >= 2.x

##### Quick start

1. 搭建grafana
2. 导入`prometheus.json`文件
3. 修改对应的`Data source`
4. 保存
