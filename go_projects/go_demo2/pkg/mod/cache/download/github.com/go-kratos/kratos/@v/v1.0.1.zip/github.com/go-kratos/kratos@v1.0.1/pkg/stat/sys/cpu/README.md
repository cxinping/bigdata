## stat/sys

System Information

## 项目简介

获取Linux平台下的系统信息，包括cpu主频、cpu使用率等
