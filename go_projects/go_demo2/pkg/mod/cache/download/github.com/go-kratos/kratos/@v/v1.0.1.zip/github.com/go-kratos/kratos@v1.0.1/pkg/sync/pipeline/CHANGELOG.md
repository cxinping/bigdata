### pipeline

#### Version 1.2.0
> 1. 默认为平滑触发事件
> 2. 增加metric上报
#### Version 1.1.0
> 1. 增加平滑时间的支持
#### Version 1.0.0
> 1. 提供聚合方法 内部区分压测流量
