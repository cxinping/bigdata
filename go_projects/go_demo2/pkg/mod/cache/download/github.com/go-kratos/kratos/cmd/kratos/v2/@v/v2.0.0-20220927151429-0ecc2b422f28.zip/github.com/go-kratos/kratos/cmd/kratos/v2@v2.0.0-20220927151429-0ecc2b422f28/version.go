package main

// release is the current kratos tool version.
const release = "v2.5.0"
