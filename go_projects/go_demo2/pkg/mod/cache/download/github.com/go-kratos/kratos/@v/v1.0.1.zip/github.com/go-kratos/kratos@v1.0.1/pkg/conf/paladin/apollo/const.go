package apollo

const (
	// PaladinDriverApollo ...
	PaladinDriverApollo = "apollo"
)
