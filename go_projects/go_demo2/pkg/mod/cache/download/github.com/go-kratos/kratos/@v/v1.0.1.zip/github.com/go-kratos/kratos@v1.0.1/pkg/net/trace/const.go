package trace

// Trace key
const (
	KratosTraceID    = "kratos-trace-id"
	KratosTraceDebug = "kratos-trace-debug"
)
