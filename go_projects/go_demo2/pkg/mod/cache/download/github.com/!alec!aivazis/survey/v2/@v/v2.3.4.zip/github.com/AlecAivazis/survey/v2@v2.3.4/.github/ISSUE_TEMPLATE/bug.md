---
name: Bug report
about: Create a report to help us improve
title: ''
labels: 'Bug'
assignees: ''

---

**What operating system and terminal are you using?**

**An example that showcases the bug.**

**What did you expect to see?**

**What did you see instead?**
