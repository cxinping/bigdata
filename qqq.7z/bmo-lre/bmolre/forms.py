# -*- coding: utf-8 -*-

# flask-login
from flask_login import UserMixin
from werkzeug.security import generate_password_hash,check_password_hash

class LoginUser(UserMixin):
    def __init__(self, user):
        self.username = user.username
        self.password_hash = user.password
        self.id = user.id

    def verify_password(self, password):
        if self.password_hash is None:
            return False
        return check_password_hash(self.password_hash, password)

    def get_id(self):
        return self.id


from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField
from wtforms.validators import DataRequired,Length, EqualTo

# flask-wtf 登陆表单类
class LoginForm(FlaskForm):
    #用户名
    username = StringField('name',validators=[DataRequired(message="用户名不能为空")
        ,Length(1,5,message='长度位于1~5 之间')],render_kw={'placeholder':'输入用户名'})
    #密码
    password = PasswordField('password',validators=[DataRequired(message="密码不能为空")
        ,Length(1,5,message='长度位于1~5 之间')],render_kw={'placeholder':'输入密码'})

class SignupForm(FlaskForm):
    """用户注册表单类"""
    username = StringField('用户名', validators=[DataRequired()])
    password = PasswordField('密码', [
        DataRequired(),
        EqualTo('confirm', message='两次输入的密码不一致')
    ])
    confirm = PasswordField('确认密码')




