# -*- coding: utf-8 -*-

'''
Created on 2020-11-05

@author: Wang Shuo
'''


from werkzeug.security import generate_password_hash,check_password_hash
from datetime import datetime,timedelta
from bmolre.exts import db

# 定义用户-权限数据模型
user_role = db.Table(
    'sys_user_role',
    db.Column('user_id', db.Integer, db.ForeignKey('sys_user.id'), primary_key=True),
    db.Column('role_id', db.Integer, db.ForeignKey('sys_role.id'), primary_key=True)
)

# 定义用户数据模型
class User(db.Model):
       __tablename__='sys_user'

       id = db.Column(db.Integer, primary_key=True, autoincrement=True)
       username = db.Column(db.String(200),nullable=False,unique=True  )  # 用户名不能为空,而且必须是唯一的
       password = db.Column(db.String(100),nullable=False)               # 密码不能为空
       telephone = db.Column(db.String(20), nullable=True)
       email = db.Column(db.String(50), nullable=True)
       gender = db.Column(db.String(10), nullable=True)
       avator = db.Column(db.String(500), nullable=True)
       is_del = db.Column(db.Integer )
       remark = db.Column(db.String(500), nullable=True)
       create_by = db.Column(db.String(50), nullable=True)
       create_time = db.Column(db.DateTime ) # default=datetime.now
       update_by = db.Column(db.String(50), nullable=True)
       update_time = db.Column(db.DateTime ) # default=datetime.now
       roles = db.relationship('Role', backref='users', secondary=user_role)

       def __init__(self, username, password, create_time , update_time = datetime.now() , email='' ,telephone='', gender='', avator='' ,
                    is_del = '', remark = '', create_by='',
                    update_by = '' ):
         self.username = username
         self.password = generate_password_hash(password)
         self.telephone = telephone
         self.email = email
         self.gender = gender
         self.avator = avator
         self.is_del = is_del
         self.remark = remark
         self.create_by = create_by
         self.create_time = create_time
         self.update_by = update_by
         self.update_time = update_time

       def get_password(self):
         return self.password

       def set_password(self,raw_password):
         self.password = generate_password_hash(raw_password)#密码加密

       def check_password(self,raw_password):
         result=check_password_hash(self.password,raw_password)#
         return result

       def to_json(self):
           return {
               'id': self.id,
               'username': self.username,
               'password': self.password,
               'telephone': self.telephone,
               'email': self.email,
               'gender': self.gender,
               'avator': self.avator,
               'is_del': self.is_del,
               'remark': self.remark,
               'create_by': self.create_by,
               'create_time': self.create_time.strftime('%Y-%m-%d %H:%M:%S') if self.create_time !=None else '',
               'update_by': self.update_by,
               'update_time': self.update_time.strftime('%Y-%m-%d %H:%M:%S') if self.update_time !=None else '' ,
           }


# 定义权限数据模型
class Role(db.Model):
       __tablename__='sys_role'

       id = db.Column(db.Integer, primary_key=True, autoincrement=True)
       name = db.Column(db.String(200),nullable=False )
       remark = db.Column(db.String(500),nullable=True)
       role_sort = db.Column(db.Integer)
       is_del = db.Column(db.Integer, default = 0)
       create_by = db.Column(db.String(50), nullable=True)
       create_time = db.Column(db.DateTime )
       update_by = db.Column(db.String(50), nullable=True)
       update_time = db.Column(db.DateTime )

       def __init__(self, name, remark, create_time , update_time = datetime.now() , role_sort=0 ,is_del=0, create_by='',
                    update_by = '' ):
         self.name = name
         self.remark = remark
         self.role_sort = role_sort
         self.is_del = is_del
         self.create_by = create_by
         self.create_time = create_time
         self.update_by = update_by
         self.update_time = update_time

       def to_json(self):
           return {
               'id': self.id,
               'name': self.name,
               'remark': self.remark,
               'role_sort': self.role_sort,
               'is_del': self.is_del,
               'create_by': self.create_by,
               'create_time': self.create_time.strftime('%Y-%m-%d %H:%M:%S') if self.create_time !=None else '',
               'update_by': self.update_by,
               'update_time': self.update_time.strftime('%Y-%m-%d %H:%M:%S') if self.update_time !=None else '' ,
           }



