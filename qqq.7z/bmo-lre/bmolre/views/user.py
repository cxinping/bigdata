# -*- coding: utf-8 -*-

'''
Created on 2020-10-28

@author: WangShuo
'''

from flask import Blueprint
from flask import current_app as app
from flask import jsonify,render_template,session,redirect,url_for, request
from datetime import datetime,timedelta

from flask_jwt_extended import (
    JWTManager, jwt_required, create_access_token,get_jwt_identity
)
from flask_login import (
    current_user,logout_user, login_user, login_required
)

import bmolre.services as service
from bmolre.models import User,Role
from bmolre.forms import LoginForm, SignupForm, LoginUser
from bmolre.constant import ACCESS_TOKEN
from bmolre.exts import login_manager
from bmolre.exts import db


users_bp = Blueprint('users', __name__)


''' 定义路由 '''
@login_manager.user_loader  # 定义获取登录用户的方法
def load_user(user_id):
    if not user_id:
        return None
    user = service.query_user_by_id(user_id)
    if user is None:
        return None
    else:
        return LoginUser(user)

# http://127.0.0.1:5000/users/login
@users_bp.route('/login/', methods=('GET', 'POST'))
def login():
    print('--- login ------------')
    form = LoginForm()
    emsg = None

    if form.validate_on_submit():
        print('--- 111 --------')
        user_name = form.username.data
        password =  form.password.data
        user_info = service.query_user_by_username(user_name)

        if user_info is None:
            emsg = '没有此用户,请注册用户'
        else:
            loginUser = LoginUser(user_info)
            if loginUser.verify_password(password):
                login_user(loginUser)

                expires = timedelta(minutes=1 )
                access_token = create_access_token(user_name, expires_delta=expires)
                session[ACCESS_TOKEN] = access_token
                print('----------- access_toen ---------')
                print(access_token)

                return redirect(url_for('users.index'))
            else:
                emsg = "用户名或密码密码有误"
    else:
        print('--- other process ------------')
    return render_template('bmo_login.html', form=form, emsg=emsg)

#  退出
@users_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('users.login'))

# http://127.0.0.1:5000/users/signup
@users_bp.route('/signup', methods=('GET', 'POST'))
def signup():
    form = SignupForm()
    emsg = None
    if form.validate_on_submit():
        user_name = form.username.data
        password = form.password.data

        user_info = service.query_user_by_username(user_name)
        print('**** user_info=' , user_info, ',user_name=',user_name )

        if user_info is None:
            print('---- user_info is none ----')
            service.create_user(username=user_name,password=password)
            return redirect(url_for('users.login'))
        else:
            emsg ='用户名已存在,请重新注册'

    return render_template('bmo_signup.html',form=form,emsg=emsg)

# http://127.0.0.1:5000/users/index
# 首页,需要登录才能访问
@users_bp.route('/index')
@login_required
def index():
    return render_template('bmo_index.html', username=current_user.username)

# http://127.0.0.1:5000/users/pages
# 分页显示 用户列表
#@login_required
@users_bp.route('/pages', methods=['GET', 'POST'])
def user_pages():
    cur_page = request.args.get('cur_page',1 , type=int) #当前页
    per_page = request.args.get('per_page', 5, type=int) # 每页显示几条数据
    print('**** cur_page={},per_page={}'.format(cur_page, per_page))
    pagination = User.query.order_by(User.id.asc()).paginate(cur_page, per_page)
    users = pagination.items

    return jsonify(users)

# http://127.0.0.1:5000/users/test
@users_bp.route('/test')
@login_required
def test1():
    return render_template('bmo_index.html', username='aaa')

# http://127.0.0.1:5000/users/protected
@users_bp.route('/protected', methods=['GET', 'POST'])
@jwt_required
def protected():
    nowTime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return jsonify({'hello': 'world', 'nowTime': nowTime}), 200

# http://127.0.0.1:5000/users/session
@users_bp.route('/session')  # 首页
def get_session():
    access_token = session['access_token']
    return jsonify({'access_token' : access_token,}),202

# http://127.0.0.1:5000/users/test/app
@users_bp.route('/test/app', methods=['GET'])
def test_app_config():
    debug_status = app.config['DEBUG']
    return jsonify({'debug_status': debug_status}),201

# http://127.0.0.1:5000/users/get_time
@users_bp.route('/get_time', methods=['GET', 'POST'])
@login_required
def get_time():
    print('---  get_time ---')
    nowTime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return jsonify({'hello': 'world', 'nowTime': nowTime}), 200

# http://127.0.0.1:5000/users/hello/wang
@users_bp.route('/hello/<user>')
def hello_name(user):
   return render_template('bmo_hello.html', name = user)










