# -*- coding: utf-8 -*-

from flask import Blueprint
from datetime import datetime,timedelta

from bmolre.exts import db
from bmolre.models import User,Role
import bmolre.services as service
from bmolre.logging import log_entry_exit,get_logger

test_bp = Blueprint('test', __name__)

log = get_logger()


# http://127.0.01:5000/test/valid/input
@test_bp.route('/valid/input', methods=['GET'])
@log_entry_exit
def test_input():
    cur_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    tup1 = (1, 2)
    a = 1
    b = '  '
    c = None
    log.info("--- info message {}".format(cur_time))
    log.debug("--- debug message {}".format(cur_time))
    log.error("--- error message {}".format(cur_time))
    log.info(all([a, b, c]))

    return 'test_input ok '

# http://127.0.01:5000/test/create/user
@test_bp.route('/create/user', methods=['GET'])
def test_create_user():
    service.create_all_tables()

    username = 'tom'
    for i in range(5):

        user1 = User(username= username + str(i) , password='111', email='a@123.com', telephone='131211231', gender='male',
                     avator='c:/a.jpg',
                     is_del=1, remark='123456', create_by='wang', create_time=None,
                     update_by='li', update_time=datetime.now())
        service.create_user_model(user1)

    bmo_user = service.query_user_by_id(1)
    is_check = bmo_user.check_password('111')
    print('is_check=',is_check)

    return 'ok'

# http://127.0.01:5000/test/create/user_role
@test_bp.route('/create/user_role', methods=['GET'])
def test_create_user_role():
    service.create_all_tables()

    user1 = User(username='wangwu', password='111', email='wangwu@123.com', telephone='131211231', gender='male',
                 avator='c:/a.jpg',
                 is_del=1, remark='123456', create_by='wang', create_time=None,
                 update_by='li', update_time=datetime.now())
    user2 = User(username='lisi', password='111', email='lisi@123.com', telephone='131211231', gender='male',
                 avator='c:/a.jpg',
                 is_del=1, remark='123456', create_by='wang', create_time=None,
                 update_by='li', update_time=datetime.now())

    role1 = Role( name='add user', remark='1111', create_time=datetime.now(),
                  role_sort = 1, is_del = 0, create_by = 'aaa',  update_by = 'aaa' )
    role2 = Role( name='update user', remark='222222', create_time=datetime.now(),
                  role_sort = 2, is_del = 0, create_by = 'bbb',  update_by = 'bbb' )
    role3 = Role( name='delete user', remark='3333', create_time=datetime.now(),
                  role_sort = 3, is_del = 0, create_by = 'ccc',  update_by = 'ccc' )

    user1.roles.append(role1)
    user1.roles.append(role2)
    user1.roles.append(role3)

    user2.roles.append(role1)
    user2.roles.append(role2)

    db.session.add(user1)
    db.session.add(user2)
    db.session.commit()
    db.session.close()

    return 'ok'

# http://127.0.01:5000/test/user/query
@test_bp.route('/user/query', methods=['GET'])
def test_user_query():
    user = User.query.filter(User.id == 1 , User.username=='wangwu').first()
    print(user.to_json() )

    print('---- 查询单个角色')
    role = Role.query.filter(Role.id ==1).first()
    print(role.to_json())

    print('---- 查询拥有角色的多个用户')
    selUsers = role.users
    for selUser in selUsers:
        print(selUser.to_json() )

    return 'select ok'


# http://127.0.01:5000/test/user/del
@test_bp.route('/user/del', methods=['GET'])
def test_table4():
    #  删除user主键为1的用户
    #user = User.query.filter(User.id == 1, User.username == 'wangwu').first()
    #db.session.delete(user)

    #  删除主键为1的角色
    #role = Role.query.filter(Role.id == 1 ).first()
    #db.session.delete(role)

    Role.query.filter(Role.id == 2).update({"remark" : "abcdef"})

    db.session.commit()
    db.session.close()

    return 'delete ok'
