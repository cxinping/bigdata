# -*- coding: utf-8 -*-

'''
Created on 2020-10-28

@author: WangShuo
'''

import os
import datetime
import logging as python_logging
from flask import Flask
from .views.user import users_bp
from .views.test import test_bp
from http import HTTPStatus
from .constant import CFG_DEBUG
from .logging import get_logger, log_entry_exit

GUNICORN_ERROR_LOGGER_NAME = 'gunicorn.error'

def create_app(config_object=None, config_map=None):
    # Create and configure the app
    app = Flask(__name__)

    app.logger.debug('loggers=' + str(python_logging.Logger.manager.loggerDict))

    # Use gunicorn log handler if this application is initiated by gunicorn
    if GUNICORN_ERROR_LOGGER_NAME in python_logging.Logger.manager.loggerDict:
        gunicorn_logger = python_logging.getLogger(GUNICORN_ERROR_LOGGER_NAME)

        app.logger.debug('gunicorn_logger.level=' + str(gunicorn_logger.level))
        app.logger.debug('gunicorn_logger.handlers=' + str(gunicorn_logger.handlers))

        app.logger.handlers = gunicorn_logger.handlers
        app.logger.setLevel(gunicorn_logger.level)

    # configure blue print
    app.register_blueprint(users_bp, url_prefix='/users')
    app.register_blueprint(test_bp, url_prefix='/test')

    # Overwrite default config by input parameter
    app.config.from_object(config_object)

    if config_map is not None:
        # load the test config if passed in
        app.config.from_mapping(config_map)

    # Put debug flag into os environment for reference by logger, etc.
    os.environ[CFG_DEBUG] = str(app.config[CFG_DEBUG])

    # Create logger after app initiated to avoid recursive dependency
    app.logger.debug('** app.config=%s', app.config)
    app.logger.debug('** os.environ=%s', os.environ)

    # a simple page that says hello
    @app.route('/hello')
    def hello():
        return 'Hello, World!'

    return app
