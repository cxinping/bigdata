# -*- coding: utf-8 -*-

'''
Created on 2020-11-05

@author: Wang Shuo
'''


from datetime import datetime
from .models import User
from bmolre.exts import db


def create_all_tables():
    db.drop_all()
    db.create_all()

def query_user_by_id(id):
    return User.query.filter(User.id == id).first()

def query_user_by_username(username):
    return User.query.filter(User.username == username).first()

def create_user(username, password, create_time,update_time, email='' ,telephone='', gender='', avator='' ,
                    is_del = '', remark = '', create_by='',
                    update_by = '' ):
    user = User(username, password, email ,telephone, gender, avator ,
                    is_del , remark , create_by , create_time ,
                    update_by , update_time  )
    db.session.add(user)
    db.session.commit()
    db.session.close()

def create_user_model(user):
    db.session.add(user)
    db.session.commit()
    db.session.close()

def update_user(id, username, email='' ,telephone='', gender='', avator='' ,
                    is_del = '', remark = '', update_time=None,
                    update_by = '' ):
    user = query_user_by_id(id)
    user.email = email
    user.telephone = telephone
    user.gender = gender
    user.avator = avator
    user.remark = remark
    user.update_time = datetime.now()
    db.session.commit()
    db.session.close()

def del_user(id):
    user = User.query.filter(User.id == id).first()
    db.session.delete(user)
    db.session.commit()
    db.session.close()

