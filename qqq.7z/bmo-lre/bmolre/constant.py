# -*- coding: utf-8 -*-

'''
Created on 2020-11-06

@author: Wang Shuo
'''


# Configure debug flag
CFG_DEBUG = 'DEBUG'
# Jwt access token
ACCESS_TOKEN = 'access_token'

