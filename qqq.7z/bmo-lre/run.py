# -*- coding: utf-8 -*-
'''
Created on 2020-10-28

@author: WangShuo
'''

from bmolre import create_app
from bmolre.exts import db, jwt,login_manager

app = create_app(config_object='config.development')
#app = create_app(config_object='config.default')

db.init_app(app)
jwt.init_app(app)
login_manager.init_app(app)
login_manager.login_view = 'users.login'

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

