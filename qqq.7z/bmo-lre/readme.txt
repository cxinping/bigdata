需求
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:8443/secure/RapidBoard.jspa?rapidView=10062&projectKey=LRE&view=planning&selectedIssue=LRE-6&issueLimit=100

提交代码
http://10.119.61.92:7990/projects/LRE/repos/bmo-lre/browse
http://10.119.61.92:7990/projects/BMOSERV

查看当前任务
https://infrguawdvagi01.sacmcmqa.adrootqa.bmogc.net:8443/secure/RapidBoard.jspa?rapidView=10062&projectKey=LRE&view=planning&selectedIssue=LRE-6&issueLimit=100

BMOSXXX报表的文档
http://10.119.61.92:8090/display/KB/OTHER

README.md
> pip install cx_oracle
> https://pypi.org/project/cx-Oracle/5.1.3/#files
> https://cloud.tencent.com/developer/article/1661831
> https://blog.51cto.com/1767340368/2092439
>
>  pip install Flask-Mail



SELECT * FROM RRA_SIDS.s_gfi_cn_counterparty

BMOS0008涉及的6个SQL查询：
Query 1
SELECT
  Table__2.DATA_DATE,
  Table__2.LOCAL_BRANCH,
  Table__2.CUSTOMER_NO,
  LPAD(TRIM(Table__5.FIELD_VAL_52), 10, '0'),
  Table__9.IBUK_ID,
  Table__9.PIX_ID,
  Table__5.FIELD_VAL_39,
  Table__2.CHINESE_NAME,
  DECODE(LENGTH(Table__5.FIELD_VAL_16),18,Table__5.FIELD_VAL_16,null)
 ,
  Table__2.CUSTOMER_NAME1,
  Table__2.CUSTOMER_CATEGORY,
  Table__2.NATIONALITY,
  Table__2.COUNTRY,
  Table__2.EXPOSURE_COUNTRY,
  Table__5.FIELD_VAL_1,
  Table__5.FIELD_VAL_5,
  Table__5.FIELD_VAL_10,
  Table__5.FIELD_VAL_4,
  Table__5.FIELD_VAL_58,
  Table__2.UNIQUE_ID_VALUE,
  Table__7.GROUP_ID,
  Table__2.RECORD_STAT,
  decode(Table__2.DATA_DATE,null,'CMS','CMS')
FROM
  RRA_SIDS.S_FLC_STTM_CUSTOMER  Table__2,
  RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS  Table__5,
  RRA_SIDS.S_CBI_T_CMN_CUST_INF  Table__9,
  RRA_SIDS.S_FLC_STTM_CUST_GROUP  Table__7
WHERE
  ( Table__2.CUSTOMER_NO=SUBSTR(Table__5.REC_KEY(+), 1, 6)  )
  AND  ( Table__2.DATA_DATE=Table__5.DATA_DATE(+)  )
  AND  ( Table__2.CUSTOMER_NO=Table__7.CUSTOMER_NO(+)  )
  AND  ( Table__2.DATA_DATE=Table__7.DATA_DATE(+)  )
  AND  ( Table__2.CUSTOMER_NO=Table__9.CBS_ID(+)  )
  AND  ( Table__2.DATA_DATE=Table__9.DATA_DATE(+)  )
  AND  ( Table__5.FUNCTION_ID(+)='STDCIF'  )
  AND  ( Table__2.AUTH_STAT='A'  )
  AND  ( Table__2.RECORD_STAT  IN ('C','O')  )
  AND  ( Table__2.CUSTOMER_CATEGORY IN ('NBFI','BANK', 'INTERNAL', 'CORPORATE','INDIVIDUAL')  )
  AND
  Table__2.DATA_DATE  =  '20200630'

Query 2

(
SELECT
  RRA_SIDS.S_UEN_CHINA.CIF_NO,
  RRA_SIDS.S_UEN_CHINA.UEN_NO,
  RRA_SIDS.S_UEN_CHINA.DATA_DATE,
  max(RRA_SIDS.S_UEN_CHINA.DATA_DATE),
  Decode(RRA_SIDS.S_UEN_CHINA.SOURCE_SYSTEM_ID,0,3,3)
FROM
  RRA_SIDS.S_UEN_CHINA
WHERE
  RRA_SIDS.S_UEN_CHINA.DATA_DATE  IN  ('20200630')
GROUP BY
  RRA_SIDS.S_UEN_CHINA.CIF_NO,
  RRA_SIDS.S_UEN_CHINA.UEN_NO,
  RRA_SIDS.S_UEN_CHINA.DATA_DATE,
  Decode(RRA_SIDS.S_UEN_CHINA.SOURCE_SYSTEM_ID,0,3,3)
UNION
SELECT
  RRA_SIDS.S_UEN_NA.CIF_NO,
  RRA_SIDS.S_UEN_NA.UEN_NO,
  RRA_SIDS.S_UEN_NA.DATA_DATE,
  max(RRA_SIDS.S_UEN_NA.DATA_DATE),
  Decode(RRA_SIDS.S_UEN_NA.SOURCE_SYSTEM_ID,0,2,2)
FROM
  RRA_SIDS.S_UEN_NA
WHERE
  RRA_SIDS.S_UEN_NA.DATA_DATE  IN  ('20200630')
GROUP BY
  RRA_SIDS.S_UEN_NA.CIF_NO,
  RRA_SIDS.S_UEN_NA.UEN_NO,
  RRA_SIDS.S_UEN_NA.DATA_DATE,
  Decode(RRA_SIDS.S_UEN_NA.SOURCE_SYSTEM_ID,0,2,2)
UNION
SELECT
  LPAD(TRIM(RRA_SIDS.S_UEN_BRANCH.CIF_NO),10,0),
  RRA_SIDS.S_UEN_BRANCH.PARENT_UEN,
  RRA_SIDS.S_UEN_BRANCH.DATA_DATE,
  max(RRA_SIDS.S_UEN_BRANCH.DATA_DATE),
  decode(RRA_SIDS.S_UEN_BRANCH.SOURCE_SYSTEM_ID,0,1,1)
FROM
  RRA_SIDS.S_UEN_BRANCH
WHERE
  RRA_SIDS.S_UEN_BRANCH.DATA_DATE  IN  ('20200630')
GROUP BY
  LPAD(TRIM(RRA_SIDS.S_UEN_BRANCH.CIF_NO),10,0),
  RRA_SIDS.S_UEN_BRANCH.PARENT_UEN,
  RRA_SIDS.S_UEN_BRANCH.DATA_DATE,
  decode(RRA_SIDS.S_UEN_BRANCH.SOURCE_SYSTEM_ID,0,1,1)
)

Query 3

SELECT
  Table__7.GROUP_ID,
  Table__8.GROUP_NAME,
  Table__7.DATA_DATE,
  decode(Table__8.GROUP_NAME,null,null,null)
FROM
  RRA_SIDS.S_FLC_STTM_CUST_GROUP  Table__7,
  RRA_SIDS.S_FLC_STTM_GROUP  Table__8
WHERE
  ( Table__7.GROUP_ID=Table__8.GROUP_ID(+)  )
  AND  ( Table__7.DATA_DATE=Table__8.DATA_DATE(+)  )
  AND
  Table__7.DATA_DATE  =  '20200630'

Query 4

SELECT
  Table__5.DATA_DATE,
  SUBSTR(Table__5.REC_KEY, 1, 6),
  LPAD(TRIM(Table__5.FIELD_VAL_52), 10, '0'),
  nvl(Table__3.RRA_CODE,'100000'),
  nvl(Table__4.RRA_CODE,'200000'),
  Table__6.BUSINESS_LIC
FROM
  RRA_SIDS.S_FLC_CSTM_FUNC_UDF_FIELDS  Table__5,
  RRA_SIDS.MAP_S_G_CODE  Table__3,
  RRA_SIDS.MAP_S_G_CODE  Table__4,
  RRA_SIDS.S_CMCIF_CUST_INFO  Table__6
WHERE
  ( Table__5.FIELD_VAL_2=Table__3.SOURCE_CODE(+)  )
  AND  ( Table__5.FIELD_VAL_7=Table__4.SOURCE_DESCRIPTION_CN(+)  )
  AND  ( LPAD(TRIM(Table__5.FIELD_VAL_52), 10, '0')=LPAD(TRIM(Table__6.CIF_ID(+)), 10, '0')  )
  AND  ( Table__3.TYPE_CODE(+)='FINA_CODE'  )
  AND  ( Table__4.TYPE_CODE(+)='FINA_CODE'  )
  AND  ( Table__5.FUNCTION_ID(+)='STDCIF'  )
  AND  ( length(Table__6.BUSINESS_LIC(+))=18  )
  AND
  (
   Table__5.DATA_DATE  =  '20200630'
   AND
   Table__6.DATA_DATE  IN  ('20200630')
  )

Query 5


SELECT
  max(RRA_SIDS.S_UEN_CHINA.DATA_DATE)
FROM
  RRA_SIDS.S_UEN_CHINA
WHERE
  RRA_SIDS.S_UEN_CHINA.DATA_DATE  <=  '20200630'

Query 6

SELECT
  max(Table__6.DATA_DATE
)
FROM
  RRA_SIDS.S_CMCIF_CUST_INFO  Table__6
WHERE
  ( length(Table__6.BUSINESS_LIC(+))=18  )
  AND
  Table__6.DATA_DATE  <=  '20200630'

