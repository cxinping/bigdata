# -*- coding: utf-8 -*-

import unittest
from bmolre import create_app

class TestBmoLre(unittest.TestCase):
    def setUp(self):
        app = create_app(config_object='config.default',config_map={'TESTING': True})
        self.client = app.test_client()
        self.app = app

    def tearDown(self):
        pass

    def test_hello(self):
        rv = self.client.get('/hello')
        assert b'Hello, World' in rv.data

    def test_app_is_Production(self):
        self.assertTrue(self.app.config['DEBUG'] is False)




if __name__ == "__main__":
    unittest.main(verbosity=2)
