# Prerequisites
## Dependencies of runtime
* python3-3.6.8-17.el7.x86_64
* Flask 1.1.2
* Flask-SQLAlchemy 2.4.4
* psycopg2  2.8.6
* flask-jwt-extended 3.24.1
* Flask-Login 0.5.0
* openpyxl 3.0.5
* Flask-Mail 0.9.1




